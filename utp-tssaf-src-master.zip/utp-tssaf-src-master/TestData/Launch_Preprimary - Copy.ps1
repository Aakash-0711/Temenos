function Reg_cob([String]$clseq, [String]$coindex)
{
   # write-output "In the function Reg_cob with the parameter passed : last sequence value : "$LastSequence
   # write-output "In the function Reg_cob with the parameter passed : current index value : "$orgindex



    if ( $LastSequence -ne "TB00" )
    {
          if ( $LastSequence -eq "SETUP" -and $LastSequence.Contains("NS") )
           {
           }
           else
           {
            <# Stop Jboss Application Server #>
            write-output "Stoping JBoss Application Server"
            $logdata = " - Stoping JBoss Application Server"
            tRun AR.UpdateRlog $logdata
            cd $env:PP_HOME
            Start-Process -FilePath .\WJbossStop.vbs
            Start-Sleep -s 5

            write-output "Stoping ActiveMQ"
			Start-Process -FilePath .\MQStop.vbs

            <# Stop H2 Database #>
            $logdata = " - Stoping H2 Database"
            tRun AR.UpdateRlog $logdata
            write-output "Stoping H2 Database"
            cd $env:PP_HOME
            Start-Process -FilePath .\WStopH2.vbs
            Start-Sleep -s 3

		# Taking before COB backup from TB01 to TB06
        Write-host "Taking backup of Database for Run Sequence-"$COBSeq
        cd $env:PP_HOME
        $var1 = "Seq$COBSeq"
        Start-Process -FilePath .\BackupRunner.vbs $var1
        Start-Sleep -s 20
        $script:COBSeq++
            Write-host "Value of COBSEQ after incrementing is "$COBSeq
            }
        cd $env:PP_HOME
        Start-Process -FilePath .\WStartH2.vbs
		Start-Sleep -s 10
        #$logdata = " - Backup Completed"
        #tRun AR.UpdateRlog $logdata
         DBTools -s -u t24user -p Temenos_123 JQL CLEAR-FILE F.RECORD.LOCK
		 DBTools -s -u t24user -p Temenos_123 JQL CLEAR-FILE F.TSA.STATUS
        <#tRun AR.StartJBoss#>
		write-output "Starting JBoss Application Server"
		$logdata = " - Starting JBoss"
        tRun AR.UpdateRlog $logdata
		cd $env:PP_HOME
		Start-Process -FilePath .\WJbossStart.vbs

		cd $env:PP_HOME
		Start-Process -FilePath .\MQStart.vbs
				$deployedfile = test-path $txtfilepath
			if ($deployedfile -eq $true){
			Remove-Item $txtfilepath
			}
				$notdeployedfile = test-path $jbossfailed
			if ($notdeployedfile -eq $true){
			Remove-Item $jbossfailed
			}
		Start-Sleep -s 2
		$TimeStart = Get-Date
		$TimeEnd = $timeStart.addminutes(4)
		Do {
		$TimeNow = Get-Date
		$testpathn = test-path $txtfilepath
		$testfailure = test-path $jbossfailed
		if ($testpathn -eq $true) {
		Write-host "Jboss Deployment successful"
		$jbosscheck = "success"
		break
		}
		ElseIf($testfailure -eq $true){
		$jbosscheck = "fail"
		break
		}
		Else{
		$jbosscheck = ""
		}
		Start-Sleep -Seconds 10
		}
		Until ($TimeNow -ge $TimeEnd)

		if($jbosscheck -eq "success"){
		Write-Host "Jboss TAFJJEE_EAR.ear deployment is Successful"

		$logdata = " - JBoss deployment successful"
        tRun AR.UpdateRlog $logdata

		}
		else{
		 $logdata = " - JBoss TAFJJEE_EAR.ear file Deployment is unsuccessful/Unavailable. Terminating the SEAT Regression"
            tRun AR.UpdateRlog $logdata
        Write-Host "JBoss TAFJJEE_EAR.ear file Deployment is unsuccessful/Unavailable. Please check the JBoss server logs for more information."
        $logdata = " - Stopping JBoss Application Server"
            tRun AR.UpdateRlog $logdata
            Write-Host "Stopping JBoss Application Server"
            cd $env:PP_HOME
            Start-Process -FilePath .\WJbossStop.vbs
            $logdata = " - Stoping H2 Database"

            write-output "Stoping ActiveMQ"
			Start-Process -FilePath .\MQStop.vbs
            $logdata = " - Stoping ActiveMQ"

            tRun AR.UpdateRlog $logdata
            Write-Host "Stoping H2 Database"
            cd $env:PP_HOME
            Start-Process -FilePath .\WStopH2.vbs
            $logdata = " - Stoping Code coverage receiver"
            tRun AR.UpdateRlog $logdata
            Write-Host "Stoping Code coverage receiver"
            cd $env:PP_HOME
            Start-Process -FilePath .\CCStop.vbs
        Exit
		}


		$logdata = " - Starting Service"
        tRun AR.UpdateRlog $logdata
        tRun AR.StartService TSM
		$logdata = " - Service Started"
		tRun AR.UpdateRlog $logdata
		$logdata = " - Starting LaunchServices"
		tRun AR.UpdateRlog $logdata
        <#tRun AR.LaunchServices#>
		Start-Process -FilePath .\WLaunchService.vbs
		$logdata = " - LaunchServices Completed"
		tRun AR.UpdateRlog $logdata
    }
   <#if( $ScriptGroups -ne $null -and $SEQBuild -eq "PREPRODTEST" )
    {
        write-output "Build Tpr Files"
       <tRun AR.PPBuildTprFiles $ScriptGroups>
	   Clear-variable -Name ScriptGroups
    } Not Required now. Build Tpr files will be done as initial step #>
<#Before COB Service start calling FixEODerros#>
    write-output "Calling FixEODerros Before COB"
    tRun AR.FixEODerrors
    write-output "Starting Cob Service"
    tRun AR.StartService $index
}

function Reg_NS_Injection([String]$nlseq, [String]$noindex)
{
    #write-output "In the function Reg_NS_Injection with the parameter passed : last sequence value : "$LastSequence
    #write-output "In the function Reg_NS_Injection with the parameter passed : current index value : "$orgindex

    <# Injection Process #>
    $NSInject = $orgindex.split("-")[0]
    $DateCheck = $orgindex.split("-")[2]
    $NSInject += "-NS"
    write-output "Injecting Scripts "$NSInject
	$logdata = " - Injecting Scripts"
	tRun AR.UpdateRlog $logdata
    <#tRun AR.ScriptInject $NSInject $SortOption#>
	#Start-Process -FilePath .\WScriptInject.bat -ArgumentList "$NSInject $SortOption"
	Start-Process -FilePath .\WScriptInjectStart.vbs $NSInject,$SortOption
	tRun AR.ScriptInjectCheck $NSInject
    <# Check If COB is Still running ?#>
    write-output "Cob Check $DateCheck"
    tRun AR.CobcheckProcess $DateCheck $LastSequence
    write-output "Job Time Analysis"
    tRun JT.ANALYSE.REG $LastSequence

    $NSInject = $orgindex.split("-")[0]

        $logdata = " - Service Check Start Time"
        tRun AR.UpdateRlog $logdata
    <# Stop Services #>
        write-output "Stoping Services"
        tRun AR.StopService TSM
        $logdata = " - Service Check End Time"
        tRun AR.UpdateRlog $logdata
    <# Stop Jboss Application Server #>
        write-output "Stoping JBoss Application Server"
        cd $env:PP_HOME
        Start-Process -FilePath .\WJbossStop.vbs
		$logdata = " - JBoss Stopped"

		write-output "Stoping ActiveMQ"
		Start-Process -FilePath .\MQStop.vbs
        $logdata = " - Stoping ActiveMQ"

		tRun AR.UpdateRlog $logdata
    <# Clear F.RECORD.LOCK just incase if T24 Didnot cleanup #>
        write-output "Clearing F.RECORD.LOCK file"
        DBTools -s -u t24user -p Temenos_123 JQL CLEAR-FILE F.RECORD.LOCK
    <# Stop H2 Database #>
        write-output "Stoping H2 Database"
        cd $env:PP_HOME
        Start-Process -FilePath .\WStopH2.vbs
		Start-Sleep -s 3

		if ($NSInject.Contains("TB00")){
		Write-host "Taking backup of after COB Database for TB00"
        cd $env:PP_HOME
        $var1 = "Seq0"
        Start-Process -FilePath .\BackupRunner.vbs $var1
        Start-Sleep -s 20
		}
		#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Add condition if ns inject is TB00 Take backup
    <# Stop the LockManager
        #write-output "Stoping the LockManager"
        #cd $env:PP_HOME
        #Start-Process -FilePath .\WKilllockmanager.vbs
        #$logdata = " - Taking Backup"
        #tRun AR.UpdateRlog $logdata
    <# Database Backup Activity
        write-output "Taking Database Backup from "$env:PP_HOME
        $BackupGroup = $NSInject
        $BackupGroup += "_COB"
        $temp = Get-Date -format "yyyyMMdd"
        $Backupname = $temp
        $Backupname += "_"
        $Backupname += $BackupGroup
        cd $env:PP_HOME
        $temp = Get-Date -format "yyyyMMdd"
    <#    gtar -cvf - DEV.h2.db | gzip -> DEV_TB02_$1_$Backupname.tar.gz
    <# Start H2 Database
        write-output "Starting Database"
        cd $env:PP_HOME
        Start-Process -FilePath .\WStartH2.bat
        Start-Sleep -s 10
        $logdata = " - Backup Completed"
        tRun AR.UpdateRlog $logdata
        write-output "Stoping H2 Database"
        cd $env:PP_HOME
        Start-Process -FilePath .\WStopH2.vbs #>
		#$GetSeq=$NSInject.Substring($NSInject.Length - 2)
		#Start-Job -Name CallErrorRoutine -ScriptBlock {tRun GET.REGRESSION.ERROR $GetSeq}
}

function Reg_Setup([String]$nlseq, [String]$noindex)
{
    #write-output "In the function Reg_NS_Injection with the parameter passed : last sequence value : "$LastSequence
    #write-output "In the function Reg_NS_Injection with the parameter passed : current index value : "$orgindex

             <# Start H2 Database #>
            write-output "Starting Database"
            cd $env:PP_HOME
            Start-Process -FilePath .\WStartH2.vbs
			Start-Sleep -s 10

			<# Start ActiveMQ #>
            write-output "Starting ActiveMQ"
            cd $env:PP_HOME
            Start-Process -FilePath .\MQStart.vbs
			Start-Sleep -s 10

            cd $env:PP_HOME
		    Start-Process -FilePath .\usercreation.vbs
		    $logdata = " - DBTools User created"
            tRun AR.UpdateRlog $logdata
            write-output " DBTools user created successfully"

			if ( $SEQBuild -eq "UPLDSEQBLD" )
            {
              tRun CHANGE.SPF.OS $OSType
              write-output "Starting Script Review"
               tRun REG.CLEAR.TXN.IN.RESULT
              write-output "Build Tpr Files & Upload Sequence"
              tRun AR.PPBuildTprFiles $ScriptGroups
              Clear-variable -Name ScriptGroups
DBCheck
              $filecheck = test-path $dbcheckpath
              if ($filecheck -eq $true)
              {
              Write-Host "Databae is unsuitable for this Pre-primary regression. Please use proper DB"
              }
            }
			else
			{
			write-output "Starting Code coverage receiver"
			cd $env:PP_HOME
            Start-Process -FilePath .\CCStart.vbs
            Start-Sleep -s 4

    		 #write-output "Clearing TXN ID and TXN COMPANY in RF"
			 #tRun REG.CLEAR.TXN.IN.RESULT
			 #$logdata = " - Clearing TXN ID and TXN COMPANY in RF"
		    # tRun AR.UpdateRlog $logdata

             write-output "Set the number of agents for COB-1"
             tRun REG.TSA.PROF.FOR.COB
             $logdata = " - Set the number of agents for COB-1"
             tRun AR.UpdateRlog $logdata

             write-output "Convert the special character in msgin scripts"
             tRun REG.CHANGE.MSG.IN
             $logdata = " - Convert the special character in msgin scripts"
             tRun AR.UpdateRlog $logdata

             write-output "Stop the Services that are set AUTO or START"
             tRun REG.TSA.SERVICES
             $logdata = " - Stop the Services that are set AUTO or START"
             tRun AR.UpdateRlog $logdata
		    }
    <# Stop H2 Database #>
        write-output "Stoping H2 Database"
		    $logdata = " - Stoping H2 Database"
            tRun AR.UpdateRlog $logdata
            cd $env:PP_HOME
            Start-Process -FilePath .\WStopH2.vbs
            Start-Sleep -s 3
}

function Reg_Reports([String]$nlseq, [String]$noindex)
{
    #write-output "In the function Reg_NS_Injection with the parameter passed : last sequence value : "$LastSequence
    #write-output "In the function Reg_NS_Injection with the parameter passed : current index value : "$orgindex
    $rptname = "Report_{0}" -f (get-date).ToString("yyyy-MM-dd-hh-mm-ss")
    $dirName = "$env:UTP_HOME\TAFJ\CodeCoverageReport\$rptname"
    "$rptname" | out-file -encoding ASCII -filepath "$env:PP_HOME\codefile.txt"
        # Create dir if needed
        if(-not (test-path $dirName)) {
        md $dirName | out-null
        }
CCGen
        <# Start H2 Database #>
        write-output "Starting Database"
        cd $env:PP_HOME
        Start-Process -FilePath .\WStartH2.vbs
		Start-Sleep -s 10

		write-output "Generating Error Report"
		tRun GET.REGRESSION.ERROR
		write-output "Generating Execution Time"
		tRun GET.TIME.FROM.RLOG
		$logdata = " - Reports generated successfully"
		tRun AR.UpdateRlog $logdata
		write-output "Generating code coverage report"
		cd $env:PP_HOME
		#set-variable -name DateVal -value (Get-Date -Format s)

    <# Stop H2 Database #>
        write-output "Stoping H2 Database"
        cd $env:PP_HOME
        Start-Process -FilePath .\WStopH2.vbs
        Start-Sleep -s 3
}

function Reg_injection([String]$ilseq, [String]$ioindex)
{
    #write-output "In the function Reg_injection with the parameter passed : last sequence value : "$LastSequence
    #write-output "In the function Reg_injection with the parameter passed : current index value : "$orgindex
    $Inject = $orgindex

    if ( !$LastSequence )
    {
        <# Start H2 Database#>
        write-output "Starting Database"
        cd $env:PP_HOME
        Start-Process -FilePath .\WStartH2.vbs
        <# Start Jboss Application Server #>
		Start-Sleep -s 10
        write-output "Starting JBoss Application Server"
        <#tRun AR.StartJBoss#>
		$logdata = " - Starting JBoss Application Server"
		tRun AR.UpdateRlog $logdata
		Start-Process -FilePath .\WJbossStart.vbs

		write-output "Starting ActiveMQ"
		Start-Process -FilePath .\MQStart.vbs

			$deployedfile = test-path $txtfilepath
			if ($deployedfile -eq $true){
			Remove-Item $txtfilepath
			}
			$notdeployedfile = test-path $jbossfailed
			if ($notdeployedfile -eq $true){
			Remove-Item $jbossfailed
			}

		Start-Sleep -s 2
		$TimeStart = Get-Date
		$TimeEnd = $timeStart.addminutes(4)
		Do {
		$TimeNow = Get-Date
		$testpath = test-path $txtfilepath
		$testfailure = test-path $jbossfailed
		if ($testpath -eq $true) {
		Write-host "Jboss Deployment successful"
		$jbosscheck = "success"
		break
		}
		ElseIf($testfailure -eq $true){
		$jbosscheck = "fail"
		break
		}
		Else{
		$jbosscheck = ""
		}
		Start-Sleep -Seconds 10
		}
		Until ($TimeNow -ge $TimeEnd)

		if($jbosscheck -eq "success"){
		Write-Host "Jboss TAFJJEE_EAR.ear deployment is Successful"

		$logdata = " - JBoss deployment successful"
        tRun AR.UpdateRlog $logdata
		}
		else{
		 $logdata = " - JBoss TAFJJEE_EAR.ear file Deployment is unsuccessful/Unavailable. Terminating the SEAT Regression"
            tRun AR.UpdateRlog $logdata
        Write-Host "JBoss TAFJJEE_EAR.ear file Deployment is unsuccessful/Unavailable. Please check the JBoss server logs for more information."
        $logdata = " - Stopping JBoss Application Server"
            tRun AR.UpdateRlog $logdata
            Write-Host "Stopping JBoss Application Server"
            cd $env:PP_HOME
            Start-Process -FilePath .\WJbossStop.vbs
            $logdata = " - Stoping H2 Database"

            write-output "Stoping ActiveMQ"
			Start-Process -FilePath .\MQStop.vbs
            $logdata = " - Stoping ActiveMQ"

            tRun AR.UpdateRlog $logdata
            Write-Host "Stoping H2 Database"
            cd $env:PP_HOME
            Start-Process -FilePath .\WStopH2.vbs
            $logdata = " - Stoping Code coverage receiver"
            tRun AR.UpdateRlog $logdata
            Write-Host "Stoping Code coverage receiver"
            cd $env:PP_HOME
            Start-Process -FilePath .\CCStop.vbs
        Exit
		}

        cd $env:PP_HOME
		Start-Process -FilePath .\usercreation.vbs
		$logdata = " - DBTools User created"
        tRun AR.UpdateRlog $logdata
        write-output " DBTools user created successfully"
		DBTools -s -u t24user -p Temenos_123 JQL CLEAR-FILE F.RECORD.LOCK
    	DBTools -s -u t24user -p Temenos_123 JQL CLEAR-FILE F.TSA.STATUS
        <# Start Services and execute START.TSM #>
        write-output "Starting Services"
		$logdata = " - Starting Services"
		tRun AR.UpdateRlog $logdata
        tRun AR.StartService TSM
        <# Launch TSA Services #>
        write-output "Launch TSA Services"
		$logdata = " - Launch TSA Services"
		tRun AR.UpdateRlog $logdata
        <#tRun AR.LaunchServices#>
		Start-Process -FilePath .\WLaunchService.vbs
		$logdata = " - LaunchServices Completed"
		tRun AR.UpdateRlog $logdata
        <# tRun AR.UpdateActService to update the SEAT.PARAMETER #>
        tRun AR.UpdateActService
    }
    else
    {
        <# Changes made for execution as per uploade sequence changed #>
        if ( $LastSequence.Contains("SETUP") -or $LastSequence.Contains("NS") )
        {
            <# Start H2 Database #>
            write-output "Starting Database"
            cd $env:PP_HOME
            Start-Process -FilePath .\WStartH2.vbs
			if ( $LastSequence.Contains("NS") )
			{
			Get-ChildItem "$env:T24_HOME\&SAVEDLISTS&" -Recurse -Force -Filter SCRPT* | Where-Object {!$_.PSIsContainer} | Remove-Item
            #$GetSeq  = $LastSequence.Substring(2,2)
             #Write-Output $GetSeq
             #tRun REG.SET.UPLOAD.SEQUENCE $GetSeq
             #Start-Job -ScriptBlock {tRun GET.REGRESSION.ERROR}
   		     }
            <# Start Jboss Application Server #>
			Start-Sleep -s 10
            write-output "Starting JBoss Application Server"
            <#tRun AR.StartJBoss#>
			$logdata = " - Starting JBoss Application Server"
		    tRun AR.UpdateRlog $logdata
			Start-Process -FilePath .\WJbossStart.vbs

			write-output "Starting ActiveMQ"
			Start-Process -FilePath .\MQStart.vbs

				$deployedfile = test-path $txtfilepath
			if ($deployedfile -eq $true){
			Remove-Item $txtfilepath
			}
				$notdeployedfile = test-path $jbossfailed
			if ($notdeployedfile -eq $true){
			Remove-Item $jbossfailed
			}

		Start-Sleep -s 2
		$TimeStart = Get-Date
		$TimeEnd = $timeStart.addminutes(4)
		Do {
		$TimeNow = Get-Date
		$testpath = test-path $txtfilepath
		$testfailure = test-path $jbossfailed
		if ($testpath -eq $true) {
		Write-host "Jboss Deployment successful"
		$jbosscheck = "success"
		break
		}
		ElseIf($testfailure -eq $true){
		$jbosscheck = "fail"
		break
		}
		Else{
		$jbosscheck = ""
		}
		Start-Sleep -Seconds 10
		}
		Until ($TimeNow -ge $TimeEnd)

		if($jbosscheck -eq "success"){
		Write-Host "Jboss TAFJJEE_EAR.ear deployment is Successful"

		$logdata = " - JBoss deployment successful"
        tRun AR.UpdateRlog $logdata

		}
		else{
		 $logdata = " - JBoss TAFJJEE_EAR.ear file Deployment is unsuccessful/Unavailable. Terminating the SEAT Regression"
            tRun AR.UpdateRlog $logdata
        Write-Host "JBoss TAFJJEE_EAR.ear file Deployment is unsuccessful/Unavailable. Please check the JBoss server logs for more information."
        $logdata = " - Stopping JBoss Application Server"
            tRun AR.UpdateRlog $logdata
            Write-Host "Stopping JBoss Application Server"
            cd $env:PP_HOME
            Start-Process -FilePath .\WJbossStop.vbs
            $logdata = " - Stoping H2 Database"
            write-output "Stoping ActiveMQ"
			Start-Process -FilePath .\MQStop.vbs

            tRun AR.UpdateRlog $logdata
            Write-Host "Stoping H2 Database"
            cd $env:PP_HOME
            Start-Process -FilePath .\WStopH2.vbs
            $logdata = " - Stoping Code coverage receiver"
            tRun AR.UpdateRlog $logdata
            Write-Host "Stoping Code coverage receiver"
            cd $env:PP_HOME
            Start-Process -FilePath .\CCStop.vbs
        Exit
		}

			$logdata = " - Clearing F.TSA.STATUS"
		    tRun AR.UpdateRlog $logdata
			DBTools -s -u t24user -p Temenos_123 JQL CLEAR-FILE F.RECORD.LOCK
    		DBTools -s -u t24user -p Temenos_123 JQL CLEAR-FILE F.TSA.STATUS
            <# Start Services and execute START.TSM #>
            write-output "Starting Services"
            tRun AR.StartService TSM
            <# Launch TSA Services #>
            write-output "Launch TSA Services"
            <#tRun AR.LaunchServices#>
		    Start-Process -FilePath .\WLaunchService.vbs
		    $logdata = " - LaunchServices Completed"
		    tRun AR.UpdateRlog $logdata
        }
    }
    <#if ( $ScriptGroups -ne $null -and $SEQBuild -eq "PREPRODTEST" )
    {
        write-output "Build Tpr Files"
        tRun AR.PPBuildTprFiles $ScriptGroups
        Clear-variable -Name ScriptGroups
    } Not Required now. Build Tpr files will be done as initial step#>

    $Inject = $orgindex.split("-")[1]
    <# Check if we are in END group to populate NS verification#>
    if ( $Inject -eq "END" -or $orgindex.Contains("TB06-USEREXITS") )
    {
        $var = $orgindex.split("-")[0]
        $Inject = $orgindex
        write-output "Injecting Scripts "$Inject
        <#tRun AR.ScriptInject $Inject $SortOption#>
		#Start-Process -FilePath .\WScriptInject.bat -ArgumentList "$Inject $SortOption"
		Start-Process -FilePath .\WScriptInjectStart.vbs $Inject,$SortOption
		tRun AR.ScriptInjectCheck $Inject
        $logdata = " - Service Check Start Time"
        tRun AR.UpdateRlog $logdata
        <# Stop Services #>
        write-output "Start Seat Service - at the END stages"
        tRun AR.StartService $SeatService
        write-output "Checking Activation Services"
        tRun AR.CheckActService
        write-output "Checking JOB.LIST before TSM stop"
        tRun AR.CheckJobList
		write-output "Checking Activation Services and JOB.LIST before TSM stop"
        tRun AR.CheckServices $index
        write-output "Checking Activation Services and JOB.LIST before TSM stop"
       tRun AR.CheckServices $SeatService

        if ( !$orgindex.Contains("TB06-END") )
        {
            write-output "Stoping Services"
            $logdata = " - Stoping Services"
            tRun AR.UpdateRlog $logdata
            tRun AR.StopService TSM
            $logdata = " - Service Check End Time"
            tRun AR.UpdateRlog $logdata
            <# Stop Jboss Application Server #>
            <#write-output "Stoping JBoss Application Server"
            $logdata = " - Stoping JBoss Application Server"
            tRun AR.UpdateRlog $logdata
            cd $env:PP_HOME
            Start-Process -FilePath .\WJbossStop.vbs
            Start-Sleep -s 10

            write-output "Stoping ActiveMQ"
			Start-Process -FilePath .\MQStop.vbs
			Start-Sleep -s 5

            <# Stop H2 Database #>
            <#$logdata = " - Stoping H2 Database"
            tRun AR.UpdateRlog $logdata
            write-output "Stoping H2 Database"
            cd $env:PP_HOME
            Start-Process -FilePath .\WStopH2.vbs
            Start-Sleep -s 3 #>

            #write-output "Stoping the LockManager"
            #cd $env:PP_HOME
            #Start-Process -FilePath .\WKilllockmanager.bat
            <# $logdata = " - Taking Backup"
            tRun AR.UpdateRlog $logdata
            Database Backup Activity
            write-output "Taking Database Backup from "$env:PP_HOME
            $BackupGroup = $var
            $temp = Get-Date -format "yyyyMMdd"
            $Backupname += $temp
            $Backupname += "_"
            $Backupname += $BackupGroup
            cd $env:PP_HOME
            $temp = Get-Date -format "yyyyMMdd"
            gtar -cvf - DEV.h2.db | gzip -> DEV_TB02_$1_$Backupname.tar.gz #>
        }
        else
        {
            $logdata = " - Service Check End Time"
            tRun AR.UpdateRlog $logdata
        }
    }

    else
    {
        <# Script Verification
        #      write-output "Verifying Script group $index"
        #      tRun AR.ScriptProcess $index
        # AR.PPBuildTprFiles will take care of the tpr building process
        # Process script injection in a loop #>
        $Inject = $orgindex
        write-output "Injecting Scripts "$Inject
        <#tRun AR.ScriptInject $Inject $SortOption#>
		#Start-Process -FilePath .\WScriptInject.bat -ArgumentList "$Inject $SortOption"
		Start-Process -FilePath .\WScriptInjectStart.vbs $Inject,$SortOption
		tRun AR.ScriptInjectCheck $Inject
        $logdata = " - Service Check Start Time"
        tRun AR.UpdateRlog $logdata
        if ( $Inject -ne "TB00"  -and  !$orgindex.Contains("TB01-COMP") )
        {
            <# Check Activation services before starting next script injection
            # Stop Services #>
            write-output "Start Seat Service - for all other Script Groups"
            tRun AR.StartService $SeatService
			sleep 5
            write-output "Checking Activation Services"
            tRun AR.CheckActService
            write-output "Checking JOB.LIST before TSM stop"
            tRun AR.CheckJobList
			write-output "Checking Activation Services and JOB.LIST before TSM stop"
           tRun AR.CheckServices $index
           write-output "Checking Activation Services and JOB.LIST before TSM stop"
           tRun AR.CheckServices $SeatService
        }
        $logdata = " - Service Check End Time"
        tRun AR.UpdateRlog $logdata
    }

}

<#Environmental Varibale#>

set-executionpolicy unrestricted -force

$env:TAFJDIR = "TAFJ"
$env:H2DIR = "db\h2"
$env:JBOSSDIR = "jboss"
$env:UTP_HOME ="D:\UTP-DEV-2017.11.05-02-790-saf-retailsuite-developer-s08\Temenos"
$env:BRP_HOME = "$env:UTP_HOME\BRP"
$env:LOG_HOME = "$env:UTP_HOME\logs"
$env:GENERATED = "$env:BRP_HOME\generated"
$env:MANUAL = "$env:BRP_HOME\manual"
$env:GENERATED_TCIB = "$env:UTP_HOME\Channels_Generated"

$env:PP_HOME = "$env:UTP_HOME\db\h2\PPServices"
$env:H2_HOME = "$env:UTP_HOME\$env:H2DIR"
$env:TAFJ_HOME = "$env:UTP_HOME\$env:TAFJDIR"
$env:PATH += ";$env:TAFJ_HOME\bin"
$env:JBOSS_HOME = "$env:UTP_HOME\$env:JBOSSDIR"
$env:T24_HOME = "$env:UTP_HOME\t24home\default"
$env:JAVA_HOME = "$env:UTP_HOME\java\jdk"

$ScriptGroups = ""
$SeatService = "BNK/SEAT.CHECK.RESULTS.COB"
$SortOption = "DSND"
$OSType = "NT"
$global:ScriptGroups

$txtfilepath = "$env:JBOSS_HOME\standalone\deployments\TAFJJEE_EAR.ear.deployed"
$txtfilepath1 = "$env:JBOSS_HOME\standalone\deployments\TAFJJEE_EAR.ear.isdeploying"
$jbossfailed = "$env:JBOSS_HOME\standalone\deployments\TAFJJEE_EAR.ear.failed"
$testpath = test-path $txtfilepath
$testpath1 = test-path $txtfilepath1
$jbosscheck = ""
$SEQBuild = $args
$COBSeq = 1
Get-Content D:\UTP-DEV-2017.11.05-02-790-saf-retailsuite-developer-s08\Temenos\AR_UploadSequence_Preprimary|ForEach-Object {
    $orgindex = $_
    $index = $_.split("-")[1]
    if ( $index -eq "NS" )
    {
        $NsGroup = $_.split("-")[0]
        $NsGroup += "-"
        $NsGroup += $_.split("-")[1]
        $ScriptGroups += "_$NsGroup"
    }
    else
    {
        <#write-output " string : "$orgindex.Substring(0,2)" or string :"$orgindex#>
        if ( $orgindex.Substring(0,2) -eq "TB" )
        {
            $ScriptGroups += "_$orgindex"
        }
    }
}
#Write-Output " writing processed string : "$ScriptGroups

$LastSequence = ""
Get-Content D:\UTP-DEV-2017.11.05-02-790-saf-retailsuite-developer-s08\Temenos\AR_UploadSequence_Preprimary|ForEach-Object {
    $orgindex = $_
    <#$index = $_.split("-")[1]#>
	$index = $orgindex
    if ( $orgindex.Contains("COB") )
    {
        Reg_cob("$LastSequence", "$orgindex")
		Clear-variable -Name ScriptGroups
    }
    ElseIf ( $orgindex.Contains("NS") )
    {
        Reg_NS_Injection("$LastSequence", "$orgindex")
    }
    ElseIf ( $orgindex.Contains("SETUP") )
    {
        Reg_Setup("$LastSequence", "$orgindex")
    }
	ElseIf ( $orgindex.Contains("REPORTS") )
    {
        Reg_Reports("$LastSequence", "$orgindex")
    }
    else
    {
        Reg_injection("$LastSequence", "$orgindex")
		Clear-variable -Name ScriptGroups
    }

    $LastSequence = $orgindex
}
