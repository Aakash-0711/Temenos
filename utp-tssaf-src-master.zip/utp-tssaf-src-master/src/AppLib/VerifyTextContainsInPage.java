package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class VerifyTextContainsInPage {
	static String parameters,text,validationType;
	/**
	 * @param args
	 * optionToCheck
	 * dropdownName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{

		String[] paramArr=Demo1.arrParameters;
		try{
			text=paramArr[0];
			validationType=paramArr[1];
			Reuse.VerifyTextContainsInPage(text, validationType);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>"+text+"</b> contains","<b>"+text+"</b> should be exist",e.getMessage());
		}
	}
}
