package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class BrowserNavigation {
	static String parameters,windowName,navigation;
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;
		try{
			windowName=paramArr[0];
			navigation=paramArr[1].trim();
			Reuse.BrowserNavigation(navigation, windowName);
		}catch(Exception e){
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "<b>"+navigation+"</b> window <b>"+windowName+"</b>","Should be <b>"+navigation+"</b> window <b>"+windowName+"</b>",e.getMessage());
		}
	}
}