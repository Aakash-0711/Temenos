package AppLib;



import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class UploadFile {

	static String action,elementname, filename;


	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception {
		try {
			System.out.println();
			By by=null;
			By by1=null;
			String[] paramArr = Demo1.arrParameters;
			action=paramArr[0].trim();
			elementname = paramArr[1];
			filename = paramArr[2];
			System.out.println();
			by= Reuse.GetLocator(paramArr[3]);
			if(action.equalsIgnoreCase("JS")) {
				by1= Reuse.GetLocator(paramArr[4]);
				Reuse.uploadfileUsingJS(elementname, filename, by,by1);
			}
			else if (action.equalsIgnoreCase("SELENIUM")) {
				Reuse.uploadfile(elementname, filename, by);
			}
			else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Attach a file in <b>"+elementname+"</b>","File should be attached successfully","File is not attached successfully");
			}


		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Attach a file in <b>"+elementname+"</b>","File should be attached successfully","File is not attached successfully");
		}
	}
}
