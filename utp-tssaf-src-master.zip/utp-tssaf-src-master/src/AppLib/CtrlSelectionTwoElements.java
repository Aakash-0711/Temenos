package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class CtrlSelectionTwoElements {
	static String element1,element1Name,element2,element2Name;
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		By by1=null;
		By by2=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			element1=paramArr[0];
			element1Name=paramArr[1];
			element2=paramArr[2];
			element2Name=paramArr[3];
			by1=Reuse.GetLocator(element1);
			by2=Reuse.GetLocator(element2);
			Reuse.CtrlSelectionTwoElements(by1, element1Name, by2, element2);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Press Ctrl and Select <b>"+element1Name+"</b> and <b>"+element2Name+"</b>","Ctrl Selection action should be done",e.getMessage());
		}
	}
}
