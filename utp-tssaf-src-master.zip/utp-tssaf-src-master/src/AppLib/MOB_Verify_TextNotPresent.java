package AppLib;

import static org.apache.commons.lang3.StringEscapeUtils.escapeHtml3;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class MOB_Verify_TextNotPresent {
	static String parameters,locatorType,locator,text,elementName;
	/**
	 * @param args
	 * text
	 * elementName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() {

		By by=null;
		String[] paramArr=Demo1.arrParameters;

		try{
			text=escapeHtml3(paramArr[0]);
			elementName=paramArr[1];
			by=Reuse.GetLocator(paramArr[2]);
			Reuse.MOB_Verify_TextNotPresent(by, text,elementName);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>"+text+"</b> not present","<b>"+text+"</b> should not be present","Unable to locate <b>"+elementName+"</b>");
		}
	}
}
