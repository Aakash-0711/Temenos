package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class AlterValueInTestData {
	static String variable,elementName,action,textToAppend,textToBeReplace;

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{

			String[] paramArr=Demo1.arrParameters;
			variable=paramArr[0];
			textToAppend=paramArr[1];
			action=paramArr[2].trim();


			//String text=StoreText.txtAndVal.get(variableName);
			String text=Reuse.GetPropertyValue(variable);

			if(action.equals("PREFIX")){

				Reuse.WriteProperties(variable,textToAppend + text);

				 Demo1.gbTestCaseStatus = "Pass";
	                Demo1.ReportStep(2, "Store text <b>" +  textToAppend + text + "</b> in <b>" + variable + "</b> variable",
	                        "Text <b>"  + textToAppend + text + "</b> should be stored in <b>" + variable + "</b> variable",
	                        "Stored");

			}else if(action.equals("SUFFIX")){
			    Reuse.WriteProperties(variable, text + textToAppend);

			    Demo1.gbTestCaseStatus = "Pass";
                Demo1.ReportStep(2, "Store text <b>" + text + textToAppend + "</b> in <b>" + variable + "</b> variable",
                        "Text <b>" + text + textToAppend + "</b> should be stored in <b>" + variable + "</b> variable",
                        "Stored");

			}else if(action.equals("REPLACE")){

			    textToBeReplace=paramArr[3];

                Reuse.WriteProperties(variable, text.replace(textToAppend, textToBeReplace));

                Demo1.gbTestCaseStatus = "Pass";
                Demo1.ReportStep(2, "Store text <b>" + text + textToAppend + "</b> in <b>" + variable + "</b> variable",
                        "Text <b>" + text + textToAppend + "</b> should be stored in <b>" + variable + "</b> variable",
                        "Stored");

            }else{
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Use stored text","Use stored text as: <b>"+action+"</b>","Wrong action <b>"+action+"</b>");
			}



		}catch(Exception e){
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Get value from file","Should be able to get the value from file",e.getMessage());
		}
	}
}
