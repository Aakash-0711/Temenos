package AppLib;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.openqa.selenium.By;

import com.google.common.base.Throwables;

import Driver.Config;
import Driver.Demo1;
import Driver.Reuse;

public class ExecuteCommand {
	static String parameters,batFileName,program,arguments;
	/**
	 * @param args
	 * itemToSelect
	 * dropdownName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			By by=null;
			String[] paramArr=Demo1.arrParameters;
			program=paramArr[0];
			batFileName=paramArr[1];
			arguments=paramArr[2];


			 ProcessBuilder pb = new ProcessBuilder("cmd", "/c", arguments);
	            File dir = new File(Config.batchHome+ File.separator +batFileName);
	            pb.directory(dir);
	            Process p = pb.start();


	            Demo1.gbTestCaseStatus = "Pass";
                Demo1.ReportStep(2, "Executing <b>" + program, program+" should be executed successfully",
                        program+":"+batFileName+" has been executed successfully");



			/*if(paramArr.length==2)
			{
			    String path=null;
	            String   curDir = System.getProperty("user.dir");
	            try{


	                 path  = Config.batchHome+ File.separator + batFileName;
	                System.out.println("path of the dir ::"+path);

//	                executebatproc(path);

	                earMod1Create(Config.batchHome,batFileName);

	                Runtime.getRuntime().exec("cmd /c " + curDir+File.separator+"TestData\\Tssaftest.bat");

//	                Runtime.getRuntime().exec("cd "+ Config.batchHome);
//                    Runtime.getRuntime().exec("cmd /c "+batFileName );


	                Demo1.gbTestCaseStatus = "Pass";
	                Demo1.ReportStep(2, "Executing <b>" + program, program+" should be executed successfully",
	                    program+":"+batFileName+" has been executed successfully");
	            }catch(Exception e){
	                try{
	                    System.out.println("Executed in catch");
	                    Runtime.getRuntime().exec("cmd /c start " + path);

	                    Demo1.gbTestCaseStatus = "Pass";
	                    Demo1.ReportStep(2, "Executing <b>" + program, program+" should be executed successfully",
	                            program+":"+batFileName+" has been executed successfully");


	                }catch(Exception e1){

	                    try {
	                        System.out.println("Executed in catch2");
	                        Runtime.getRuntime().exec("cd "+ Config.batchHome);
	                        Runtime.getRuntime().exec("cmd /c start "+batFileName );

	                        Demo1.gbTestCaseStatus = "Pass";
	                        Demo1.ReportStep(2, "Executing <b>" + program, program+" should be executed successfully",
	                                program+":"+batFileName+" has been executed successfully");

	                    } catch (Exception e2) {
	                        Reuse.log(e2);
	                        Demo1.gbTestCaseStatus = "Fail";
	                        Demo1.ReportStep(2, "Executing <b>" + program, program+" should be executed successfully","Could not trigger"+
	                                program+":"+batFileName+"::"+Throwables.getStackTraceAsString(e2));
	                    }


	                }
	            }
			}

			if(paramArr.length==3)
            {
			    arguments=paramArr[2];

			    String path=null;
                String   curDir = System.getProperty("user.dir");

                path  = Config.batchHome+ File.separator + batFileName + " " + arguments;

                System.out.println("path of the dir ::"+path);

			    try{

earMod1Create(Config.batchHome+ File.separator + batFileName ,arguments);

                    Runtime.getRuntime().exec("cmd /c " + curDir+File.separator+"TestData\\Tssaftest.bat");




//			        Runtime.getRuntime().exec("cd "+ Config.batchHome);
//                    Runtime.getRuntime().exec("cmd /c start " + batFileName + " " + arguments );
//
//                    Runtime.getRuntime().exec("cmd /c start " + path);

                    Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, "Executing <b>" + program, program+" should be executed successfully",
                            program+":"+batFileName+" has been executed successfully");


                }catch(Exception e1){

                    try {
                        System.out.println("Executed in catch");
                        Runtime.getRuntime().exec("cd "+ Config.batchHome);
                        Runtime.getRuntime().exec("cmd /c start " + batFileName + " " + arguments );

                        Demo1.gbTestCaseStatus = "Pass";
                        Demo1.ReportStep(2, "Executing <b>" + program, program+" should be executed successfully",
                                program+":"+batFileName+" has been executed successfully");

                    } catch (Exception e2) {
                        Reuse.log(e2);
                        Demo1.gbTestCaseStatus = "Fail";
                        Demo1.ReportStep(2, "Executing <b>" + program, program+" should be executed successfully","Could not trigger"+
                                program+":"+batFileName+"::"+Throwables.getStackTraceAsString(e2));
                    }


                }
            }*/

		}catch(Exception e){
            Reuse.log(e);
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Executing <b>" + program, program+" should be executed successfully","Could not trigger"+
                    program+":"+batFileName+"::"+Throwables.getStackTraceAsString(e));
            }
	}



public static void executebatproc(String args) {

    ProcessBuilder processBuilder = new ProcessBuilder(args);

    //Process process = Runtime.getRuntime().exec(
    //            "cmd /c hello.bat", null, new File("C:\\Users\\mkyong\\"));

    try {

        Process process = processBuilder.start();


    } catch (IOException e) {
        e.printStackTrace();
    }

}


public static void earMod1Create(String path, String batFileName){

    try {
        String   curDir = System.getProperty("user.dir");
        FileWriter fr;
        String UserDirectory = Config.batchHome;
        String[] Userloc = UserDirectory.split(":");
        fr = new FileWriter(curDir+File.separator+"TestData\\Tssaftest.bat");
         fr.write(Userloc[0]+":\n");
         fr.write("cd "+path+"\n");
         fr.write(batFileName);

         fr.close();
         //earMod1CreateStat = true;
    } catch (Exception e) {
      e.printStackTrace();
      System.out.println("Bat Creation unsuccessful");
    }
}

}