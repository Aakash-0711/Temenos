package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

/**
 * Created by shanmugamarun on 26-04-2017.
 */
public class DatePickerSetDate {
    static String parameters,text,locatorType,locator,date;

    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        // TODO Auto-generated method stub
        ExecuteComponent();
    }
    public static void ExecuteComponent() throws Exception{
        String[] paramArr= Demo1.arrParameters;
        By by;
        try{
            text=paramArr[0];
            date=paramArr[1];
            by= Reuse.GetLocator(paramArr[2]);
            Reuse.DateSelector(by, date,text);
        }catch(Exception e){
            Demo1.logger.error("Problem in oDatePicker. This may be because of the locator syntax error: " + paramArr[2]);
            Demo1.logger.error(e);
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Input text in to the field <b>"+text+"</b>","Input text <b>"+ text+"</b>","Unable to locate <b>"+text+"</b> Textbox");
        }
    }
}
