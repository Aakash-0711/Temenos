package AppLib;

import Driver.Demo1;
import Driver.Reuse;
import Driver.ReuseT24API;

public class API_SetRequestValue {
	static String userName,Password,URL,path,action,key,value;
	private static String appUrl;
	/**
	 * @param
	 * elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static String replaceLast(String text, String regex, String replacement) {
        return text.replaceFirst("(?s)"+regex+"(?!.*?"+regex+")", replacement);
    }

	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;




		key = paramArr[0];
		value = paramArr[1];
		action = paramArr[2];



		try {




		if(action.equals("HEADER")){
		    ReuseT24API.API_givenRequestHeader(key, value);
        }else if(action.equals("FORM_PARAMETER")){
            ReuseT24API.API_givenRequestFormParam(key, value);
        }else if(action.equals("QUERY_PARAMETER")){
            ReuseT24API.API_givenAQueryParameter(key, value);
        }/*else if(action.equals("MULTIPART")){
            ReuseT24API.API_givenRequestMultiParam(key, value);
        }*/else if(Demo1.parametersListGlobalRef.contains("MULTIPART")){

            String delimiter = "\",";

            String[] arrParamList = Demo1.parametersListGlobalRef.split(delimiter);

            String a = arrParamList[0].substring(1);

            System.out.println(a +"a");

            String b = arrParamList[arrParamList.length -1].substring(1).split("\"")[0];

            System.out.println(b +"b");

            String c = Demo1.parametersListGlobalRef.replaceFirst(a, "");

            c = replaceLast(c, b, "").substring(3);

            System.out.println(c +"c");

            String d = c.substring(1, c.lastIndexOf("\",\"\""));

            System.out.println("key::"+ a + ",value::"+ d);

            ReuseT24API.API_givenRequestMultiParam(a, d);

        }
               else {
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Use property text", "Use property text as: <b>" + action + "</b>", "Wrong action <b>" + action + "</b>");
        }


		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "To request api ",
                    "API request of " + action  + "is should be sent",
                    "API request not sent successfully");
		}
	}

}
