package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class MOB_ScrollDown {
	static String elementType, elementName;

	/**
	 * @param args
	 *            elementType elementName locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception {
		By by = null;
		try{
			String[] paramArr = Demo1.arrParameters;
			elementType = paramArr[0];
			elementName = paramArr[1];

			//Test

	Reuse.MOB_ScrollDown(elementType, elementName);

		//Test


		}catch(Exception e){
			Demo1.logger.error("Click_Element "+e);
		}
	}



}
