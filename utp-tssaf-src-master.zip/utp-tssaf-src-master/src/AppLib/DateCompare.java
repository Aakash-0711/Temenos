package AppLib;

import Driver.Demo1;
import Driver.Reuse;

/**
 * @author aakash.manohar
 *
 */
public class DateCompare {

	public static String dateFormat, action, fromDate, toDate, expectedValue;

	public static void main(String[] args) {

		ExecuteComponent();

	}

	public static void ExecuteComponent() {

		try {
			String[] paramArr = Demo1.arrParameters;
			dateFormat = paramArr[0];
			action = paramArr[1];
			fromDate = paramArr[2];
			toDate = paramArr[3];
			expectedValue = paramArr[4];

			Reuse.compareDate(dateFormat, action, fromDate, toDate, expectedValue);
		} catch (Exception e) {
			e.printStackTrace();
			Demo1.logger.error("DateCompare Component. " + e);
		}

	}

}
