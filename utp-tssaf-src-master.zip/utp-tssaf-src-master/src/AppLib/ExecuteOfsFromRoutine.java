package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class ExecuteOfsFromRoutine {
	static String elementType, RoutineName, arg1, arg2, arg3, arg4, applicationName, ofsMessage, outputParams, routineValue;

	/**
	 * @param args
	 *            elementType elementName locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception {
		By by = null;
		try{
			String[] paramArr = Demo1.arrParameters;

			RoutineName = paramArr[0];
			arg1 = paramArr[1];
			arg2 = paramArr[2];
			arg3 = paramArr[3];
			arg4 = paramArr[4];

			applicationName = paramArr[5];
			ofsMessage = paramArr[6];
			outputParams = paramArr[7];

//			ofsText = paramArr[3];
			//Test
//			routineValue =  paramArr[8];

//			Reuse.testrunPaymentsRoutine(RoutineName, arg1, arg2, arg3, applicationName, ofsMessage, outputParams, routineValue);


			if (paramArr.length == 9){
			    routineValue =  paramArr[8];

		          Reuse.runPaymentsRoutine(RoutineName, arg1, arg2, arg3, arg4, applicationName, ofsMessage, outputParams, routineValue);
			}else{

			    Reuse.runPaymentsRoutine(RoutineName, arg1, arg2, arg3, arg4, applicationName, ofsMessage, outputParams, "");


			}




		}catch(Exception e){
			Demo1.logger.error("Click_Element "+e);
		}
	}



}
