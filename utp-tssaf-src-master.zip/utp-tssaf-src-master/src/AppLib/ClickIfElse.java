package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class ClickIfElse {
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception {
		By by1,by2,by3;
		try{
			String[] paramArr = Demo1.arrParameters;
			by1=Reuse.GetLocator(Reuse.getValueOfRunTimeVariables(paramArr[0]));
			by2=Reuse.GetLocator(Reuse.getValueOfRunTimeVariables(paramArr[2]));
			by3=Reuse.GetLocator(Reuse.getValueOfRunTimeVariables(paramArr[3]));
			Reuse.ClickIfElse(by1,by2,by3, paramArr[1]);
		}catch(Exception e){
			Demo1.logger.error("ClickIfElse Component. "+e);
		}
	}
}
