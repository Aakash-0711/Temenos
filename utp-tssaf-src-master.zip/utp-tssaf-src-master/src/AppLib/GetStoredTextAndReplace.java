package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class GetStoredTextAndReplace {
	static String parameters,locatorType,locator,variableName,elementName,action,replaceAction;
	static String target="";
	static String replacement="";

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			By by=null;
			String[] paramArr=Demo1.arrParameters;
			variableName=paramArr[0];
			elementName=paramArr[1];
			action=paramArr[2].trim();
			replaceAction=paramArr[3].trim();
			target=paramArr[4];
			replacement=paramArr[5].trim();
			by=Reuse.GetLocator(paramArr[6]);

			String replaceText=StoreText.txtAndVal.get(variableName);
			String text="";
			if(replacement.isEmpty()){
				replacement="";
			}
			if(replaceAction.equalsIgnoreCase("REPLACE_ALL")){
				text=replaceText.replaceAll(target, replacement);
			}else if(replaceAction.equalsIgnoreCase("REPLACE_FIRST")){
				text=replaceText.replaceFirst(target, replacement);
			}else if(replaceAction.equalsIgnoreCase("REPLACE")){
				text=replaceText.replace(target, replacement);
			}
			if(action.equals("TEXT_PRESENT")){
				Reuse.Verify_TextPresent(by, text,elementName);
			}else if(action.equals("TEXT_NOT_PRESENT")){
				Reuse.Verify_TextNotPresent(by, text, elementName);
			}else if(action.equals("TEXT_CONTAINS")){
				Reuse.Verify_TextContains(by, text, elementName);
			}else if(action.equals("TEXT_NOT_CONTAINS")){
				Reuse.Verify_TextNotContains(by, text, elementName);
			}else if(action.equals("SET_TEXT")){
				Reuse.TextBox_InputText(by, text, elementName);
			}else if(action.equals("APPEND_TEXT")){
				Reuse.TextBox_AppendText(by, text, elementName);
			}else{
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Use stored text","Use stored text as: <b>"+action+"</b>","Wrong action <b>"+action+"</b>");
			}
		}catch(Exception e){
			Demo1.logger.error("GetStoredTextAndReplace" +e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Use stored text","Use stored text as: <b>"+action+"</b>",e.getMessage());
		}
	}
}
