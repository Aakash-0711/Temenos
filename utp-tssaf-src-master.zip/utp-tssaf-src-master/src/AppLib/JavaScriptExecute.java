package AppLib;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;

import Driver.Demo1;
import Driver.Reuse;

public class JavaScriptExecute {
    static String elementName, action, inputValue, script;

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        ExecuteComponent();
    }

    public static void ExecuteComponent() {

        By by = null;
        String[] paramArr = Demo1.arrParameters;
        try {
        	script = paramArr[0];
            elementName = paramArr[1];
            action = paramArr[2];
            inputValue = paramArr[3];
            JavascriptExecutor executor = (JavascriptExecutor) Demo1.driver;

            if(action.equals("EXECUTE")){
            	executor.executeScript(script);
            	Demo1.gbTestCaseStatus = "Pass";
                Demo1.ReportStep(2, action + " using given script should be done", "Element name:" + elementName, action + " using given script done successfully");
            }else if(action.equals("INNTER_HTML_UPDATE")){
            	System.out.println("It is inside inner html update");
            	WebElement element = null;
            	element = Demo1.driver.findElement(Reuse.GetLocator(script));
            	executor.executeScript(
          			  "var ele=arguments[0]; ele.innerHTML = ' " + inputValue + "';", element);
            	Demo1.gbTestCaseStatus = "Pass";
                Demo1.ReportStep(2, action + " using given script should be done", "Element name:" + elementName, action + " using given script done successfully");
            }else if(action.equals("CLICK")){
            	executor.executeScript(script + ".click()");
            	Demo1.gbTestCaseStatus = "Pass";
                Demo1.ReportStep(2, action + " using given script should be done", "Element name:" + elementName, action + " using given script done successfully");
            }else if(action.equals("INPUT")){
            	executor.executeScript(script + ".value=\'" + inputValue + "\'");
            	Demo1.gbTestCaseStatus = "Pass";
                Demo1.ReportStep(2, action + " using given script should be done", "Element name:" + elementName, action + " using given script done successfully");
            }else if(action.equals("ELEMENT_EXIST")){
            	Object obj = executor.executeScript("return " + script);
            	/*ArrayList<Object> objs = (ArrayList<Object>) obj;
            	WebElement foundElement = (WebElement) objs.get(0);*/

            	RemoteWebElement foundElement = (RemoteWebElement) obj;
            	System.out.println("ELEMENT FOUND::" + foundElement.getTagName());
            	WebElement finalElement = foundElement;
            	if(finalElement != null){
            		System.out.println("Element is found and displayed");
            		Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, elementName + " using given script should be checked", "Element name:" + elementName, elementName + " is Exist");
            	}else{
            		System.out.println("Element is not found and not displayed");
            		Demo1.gbTestCaseStatus = "Fail";
                    Demo1.ReportStep(2, elementName + " using given script should be checked", "Element name:" + elementName, elementName + " is not Exist");
            	}
            }else if(action.equals("ELEMENT_NOTEXIST")){
            	try{
            		Object obj = executor.executeScript("return " + script);
                	/*ArrayList<Object> objs = (ArrayList<Object>) obj;
                	WebElement foundElement = (WebElement) objs.get(0);*/

                	RemoteWebElement foundElement = (RemoteWebElement) obj;
                	System.out.println("ELEMENT FOUND::" + foundElement.getTagName());
                	WebElement finalElement = foundElement;
                	if(finalElement != null){
                		Demo1.gbTestCaseStatus = "Fail";
                        Demo1.ReportStep(2, action + " using given script should be checked", "Element name:" + elementName, action + " using given script has failed");
                	}else{
                		Demo1.gbTestCaseStatus = "Pass";
                        Demo1.ReportStep(2, action + " using given script should be checked", "Element name:" + elementName, action + " using given script done successfully");
                	}
            	}catch(Exception e){ //since the element not found which is expected
            		Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, action + " using given script should be checked", "Element name:" + elementName, action + " using given script done successfully");
            	}

            }else if(action.equals("ELEMENT_ENABLED")){
            	Object obj = executor.executeScript("return " + script);
            	/*ArrayList<Object> objs = (ArrayList<Object>) obj;
            	WebElement foundElement = (WebElement) objs.get(0);*/

            	RemoteWebElement foundElement = (RemoteWebElement) obj;
            	System.out.println("ELEMENT FOUND::" + foundElement.getTagName());
            	WebElement finalElement = foundElement;
            	if(finalElement.isEnabled()){
            		Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, action + " using given script should be checked", "Element name:" + elementName, action + " using given script done successfully");
            	}else{
            		Demo1.gbTestCaseStatus = "Fail";
                    Demo1.ReportStep(2, action + " using given script should be checked", "Element name:" + elementName, action + " using given script has failed");
            	}
            }else if(action.equals("ELEMENT_DISABLED")){
            	Object obj = executor.executeScript("return " + script);
            	/*ArrayList<Object> objs = (ArrayList<Object>) obj;
            	WebElement foundElement = (WebElement) objs.get(0);*/

            	RemoteWebElement foundElement = (RemoteWebElement) obj;
            	System.out.println("ELEMENT FOUND::" + foundElement.getTagName());
            	WebElement finalElement = foundElement;
            	if(! finalElement.isEnabled()){
            		Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, action + " using given script should be checked", "Element name:" + elementName, action + " using given script done successfully");
            	}else{
            		Demo1.gbTestCaseStatus = "Fail";
                    Demo1.ReportStep(2, action + " using given script should be checked", "Element name:" + elementName, action + " using given script has failed");
            	}
            }else if(action.equals("TEXT_PRESENT")){
            	Object obj = executor.executeScript("return " + script);
            	/*ArrayList<Object> objs = (ArrayList<Object>) obj;
            	WebElement foundElement = (WebElement) objs.get(0);*/

            	RemoteWebElement foundElement = (RemoteWebElement) obj;

            	if(foundElement.getText().equals(inputValue)){
        			Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, action + " using given script should be verified", "Element name:" + elementName, action + " using given script verified successfully");
        		}else{
            		Demo1.gbTestCaseStatus = "Fail";
                    Demo1.ReportStep(2, action + " using given script should be verified", "Element name:" + elementName, action + " using given script has failed");
            	}
            }else if(action.equals("TEXT_NOTPRESENT")){
            	Object obj = executor.executeScript("return " + script);
            	/*ArrayList<Object> objs = (ArrayList<Object>) obj;
            	WebElement foundElement = (WebElement) objs.get(0);*/

            	RemoteWebElement foundElement = (RemoteWebElement) obj;

            	if(! foundElement.getText().equals(inputValue)){
        			Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, action + " using given script should be verified", "Element name:" + elementName, action + " using given script verified successfully");
        		}else{
            		Demo1.gbTestCaseStatus = "Fail";
                    Demo1.ReportStep(2, action + " using given script should be verified", "Element name:" + elementName, action + " using given script has failed");
            	}
            }else if(action.equals("TEXT_CONTAINS")){
            	Object obj = executor.executeScript("return " + script);
            	/*ArrayList<Object> objs = (ArrayList<Object>) obj;
            	WebElement foundElement = (WebElement) objs.get(0);*/
            	RemoteWebElement foundElement = (RemoteWebElement) obj;

            	if(foundElement.getText().contains(inputValue)){
        			Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, action + " using given script should be verified", "Element name:" + elementName, action + " using given script verified successfully");
        		}else{
            		Demo1.gbTestCaseStatus = "Fail";
                    Demo1.ReportStep(2, action + " using given script should be verified", "Element name:" + elementName, action + " using given script has failed");
            	}
            }else if(action.equals("TEXT_NOTCONTAINS")){
            	Object obj = executor.executeScript("return " + script);
            	/*ArrayList<Object> objs = (ArrayList<Object>) obj;
            	WebElement foundElement = (WebElement) objs.get(0);*/
            	RemoteWebElement foundElement = (RemoteWebElement) obj;

            	if(! foundElement.getText().contains(inputValue)){
        			Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, action + " using given script should be verified", "Element name:" + elementName, action + " using given script verified successfully");
        		}else{
            		Demo1.gbTestCaseStatus = "Fail";
                    Demo1.ReportStep(2, action + " using given script should be verified", "Element name:" + elementName, action + " using given script has failed");
            	}
            }else if(action.equals("ATTRIBUTEVALUE_EXIST")){
            	String[] parsed = inputValue.split("=");
            	Object obj = executor.executeScript("return " + script);
            	/*ArrayList<Object> objs = (ArrayList<Object>) obj;
            	WebElement foundElement = (WebElement) objs.get(0);*/

            	RemoteWebElement foundElement = (RemoteWebElement) obj;

            	String actualValue = foundElement.getAttribute(parsed[0]);
        		if(actualValue.equalsIgnoreCase(parsed[1])){
        			Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, action + " using given script should be verified", "Element name:" + elementName, action + " using given script verified successfully");
        		}else{
            		Demo1.gbTestCaseStatus = "Fail";
                    Demo1.ReportStep(2, action + " using given script should be verified", "Element name:" + elementName, action + " using given script has failed");
            	}
            }else if(action.equals("ATTRIBUTEVALUE_NOTEXIST")){
            	String[] parsed = inputValue.split("=");

            	Object obj = executor.executeScript("return " + script);
            	/*ArrayList<Object> objs = (ArrayList<Object>) obj;
            	WebElement foundElement = (WebElement) objs.get(0);*/

            	RemoteWebElement foundElement = (RemoteWebElement) obj;

            	String actualValue = foundElement.getAttribute(parsed[0]);
        		if(! actualValue.equalsIgnoreCase(parsed[1])){
        			Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, action + " using given script should be verified", "Element name:" + elementName, action + " using given script verified successfully");
        		}else{
            		Demo1.gbTestCaseStatus = "Fail";
                    Demo1.ReportStep(2, action + " using given script should be verified", "Element name:" + elementName, action + " using given script has failed");
            	}
            }else if(action.equals("ATTRIBUTEVALUE_CONTAINS")){
            	String[] parsed = inputValue.split("=");

            	Object obj = executor.executeScript("return " + script);
            	/*ArrayList<Object> objs = (ArrayList<Object>) obj;
            	WebElement foundElement = (WebElement) objs.get(0);*/

            	RemoteWebElement foundElement = (RemoteWebElement) obj;

            	String actualValue = foundElement.getAttribute(parsed[0]);
        		if(actualValue.contains(parsed[1])){
        			Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, action + " using given script should be verified", "Element name:" + elementName, action + " using given script verified successfully");
        		}else{
            		Demo1.gbTestCaseStatus = "Fail";
                    Demo1.ReportStep(2, action + " using given script should be verified", "Element name:" + elementName, action + " using given script has failed");
            	}
            }else if(action.equals("ATTRIBUTEVALUE_NOTCONTAINS")){
            	String[] parsed = inputValue.split("=");

            	Object obj = executor.executeScript("return " + script);
            	/*ArrayList<Object> objs = (ArrayList<Object>) obj;
            	WebElement foundElement = (WebElement) objs.get(0);*/

            	RemoteWebElement foundElement = (RemoteWebElement) obj;

            	String actualValue = foundElement.getAttribute(parsed[0]);
        		if(! actualValue.contains(parsed[1])){
        			Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, action + " using given script should be verified", "Element name:" + elementName, action + " using given script verified successfully");
        		}else{
            		Demo1.gbTestCaseStatus = "Fail";
                    Demo1.ReportStep(2, action + " using given script should be verified", "Element name:" + elementName, action + " using given script has failed");
            	}
            }

        } catch (Exception e) {
        	e.printStackTrace();
            Demo1.logger.error("ERROR::" + e.getStackTrace());
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, action + " using given script should be executed", "Element name:" + elementName, action + " using given script has failed");
        }
    }
}
