package AppLib;

import Driver.Demo1;
import Driver.Reuse;
import org.openqa.selenium.By;

public class Shadow_JavaScriptDragAndDrop {
	static String elementName,From,To;
	/**
	 * @param args
	 * elementName
	 * 
	 * @throws Exception
	 * @author aakash.manohar 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{	
		String[] paramArr=Demo1.arrParameters;
		try{
			elementName=paramArr[0];
			From=paramArr[1];
			To=paramArr[2];
		
			Reuse.Shadow_JavaScriptDragAndDrop(From,To,elementName);
		}catch(Exception e){
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Shadow Drag and Drop Event","Drag and Drop Event should be done: <b>","Element not found");
		}
	}

}
