package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class CloseAllChildWindows{

	/**
	 * @param
	 *  elementType
	 *  elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			Reuse.CloseAllChildWindows();
		}catch(Exception e){
			Demo1.logger.error("CloseAllChildWindows - "+e);
		}
	}
}
