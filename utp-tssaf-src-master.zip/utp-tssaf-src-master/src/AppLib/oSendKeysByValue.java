package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class oSendKeysByValue {

	static String text,textBoxName,locator;

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception  {
		String[] paramArr=Demo1.arrParameters;
		By by=null;
		try{
			text=paramArr[0];
			textBoxName=paramArr[1];
			by=Reuse.GetLocator(paramArr[2]);
			Reuse.oSendKeysByValue(by,text,textBoxName);

		}catch(Exception e){
			Demo1.logger.error("Problem in oSendKeysByValue. This may be because of the locator syntax error: " + paramArr[2]);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Input text in to the field <b>"+textBoxName+"</b>","Input text <b>"+ text+"</b>","Unbale to locate <b>"+textBoxName+"</b> Textbox");
		}
	}

}
