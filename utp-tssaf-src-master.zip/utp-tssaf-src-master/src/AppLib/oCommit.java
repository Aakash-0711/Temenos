package AppLib;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import Driver.Demo1;
import Driver.Reuse;

public class oCommit {
	public static String txnID;

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception{
		try{
			Demo1.driver.findElement(By.xpath("//img[@title='Commit the deal']")).click();
			Reuse.oWait(2);
			/*if(Reuse.isLinkPresent("Accept Overrides")){
				Reuse.Link_Click("Accept Overrides");
				Reuse.oWait(2);
			}	*/
			WebElement element= Demo1.driver.findElement(By.xpath("//td[@class='message']"));
			if(element.isDisplayed()){
				String str=element.getText();
				if(str.contains("Txn Complete:")){

					String[] splitStr=str.split(" ");
					txnID = splitStr[2];

					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Trasaction complete validation","Txn should be completed successfull","Txn completed with Txn id: " +txnID);
				}else{
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Trasaction complete validation","Txn should be completed successfull","Txn not completed");
				}
			}
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Trasaction complete validation","Txn should be completed successfull","Unable to locate element Commit the deal");
		}
		//File excelFile = new File(Demo1.curDir + "\\Testware\\Testware.xls");
		//Workbook wb = Workbook.getWorkbook(excelFile);
		//Sheet sheet = wb.getSheet(0);
		/*FileInputStream file = new FileInputStream(new File("C:\\test.xls"));

        HSSFWorkbook workbook = new HSSFWorkbook(file);
        HSSFSheet sheet = workbook.getSheetAt(0);
        HSSFCell cell = null;

        //Update the value of cell
        cell = sheet.getRow(2).getCell(1);
        cell.setCellValue*/
	}
}
