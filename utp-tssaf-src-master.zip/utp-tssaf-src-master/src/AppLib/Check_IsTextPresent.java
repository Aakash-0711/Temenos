package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class Check_IsTextPresent {
	static String action,elementName,textToCheck,compareAction;
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		By by=null;
		try{
			String[] paramArr=Demo1.arrParameters;
			action=paramArr[0].trim();
			elementName=paramArr[1];
			textToCheck=paramArr[2];
			compareAction=paramArr[3].trim();
			by=Reuse.GetLocator(paramArr[4]);
			Reuse.CheckPoint_IsElementTextPresent(by, elementName, textToCheck, compareAction, action);
		}catch(Exception e){
			Demo1.logger.error(e.getMessage());
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check Text <b>"+textToCheck+"</b> Present for the element <b>"+elementName+"</b>", "Text <b>"+textToCheck+"</b> should be displayed","Unable to locate element <b>"+elementName+"</b> or "+e.getMessage());
		}
	}
}
