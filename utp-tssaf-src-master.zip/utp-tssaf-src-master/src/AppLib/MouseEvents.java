package AppLib;

import org.openqa.selenium.By;
import Driver.Demo1;
import Driver.Reuse;

public class MouseEvents {
	static String elementName,elementType,locator,event;
	/**
	 * @param
	 *
	 *
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			elementName=paramArr[0];
			elementType=paramArr[1];
			locator=paramArr[2];
			event=paramArr[3].trim();

			

			if(event.equalsIgnoreCase("DOUBLE_CLICK")){
				by=Reuse.GetLocator(locator);
				Reuse.DoubleClick(by, elementType, elementName);
			}else if(event.equalsIgnoreCase("RIGHT_CLICK")){
				by=Reuse.GetLocator(locator);
				Reuse.RightClick(by, elementType, elementName);
			}else if(event.equalsIgnoreCase("MOUSE_OVER")){
				by=Reuse.GetLocator(locator);
				Reuse.MouseOver(by, elementName);
			}else if(event.equalsIgnoreCase("CONTEXT_CLICK")){
				by=Reuse.GetLocator(locator);
				Reuse.ContextClick(by, elementType, elementName);
			}else if(event.equalsIgnoreCase("JS_MOUSE_OVER")){
				by=Reuse.GetLocator(locator);
                Reuse.JS_MouseOver(by, elementName);
            }else if(event.equalsIgnoreCase("SHADOW_MOUSE_OVER")) {
            	Reuse.ShadowMouseOver(locator, elementName);
            }
            else if(event.equalsIgnoreCase("SHADOW_RIGHT_CLICK")) {
            	Reuse.ShadowRightClick(locator, elementName);
            }
			
			else{
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Mouseover Event","Mouseover Event should be done","Event not found");
			}

		}catch(Exception e){
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Mouseover Event","Mouseover Event should be done","Element not found");
		}
	}
}

