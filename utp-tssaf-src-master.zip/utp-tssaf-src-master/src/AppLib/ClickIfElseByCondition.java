package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class ClickIfElseByCondition {
	
	static String elementName,propertyKey;

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	
	public static void ExecuteComponent() throws Exception {
		By by1,by2;
		try{
			String[] paramArr = Demo1.arrParameters;
			elementName=paramArr[0];
			propertyKey=paramArr[1];
			by1=Reuse.GetLocator(Reuse.getValueOfRunTimeVariables(paramArr[2]));
			by2=Reuse.GetLocator(Reuse.getValueOfRunTimeVariables(paramArr[3]));
			Reuse.clickIfElseByCondition(elementName,propertyKey,by1,by2);
		}catch(Exception e){
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Click element <b>" + elementName + "</b>",
					"Should be able to click on <b>" + elementName + "</b>",
					"Element <b>" + elementName + "</b> not present/unable to locate element");
		}
	}

}
