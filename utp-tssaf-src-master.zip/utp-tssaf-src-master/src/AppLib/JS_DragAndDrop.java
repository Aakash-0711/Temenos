package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class JS_DragAndDrop {
	static String parameters,locatorType,locator,elementName;
	/**
	 * @param args
	 * xOffset
	 * yOffset
	 * elementName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		By by=null;
		By by1=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			elementName=paramArr[0];
			by=Reuse.GetLocator(paramArr[1]);
			by1=Reuse.GetLocator(paramArr[2]);

			Reuse.JS_DragAndDrop(by,by1,elementName);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Drag and Drop Event","Drag and Drop Event should be done: <b>","Element not found");
		}
	}

}
