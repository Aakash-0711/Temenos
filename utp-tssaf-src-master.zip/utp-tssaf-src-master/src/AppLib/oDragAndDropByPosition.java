package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class oDragAndDropByPosition {
	static String parameters,locatorType,locator,elementName;
	static int xOffset,yOffset;
	/**
	 * @param args
	 * xOffset
	 * yOffset
	 * elementName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			xOffset=Integer.parseInt(paramArr[0]);
			yOffset=Integer.parseInt(paramArr[1]);
			elementName=paramArr[2];
			by=Reuse.GetLocator(paramArr[3]);

			Reuse.DragAndDropByPosition(by,xOffset,yOffset,elementName);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Drag and Drop Event","Drag and Drop Event should be done with the xOffset: <b>"+xOffset+"</b> and yOffset: <b>"+yOffset+"</b>","Element not found");
		}
	}

}
