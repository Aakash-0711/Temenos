package AppLib;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Driver.Demo1;

/**
 * TODO: Document me!
 *
 * @author ssandeep
 *
 */
public class Createexcel {
	public static String outexcelpath;

	public static void main(String[] args) {
		try {
			ExecuteComponent();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void ExecuteComponent() throws Exception

	{

		String curDir = System.getProperty("user.dir");
		Properties prop = new Properties();
		InputStream input = new FileInputStream(curDir + "\\Config\\config.properties");
		prop.load(input);
		try {
			String temp1[] = new String[5];
			temp1[0] = "scbindexpage";
			DASHBOARD.d2.indexDriver(temp1);

			DASHBOARD.d2.WriteindexReportHeader(temp1);
			String timeStamp = new SimpleDateFormat("yyyyMMdd_HH_mm_ss").format(Calendar.getInstance().getTime());
			String resultfolder = prop.getProperty("tapresult").trim();
			outexcelpath = "Result\\TTIResults\\" + resultfolder + timeStamp + "\\" + "SCBTESTRESULT" + timeStamp
					+ ".xlsx";
			File dir = new File("Result\\TTIResults\\" + resultfolder + timeStamp);
			dir.mkdir();
			// String outexcelFilePath
			Workbook workbook1 = new XSSFWorkbook();
			FileOutputStream fos = new FileOutputStream(outexcelpath, true);
			Sheet outsheet = workbook1.createSheet("0");
			Row header = outsheet.createRow((short) 0);
			header.createCell(0).setCellValue("SYSTEM");
			header.createCell(1).setCellValue("Checkpoint");
			header.createCell(2).setCellValue("Testcase");
			header.createCell(3).setCellValue("Table_name");
			header.createCell(4).setCellValue("RECID");
			for (int rowcnt = 0; rowcnt < 10; rowcnt++) {
				header.createCell(4 * (rowcnt + 1) + 2).setCellValue("FIELD NAME");
				header.createCell(4 * (rowcnt + 1) + 3).setCellValue("EXPECTED VALUE");
				header.createCell(4 * (rowcnt + 1) + 4).setCellValue("ACTUAL VALUE");
				header.createCell(4 * (rowcnt + 1) + 5).setCellValue("ERROR DETAILS");

			}
			System.out.println("OUTPUT EXCEL PATH::" + outexcelpath);
			Demo1.logger.info("OUTPUT EXCEL PATH::" + outexcelpath);
			workbook1.write(fos);
			fos.close();
			workbook1.close();
			// ((FileOutputStream) workbook1).close();
			// String[] paramArr = Demo1.arrParameters;

			// main();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
