package AppLib;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Driver.Demo1;

/**
 * TODO: Document me!
 *
 * @author ssandeep
 *
 */
public class Testt24data {

    Connection conn = null;
    Statement stmt = null;

    public static void main(String[] args) throws IOException, SQLException {
        Properties prop = new Properties();

        String curDir;
        curDir = System.getProperty("user.dir");
        InputStream input = new FileInputStream(curDir + "\\Config\\config.properties");
        prop.load(input);

        GetPropertyValues properties = new GetPropertyValues();

        String JDBC_DRIVER = prop.getProperty("t24driver").trim();

        String DB_URL = prop.getProperty("t24url").trim();

        String USER = prop.getProperty("t24dbusername").trim();

        String PASS = prop.getProperty("t24dbpasswordt").trim();
        Date time = new Date(System.currentTimeMillis());
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HH_mm_ss").format(Calendar.getInstance().getTime());
        Demo1.gbTestCaseStatus = "Pass";
        Demo1.DB2flag = true;
        String outexcelFilePath = Createexcel.outexcelpath;

        Connection conn = null;
        Statement stmt = null;
        String Table_name = null;
        String Test_case = null;
        String Checkpoint = null;
        String RECID = null;
        String[] Field_name = new String[10];
        String[] Field_value = new String[10];
        String[] SplitRecord = new String[100];
        String Field_names = null;
        String Field_values = null;
        String indexinformation[] = new String[5];
        int rec;

        String excelFilePath = "TestWare\\TestWare.xlsx";

        String checkpointtestdata = args[0];
        boolean DBconnect = true;
        FileInputStream inputStream = new FileInputStream(new File(excelFilePath));

        int i = 0;
        int j;
        String prefix = "<html><body><table>\n";
        final StringBuilder sb1 = new StringBuilder(prefix);
        try {
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement();
        } catch (java.sql.SQLException EX) {
            DBconnect = false;
            checksum.Teststatusflag = false;
            Demo1.gbTestCaseStatus = "Fail";
            System.out.println("Problem with Connection correct your T24 URL & Credential");
        }

        if (DBconnect) {
            try {

                Workbook workbook = new XSSFWorkbook(excelFilePath);
                Sheet firstSheet = workbook.getSheetAt(5);
                Workbook workbook1 = new XSSFWorkbook(outexcelFilePath);
                Sheet outsheet = workbook1.getSheetAt(0);
                Iterator<Row> iterator1 = outsheet.iterator();

                short rowcount = 0;
                while (iterator1.hasNext()) {
                    rowcount += 1;
                    iterator1.next();
                }
                DASHBOARD d3 = new DASHBOARD();

                indexinformation[0] = "T24" + checkpointtestdata;
                d3.indexDBDriver(indexinformation);
                String[] indexarg = new String[2];
                indexarg[0] = "T24";
                indexarg[1] = checkpointtestdata;
                d3.DBWriteindexReportHeader(indexarg);

                Iterator<Row> iterator = firstSheet.iterator();
                iterator.next();
                int testcasecount = DASHBOARD.testcasecount;

                while (iterator.hasNext()) {
                    Row nextRow = iterator.next();
                    Iterator<Cell> cellIterator = nextRow.cellIterator();
                    i = 0;

                    Checkpoint = cellIterator.next().getStringCellValue();
                    // System.out.println("debug "+Checkpoint);
                    DASHBOARD.Currentteststatus = "";
                    if (checkpointtestdata.equals(Checkpoint)) {
                        Row nextRow1 = outsheet.createRow(rowcount);
                        rowcount += 1;

                        Test_case = cellIterator.next().getStringCellValue();
                        Table_name = cellIterator.next().getStringCellValue();
                        Table_name = Table_name.replace("\"", "");

                        RECID = cellIterator.next().getStringCellValue();
                        String indirectfield = null;
                        System.out.println(Table_name);

                        RECID = RECID.replace("\"", "");
                        if (RECID.contains("*")) {
                            indirectfield = RECID.substring(RECID.lastIndexOf("*") + 1);
                            RECID = RECID.replace(RECID.substring(RECID.lastIndexOf("*") + 1), "");
                            RECID = RECID.replace("*", "");
                            System.out.println(RECID);
                        }
                        String RECIDtemp = RECID;
                        String suffix = null;
                        String prefixs = null;
                        if (RECID.contains("##")) {
                            suffix = RECID.substring(RECID.lastIndexOf("##"));
                            RECID = RECID.replace(RECID.substring(RECID.lastIndexOf("##")), "");
                            RECID = RECID.replace(suffix, "");
                            suffix = suffix.replace("##", "");
                        }
                        if (RECID.contains("#")) {
                            prefixs = RECID.substring(0, RECID.indexOf("#"));
                            RECID = RECID.replace(RECID.substring(0, RECID.indexOf("#") + 1), "");
                            RECID = RECID.replace(prefixs, "");
                            prefixs = prefixs.replace("#", "");
                        }
                        if (RECID.contains("auto@")) {
                            RECID = RECID.replace("auto@", "");
                            System.out.println(RECID);
                            RECID = StoreText.txtAndVal.get(RECID);
                            System.out.println(RECID);
                        }
                        if (suffix != null) {
                            RECID = RECID + suffix;
                        }
                        if (prefixs != null) {
                            RECID = prefixs + RECID;
                        }

                        System.out.println(RECID);

                        Test_case = Test_case.replace("\"", "");
                        String[] reportstring = new String[4];
                        reportstring[0] = "T24";
                        reportstring[1] = Checkpoint;
                        reportstring[2] = Test_case;
                        DASHBOARD.d2.reportindexbody(reportstring);

                        String arr1[] = new String[8];
                        arr1[0] = "T24_" + Checkpoint + "_" + Test_case;
                        DASHBOARD d1 = new DASHBOARD();
                        d1.testDriver(arr1);

                        i = 0;
                        int colcnt = nextRow.getLastCellNum();
                        System.out.println("colcnt " + colcnt);
                        for (int ii = 0; ii <= ((colcnt - 4) / 2) - 1; ii++) {

                            System.out.println(" i - " + i);
                            System.out.println("ii " + ii);

                            Field_names = cellIterator.next().getStringCellValue();
                            System.out.println(Field_names);
                            Field_names = Field_names.replace("\"", "");
                            Field_values = cellIterator.next().getStringCellValue();
                            System.out.println(Field_values);
                            Field_values = Field_values.replace("\"", "");
                            if (!Field_names.equals("")) {
                                Field_name[i] = Field_names;
                                Field_value[i] = Field_values;
                                System.out.print(Field_name[i]);
                                System.out.print(Field_value[i]);

                                System.out.print(" - ");
                                i += 1;
                            }

                        }
                        ArrayList<String> list = new ArrayList<>();
                        for (String s : Field_name)
                            if (!(s == null))
                                list.add(s);
                        Field_name = list.toArray(new String[list.size()]);

                        ArrayList<String> list1 = new ArrayList<>();
                        for (String s1 : Field_value)
                            if (!(s1 == null))
                                list1.add(s1);
                        Field_value = list1.toArray(new String[list.size()]);
                        System.out.println();
                        String[] ActualFieldname = new String[Field_name.length];
                        String[] ActFieldname = new String[Field_value.length];
                        int l = 0;

                        int[] OrdPos = new int[Field_name.length];
                        for (l = 0; l < Field_name.length; l++) {
                            int CharPos = Field_name[l].indexOf(':');
                            if (CharPos != -1) {
                                ActualFieldname = Field_name[l].split(":");
                                ActFieldname[l] = ActualFieldname[0];
                            } else {
                                ActFieldname[l] = Field_name[l];
                            }

                        }
                        try {

                            Class.forName("org.h2.Driver");
                        } catch (ClassNotFoundException e) {

                        }

                        System.out.println("Connecting to database...");
                        try {
                            System.out.println(DB_URL);
                            conn = DriverManager.getConnection(DB_URL, USER, PASS);
                        } catch (SQLException e) {
                            System.out.println(e);

                        }

                        System.out.println("Creating statement...");
                        try {
                            stmt = conn.createStatement();
                        } catch (SQLException e) {

                        }
                        String record = null;
                        int StrLeng = Table_name.length();

                        int StrFileName = Table_name.indexOf('.');
                        String AppNAme = Table_name.substring(StrFileName + 1, StrLeng);
                        int NAUreplace = AppNAme.indexOf('$');
                        if (NAUreplace >= 0) {
                            AppNAme = AppNAme.substring(0, NAUreplace);
                        }
                        System.out.println("SS NAME " + AppNAme);

                        String sql1 = "SELECT  * FROM F_STANDARD_SELECTION WHERE RECID = '" + AppNAme + "'";
                        ResultSet rs = null;
                        try {
                            rs = stmt.executeQuery(sql1);
                        } catch (SQLException se) {

                            System.out.println("Invalid application");
                            se.printStackTrace();
                        }
                        while (rs.next()) {
                            record = rs.getString("STRRECORD");
                        }
                        if (record == null) {
                            System.out.println("invalid application");

                        }
                        rs.close();
                        String aChar = null;
                        String bChar = null;
                        String cChar = null;
                        String[] FieldNameSS = null;
                        String[] UserFieldNameSS = null;
                        String[] FieldPosSS = null;
                        String[] UserFieldPosSS = null;
                        String[] PosField = null;
                        String[] localpos = new String[100];

                        if (record != null) {
                            int FM = 63742;
                            aChar = new Character((char) FM).toString();
                            SplitRecord = record.split(aChar);
                            int VM = 63741;
                            bChar = new Character((char) VM).toString();
                            int SM = 63740;
                            cChar = new Character((char) SM).toString();
                            FieldNameSS = SplitRecord[0].split(bChar);
                            FieldPosSS = SplitRecord[2].split(bChar);
                            UserFieldNameSS = SplitRecord[14].split(bChar);
                            UserFieldPosSS = SplitRecord[16].split(bChar);
                            PosField = new String[ActFieldname.length];
                            int userpos;
                            for (int n = 0; n < ActFieldname.length; n++) {
                                int pos = Arrays.asList(FieldNameSS).indexOf(ActFieldname[n]);
                                if (pos == -1) {
                                    userpos = Arrays.asList(UserFieldNameSS).indexOf(ActFieldname[n]);
                                    if (userpos == -1) {
                                        System.out.println("invalid field");
                                        PosField[n] = "invalid field";
                                    } else {
                                        // PosField[n]=
                                        // Arrays.asList(FieldNameSS).indexOf(localpos[0]);
                                        System.out.println("userpos" + userpos);
                                        System.out.println("UserFieldNameSS" + UserFieldNameSS[userpos]);
                                        System.out.println("userposition" + UserFieldPosSS[userpos]);
                                        localpos[n] = UserFieldPosSS[userpos];
                                        pos = Arrays.asList(FieldNameSS).indexOf("LOCAL.REF");
                                        PosField[n] = FieldPosSS[pos];
                                        System.out.println("userfield " + PosField[n] + userpos);
                                    }
                                } else {
                                    localpos[n] = "0";
                                    PosField[n] = FieldPosSS[pos];
                                }
                            }
                        }
                        ResultSet rs1 = null;
                        String Record1 = null;
                        if (record != null) {

                            try {
                                ResultSet tablers = null;
                                String sqltable = "SELECT ORCLFILENAME FROM TAFJ_VOC WHERE RECID = '" + Table_name
                                        + "'";
                                System.out.println("VOC SQL" + sqltable);
                                tablers = stmt.executeQuery(sqltable);
                                tablers.next();
                                System.out.println("oracle file name " + tablers.getString("ORCLFILENAME"));
                                String Sqlexe = "SELECT STRRECORD FROM \"" + tablers.getString("ORCLFILENAME")
                                        + "\" WHERE RECID = '" + RECID + "'";
                                rs1 = stmt.executeQuery(Sqlexe);

                                while (rs1.next()) {
                                    Record1 = rs1.getString("STRRECORD");
                                }
                            } catch (SQLException se) {

                                System.out.println("Invalid record ID");
                                se.printStackTrace();
                            }
                        }

                        if (Record1 == null) {
                            System.out.println("invalid record");

                        }
                        System.out.println(Record1);
                        if (Record1 != null && record != null) {
                            String[] ActFldVal = new String[Field_value.length];
                            String[] SplitRecord1 = Record1.split(aChar);
                            for (int p = 0; p < Field_name.length; p++) {
                                String[] FieldDiv;
                                String ACtualFieldvalue = null;
                                FieldDiv = Field_name[p].split("\\:");
                                if (localpos[p].contains("LOCAL.REF")) {
                                    FieldDiv[1] = localpos[p].substring(localpos[p].lastIndexOf(",") + 1,
                                            localpos[p].indexOf(">"));
                                    System.out.println("inside userpos" + FieldDiv[1]);
                                }

                                int counter = FieldDiv.length - 1;
                                if (counter == 2 && !(PosField[p].equals("invalid field"))) {
                                    System.out.println("inside 2");
                                    int FmPOS = Integer.parseInt(PosField[p]);
                                    ACtualFieldvalue = SplitRecord1[FmPOS - 1];
                                    System.out.println("local value " + ACtualFieldvalue);
                                    String[] FieldValVm = ACtualFieldvalue.split(bChar);
                                    int VmPOS = Integer.parseInt(FieldDiv[1]);
                                    ACtualFieldvalue = FieldValVm[VmPOS - 1];
                                    String[] FieldValSm = ACtualFieldvalue.split(cChar);

                                    int SmPOS = Integer.parseInt(FieldDiv[2]);
                                    ACtualFieldvalue = FieldValSm[SmPOS - 1];
                                    ActFldVal[p] = ACtualFieldvalue;
                                } else if (counter == 1 && !(PosField[p].equals("invalid field"))) {
                                    System.out.println("inside 1");
                                    int FmPOS = Integer.parseInt(PosField[p]);
                                    ACtualFieldvalue = SplitRecord1[FmPOS - 1];
                                    String[] FieldValVm = ACtualFieldvalue.split(bChar);
                                    int VmPOS = Integer.parseInt(FieldDiv[1]);
                                    ACtualFieldvalue = FieldValVm[VmPOS - 1];
                                    ActFldVal[p] = ACtualFieldvalue;
                                } else if (!(PosField[p].equals("invalid field"))) {
                                    System.out.println("inside 0");
                                    int FmPOS = Integer.parseInt(PosField[p]);
                                    ACtualFieldvalue = SplitRecord1[FmPOS - 1];
                                    ActFldVal[p] = ACtualFieldvalue;
                                }
                            }

                            nextRow1.createCell(0).setCellValue("T24");
                            nextRow1.createCell(1).setCellValue(Checkpoint);

                            nextRow1.createCell(2).setCellValue(Test_case);
                            nextRow1.createCell(3).setCellValue(Table_name);
                            nextRow1.createCell(4).setCellValue(RECID);
                            arr1[0] = "T24";
                            arr1[1] = Checkpoint;
                            arr1[2] = Test_case;
                            arr1[3] = Table_name;
                            arr1[4] = RECID;
                            arr1[5] = "No Error";

                            d1.WriteReportHeader(arr1);
                            String arr2[] = new String[8];
                            for (j = 0; j < i; j++) {
                                String temp = Field_name[j];

                                Cell celltowritefieldname = nextRow1.createCell(4 * (j + 1) + 2);
                                System.out.println(Field_value[j]);
                                Cell celltowriteexpectedvalue = nextRow1.createCell(4 * (j + 1) + 3);
                                Cell celltowriteactualvalue = nextRow1.createCell(4 * (j + 1) + 4);
                                Cell celltowritecomments = nextRow1.createCell(4 * (j + 1) + 5);
                                celltowritefieldname.setCellValue(Field_name[j]);
                                celltowriteexpectedvalue.setCellValue(Field_value[j]);
                                celltowriteactualvalue.setCellValue(ActFldVal[j]);
                                arr2[0] = Field_name[j];
                                arr2[1] = Field_value[j];
                                arr2[3] = "No Error";
                                arr2[2] = "";
                                if (!(PosField[j].equals("invalid field"))) {
                                    arr2[2] = ActFldVal[j];

                                    if (!ActFldVal[j].equals(Field_value[j]))

                                    {
                                        checksum.Teststatusflag = false;
                                        DASHBOARD.Currentfieldstatus = "fail";
                                        DASHBOARD.Currentteststatus = "fail";
                                        checksum.teststatus = "fail";
                                        Demo1.gbTestCaseStatus = "Fail";
                                        String Err = "Error in " + Field_name[j] + " Expected Not Equal to Actual "
                                                + ActFldVal[j] + " != " + Field_value[j];
                                        System.out
                                                .println("Error in " + Field_name[j] + " Expected Not Equal to Actual "
                                                        + ActFldVal[j] + " != " + Field_value[j]);

                                        Cell celltowrite = nextRow.createCell(2 * i + j + 3);

                                        celltowrite.setCellValue(Err);
                                        celltowritecomments.setCellValue(Err);
                                        arr2[3] = Err;
                                        System.out.println(celltowrite.getStringCellValue());

                                    }
                                } else {
                                    checksum.Teststatusflag = false;
                                    DASHBOARD.Currentfieldstatus = "fail";
                                    Demo1.gbTestCaseStatus = "Fail";
                                    DASHBOARD.Currentteststatus = "fail";
                                    checksum.teststatus = "fail";
                                    arr2[3] = "Invalid Field name '" + Field_name[j] + "' in" + Table_name;
                                    celltowritecomments.setCellValue(
                                            "Invalid Field Name '" + Field_name[j] + "' in " + Table_name);

                                }
                                d1.reportbody(arr2);

                            }

                        } else {
                            checksum.Teststatusflag = false;
                            DASHBOARD.Currentteststatus = "fail";
                            Demo1.gbTestCaseStatus = "Fail";

                            if (record == null) {
                                checksum.teststatus = "fail";

                                arr1[5] = "Invalid '" + Table_name + "' T24 TABLE";
                            } else if (Record1 == null) {
                                checksum.teststatus = "fail";

                                arr1[5] = "Record '" + RECID + "' not found in " + Table_name;
                            }
                            nextRow1.createCell(0).setCellValue("T24");
                            nextRow1.createCell(1).setCellValue(Checkpoint);

                            nextRow1.createCell(2).setCellValue(Test_case);
                            nextRow1.createCell(3).setCellValue(Table_name);
                            nextRow1.createCell(4).setCellValue(RECID);
                            nextRow1.createCell(5).setCellValue(arr1[5]);
                            arr1[0] = "T24";
                            arr1[1] = Checkpoint;
                            arr1[2] = Test_case;
                            arr1[3] = Table_name;
                            arr1[4] = RECID;

                            d1.WriteReportHeader(arr1);
                        }
                        d1.reportclose();
                        String[] reportbody = new String[6];
                        reportbody[0] = "T24";
                        reportbody[1] = checkpointtestdata;
                        reportbody[2] = Test_case;
                        reportbody[3] = Table_name;
                        reportbody[4] = RECID;
                        DASHBOARD.testcasecount = DASHBOARD.testcasecount + 1;
                        reportbody[5] = Integer.toString(DASHBOARD.testcasecount);
                        if (args[0].contains("NEGATIVE")) {
                            if (DASHBOARD.Currentteststatus.equals("fail")) {
                                DASHBOARD.Currentteststatus = "";
                            } else if (DASHBOARD.Currentteststatus.equals("")) {
                                DASHBOARD.Currentteststatus = "fail";
                            }
                        }
                        d3.DBreportindexbody(reportbody);
                        if (rs1 != null) {
                            rs1.close();
                            stmt.close();
                            conn.close();

                        }

                    }

                    inputStream.close();

                }
                d3.indexDBclose();
                Workbook workbook2 = new XSSFWorkbook();
                workbook2 = workbook1;

                FileOutputStream fos = new FileOutputStream(outexcelFilePath, true);
                workbook2.write(fos);
                workbook2.close();
                workbook1.close();
            } catch (NoSuchElementException ex) {
                DASHBOARD.Currentteststatus = "Warn";
                DASHBOARD.Currentfieldstatus = "Warn";
                Demo1.gbTestCaseStatus = "Warn";
                Demo1.TestStepWarningCount = Demo1.TestStepWarningCount + 1;
                Demo1.logger.warn("Warning in " + Demo1.gbCurrTestCaseName + "  --->" + ex);
                System.out.println(ex);
                ex.printStackTrace();

            } catch (IllegalStateException ex) {
                DASHBOARD.Currentteststatus = "Warn";
                DASHBOARD.Currentfieldstatus = "Warn";
                Demo1.gbTestCaseStatus = "Warn";
                Demo1.TestStepWarningCount = Demo1.TestStepWarningCount + 1;
                Demo1.logger.warn("Warning in " + Demo1.gbCurrTestCaseName + "  --->" + ex.getStackTrace());
                System.out.println(ex);

            }
        }
        if (!checksum.checksumvariable) {
            Demo1.Linkflag = true;
            if (Demo1.gbTestCaseStatus.equals("Warn")) {
                Demo1.SCBindexpage = "..\\..\\logs\\application.html";
                Demo1.ReportStep(2, "<b>T24 DB CHECK</b>", args[0], Demo1.gbTestCaseStatus);
                System.out.println("ReportStep");
            } else if (!DBconnect) {
                Demo1.Linkflag = false;
                Demo1.ReportStep(2, "<b>T24 DB CHECK</b>", args[0],
                        "Problem with Connection, Correct your T24 DB URL & DB Credential");
                System.out.println("ReportStep");
            } else {
                Demo1.SCBindexpage = indexinformation[0];
                if (args[0].contains("NEGATIVE")) {
                    if (Demo1.gbTestCaseStatus.equals("Pass")) {
                        Demo1.gbTestCaseStatus = "Fail";
                    } else if (Demo1.gbTestCaseStatus.equals("Fail")) {
                        Demo1.gbTestCaseStatus = "Pass";
                    }
                }
                Demo1.ReportStep(2, "<b>T24 DB CHECK</b>", args[0], Demo1.gbTestCaseStatus);
                System.out.println("ReportStep");
            }
        }

    }

    public static void ExecuteComponent() throws Exception {

        String[] paramArr = Demo1.arrParameters;
        try {
            main(paramArr);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
