package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class SelectOptionByIndex {
	static String dropdownName;
	static int index=0;
	/**
	 * @param args
	 * itemToSelect
	 * dropdownName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() {
		try{
			By by=null;
			String[] paramArr=Demo1.arrParameters;
			dropdownName=paramArr[0];
			index=Integer.parseInt(paramArr[1].trim());
			by=Reuse.GetLocator(paramArr[2]);

			if(Demo1.arrParameters.length==4 && Demo1.arrParameters[Demo1.arrParameters.length-1].trim().equalsIgnoreCase("OPTIONAL")){
				Reuse.SelectOptionByIndex(dropdownName,index,by,true);
			}else{
				Reuse.SelectOptionByIndex(dropdownName, index, by);

			}
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Select <b> Index "+index+"</b> from <b>"+dropdownName+"</b> dropdown","Should be select <b> index "+index+"</b>",e.getMessage());
		}
	}
}
