package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class ClickIf_OR_NOT_ElementDisplayed {
	static String elementName1,elementName2,elementwait;
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	
	public static void ExecuteComponent() throws Exception {
		By by1,by2;
		try{
			String[] paramArr = Demo1.arrParameters;
			elementName1 = paramArr[0];
			elementName2 = paramArr[1];
			by1 = Reuse.GetLocator(paramArr[2]);
			by2 = Reuse.GetLocator(paramArr[3]);
			elementwait=paramArr[4];
			
			Reuse.ClickIf_OR_NOT_ElementDisplayed(elementName1,elementName2,by1,by2,Integer.parseInt(elementwait));
		}catch(Exception e){
			Demo1.logger.error("Element is not identified"+e);
			e.printStackTrace();
		}
	}

}
