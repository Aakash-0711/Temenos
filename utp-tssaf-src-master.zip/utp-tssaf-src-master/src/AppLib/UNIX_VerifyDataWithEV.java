package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.ExternalConnection;

public class UNIX_VerifyDataWithEV{
	static String parameters,locatorType,locator,elementType,elementName,action,command,expectedValue;
	/**
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			By by=null;
			String[] paramArr=Demo1.arrParameters;
			command=paramArr[0];
			action=paramArr[1];
			expectedValue=paramArr[2];

			if(action.equals("EQUALS")){
                ExternalConnection.unix_VerifyDataEqualsFromUnix(command, expectedValue);
            }else if(action.equals("NOT_EQUALS")){
                ExternalConnection.unix_VerifyDataNotEqualsFromUnix(command, expectedValue);
            }else if(action.equals("CONTAINS")){
                ExternalConnection.unix_VerifyDataContainsFromUnix(command, expectedValue);
            }


		}catch(Exception e){
			Demo1.logger.error("Problem in Action class");
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, action+" <b>"+elementName+"</b>"+elementType,"Should be "+action+" <b>"+elementName+"</b> "+elementType,"Unable to locate <b>"+elementName+"</b> "+elementType);
		}
	}
}
