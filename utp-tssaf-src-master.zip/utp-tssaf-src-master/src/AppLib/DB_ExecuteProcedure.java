package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.ExternalConnection;

public class DB_ExecuteProcedure{
	static String parameters,locatorType,locator,elementType,elementName,action,procedureName,expectedValue,variableName,url,path;
	/**
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			By by=null;
			String[] paramArr=Demo1.arrParameters;
			url=paramArr[0];
			procedureName=paramArr[1];
			parameters=paramArr[2];



			ExternalConnection.dB_ExecuteProcedure(url, procedureName, parameters );


		}catch(Exception e){
			Demo1.logger.error("Problem in Action class");
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, action+" <b>"+elementName+"</b>"+elementType,"Should be "+action+" <b>"+elementName+"</b> "+elementType,"Unable to locate <b>"+elementName+"</b> "+elementType);
		}
	}
}
