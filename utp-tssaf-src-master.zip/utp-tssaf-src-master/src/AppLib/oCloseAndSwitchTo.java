package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class oCloseAndSwitchTo {
	static String windowToClose,windowToFocus,parameters;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent(){
		String[] paramArr=Demo1.arrParameters;
		try{
			Thread.sleep(5000);
			for(String winHandle : Demo1.driver.getWindowHandles()){
				Reuse.log(Demo1.driver.switchTo().window(winHandle).getTitle());
			}
			windowToClose=paramArr[0];
			windowToFocus=paramArr[1];
			boolean done = false;
			for(String winHandle : Demo1.driver.getWindowHandles()){
				if(Demo1.driver.switchTo().window(winHandle).getTitle().equals(windowToClose)){
					Demo1.driver.switchTo().window(winHandle);
					Demo1.driver.close();
					for(String winHandl : Demo1.driver.getWindowHandles()){
						if(Demo1.driver.switchTo().window(winHandl).getTitle().equals(windowToFocus)){
							done = true;
							Demo1.driver.switchTo().window(winHandl);
							break;
						}
					}
				}
			}

			if(!done){
			    Thread.sleep(5000);
                for(String winHandle : Demo1.driver.getWindowHandles()){
                    Reuse.log(Demo1.driver.switchTo().window(winHandle).getTitle());
                }
                for(String winHandle : Demo1.driver.getWindowHandles()){
                    if(Demo1.driver.switchTo().window(winHandle).getTitle().equals(windowToClose)){
                        Demo1.driver.switchTo().window(winHandle);
                        Demo1.driver.close();
                        for(String winHandl : Demo1.driver.getWindowHandles()){
                            if(Demo1.driver.switchTo().window(winHandl).getTitle().equals(windowToFocus)){
                                done = true;
                                Demo1.driver.switchTo().window(winHandl);
                                break;
                            }
                        }
                    }
                }
            }

            if(!done){
                Reuse.log(windowToClose+" Window not found");
            }
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}
