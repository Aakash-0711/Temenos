package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class ClickIf {
	static String elementType,elementName,condition;
	/**
	 * @param args
	 * elementType
	 * elementName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{

		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			elementType=paramArr[0];
			elementName=paramArr[1];
			condition=paramArr[2];
			by=Reuse.GetLocator(Reuse.getValueOfRunTimeVariables(paramArr[3]));
			Reuse.ClickIf(by,elementType,elementName,condition);
		}catch(Exception e){
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Click "+elementType+" <b>"+elementName +"</b>",""+elementType+" <b>"+elementName +"</b> should get clicked","Unable to locate "+elementType+" <b>"+elementName+"</b>");
		}
	}
}
