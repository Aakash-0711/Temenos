package AppLib;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;

import Driver.Config;
import Driver.Demo1;
import Driver.Reuse;

public class StoreText {
    public static Map<String, String> txtAndVal = null;
    public static Boolean isMapInitialized = false;
    static String parameters, locatorType, locator, variableName, elementName, action = "";

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        ExecuteComponent();
    }

    public static void ExecuteComponent() {
          action = "";
        By by = null;
        String[] paramArr = Demo1.arrParameters;
        try {
            variableName = paramArr[0];
            elementName = paramArr[1];
            if (paramArr.length == 4) {
                action = paramArr[3];
            }
            by = Reuse.GetLocator(paramArr[2]);
//            Reuse.waitForTextToAppear(by);
            oStoreText(by, variableName, elementName);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }


    public static void oStoreText(By by, String variableName, String elementName) {

        try {
            if (!isMapInitialized) {
                txtAndVal = new HashMap<>();
                isMapInitialized = true;
            }

            String eleText = null;

            if(Demo1.envName.equalsIgnoreCase("MOBILEAPP")){
                eleText = Demo1.driver1.findElement(by).getText();
                if (eleText != null & eleText.trim().isEmpty()) {
                    eleText = Demo1.driver1.findElement(by).getAttribute("text");
                    if (eleText == null) {
                        eleText = "";
                    }
                }
            }
            else {

             eleText = Demo1.driver.findElement(by).getText();
            if (eleText != null & eleText.trim().isEmpty()) {
                eleText = Demo1.driver.findElement(by).getAttribute("value");
                if (eleText == null) {
                    eleText = "";
                }
            }
            }

            if (eleText != null) {
                if (!txtAndVal.containsKey(variableName) || Config.Mode.toUpperCase().contains("RUNTIME")) {
                   String strProcessed =  Reuse.getProcessedString(action,eleText.trim());
                    txtAndVal.put(variableName, strProcessed);
                    Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, "Store text <b>" + eleText + "</b> in <b>" + variableName + "</b> variable", "Text <b>" + eleText + "</b> should be stored in <b>" + variableName + "</b> variable", "Stored");

                } else {
                    Demo1.gbTestCaseStatus = "Fail";
                    Demo1.ReportStep(2, "Store text <b>" + eleText + "</b> in <b>" + variableName + "</b> variable", "Text <b>" + eleText + "</b> should be stored in <b>" + variableName + "</b> variable", "Provided variable <b>" + variableName + " already exist. Kindly provide some other variable name.");
                }
            } else {
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Store text <b>" + eleText + "</b> in <b>" + variableName + "</b> variable", "Text <b>" + eleText + "</b> should be stored in <b>" + variableName + "</b> variable", "Unable to get text from <b>" + elementName + "</b>");
            }

        } catch (Exception e) {
        	e.printStackTrace();
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Store text in <b>" + variableName + "</b> variable", "Text should be stored in <b>" + variableName + "</b> variable", e.getMessage());
        }
    }
}
