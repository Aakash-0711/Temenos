package AppLib;

import java.io.IOException;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class oRadioButton_Select {
	static String parameters,locatorType,locator,radioButtonName;
	/**
	 * @param args
	 * radioButtonName
	 * locator
	 * @throws IOException
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			radioButtonName=paramArr[0];
			by=Reuse.GetLocator(paramArr[1]);

			Reuse.RadioButton_Select(by,radioButtonName);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Select RadioButton <b>"+radioButtonName+"</b>","Should be able to select RadioButton <b>"+radioButtonName+"</b>","Unable to locate radiobutton <b>"+radioButtonName+"</b>");
		}
	}
}
