package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class Date {
    static String elementName, dateFormat, action, daysCount, runTimeVariableName, scheduledDaysCount,zone;

    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        // TODO Auto-generated method stub
        ExecuteComponent();
    }

    public static void ExecuteComponent() throws Exception {
        try {
            boolean dateMMM = false;
            By by = null;
            String[] paramArr = Demo1.arrParameters;
            elementName = paramArr[0];
            dateFormat = paramArr[1].trim();
            action = paramArr[2].trim();
            
            String elementLocator = paramArr[3];
            by = Reuse.GetLocator(elementLocator);
            if (dateFormat.contains("MMM")) {
                dateMMM = true;
            }
            String text = Reuse.dateFormat(dateFormat);
            
            if(paramArr.length == 5){
                zone = paramArr[4];
                text = Reuse.dateFormat(dateFormat,zone);
            }
            
            if(paramArr.length == 7){
                if(paramArr[4].isEmpty()){
                    daysCount = "0";
                }else{
                    daysCount = paramArr[4];
                }
                
                runTimeVariableName = paramArr[5];
                scheduledDaysCount = paramArr[6];
            }
            
            
//			//Verify_TextPresent_IgnoreCase
            if (action.equals("DATE_PRESENT")) {
                if (dateMMM) {
                    Reuse.Verify_TextPresent_IgnoreCase(by, text, elementName);

                } else {
                    Reuse.Verify_TextPresent(by, text, elementName);
                }
            } else if (action.equals("DATE_NOT_PRESENT")) {
                Reuse.Verify_TextNotPresent(by, text, elementName);
            } else if (action.equals("DATE_CONTAINS")) {
                Reuse.Verify_TextContains(by, text, elementName);
            } else if (action.equals("DATE_NOT_CONTAINS")) {
                Reuse.Verify_TextNotContains(by, text, elementName);
            } else if (action.startsWith("SET_DATE")) {
            	
            	if(action.equals("SET_DATE")) {
            		Reuse.TextBox_InputText(by, text, elementName);
            	}else if(action.equals("SET_DATE+1")) {
            		String dte = Reuse.dateFormat(dateFormat, 1, "ADD");
            		Reuse.TextBox_InputText(by, dte, elementName);
            	}
                
            } else if (action.equals("STORE_DATE")) {             //newly added to store date values
                Reuse.storeManipulatedApplicationDate(by, dateFormat, elementName, daysCount, runTimeVariableName);
            } else if (action.equals("STORE_EFFECTIVE_SCHEDULED_DATE")) {             //to store effective scheduled date value
                
                /*String monthDaysStringLocator = "xpath=//span[@script-id='VerHOLIDAY.MTH_MONTH-INDEX_TABLE.VALUE']";*/
                
                Reuse.storeEffectiveScheduledDate(runTimeVariableName, dateFormat, elementLocator, scheduledDaysCount);
            }
            else if(action.equals("SET_CUSTOMDATE")) {
            	runTimeVariableName = paramArr[5];
            	String date = Reuse.customDateFormat(dateFormat, Integer.parseInt(paramArr[4]), runTimeVariableName);
            	Reuse.TextBox_InputText(by, date, elementName);
            }
            else if(action.equals("SET_CUSTOMTIME")) {
            	zone = paramArr[5];
            	String time = Reuse.customTimeFormat(dateFormat, Integer.parseInt(paramArr[4]), zone);
            	Reuse.TextBox_InputText(by, time, elementName);
            }
            else if(action.equals("SET_CURRENTDATE")) {
            	String dte = Reuse.dateFormat(dateFormat);
        		Reuse.Shadow_SetText(elementLocator, dte, elementName);
            }
            else if(action.equals("SET_CUSTOMDATEFROMCURRENTDATE")) {
            	String dte = Reuse.dateFormat(dateFormat,Integer.parseInt(paramArr[4]));
        		Reuse.TextBox_InputText(by, dte, elementName);
            }
            else {
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Date format", "Date format <b>" + dateFormat + "</b> should be set ", "Wrong action <b>" + action + "</b>");
            }
        } catch (Exception e) {
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Date format", "Date format <b>" + dateFormat + "</b> should be set ", e.getMessage());
        }
    }
}
