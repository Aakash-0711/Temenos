package AppLib;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;
import java.util.Properties;

import net.neoremind.sshxcute.core.ConnBean;
import net.neoremind.sshxcute.core.IOptionName;
import net.neoremind.sshxcute.core.Result;
import net.neoremind.sshxcute.core.SSHExec;
import net.neoremind.sshxcute.core.SysConfigOption;
import net.neoremind.sshxcute.exception.TaskExecFailException;
import net.neoremind.sshxcute.task.CustomTask;
import net.neoremind.sshxcute.task.impl.ExecCommand;
import net.neoremind.sshxcute.task.impl.ExecShellScript;

/**
 * TODO: Document me!
 *
 * @author rashishkumar
 *
 */
public class SshExecuteOfs {

    private static boolean executorinitialized;
    private static SSHExec sshExecutor;

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }

    public static String ExecuteComponent(String CreateOfs1) {

        connectSshExecutor();

        Properties prop = new Properties();
        String curDir = System.getProperty("user.dir");
        InputStream input;

        try {
            input = new FileInputStream(curDir + "\\Config\\config.properties");
            prop.load(input);
        } catch (IOException e) {
            System.out.println("Unable to read the config file");
        }

        String TAFJBIN = prop.getProperty("TAFJBIN").trim();

        CustomTask task1 = new ExecCommand("cd " + TAFJBIN);
        CustomTask task2 = new ExecShellScript(TAFJBIN + "/executeofs.sh", CreateOfs1);

        Result r1 = null;
        Result r2 = null;

        try {

            r1 = sshExecutor.exec(task1);

            r2 = sshExecutor.exec(task2);

        } catch (TaskExecFailException e) {

            e.printStackTrace();
        }
        System.out.println("Return code: " + r1.rc);

        String ReturnString = r2.sysout;
        ReturnString = ReturnString.replace("<requests>", "");
        ReturnString = ReturnString.replace("<request>", "");

        System.out.println("Return code: " + r2.rc);

        /*//SSH is disconnected here - newly added line (2-MAY-2019)
        ssh.disconnect();*/

        return ReturnString;
    }

    //this is to establish connection using sshExecutor only for the first time call
    private static void connectSshExecutor() {

        if(! executorinitialized){

            executorinitialized = true;

            Properties prop = new Properties();
            InputStream input;
            String curDir = System.getProperty("user.dir");

            try {
                input = new FileInputStream(curDir + "\\Config\\config.properties");
                prop.load(input);
            } catch (IOException e) {
                System.out.println("Unable to read the config file");
            }

            String host = prop.getProperty("host").trim();
            String user = prop.getProperty("user").trim();
            String password = prop.getProperty("password").trim();

            SSHExec.setOption(IOptionName.HALT_ON_FAILURE, true);
            ConnBean cb = new ConnBean(host, user, password);

            SysConfigOption.INTEVAL_TIME_BETWEEN_TASKS = 1000;

            sshExecutor = SSHExec.getInstance(cb);

            sshExecutor.connect();

            System.out.println("sshExecutor is initialized successfully.");
        }else{

            if(Objects.isNull(sshExecutor)){
                System.out.println("sshExecutor connection was lost.");
                sshExecutor.connect();
                System.out.println("sshExecutor connection is re-initialized successfully.");
            }

        }
    }

    //OLDER APPROACH COMMENTED ON 2-MAY-2019
    /*public static String ExecuteComponent(String CreateOfs1) {
        Properties prop = new Properties();
        String curDir = System.getProperty("user.dir");
        InputStream input;



        try {
            input = new FileInputStream(curDir + "\\Config\\config.properties");
            prop.load(input);
        } catch (IOException e) {
            System.out.println("Unable to read the config file");
        }

        String TAFJBIN = prop.getProperty("TAFJBIN").trim();
        String host = prop.getProperty("host").trim();
        String user = prop.getProperty("user").trim();
        String password = prop.getProperty("password").trim();
        String java_home = prop.getProperty("java_home").trim();
        SSHExec.setOption(IOptionName.HALT_ON_FAILURE, true);
        ConnBean cb = new ConnBean(host,user,password);

        SysConfigOption.INTEVAL_TIME_BETWEEN_TASKS = 1000;

        SSHExec ssh = SSHExec.getInstance(cb);

        CustomTask ct1 = new ExecShellScript(TAFJBIN +"/executeofs.sh",CreateOfs1);
        CustomTask ct2 = new ExecCommand("cd " + TAFJBIN);

        //CustomTask ct3 = new ExecCommand("export JAVA_HOME=" + java_home);
        //CustomTask ct4 = new ExecCommand(TAFJBIN + "/tRun TEST.CHECK GCS '" + CreateOfs1 + "'");

        ssh.connect();

        Result r1 = null;

        //Result r2 = null;
        Result r3 = null;
        try {
            r1 = ssh.exec(ct2);
            //r2=ssh.exec(ct3);
            r3=ssh.exec(ct1);
        } catch (TaskExecFailException e) {
            // TODO Auto-generated catch block
            // Uncomment and replace with appropriate logger
            // LOGGER.error(e, e);
        }
        System.out.println("Return code: " + r1.rc);

        //System.out.println("Return code: " + r2.rc);

        String ReturnString = r3.sysout;
        ReturnString = ReturnString.replace("<requests>", "");
        ReturnString = ReturnString.replace("<request>", "");

        System.out.println("Return code: " + r3.rc);
        return ReturnString;

    }*/

}
