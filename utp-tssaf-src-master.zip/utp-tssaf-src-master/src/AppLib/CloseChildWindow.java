package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class CloseChildWindow{
	/**
	 * @param
	 *
	 *
	 *
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() {
		try{
			Reuse.CloseChildWindow();
		}catch(Exception e){
			Demo1.logger.error("error in CloseChildWindow "+e.getMessage());
		}
	}
}
