package AppLib;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;

import com.google.common.base.Throwables;

import Driver.Demo1;
import Driver.Reuse;

public class WinExecute {
	static String parameters,batFileName,program;
	/**
	 * @param args
	 * itemToSelect
	 * dropdownName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			By by=null;
			String[] paramArr=Demo1.arrParameters;
			program=paramArr[0];
			batFileName=paramArr[1];
			String path=null;
			String   curDir = System.getProperty("user.dir");
 			try{


                 path  = curDir+ File.separator +"Batch"+ File.separator + batFileName;
                 //path  = curDir+ File.separator +"Batch"+ File.separator;
                System.out.println("path of the dir"+path);


                executebatproc(path);


                Demo1.gbTestCaseStatus = "Pass";
			    Demo1.ReportStep(2, "Executing <b>" + program, program+" should be executed successfully",
                    program+":"+batFileName+" has been executed successfully");
			}catch(Exception e){
			    try{
			        System.out.println("Executed in catch");
			        Runtime.getRuntime().exec("cmd /c start " + path);

			        Demo1.ReportStep(2, "Executing <b>" + program, program+" should be executed successfully",
		                    program+":"+batFileName+" has been executed successfully");


			    }catch(Exception e1){

			        try {
			            System.out.println("Executed in catch2");
                        Runtime.getRuntime().exec("cd "+ curDir);
                        Runtime.getRuntime().exec("cmd /c start Batch/"+batFileName );

                        Demo1.ReportStep(2, "Executing <b>" + program, program+" should be executed successfully",
                                program+":"+batFileName+" has been executed successfully");

                    } catch (Exception e2) {
                        Reuse.log(e2);
                        Demo1.gbTestCaseStatus = "Fail";
                        Demo1.ReportStep(2, "Executing <b>" + program, program+" should be executed successfully","Could not trigger"+
                                program+":"+batFileName+"::"+Throwables.getStackTraceAsString(e2));
                    }


			    }
			}
		}catch(Exception e){
            Reuse.log(e);
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Executing <b>" + program, program+" should be executed successfully","Could not trigger"+
                    program+":"+batFileName+"::"+Throwables.getStackTraceAsString(e));
            }
	}



public static void executebatproc(String path) {

    ProcessBuilder processBuilder = new ProcessBuilder(path);

    try {
       Process process = processBuilder.start();


    } catch (IOException e) {
        e.printStackTrace();
    }

}

}