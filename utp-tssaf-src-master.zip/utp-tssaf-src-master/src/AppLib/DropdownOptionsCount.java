package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class DropdownOptionsCount {
	/**
	 * @param args
	 * optionToCheck
	 * dropdownName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			by=Reuse.GetLocator(paramArr[2]);
			Reuse.Dropdown_OptionsCount(Integer.parseInt(paramArr[0]), paramArr[1], by);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check Options count in <b>" + paramArr[1]	+ "</b> dropdown", "The Dropdown "+paramArr[1]+" options count should be matched with the expected count <b>"+Integer.parseInt(paramArr[0])+"</b>",e.getMessage());
		}
	}
}
