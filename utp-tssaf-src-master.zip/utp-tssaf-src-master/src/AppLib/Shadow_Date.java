package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class Shadow_Date {
	static String elementName, dateFormat, action, daysCount, runTimeVariableName, scheduledDaysCount, zone;

	/**
	 * @param args
	 * @throws Exception
	 * @author aakash.manohar
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception {
        try {
            boolean dateMMM = false;
            //By by = null;
            String[] paramArr = Demo1.arrParameters;
            elementName = paramArr[0];
            dateFormat = paramArr[1].trim();
            action = paramArr[2].trim();
            
            String elementLocator = paramArr[3];
           // by = Reuse.GetLocator(elementLocator);
            if (dateFormat.contains("MMM")) {
                dateMMM = true;
            }
            String text = Reuse.dateFormat(dateFormat);
            
            if(paramArr.length == 5){
                zone = paramArr[4];
                text = Reuse.dateFormat(dateFormat,zone);
            }
            
            if(paramArr.length == 7){
                if(paramArr[4].isEmpty()){
                    daysCount = "0";
                }else{
                    daysCount = paramArr[4];
                }
                
                runTimeVariableName = paramArr[5];
                scheduledDaysCount = paramArr[6];
            }
            
            
//			//Verify_TextPresent_IgnoreCase
            if (action.equals("DATE_PRESENT")) {
                if (dateMMM) {
                	Reuse.shadow_Verify_TextContains(elementLocator, text,elementName);

                } else {
                	Reuse.shadow_Verify_TextPresent(elementLocator, text,elementName);
                }
            } else if (action.equals("DATE_NOT_PRESENT")) {
                Reuse.shadow_Verify_TextNotPresent(elementLocator, text, elementName);
            } else if (action.equals("DATE_CONTAINS")) {
                Reuse.shadow_Verify_TextContains(elementLocator, text, elementName);
            } else if (action.equals("DATE_NOT_CONTAINS")) {
                Reuse.shadow_Verify_TextNotPresent(elementLocator, text, elementName);
            } else if (action.startsWith("SET_DATE")) {
            	
            	if(action.equals("SET_DATE")) {
            		Reuse.Shadow_SetText(elementLocator, text, elementName);
            	}else if(action.equals("SET_DATE+1")) {
            		String dte = Reuse.dateFormat(dateFormat, 1, "ADD");
            		Reuse.Shadow_SetText(elementLocator, dte, elementName);
            	}
            }  
            else if(action.equals("SET_CUSTOMDATE")) {
            	runTimeVariableName = paramArr[5];
            	String date = Reuse.customDateFormat(dateFormat, Integer.parseInt(paramArr[4]), runTimeVariableName);
            	Reuse.Shadow_SetText(elementLocator, date, elementName);
            }
            else if(action.equals("SET_CUSTOMTIME")) {
            	zone = paramArr[5];
            	String time = Reuse.customTimeFormat(dateFormat, Integer.parseInt(paramArr[4]), zone);
            	Reuse.Shadow_SetText(elementLocator, time, elementName);
            }
            else if(action.equals("SET_CURRENTDATE")) {
            	String dte = Reuse.dateFormat(dateFormat);
        		Reuse.Shadow_SetText(elementLocator, dte, elementName);
            }
            else if(action.equals("SET_CUSTOMDATEFROMCURRENTDATE")) {
            	String dte = Reuse.dateFormat(dateFormat,Integer.parseInt(paramArr[4]));
            	Reuse.Shadow_SetText(elementLocator, dte, elementName);
            }
            else {
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Date format", "Date format <b>" + dateFormat + "</b> should be set ", "Wrong action <b>" + action + "</b>");
            }
        } catch (Exception e) {
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Date format", "Date format <b>" + dateFormat + "</b> should be set ", e.getMessage());
        }
    }
}
