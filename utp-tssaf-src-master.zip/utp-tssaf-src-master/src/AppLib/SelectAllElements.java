package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class SelectAllElements {
	static String firstRow,firstRowName,lastRow,lastRowName;
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		By by1=null;
		By by2=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			firstRow=paramArr[0];
			firstRowName=paramArr[1];
			lastRow=paramArr[2];
			lastRowName=paramArr[3];
			by1=Reuse.GetLocator(firstRow);
			by2=Reuse.GetLocator(lastRow);
			Reuse.SelectAllElements(by1, firstRowName, by2, lastRowName);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Select all the<b>"+firstRowName+"</b> and <b>"+lastRowName+"</b>","Selection all rows should be done",e.getMessage());
		}
	}
}
