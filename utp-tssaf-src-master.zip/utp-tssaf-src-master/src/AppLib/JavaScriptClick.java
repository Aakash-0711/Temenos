package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class JavaScriptClick {
    static String elementName;

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        ExecuteComponent();
    }

    public static void ExecuteComponent() {

        By by = null;
        String[] paramArr = Demo1.arrParameters;
        try {
            int len = paramArr.length;
            if (len == 2) {
                by = Reuse.GetLocator(paramArr[1]);
                elementName = paramArr[0];
            } else if (len == 3) {
                by = Reuse.GetLocator(paramArr[2]);
                elementName = paramArr[1];
            } else {

                by = Reuse.GetLocator(paramArr[1]);
                elementName = paramArr[0];
            }


            Reuse.JavaScriptClick(elementName, by);
        } catch (Exception e) {
            Demo1.logger.error(e);
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Clicking on element", "Element name:" + elementName, elementName + " has not been clicked");
        }
    }
}
