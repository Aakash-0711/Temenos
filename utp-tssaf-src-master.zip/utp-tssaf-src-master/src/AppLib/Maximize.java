package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class Maximize {

	/**
	 * @param args
	 * timeOutInsec
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			Reuse.Maximize();
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Maximize window","Window should be maximized", e.getMessage());
		}
	}
}
