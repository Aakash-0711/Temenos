package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class Action{
	static String parameters,locatorType,locator,elementType,elementName,action;
	/**
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			By by=null;
			String[] paramArr=Demo1.arrParameters;
			elementType=paramArr[0];
			elementName=paramArr[1];
			action=paramArr[2];
			by=Reuse.GetLocator(paramArr[3]);

		if(action.equals("DOUBLECLICK")){
			Reuse.DoubleClick(by, elementType,elementName);
		}else if(action.equals("MOUSEMOVE")){
			Reuse.mouseMove(by, elementType,elementName);
		}

		}catch(Exception e){
			e.printStackTrace();
			Demo1.logger.error("Problem in Action class");
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, action+" <b>"+elementName+"</b>"+elementType,"Should be "+action+" <b>"+elementName+"</b> "+elementType,"Unable to locate <b>"+elementName+"</b> "+elementType);
		}
	}
}
