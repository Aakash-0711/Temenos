package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class WinWindow {
	static String parameters,windowName,action;
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;
		windowName=paramArr[0];
		action=paramArr[1].trim();
		try{
			if(action.equals("EXIST")){
				Reuse.WinWindowExist(windowName);
			}else if(action.equals("NOT_EXIST")){
				Reuse.WinWindowNotExist(windowName);
			}else if(action.equals("CLOSE")){
				Reuse.WinWindow_Close(windowName);
			}
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Window <b>"+windowName+"</b> action","Window <b>"+windowName+"</b> should be "+action,e.getMessage());
		}
	}
}
