package AppLib;

import static org.apache.commons.lang3.StringEscapeUtils.escapeHtml3;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class CalculateInterest {
    static String principalAmount, rateOfInterest, dayBasis, scheduledDaysCount1, scheduledDaysCount2, principalRepaymentElementLocator;

    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        // TODO Auto-generated method stub
        ExecuteComponent();
    }

    public static void ExecuteComponent() throws Exception {
        try {
            String[] paramArr = Demo1.arrParameters;
            principalAmount = paramArr[0].trim();

            if(principalAmount.contains("auto@")){
                principalAmount = principalAmount.substring(principalAmount.indexOf("auto@") + "auto@".length(), principalAmount.length()-1);
                principalAmount = StoreText.txtAndVal.get(principalAmount);
            }

            rateOfInterest = paramArr[1].trim();
            dayBasis = paramArr[2].trim();
            scheduledDaysCount1 = paramArr[3].trim();

            if(scheduledDaysCount1.contains("auto@")){
                scheduledDaysCount1 = scheduledDaysCount1.substring(scheduledDaysCount1.indexOf("auto@") + "auto@".length(), scheduledDaysCount1.length()-1);
                scheduledDaysCount1 = StoreText.txtAndVal.get(scheduledDaysCount1);
            }

            if(paramArr[4].trim().isEmpty()){
                scheduledDaysCount2 = "";
            }else{
                scheduledDaysCount2 = paramArr[4].trim();

                if(scheduledDaysCount2.startsWith("auto@")){
                    scheduledDaysCount2 = scheduledDaysCount2.substring(scheduledDaysCount2.indexOf("auto@") + "auto@".length(), scheduledDaysCount2.length()-1);
                    scheduledDaysCount2 = StoreText.txtAndVal.get(scheduledDaysCount2);
                }
            }

            if(paramArr[5].trim().isEmpty()){
                principalRepaymentElementLocator = "";
            }else{
                principalRepaymentElementLocator = paramArr[5].trim();
            }

            calculateInterestRateAndVerify(principalAmount, rateOfInterest, dayBasis, scheduledDaysCount1, scheduledDaysCount2, principalRepaymentElementLocator);

        } catch (Exception e) {
            Reuse.log(e);
            Demo1.logger.error(e);
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Interest Calculation", "Expected to calculate interest", e.getMessage());
        }
    }

    public static void calculateInterestRateAndVerify(String principal, String interest, String day, String scheduledDay1, String scheduledDay2, String principalRepaymentLocator) {
        try {


            String principalRepaymentAmountParsed = "";
            if(! principalRepaymentLocator.isEmpty()){
                By by = Reuse.GetLocator(principalRepaymentLocator);
                Reuse.waitForTextToAppear(by);
                String actualText = Demo1.driver.findElement(by).getText();
                if (actualText != null & actualText.trim().isEmpty()) {
                    actualText = Demo1.driver.findElement(by).getAttribute("value");
                    if (actualText == null) {
                        actualText = "";
                    }
                }
                actualText = escapeHtml3(actualText);
                actualText = actualText.replace(",", "");

                Reuse.log("actualText :" + actualText);
                principalRepaymentAmountParsed = actualText;
                System.out.println("ACTUAL TEXT:::" +  actualText);
            }

            double interestRate = 0.0;

            interestRate = Double.parseDouble(principal) - (principalRepaymentAmountParsed.isEmpty() ? 0.0 : Double.parseDouble(principalRepaymentAmountParsed));

            int index = 0;

            do{
                index++;
                if(!StoreText.txtAndVal.containsKey("STORED_INTEREST" + index)){
                    StoreText.txtAndVal.put("STORED_INTEREST" + index, Double.toString(interestRate));
                    System.out.println("STORED VARIABLE:::" + "STORED_INTEREST" + index);
                    index = -1;
                }

            }while(index > 0);

            interestRate = interestRate * Double.parseDouble(interest);

            double daysFound = Double.parseDouble(day) * 100;

            interestRate = interestRate / daysFound;

            int scheduledDaysParsed = Integer.parseInt(scheduledDay1) - (scheduledDay2.isEmpty()? 0 : Integer.parseInt(scheduledDay2));

            interestRate = interestRate * scheduledDaysParsed;

            interestRate = round(interestRate, 2);

            index = 0;

            do{
                index++;
                if(!StoreText.txtAndVal.containsKey("INTEREST_AMOUNT" + index)){
                    StoreText.txtAndVal.put("INTEREST_AMOUNT" + index, Double.toString(interestRate));
                    System.out.println("INTEREST AMOUNT STORED VARIABLE NAME:::" + "INTEREST_AMOUNT" + index);
                    index = -1;
                }

            }while(index > 0);

            Demo1.gbTestCaseStatus = "Pass";
            Demo1.ReportStep(2, "Interest Calculation", "Expected to calculate interest", "Interest was successfully calculated");

        } catch (Exception e) {
            Reuse.log(e);
            Demo1.logger.error(e);
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Interest Calculation", "Expected to calculate interest", e.getMessage());
        }
    }

    public static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }
}
