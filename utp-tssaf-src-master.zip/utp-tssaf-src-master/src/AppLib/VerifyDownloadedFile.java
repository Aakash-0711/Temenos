package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class VerifyDownloadedFile {
	static String parameters,locatorType,locator,expectedText,elementName,Alphabetcount;
	/**
	 * @param args
	 * expectedText
	 * elementName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{

		By by=null;
		String[] paramArr=Demo1.arrParameters;

		elementName=paramArr[0];
		//elementName=paramArr[1];

		//by=Reuse.GetLocator(paramArr[2]);
		try{
			Reuse.checkIfFileExist();
		}catch(Exception e){
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Downloaded file verification: <b>"+elementName+"<b>","File should be available in the download location"," <b>"+elementName+"</b> File is not avaialble / Exception occured");
		}
	}

}
