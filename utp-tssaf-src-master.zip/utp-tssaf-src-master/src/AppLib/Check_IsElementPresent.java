package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class Check_IsElementPresent {
	static String action,elementName;
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		By by=null;
		try{
			String[] paramArr=Demo1.arrParameters;
			action=paramArr[0].trim();
			elementName=paramArr[1];
			by=Reuse.GetLocator(paramArr[2]);
			Reuse.CheckPoint_IsElementPresent(by,elementName,action);
		}catch(Exception e){
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check Check point for element <b>"+elementName+"</b>", "Element <b>"+elementName+"</b> should be displayed","Unable to locate element or "+e.getMessage());
		}
	}
}
