package AppLib;

import java.io.File;
import java.io.FileWriter;

import Driver.Config;
import Driver.Demo1;
import Driver.Reuse;
import Driver.ReuseT24API;

public class API_GetResponseTime {
	
	/**
	 * @param
	 * elementName
	 *  locator
	 * @throws Exception
	 * @author aakash.manohar
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception{
		try {
		ReuseT24API.API_GetResponseTime();
		
		} catch (Throwable e) {
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "To capture api response time ",
                    "API response time should be captured",
                    "Error capturing response time");
		}
	}

}
