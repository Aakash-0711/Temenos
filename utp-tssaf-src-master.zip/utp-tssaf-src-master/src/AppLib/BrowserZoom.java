package AppLib;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import Driver.Demo1;
import Driver.Reuse;

public class BrowserZoom {
    static String zoomType;

    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        // TODO Auto-generated method stub
        ExecuteComponent();
    }

    public static void ExecuteComponent() throws Exception {
        try {
            String[] paramArr = Demo1.arrParameters;
            zoomType = paramArr[0].trim();

            if(zoomType.equals("IN"))   //this will increase the Browser Zoom percentage by 10%
                Demo1.driver.findElement(By.tagName("html")).sendKeys(Keys.chord(Keys.CONTROL, Keys.ADD));
            else if(zoomType.equals("OUT")) //this will decrease the Browser Zoom percentage by 10%
                Demo1.driver.findElement(By.tagName("html")).sendKeys(Keys.chord(Keys.CONTROL, Keys.SUBTRACT));
            else if(zoomType.equals("DEFAULT")) //this will set the Browser Zoom to default 100%
                Demo1.driver.findElement(By.tagName("html")).sendKeys(Keys.chord(Keys.CONTROL, "0"));

            Demo1.gbTestCaseStatus = "Pass";
            Demo1.ReportStep(2, "Browser Zoom", "Expected to zoom " + zoomType + " the Browser", "Browser was successfully zoomed " + zoomType);

        } catch (Exception e) {
        	e.printStackTrace();
            Reuse.log(e);
            Demo1.logger.error(e);
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Browser Zoom", "Expected to zoom " + zoomType + " the Browser", e.getMessage());
        }
    }
}
