package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class MOB_ScreenOrientation{
	static String action;
	/**
	 * @param
	 *  elementType
	 *  elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{

		String[] paramArr=Demo1.arrParameters;
		action=paramArr[0];

		if(action.equals("LANDSCAPE")){
			Reuse.MOB_Screen_Orientation_Lan();
		}else if(action.equals("PORTRAIT")){
			Reuse.MOB_Screen_Orientation_Pot();
		}
	}
}
