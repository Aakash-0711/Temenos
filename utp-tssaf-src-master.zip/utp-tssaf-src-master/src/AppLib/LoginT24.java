package AppLib;

import org.openqa.selenium.By;

import Driver.Config;
import Driver.Demo1;
import Driver.Reuse;

public class LoginT24 {
	static String url,userName,password;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public static void ExecuteComponent() {
				
		String[] paramArr=Demo1.arrParameters;
		String appUrl = "";

		try{
			url=paramArr[0];
			userName=paramArr[1];
			password=paramArr[2];

			url = paramArr[0];
//			if (url.equalsIgnoreCase("Config.URL")) {
//				appUrl = Config.appURL;
//				Demo1.pingURL = appUrl;
//				Demo1.driver.get(appUrl);
//			} else if (url.equalsIgnoreCase("Config.URL1")) {
//				appUrl = Config.appURL1;
//
//				Demo1.pingURL = appUrl;
//				Demo1.driver.get(appUrl);
//			} else if (url.equalsIgnoreCase("Config.URL2")) {
//				appUrl = Config.appURL2;
//
//				Demo1.pingURL = appUrl;
//				Demo1.driver.get(appUrl);
//			} else if (url.equalsIgnoreCase("Config.URL3")) {
//				appUrl = Config.appURL3;
//				Demo1.pingURL = appUrl;
//				Demo1.driver.get(appUrl);
//			}
//			else if (url.equalsIgnoreCase("Config.URL4")) {
//				appUrl = Config.appURL4;
//				Demo1.pingURL = appUrl;
//				Demo1.driver.get(appUrl);
//			}
//			else if (url.equalsIgnoreCase("Config.URL5")) {
//				appUrl = Config.appURL5;
//				Demo1.pingURL = appUrl;
//				Demo1.driver.get(appUrl);
//			}
			if(url.trim().toLowerCase().startsWith("config")) {
				appUrl = Config.getProperty(url.split("[.]")[1]);
				Demo1.pingURL = appUrl;
				Demo1.driver.get(appUrl);
			}
			else {
				Demo1.driver.get(url);
			}




			if(Demo1.driver.getTitle().contains("ERROR")){								
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Launch Application: "+url,url+" should be launched.","URL "+url+" not launched");		
				
			}else{	
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Launch Application: "+url,url+" should be launched.","URL "+url+" launched");
				
				Reuse.TextBox_InputText(By.id("signOnName"), userName,"User Name");
				Reuse.TextBox_InputText(By.id("password"), password,"Password");
				Reuse.Click_Element(By.id("sign-in"), "WebEdit", "SignIn");				
			}		
			//Reuse.SwitchToWindow("T24 Sign in");
			
		}catch(Exception e){
			Demo1.logger.error(e);
		}		
	}
}
