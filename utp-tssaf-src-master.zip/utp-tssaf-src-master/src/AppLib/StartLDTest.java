package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class StartLDTest{
	/**
	 * @param
	 *  elementType
	 *  elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			String[] paramArr=Demo1.arrParameters;
			Reuse.StartLDTest(paramArr[0], paramArr[1]);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Flag to confirm LD Test","Flag should be created","LD Test not completed successfully... more Inof: "+e);
		}
	}
}
