package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class oCaptureBrowserConsoleErrors {
static String logType;

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();

	}

	// Browser console error support only in google chrome

	public static void ExecuteComponent() throws Exception {
		try {
			String[] paramArr=Demo1.arrParameters;
			logType=paramArr[0];
			Reuse.ConsoleLog_Error(logType);
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
