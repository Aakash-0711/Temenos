package AppLib;

import java.io.File;

import Driver.Config;
import Driver.Demo1;
import Driver.Reuse;

public class Verify_TextContainsInFile {
	static String parameters,locatorType,locator,expectedText,path;
	/**
	 * @param args
	 * expectedText
	 * elementName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{

		String[] paramArr=Demo1.arrParameters;
		expectedText=paramArr[0];
		path=paramArr[1];

		try{
			
			if (path.startsWith("userdir")) {
                path = new File(String.valueOf(Demo1.curDir) + path.replaceFirst("userdir", "")).getCanonicalFile()
                        .toString();
                Reuse.log("source path:" + path);
            } else if (path.startsWith("config.applicationserverhomepath")) {
                path = new File(String.valueOf(Config.applicationServerHomePath)
                        + path.replaceFirst("config.applicationserverhomepath", "")).getCanonicalPath().toString();
                Reuse.log("source path:" + path);
            }

		    if(path.endsWith(".pdf"))
		    Reuse.verifyTextContainInPDF(path, expectedText);
		    else
		    Reuse.verifyTextContainInFile(path, expectedText);



		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>"+expectedText+"</b> contains","Should be contains <b>"+expectedText+"</b>","Unable to locate <b>"+path+"</b> element");
		}
	}
}
