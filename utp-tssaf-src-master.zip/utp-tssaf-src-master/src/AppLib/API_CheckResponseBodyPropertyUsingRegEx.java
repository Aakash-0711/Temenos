package AppLib;

import Driver.Config;
import Driver.Demo1;
import Driver.Reuse;
import Driver.ReuseT24API;

public class API_CheckResponseBodyPropertyUsingRegEx {
	static String userName, Password, URL, path, action, key, value, regEx;

	/**
	 * @param elementName locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception {
		String[] paramArr = Demo1.arrParameters;

		key = paramArr[0];
		value = paramArr[1];
		action = paramArr[2];
		regEx = paramArr[3];

		try {

			if (action.equals("EQUALS")) {
				ReuseT24API.API_VerifyjsonPropertyByRegEx(key, value, regEx);
			} else if (action.equalsIgnoreCase("CONTAINS")) {
				ReuseT24API.API_VerifyjsonPropertyContainsByRegEx(key, value,regEx);
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Use property text", "Use property text as: <b>" + action + "</b>",
						"Wrong action <b>" + action + "</b>");
			}

		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To request api ", "API request of " + action + "is should be sent",
					"API request not sent successfully");
		}
	}

}
