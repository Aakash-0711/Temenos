package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class MOB_Element{
	static String elementType,elementName,validation;
	/**
	 * @param
	 *  elementType
	 *  elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() {
		try{
			By by=null;
			String[] paramArr=Demo1.arrParameters;
			elementType=paramArr[0];
			elementName=paramArr[1];
			validation=paramArr[2].trim();
			by=Reuse.GetLocator(paramArr[3]);

			if(validation.equals("EXIST")){

				Reuse.MOB_IsElementPresent(by, elementType, elementName);
			}else if(validation.equals("NOT_EXIST")){

				Reuse.MOB_IsElementNotPresent(by, elementType, elementName);

			}else if(validation.equals("FOCUSED")){
				Reuse.MOB_ElementFocused(by, elementName, elementType);
			}else if(validation.equals("NOT_FOCUSED")){
				Reuse.MOB_ElementNotFocused(by, elementName, elementName);
			}else if(validation.equals("SELECTED")){
				Reuse.MOB_IsElementSelected(by, elementType, elementName);
			}else if(validation.equals("NOT_SELECTED")){
				Reuse.MOB_IsElementNotSelected(by, elementType, elementName);
			}
			else{
				Demo1.gbTestCaseStatus="Fail";
				Demo1.ReportStep(2,"Verify <b>"+elementType+" "+elementName+"</b> present",""+elementName+" should be presented","Validation Option not exist/Having some problem");
			}

		}catch(Exception e){
			if(validation.equals("EXIST")){
				Demo1.gbTestCaseStatus="Fail";
				Demo1.ReportStep(2,"Verify <b>"+elementType+" "+elementName+"</b> exist",""+elementName+" should be exist",e.getMessage());
			}else if(validation.equals("DISPLAYED")){
				Demo1.gbTestCaseStatus="Fail";
				Demo1.ReportStep(2,"Verify <b>"+elementType+" "+elementName+"</b> displayed",""+elementName+" should be displayed",e.getMessage());
			}else if(validation.equals("NOT_EXIST")){
				Demo1.gbTestCaseStatus="Fail";
				Demo1.ReportStep(2,"Verify <b>"+elementType+" "+elementName+"</b> present",""+elementName+" should not be exist",e.getMessage());
			}else if(validation.equals("FOCUSED")){
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check <b>"+elementName+"</b> "+elementType+" focused","<b>"+elementName+"</b> should be focused",e.getMessage());
			}else if(validation.equals("NOT_FOCUSED")){
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check <b>"+elementName+"</b> "+elementType+" not focused","<b>"+elementName+"</b> should not be focused",e.getMessage());
			}else if(validation.equals("SELECTED")){
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check <b>"+elementName+"</b> "+elementType+" selected","<b>"+elementName+"</b> should  be selected",e.getMessage());
			}else if(validation.equals("NOT_SELECTED")){
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check <b>"+elementName+"</b> "+elementType+" not selected","<b>"+elementName+"</b> should not be selected",e.getMessage());
			}
		}
	}
}
