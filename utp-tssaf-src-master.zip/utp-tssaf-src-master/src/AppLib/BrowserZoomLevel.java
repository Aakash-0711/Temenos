package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class BrowserZoomLevel{
	static String eleName,locTyep,locator;
	/**
	 * @param
	 *  elementType
	 *  elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			String[] paramArr=Demo1.arrParameters;
			eleName=paramArr[0];

			Reuse.JavaScriptZoom(eleName);

		}catch(Exception e){
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "zoom on page with <b>"+eleName+"</b>","Should be zoomed with <b>"+eleName+"</b>",e.getMessage());
		}
	}
}
