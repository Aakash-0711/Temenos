package AppLib;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import Driver.Demo1;
import Driver.Reuse;

public class oAuthoriseADeal {

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		String locTxnID=oCommit.txnID;

		Reuse.Click_Element(By.xpath("//img[@title='Authorises a deal']"),"Button","Authorises a deal");
		try{
			WebElement element= Demo1.driver.findElement(By.xpath("//td[@class='message']"));
			if(element.isDisplayed()){
				String str=element.getText();
				if(str.contains("Txn Complete:")){
					String[] splitStr=str.split(" ");
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Trasaction Authorisation validation","Txn should be completed successfull","Txn completed with Txn id: " +splitStr[2]);
				}else{
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Trasaction complete validation","Txn should be completed successfull","Txn not completed");
				}
			}
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Trasaction complete validation","Txn should be completed successfull","Unable to identify element");
		}
	}
}
