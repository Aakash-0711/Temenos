package AppLib;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * TODO: Document me!
 *
 * @author ssandeep
 *
 */
public class Tokenfetch {
	public static String curDir = System.getProperty("user.dir");

	public static void ExecuteComponent() throws Exception

	{

		File path = new File(curDir + "\\Testware\\Testware.xlsx");
		FileInputStream fis = new FileInputStream(path);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet tokensheet = wb.getSheetAt(7);
		int testPlanRowCnt = tokensheet.getLastRowNum();
		// XSSFSheet sheetTestScritp= wb.getSheetAt(2);
		// int testScriptRowCnt=sheetTestScritp.getLastRowNum();
		for (int i = 1; i <= testPlanRowCnt; i++) {
			if (tokensheet.getRow(i).getCell(0) != null) {
				String tokenvariable = tokensheet.getRow(i).getCell(0).getStringCellValue();
				String tokenvalue = tokensheet.getRow(i).getCell(1).getStringCellValue();
				System.out.println("tokenvariable " + tokenvariable);
				System.out.println("tokenvalue " + tokenvalue);

			}

		}
		
		wb.close();
	}

	public static void main(String[] args) {
		try {
			ExecuteComponent();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
