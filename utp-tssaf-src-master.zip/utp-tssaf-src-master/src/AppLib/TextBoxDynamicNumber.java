package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class TextBoxDynamicNumber {
	static String parameters,locatorType,locator,expectedText,elementName,NumberCount;
	/**
	 * @param args
	 * expectedText
	 * elementName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{

		By by=null;
		String[] paramArr=Demo1.arrParameters;
		NumberCount=paramArr[0];
		elementName=paramArr[1];
		by=Reuse.GetLocator(paramArr[2]);
		try{
			Reuse.RandomNumber(NumberCount,elementName,by);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify the Number entered on <b>"+elementName+"<b>","Number Should be entered","Unable to enter Number on <b>"+elementName+"</b>");

		//	Demo1.ReportStep(2, "Verify Random Number generated in <b>"+elementName+"<b>","Should generate Random Number","Unable to generate Random Number in <b>"+elementName+"</b>");
		}
	}

}
