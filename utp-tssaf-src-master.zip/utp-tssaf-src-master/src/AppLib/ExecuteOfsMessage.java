package AppLib;

import Driver.Config;
import Driver.Demo1;
import Driver.Reuse;

public class ExecuteOfsMessage{
    static String applicationName, servicePointUrl, ofsMessage, userName, passWord, outputParams;
    private static String appUrl;
    /**
     * @param
     *  servicePointUrl
     *  userName
     *  passWord
     *  ofsMessage
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        // TODO Auto-generated method stub
        ExecuteComponent();
    }
    public static void ExecuteComponent() throws Exception{

        /*Reuse.ExecuteOfsMessage();*/

        try{

            String[] paramArr = Demo1.arrParameters;

            applicationName = paramArr[0];

            servicePointUrl = paramArr[1];


//            if(servicePointUrl.equals("Config.defaultURL") || servicePointUrl.equals("config.defaultURL")){
//                servicePointUrl = Config.defaultURL;
//                /*System.out.println("URL FOUND:::" + servicePointUrl);*/
//            }
            
            if(servicePointUrl.trim().toLowerCase().startsWith("config")) {
				appUrl = Config.getProperty(servicePointUrl.split("[.]")[1]);
			}
			else {

				appUrl = servicePointUrl;
			}

            userName = paramArr[2];

            passWord = paramArr[3];

            ofsMessage = paramArr[4];

            outputParams = paramArr[5];

            Reuse.ExecuteOfsMessage(applicationName, appUrl, userName, passWord, ofsMessage, outputParams);

        }catch(Exception e){
        	e.printStackTrace();
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Execute OFS msg", "Expected to inject given ofs message ", e.getMessage());
        }
    }
}
