package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class GetValueFromFile {
	static String variable,elementName,action;

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			By by=null;
			String[] paramArr=Demo1.arrParameters;
			variable=paramArr[0];
			elementName=paramArr[1];
			action=paramArr[2].trim();
			by=Reuse.GetLocator(paramArr[3]);

			//String text=StoreText.txtAndVal.get(variableName);
			String text=Reuse.GetPropertyValue(variable);

			if(action.equals("TEXT_PRESENT")){
				Reuse.Verify_TextPresent(by, text,elementName);
			}else if(action.equals("TEXT_NOT_PRESENT")){
				Reuse.Verify_TextNotPresent(by, text, elementName);
			}else if(action.equals("TEXT_CONTAINS")){
				Reuse.Verify_TextContains(by, text, elementName);
			}else if(action.equals("TEXT_NOT_CONTAINS")){
				Reuse.Verify_TextNotContains(by, text, elementName);
			}else if(action.equals("SET_TEXT")){
				Reuse.TextBox_InputText(by, text, elementName);
			}else if(action.equals("APPEND_TEXT")){
				Reuse.TextBox_AppendText(by, text, elementName);
			}else if(action.equals("EQUALS")){
				Reuse.Verify_TextPresent(by, text, elementName);
			}else if(action.equals("CONTAINS")){
			    System.out.println(text+"storedValue");
				Reuse.Verify_TextContains(by, text, elementName);
			}else if(action.equals("NOT_EQUALS")){
				Reuse.Verify_TextNotPresent(by, text, elementName);
			}else if(action.equals("NOT_CONTAINS")){
				Reuse.Verify_TextNotContains(by, text, elementName);
			}else if(action.equals("SELECT_DROPDOWN_CONTAINS")){
				Reuse.dropdownSelectItemContains(by, text, elementName);

			}else{
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Use stored text","Use stored text as: <b>"+action+"</b>","Wrong action <b>"+action+"</b>");
			}
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Get value from file","Should be able to get the value from file",e.getMessage());
		}
	}
}
