package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class oInsertXML_TextArea {

	static String fileName,locator,textBoxName;

	public static void main(String[] args) throws Exception {
		ExecuteComponent();

	}

	public static void ExecuteComponent() throws Exception{
		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			fileName=paramArr[0];
			textBoxName=paramArr[1];
			by=Reuse.GetLocator(paramArr[2]);
			Reuse.oInsertXML_TextArea(fileName,textBoxName, by);
		}catch(Exception e){
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Inserting xmlRoute value in the <b>"+textBoxName+"</b> text box","<b>"+textBoxName+"</b> value should be inserted in text area",e.getMessage());
		}
	}

}
