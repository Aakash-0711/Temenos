package AppLib;

import static org.apache.commons.lang3.StringEscapeUtils.escapeHtml3;

import Driver.Demo1;

public class oReportStep {
	static String parameters,stepName,expectedResult,actualResult;
	static int stepLevel;
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;
		try{
			stepLevel=Integer.parseInt(paramArr[0]);
			stepName= escapeHtml3(paramArr[1]);
			expectedResult= escapeHtml3(paramArr[2]);
			actualResult= escapeHtml3(paramArr[3]);

			String sn="<b>"+stepName+"</b>";

			Demo1.ReportStep(stepLevel,sn,expectedResult,actualResult);
			//Demo1.ReportStep(stepLevel,sn,"","");
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}
