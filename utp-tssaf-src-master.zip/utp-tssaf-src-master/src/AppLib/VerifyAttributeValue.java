package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class VerifyAttributeValue {
	static String parameters,locatorType,locator,attribute,attributeValue,elementType,elementName,validationType;
	/**
	 * @param args
	 * attribute
	 * attributeValue
	 * elementType
	 * elementName
	 * validationType
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{

		By by=null;
		String[] paramArr=Demo1.arrParameters;
		attribute=paramArr[0];
		attributeValue=paramArr[1];
		elementType=paramArr[2];
		elementName=paramArr[3];
		validationType=paramArr[4];
		by=Reuse.GetLocator(paramArr[5]);
		try{
			if(validationType.equals("EXIST")){
				Reuse.VerifyAttributeValueExist(attribute,attributeValue,by,elementName);
			}else if(validationType.equals("NOT_EXIST")){
				Reuse.VerifyAttributeValueNotExist(attribute,attributeValue,by,elementName);
			}else if(validationType.equals("CONTAINS")){
				Reuse.VerifyAttributeValueContains(attribute,attributeValue,by,elementName);
			}else if(validationType.equals("NOT_CONTAINS")){
				Reuse.VerifyAttributeValueNotContains(attribute,attributeValue,by,elementName);
			}

		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Vefify attribute value <b>"+attributeValue+"</b>","Attribute value <b>"+attributeValue+" </b> should be exist","Unable to locate <b> "+elementName+" </b>element");
		}
	}

}
