package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class Alert_Text {
	static String text,action;
	/**
	 * @param
	 * elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;
		text=paramArr[0];
		action=paramArr[1].trim();
		Reuse.Alert_Text(text, action);
	}

}
