package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class oVerify_MultiTextMessages {
	static String parameters,locatorType,locator,textMessages;
	/**
	 * @param args
	 * textMessages - if more than one message, should be separated with ~ operator
	 * locator - if more than one message, should be provided common locator.
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public static void ExecuteComponent() throws Exception{

		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			textMessages=paramArr[0];
			by=Reuse.GetLocator(paramArr[1]);
			Reuse.Verify_MultiMessages(by, textMessages);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Error Message(s)  validation","Should be displayed error message(s)",e.getMessage());
		}
	}
}
