package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class MOB_ScreenSwipe{
	static String action;
	/**
	 * @param
	 *  elementType
	 *  elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{

		String[] paramArr=Demo1.arrParameters;
		action=paramArr[0];

		if(action.equals("RIGHTTOLEFT")){
			Reuse.MOB_swipingRightLeft();
		}else if(action.equals("LEFTTORIGHT")){
			Reuse.MOB_swipingLeftRight();
		}
	}
}
