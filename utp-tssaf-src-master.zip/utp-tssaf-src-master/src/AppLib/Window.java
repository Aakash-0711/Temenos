package AppLib;

import org.openqa.selenium.By;
import Driver.Demo1;
import Driver.Reuse;

public class Window{	

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() {
		try{
			By by=null;
			String[] paramArr=Demo1.arrParameters;


            if(paramArr.length==2) {
            	Reuse.WindowRegExp(paramArr[0],paramArr[1].trim());
            }
            else if (paramArr.length==1) {
            	Reuse.windowHandle(paramArr[0]);
            }
			
			/*if(action.equalsIgnoreCase("SWITCHTO")){
				Reuse.WindowRegExp(windowTitle,action);
			}else if(action.equalsIgnoreCase("CLOSE")){
				Reuse.WindowRegExp(windowTitle,action);
			}else if(action.equalsIgnoreCase("SWITCHTO_TITLE_Contains")){
				Reuse.WindowRegExp(windowTitle,action);
			}else if(action.equalsIgnoreCase("SWITCHTO_TITLE_StartsWith")){
				Reuse.WindowRegExp(windowTitle,action);
			}else if(action.equalsIgnoreCase("SWITCHTO_TITLE_EndsWith")){
				Reuse.WindowRegExp(windowTitle,action);
			}else if(action.equalsIgnoreCase("CLOSE_TITLE_Contains")){
				Reuse.WindowRegExp(windowTitle,action);
			}else if(action.equalsIgnoreCase("CLOSE_TITLE_StartsWith")){
				Reuse.WindowRegExp(windowTitle,action);
			}else if(action.equalsIgnoreCase("CLOSE_TITLE_EndsWith")){
				Reuse.WindowRegExp(windowTitle,action);
			}*/
			
		}catch(Exception e){	
			Demo1.logger.error("Error in WindowRegExp component. "+e);				
		}
	}
}
