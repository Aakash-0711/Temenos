package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class MOB_ElementSwipe {
	static String resourceId, text;

	/**
	 * @param args
	 *            elementType elementName locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception {
		By by = null;
		try{
			String[] paramArr = Demo1.arrParameters;
			resourceId = paramArr[0];
			text = paramArr[1];

			//Test

	Reuse.MOB_swipingEleLeftRight(resourceId, text);

		//Test


		}catch(Exception e){
			Demo1.logger.error("Click_Element "+e);
			e.printStackTrace();

		}
	}



}
