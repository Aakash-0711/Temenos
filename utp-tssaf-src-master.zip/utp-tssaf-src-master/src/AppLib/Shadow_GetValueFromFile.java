package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class Shadow_GetValueFromFile {
	static String variable,elementName,action;

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			String by=null;
			String[] paramArr=Demo1.arrParameters;
			variable=paramArr[0];
			elementName=paramArr[1];
			action=paramArr[2].trim();
			by=paramArr[3];

			//String text=StoreText.txtAndVal.get(variableName);
			String text=Reuse.GetPropertyValue(variable);

			if(action.equals("TEXT_PRESENT")){
				Reuse.shadow_Verify_TextPresent(by, text,elementName);
			}else if(action.equals("TEXT_CONTAINS")){
				Reuse.shadow_Verify_TextContains(by, text, elementName);
			}else if(action.equals("SET_TEXT")){
                Reuse.Shadow_SetText(by, text, elementName);
            }else if(action.equals("SELECT_BY_VISIBLETEXT")){
                Reuse.shadow_DropdownSelectVisibleText(by, text, elementName);
            }else if(action.equals("SELECT")){
                Reuse.Shadow_Dropdown_SelectItem(by, text, elementName);
            }else if(action.equals("SELECT_BY_VALUE")){
                Reuse.Shadow_Dropdown_SelectItem(by, text, elementName);
            }else{
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Use stored text","Use stored text as: <b>"+action+"</b>","Wrong action <b>"+action+"</b>");
			}
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Get value from file","Should be able to get the value from file",e.getMessage());
		}
	}
}
