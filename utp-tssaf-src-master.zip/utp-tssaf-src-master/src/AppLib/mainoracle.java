package AppLib;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Driver.Demo1;
import Driver.Reuse;

/**
 * TODO: Document me!
 *
 * @author ssandeep
 *
 */
public class mainoracle {
    public static String Currentfieldstatus="";
    public static String sybdbname;
    public static Statement stmt;
    public static void main(String[] args) throws IOException,SQLException
    {


        Properties prop = new Properties();
        String outexcelFilePath = Createexcel.outexcelpath;

        System.out.println("OUTPUT EXCEL PATH::" + outexcelFilePath);

        File files = new File(outexcelFilePath);

        String curDir;
        curDir = System.getProperty("user.dir");
        InputStream input = new FileInputStream(curDir + "\\Config\\config.properties");
        prop.load(input);String prefix = "<html><body><table>\n";
        final StringBuilder sb1 = new StringBuilder(prefix);

        boolean multiflag =false;
        GetPropertyValues properties = new GetPropertyValues();

        Date time = new Date(System.currentTimeMillis());
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HH_mm_ss").format(Calendar.getInstance().getTime());

        String url    =    prop.getProperty("tapurl").trim();

        String username    =    prop.getProperty("tapusername").trim();

        String password    =    prop.getProperty("tappassword").trim();
        String tapcontainer    =    prop.getProperty("tapcontainer").trim();
        String checkpoint = args[0];
        String Description = args[1];
        String ExpectedResult = args[2];
        Connection conn=null;
        String sybasedriver    =    prop.getProperty("sybdriver").trim();

        sybdbname   =    prop.getProperty("tapdb").trim();
        int counter=0;
        String resultfolder   =    prop.getProperty("tapresult").trim();
        Demo1.gbTestCaseStatus = "Pass";
        Demo1.DB2flag =true;//demo1
        String indexinformation[] = new String[5];
        boolean  DBconnect =true;
        try {
            Class.forName(sybasedriver).newInstance();
        } catch (InstantiationException e) {

        } catch (IllegalAccessException e) {

        } catch (ClassNotFoundException e) {

        }
        System.out.println("Driver Loaded");
        try{
            conn = DriverManager.getConnection(url,username,password);
            stmt = conn.createStatement();

            ResultSet      altersession =stmt.executeQuery("ALTER SESSION SET container = "+tapcontainer);

        }
        catch(java.sql.SQLException EX)
        {DBconnect=false;
        Oraclechecksum.Teststatusflag =false;
        Demo1.gbTestCaseStatus = "Fail";
        System.out.println("Problem with Connection correct your ORACLE URL/DBNAME/CREDENTIAL");
        }

        if(DBconnect)
        {
            try
            {

                Class.forName(sybasedriver).newInstance();
                System.out.println("connected");

                //stmt.executeUpdate("USE "+sybdbname);

                String Table_name = null;
                String  RECID = null;
                String[] Field_name = new String[25];
                short[] Vaild_field = new short[25];
                String[] Field_value = new String[25];
                String Field_names = null;
                String Field_values = null;
                String[] multi = new String[15];
                String[] multifieldnames = new String[15];
                String[] multifieldvalues = new String[15];

                String multiarray= null;
                String excelFilePath = "TestWare\\TestWare.xlsx";

                FileInputStream inputStream = new FileInputStream(new File(excelFilePath));

                int i = 0;
                int j;
                Workbook workbook = new XSSFWorkbook(excelFilePath);
                Workbook workbook1 = new XSSFWorkbook(outexcelFilePath);
                Sheet outsheet = workbook1.getSheetAt(0);
                Sheet firstSheet = workbook.getSheetAt(6);
                Iterator<Row> iterator = firstSheet.iterator();
                Iterator<Row> iterator1 = outsheet.iterator();
                short rowcount =0 ;

                while (iterator1.hasNext())
                { rowcount+=1;
                iterator1.next();
                }

                iterator.next();

                DASHBOARD d3= new DASHBOARD();

                indexinformation[0] = "TAP"+checkpoint;
                d3.indexDBDriver(indexinformation);
                String[] indexarg = new String[2];
                indexarg[0]="TAP";
                indexarg[1]=checkpoint;
                d3.DBWriteindexReportHeader(indexarg);
                int testcasecount = DASHBOARD.testcasecount;
                while (iterator.hasNext())
                {
                    Row nextRow = iterator.next();

                    Iterator<Cell> cellIterator = nextRow.cellIterator();
                    i=0;
                    String    check_point = cellIterator.next().getStringCellValue();

                    DASHBOARD.Currentteststatus="";

                    if(checkpoint.equals(check_point))
                    {
                        System.out.println("CHECKPOINT RECEIVED::" + checkpoint);
                        System.out.println("CHECKPOINT AVAILABLE::" + check_point);

                        String    Test_case = cellIterator.next().getStringCellValue();
                        Test_case= Test_case.replace("\"", "");
                        String HTMLCASE = Test_case.replace("\"", "");

                        Row nextRow1 =outsheet.createRow(rowcount);
                        rowcount+=1;
                        Table_name =  cellIterator.next().getStringCellValue();
                        Table_name = Table_name.replace("\"", "");

                        String[] reportstring = new  String[4];
                        reportstring[0]= "TAP";
                        reportstring[1] =check_point;
                        reportstring[2]= Test_case;
                        DASHBOARD.d2.reportindexbody(reportstring);

                        RECID = cellIterator.next().getStringCellValue();

                        System.out.println("RECID received:::" + RECID);

                        String indirectfield = null;
                        System.out.println("TABLE::" + Table_name);
                        RECID = RECID.replace("\"", "");
                        multiflag =false;
                        if(RECID.contains("&&"))
                        {
                            multiflag=true;
                            multiarray=    RECID.substring(RECID.indexOf("&&")+2 );
                            RECID =  RECID.replace( RECID.substring(RECID.indexOf("&&") ), "");
                            counter = RECID.split("\\&&", -1).length ;
                            System.out.println("counter ->"+counter);
                            multi = multiarray.split("\\&&", -1);
                            for(int ii=0;ii<counter;ii++)
                            {


                                multifieldnames[ii]=multi[ii].substring(0,multi[ii].indexOf('='));
                                multifieldvalues[ii]=multi[ii].substring(multi[ii].indexOf('=')+1);
                                if(multifieldvalues[ii].contains("auto@"))
                                {
                                    multifieldvalues[ii] = multifieldvalues[ii].replace("auto@", "");
                                    //System.out.println("FIELD VALUE::" + multifieldvalues[ii]);

                                    //added to fetch value from properties file if value is not present
                                    if(null != Reuse.GetPropertyValue(multifieldvalues[ii])){

                                        multifieldvalues[ii] = Reuse.GetPropertyValue(multifieldvalues[ii]);
                                    }else if(null != StoreText.txtAndVal.get(multifieldvalues[ii])){

                                        multifieldvalues[ii] = StoreText.txtAndVal.get(multifieldvalues[ii]);
                                    }else{
                                        /*System.out.println("ERROR::FIELD VALUE IS MISSING");*/
                                        Demo1.logger.error("ERROR::FIELD VALUE IS MISSING");
                                        multifieldvalues[ii] = "";
                                    }

                                    System.out.println("AFTER REPLACING auto@->"+multifieldvalues[ii]);
                                }

                                System.out.println("FIELD NAME::" + multifieldnames[ii]+ "\tFIELD VALUE:: "+multifieldvalues[ii]);
                            }
                        }
                        if(RECID.contains("="))
                        {indirectfield = RECID.substring(0,RECID.lastIndexOf("=") );
                        RECID =  RECID.replace( RECID.substring(0,RECID.lastIndexOf("=") ), "");
                        RECID = RECID.replace("=", "");
                        System.out.println("AFTER REPLACING = symbol ->"+RECID);
                        }

                        //NEWER APPROACH ADDED
                        if(RECID.contains("auto@")){

                            System.out.println("RECID RECEIVED:::" + RECID);

                            do{
                                int start = RECID.indexOf("auto@");
                                int end = 0;
                                String variable = null, value = null;
                                if(RECID.contains("##")){
                                    end = RECID.indexOf("##", start + 5);
                                    end+=2;
                                    variable = RECID.substring(start, end-2);
                                    String actualVariable = variable.substring(5, variable.length());

                                    //added to fetch value from properties file if value is not present
                                    if(null != Reuse.GetPropertyValue(actualVariable)){
                                        value = Reuse.GetPropertyValue(actualVariable);
                                    }else if(null != StoreText.txtAndVal.get(actualVariable)){
                                        value = StoreText.txtAndVal.get(actualVariable);
                                    }else{
                                        Demo1.logger.error("ERROR::DYNAMIC VARIABLE VALUE IS MISSING.");
                                        value = "";
                                    }

                                    String temp = RECID.substring(0, end);
                                    String updated = temp;

                                    if(temp.contains("##")){
                                        temp = temp.replaceFirst("##", "");
                                    }
                                    if(temp.contains("#")){
                                        temp = temp.replaceFirst("#", "");
                                    }
                                    RECID = RECID.replaceFirst(updated, temp);
                                }else{
                                    variable = RECID.substring(start);
                                    String actualVariable = variable.substring(5, variable.length());

                                    //added to fetch value from properties file if value is not present
                                    if(null != Reuse.GetPropertyValue(actualVariable)){
                                        value = Reuse.GetPropertyValue(actualVariable);
                                    }else if(null != StoreText.txtAndVal.get(actualVariable)){
                                        value = StoreText.txtAndVal.get(actualVariable);
                                    }else{
                                        Demo1.logger.error("ERROR::DYNAMIC VARIABLE VALUE IS MISSING.");
                                        value = "";
                                    }
                                }

                                RECID = RECID.replaceFirst(variable, value);

                            }while(RECID.contains("auto@"));

                            if(RECID.contains("##")){
                                RECID = RECID.replaceFirst("##", "");
                            }
                            if(RECID.contains("#")){
                                RECID = RECID.replaceFirst("#", "");
                            }

                            /*int count = RECID.split("\\@", -1).length;
                            if(count == 2){
                                RECID = RECID.replace("@auto", "");

                                //added to fetch value from properties file if value is not present
                                if(null == StoreText.txtAndVal.get(RECID)){
                                    RECID = Reuse.GetPropertyValue(RECID);
                                }else{
                                    RECID = (String)StoreText.txtAndVal.get(RECID);
                                }

                            }else if(count > 2){
                                do{
                                    int start = RECID.indexOf("@auto");
                                    int end = RECID.indexOf("@", start + 5);
                                    String variable = RECID.substring(start, end + 1);
                                    String actualVariable = variable.substring(5, variable.length()-1);

                                    String value;

                                    if(null == StoreText.txtAndVal.get(actualVariable)){
                                        value = Reuse.GetPropertyValue(actualVariable);
                                    }else{
                                        value = StoreText.txtAndVal.get(actualVariable);
                                    }

                                    RECID = RECID.replaceFirst(variable, value);
                                }while(RECID.contains("@auto"));
                            }*/
                        }

                        /*String suffix = null;         //OLDER APPROACH - UPDATED WITH ABOVE
                        String prefixs = null;
                        if(RECID.contains("##")){
                            suffix = RECID.substring(RECID.lastIndexOf("##") );
                            RECID =  RECID.replace( RECID.substring(RECID.lastIndexOf("##") ), "");
                            RECID = RECID.replace(suffix, "");
                            suffix = suffix.replace("##", "");
                        }
                        if(RECID.contains("#")){
                            prefixs = RECID.substring(0,RECID.indexOf("#"));
                            RECID =  RECID.replace( RECID.substring(0,RECID.indexOf("#")+1 ), "");
                            RECID = RECID.replace(prefixs, "");
                            prefixs = prefixs.replace("#", "");
                        }
                        if(RECID.contains("auto@")){
                            RECID = RECID.replace("auto@", "");
                            System.out.println(RECID);

                            //added to fetch value from properties file if value is not present
                            if(null == StoreText.txtAndVal.get(RECID)){

                                RECID = Reuse.GetPropertyValue(RECID);
                            }else{

                                RECID = (String)StoreText.txtAndVal.get(RECID);
                            }

                            System.out.println("AFTER REPLACING auto@->"+RECID);
                        }

                        if(suffix!=null){
                            RECID= RECID+suffix;
                        }

                        if(prefixs!=null){
                            RECID= prefixs+RECID;
                        }*/

                        System.out.println("RECID AFTER FINAL PARSE:::" + RECID);

                        final StringBuilder sb = new StringBuilder(prefix);

                        i = 0;
                        int jk = 0;
                        while (cellIterator.hasNext()) {

                            Field_names = cellIterator.next().getStringCellValue();

                            Field_names = Field_names.replace("\"", "");
                            Field_values = cellIterator.next().getStringCellValue();

                            Field_values = Field_values.replace("\"", "");
                            if (!Field_names.equals("") && (!(Field_names.startsWith("@"))))
                            {
                                Field_name[i] = Field_names;

                                if(Field_values.contains("auto@")){
                                    System.out.println("FIELD VALUE:::" + Field_values);

                                    int count = Field_values.split("\\@", -1).length;

                                    if(count == 2){
                                        Field_values = Field_values.replace("auto@", "");

                                        //added to fetch value from properties file if value is not present
                                        if(null != Reuse.GetPropertyValue(Field_values)){
                                            Field_values = Reuse.GetPropertyValue(Field_values);
                                        }else if(null != StoreText.txtAndVal.get(Field_values)){
                                            Field_values = StoreText.txtAndVal.get(Field_values);
                                        }else{
                                            Demo1.logger.error("ERROR::FIELD VALUE IS MISSING");
                                            Field_values = "";
                                        }

                                    }else if(count > 2){
                                        do{
                                            int start = Field_values.indexOf("auto@");
                                            int end = Field_values.indexOf("@", start + 5);
                                            String variable = Field_values.substring(start, end + 1);
                                            String actualVariable = variable.substring(5, variable.length()-1);

                                            String value;

                                            if(null != Reuse.GetPropertyValue(actualVariable)){
                                                value = Reuse.GetPropertyValue(actualVariable);
                                            }else if(null != StoreText.txtAndVal.get(actualVariable)){
                                                value = StoreText.txtAndVal.get(actualVariable);
                                            }else {
                                                Demo1.logger.error("ERROR::FIELD VALUE IS MISSING");
                                                value = "";
                                            }

                                            Field_values = Field_values.replaceFirst(variable, value);
                                        }while(Field_values.contains("auto@"));
                                    }

                                    /*String value = Field_values.replace("auto@", "");     //recently commented
                                    //added to fetch value from properties file if value is not present
                                    if(null == StoreText.txtAndVal.get(value)){

                                        Field_values = Reuse.GetPropertyValue(value);
                                    }else{

                                        Field_values = (String)StoreText.txtAndVal.get(value);
                                    }*/
                                }

                                Field_value[i] = Field_values;
                                System.out.print("FIELDNAME:::" + Field_name[i]);
                                System.out.print("FIELDVALUE::" + Field_value[i]);
                                System.out.println();
                                i+=1;
                                jk+=1;
                            }else if (Field_names.startsWith("@")){
                                Field_name[i] = Field_names.substring(1, Field_names.length());

                                if(Field_values.contains("auto@")){
                                    System.out.println("FIELD VALUE:::" + Field_values);

                                    int count = Field_values.split("\\@", -1).length;

                                    if(count == 2){
                                        Field_values = Field_values.replace("auto@", "");

                                        //added to fetch value from properties file if value is not present
                                        if(null != Reuse.GetPropertyValue(Field_values)){
                                            Field_values = Reuse.GetPropertyValue(Field_values);
                                        }else if(null != StoreText.txtAndVal.get(Field_values)){
                                            Field_values = StoreText.txtAndVal.get(Field_values);
                                        }else{
                                            Demo1.logger.error("ERROR::FIELD VALUE IS MISSING");
                                            Field_values = "";
                                        }

                                    }else if(count > 2){
                                        do{
                                            int start = Field_values.indexOf("auto@");
                                            int end = Field_values.indexOf("@", start + 5);
                                            String variable = Field_values.substring(start, end + 1);
                                            String actualVariable = variable.substring(5, variable.length()-1);

                                            String value;

                                            if(null != Reuse.GetPropertyValue(actualVariable)){
                                                value = Reuse.GetPropertyValue(actualVariable);
                                            }else if(null != StoreText.txtAndVal.get(actualVariable)){
                                                value = StoreText.txtAndVal.get(actualVariable);
                                            }else{
                                                Demo1.logger.error("ERROR::FIELD VALUE IS MISSING");
                                                value = "";
                                            }

                                            Field_values = Field_values.replaceFirst(variable, value);
                                        }while(Field_values.contains("auto@"));
                                    }
                                }

                                /*if(Field_values.startsWith("auto@")){     //recently commented
                                    System.out.println("FIELD WITH VARIABLE NAME:::" + Field_values);

                                    String value = Field_values.replace("auto@", "");

                                    //added to fetch value from properties file if value is not present
                                    if(null == StoreText.txtAndVal.get(value)){

                                        Field_values = Reuse.GetPropertyValue(value);
                                    }else{

                                        Field_values = (String)StoreText.txtAndVal.get(value);
                                    }
                                    System.out.println("AFTER REPLACING auto@:::" + Field_values);
                                }*/

                                Field_value[i] = Field_values;
                                System.out.print("FIELDNAME:::" +Field_name[i]);
                                System.out.print("FIELDVALUE::" + Field_value[i]);
                                i+=1;
                            }
                        }
                        System.out.println();
                        String sql;
                        String testsql;
                        String tableerror = null;
                        String recerror = null;
                        short validtable = 1;
                        short validrec =1;
                        try{
                            sql = "select * from "+sybdbname+"."+Table_name;
                            System.out.println("Table Sql"+sql);
                            //stmt.executeUpdate("USE "+sybdbname);
                            stmt.executeQuery(sql);
                            try{
                                if(!(indirectfield == null))
                                {
                                    String[] typeString = new String[2];
                                    typeString[0] = indirectfield;
                                    typeString[1] = Table_name;

                                    if(typefindint(typeString))
                                    {
                                        sql= "select * from "+sybdbname+"."+Table_name+ " WHERE "+indirectfield+" = "+RECID;
                                    }
                                    else{
                                        sql= "select * from "+sybdbname+"."+Table_name+ " WHERE "+indirectfield+" = '"+RECID+"'";
                                    }
                                    System.out.println("Indirect Sql"+sql);
                                }
                                else
                                {
                                    sql = "select * from "+sybdbname+"."+Table_name+" where code = '"+RECID+"'";
                                }
                                //stmt.executeUpdate("USE "+sybdbname);
                                System.out.println("OUTSIDE "+sql);
                                ResultSet rs1 =  stmt.executeQuery(sql);

                                rs1.next();
                                if(!(indirectfield == null))


                                {
                                    if(rs1.getString(1)==null)
                                    {
                                        Oraclechecksum.teststatus="fail";
                                        validrec = 0;
                                        recerror = "Record "+RECID+" not exist in  "+Table_name+" table";
                                        System.out.println(recerror);

                                    }


                                }
                                else if(rs1.getString(1)==null)
                                {
                                    Oraclechecksum.Teststatusflag =false;
                                    Oraclechecksum.teststatus="fail";
                                    validrec = 0;
                                    recerror = "Record "+RECID+" not exist in  "+Table_name+" table";
                                    System.out.println(recerror);

                                }
                            }
                            catch(SQLException recerr)
                            {
                                Oraclechecksum.Teststatusflag =false;
                                Oraclechecksum.teststatus="fail";
                                validrec = 0;
                                recerror = "Record "+RECID+" not exist in  "+Table_name+" table";
                                System.out.println(recerror);
                                System.out.println(recerr);
                            }
                        }
                        catch (SQLException ex)
                        {validtable = 0;
                        Oraclechecksum.teststatus="fail";
                        Oraclechecksum.Teststatusflag =false;
                        tableerror = "Invalid "+Table_name+" table in TAP Database";
                        System.out.println("Invalid "+Table_name+" table in TAP Database");
                        System.out.println(ex);
                        }
                        String arr1[] = new String[8];
                        arr1[0]="TAP_"+check_point+"_"+Test_case.trim();
                        DASHBOARD d1 = new   DASHBOARD();
                        d1.testDriver(arr1);
                        if (validtable==1 && validrec ==1 )
                        {


                            sql = "SELECT ";
                            short flag = 0;

                            for( j=0;j<i;j++)
                            {
                                if(!(indirectfield == null))
                                {
                                    String[] typeString = new String[2];
                                    typeString[0] = indirectfield;
                                    typeString[1] = Table_name;

                                    if(typefindint(typeString))
                                    {
                                        testsql = "select "+Field_name[j]+" from "+sybdbname+"."+Table_name+" where "+indirectfield+" = "+RECID;
                                    }

                                    else{
                                        testsql = "select "+Field_name[j]+" from "+sybdbname+"."+Table_name+" where "+indirectfield+" = '"+RECID+"'";
                                    }
                                }

                                else{
                                    testsql = "select "+Field_name[j]+" from "+sybdbname+"."+Table_name+" where code = '"+RECID+"'";

                                }


                                try{
                                    System.out.println(testsql);
                                    Vaild_field[j]=1;
                                    //stmt.executeUpdate("USE "+sybdbname);
                                    stmt.executeQuery(testsql);
                                }
                                catch(SQLException fieldex)
                                {
                                    Vaild_field[j]=0;
                                    System.out.println("Invalid "+Field_name[j]+" column in "+Table_name);
                                    System.out.println(fieldex);

                                }

                                if (j!=(i) && Vaild_field[j]!=0 )
                                { if(flag==0){
                                    sql=sql.concat(Field_name[j]);
                                    flag =1;
                                }
                                else
                                {
                                    sql =sql.concat(",");
                                    sql=sql.concat(Field_name[j]);
                                }
                                }

                            }

                            sql =sql.concat(" FROM "+sybdbname+".");
                            sql= sql.concat(Table_name);

                            if(!(indirectfield == null))
                            {
                                String[] typeString = new String[2];
                                typeString[0] = indirectfield;
                                typeString[1] = Table_name;

                                if(typefindint(typeString))
                                {
                                    sql= sql.concat(" WHERE "+indirectfield+" = ");
                                    sql= sql.concat(RECID);

                                }
                                else
                                {
                                    sql= sql.concat(" WHERE "+indirectfield+" = '");
                                    sql= sql.concat(RECID);
                                    sql= sql.concat("'");
                                }


                            }
                            else
                            {

                                sql= sql.concat(" WHERE code = '");
                                sql= sql.concat(RECID);
                                sql= sql.concat("'");
                            }

                            if(multiflag)
                            {

                                String[] typeString = new String[2];
                                for(int ii=0;ii<counter;ii++)
                                {

                                    typeString[0] = multifieldnames[ii];
                                    typeString[1] = Table_name;

                                    if(typefindint(typeString))
                                    {   sql= sql.concat(" and ");
                                    sql= sql.concat(multifieldnames[ii]+" = ");
                                    sql= sql.concat(multifieldvalues[ii]);

                                    }
                                    else
                                    {
                                        sql= sql.concat(" and ");
                                        sql= sql.concat(multifieldnames[ii]+" = '");
                                        sql= sql.concat(multifieldvalues[ii]);
                                        sql= sql.concat("'");
                                    }
                                }
                                multiflag=false;
                            }
                            System.out.println(sql);
                            //stmt.executeUpdate("USE "+sybdbname);
                            ResultSet rs = stmt.executeQuery(sql);
                            nextRow1.createCell(0).setCellValue("TAP");
                            nextRow1.createCell(1).setCellValue(check_point);
                            nextRow1.createCell(2).setCellValue(Test_case);
                            nextRow1.createCell(3).setCellValue(Table_name);
                            nextRow1.createCell(4).setCellValue(RECID);


                            arr1[0]="TAP";
                            arr1[1]=check_point;
                            arr1[2]=Test_case;
                            arr1[3]=Table_name;
                            arr1[4]=RECID;
                            arr1[5]="No Error";

                            d1.WriteReportHeader(arr1);


                            while( rs.next()){
                                String arr2[] = new String[8];
                                for(j=0;j<jk;j++)
                                {  DASHBOARD.Currentfieldstatus = "";
                                String temp = Field_name[j];

                                System.out.println("FIELD VALUE::" + Field_value[j]);
                                Cell  celltowritefieldname = nextRow1.createCell(4*(j+1)+2);

                                Cell  celltowriteexpectedvalue = nextRow1.createCell(4*(j+1)+3);
                                Cell  celltowriteactualvalue = nextRow1.createCell(4*(j+1)+4);
                                Cell celltowritecomments = nextRow1.createCell(4*(j+1)+5);
                                celltowritefieldname.setCellValue(Field_name[j]);
                                celltowriteexpectedvalue.setCellValue(Field_value[j]);
                                arr2[0]=Field_name[j];
                                arr2[1]=Field_value[j];
                                arr2[2]="";
                                arr2[3]="No Error";
                                if(Vaild_field[j]!=0){
                                    celltowriteactualvalue.setCellValue(rs.getString(temp));
                                    arr2[2] =rs.getString(temp);
                                }

                                if(Vaild_field[j]!=0)
                                {
                                    String Temp1 = rs.getString(Field_name[j]);
                                    if (Temp1 == null){
                                        Temp1 = "";
                                    }
                                    if (!Temp1.equals(Field_value[j]))

                                    {
                                        String Err = "Error in "+Field_name[j]+" Actual Not Equal to Expected "+Temp1+" != "+Field_value[j];
                                        System.out.println("Error in "+Field_name[j]+" Actual Not Equal to Expected "+Temp1+" != "+Field_value[j]);
                                        Oraclechecksum.Teststatusflag =false;
                                        sb.append("<td>");
                                        sb.append(Err);
                                        sb.append("</td>");
                                        celltowritecomments.setCellValue(Err);
                                        Oraclechecksum.teststatus = "fail";
                                        DASHBOARD.Currentteststatus="fail";
                                        DASHBOARD.Currentfieldstatus = "fail";
                                        arr2[3]=Err;
                                        Demo1.gbTestCaseStatus = "Fail";


                                    }
                                    sb.append("</tr>\n");
                                }

                                else
                                {Oraclechecksum.Teststatusflag =false;
                                DASHBOARD.Currentteststatus="fail";
                                Oraclechecksum.teststatus="fail";
                                Demo1.gbTestCaseStatus = "Fail";
                                DASHBOARD.Currentfieldstatus = "fail";
                                arr2[3]="Invalid '"+Field_name[j]+"' Column name in "+Table_name;
                                celltowritecomments.setCellValue("Invalid '"+Field_name[j]+"' Column name in "+Table_name);
                                }
                                d1.reportbody(arr2);
                                }

                                if (j==jk && j<i){
                                    String temp = Field_name[j];
                                    String VarValue =(rs.getString(temp));
                                    StoreText.txtAndVal.put(Field_value[j], VarValue);

                                    //added to store in testVariables.properties file also
                                    Reuse.WriteProperties(Field_value[j], VarValue);
                                }

                            }

                            rs.close();
                        }

                        else
                        {arr1[0]="TAP";
                        arr1[1]=check_point;
                        arr1[2]=Test_case;
                        arr1[3]=Table_name;
                        arr1[4]=RECID;

                        DASHBOARD.Currentteststatus="fail";
                        Oraclechecksum.teststatus="fail";
                        nextRow1.createCell(0).setCellValue("TAP");
                        nextRow1.createCell(1).setCellValue(check_point);
                        nextRow1.createCell(2).setCellValue(Test_case);
                        nextRow1.createCell(3).setCellValue(Table_name);
                        nextRow1.createCell(4).setCellValue(RECID);
                        if(validtable!=1)
                        {
                            Oraclechecksum.Teststatusflag =false;
                            Demo1.gbTestCaseStatus="Fail";
                            nextRow1.createCell(5).setCellValue(tableerror);
                            arr1[5]=tableerror;

                        }
                        else
                        { Oraclechecksum.Teststatusflag =false;
                        Demo1.gbTestCaseStatus="Fail";
                        nextRow1.createCell(5).setCellValue(recerror);
                        arr1[5]=recerror;
                        }
                        d1.WriteReportHeader(arr1);

                        }
                        d1.reportclose();
                        String[] reportbody = new String[6];
                        reportbody[0]="TAP";
                        reportbody[1]=check_point;
                        reportbody[2]=Test_case;
                        reportbody[3]=Table_name;
                        reportbody[4]=RECID;
                        DASHBOARD.testcasecount =DASHBOARD.testcasecount+1;
                        reportbody[5]=Integer.toString(DASHBOARD.testcasecount);
                        if(args[0].contains("NEGATIVE"))
                        {
                            if(DASHBOARD.Currentteststatus.equals("fail"))
                            {
                                DASHBOARD.Currentteststatus="";
                            }
                            else if (DASHBOARD.Currentteststatus.equals(""))
                            {
                                DASHBOARD.Currentteststatus="fail";
                            }
                        }
                        d3.DBreportindexbody(reportbody);//fix1
                    }

                }
                d3.indexDBclose();
                sb1.append("</table>");
                sb1.append("</body>");
                sb1.append("</html>");


                stmt.close();
                conn.close();
                Workbook workbook2 = new XSSFWorkbook();
                workbook2 = workbook1;
                FileOutputStream fos = new FileOutputStream(outexcelFilePath,true);
                workbook2.write(fos);

                workbook1.close();
                workbook2.close();
                fos.close();
                inputStream.close();


            }
            catch (NoSuchElementException ex)
            {DASHBOARD.Currentteststatus = "Warn";
            DASHBOARD.Currentfieldstatus="Warn";
            Demo1.gbTestCaseStatus="Warn";
            Demo1.TestStepWarningCount=Demo1.TestStepWarningCount+1;
            Demo1.logger.warn("Warning in "+Demo1.gbCurrTestCaseName+"  --->"+ex);
            System.out.println(ex);
            ex.printStackTrace();

            }
            catch (InstantiationException ex)
            {DASHBOARD.Currentteststatus = "Warn";
            DASHBOARD.Currentfieldstatus="Warn";
            Demo1.gbTestCaseStatus="Warn";
            Demo1.TestStepWarningCount=Demo1.TestStepWarningCount+1;
            Demo1.logger.warn("Warning in "+Demo1.gbCurrTestCaseName+"  --->"+ex);
            System.out.println(ex);

            }
            catch (IllegalAccessException ex)
            {
                DASHBOARD.Currentteststatus = "Warn";
                DASHBOARD.Currentfieldstatus="Warn";
                Demo1.gbTestCaseStatus="Warn";
                Demo1.TestStepWarningCount=Demo1.TestStepWarningCount+1;
                Demo1.logger.warn("Warning in "+Demo1.gbCurrTestCaseName+"  --->"+ex);
                System.out.println(ex);

            }
            catch (ClassNotFoundException ex)
            {DASHBOARD.Currentteststatus = "Warn";
            DASHBOARD.Currentfieldstatus="Warn";
            Demo1.gbTestCaseStatus="Warn";
            Demo1.TestStepWarningCount=Demo1.TestStepWarningCount+1;
            Demo1.logger.warn("Warning in "+Demo1.gbCurrTestCaseName+"  --->"+ex);
            System.out.println(ex);

            }
            catch(IllegalStateException ex)
            {DASHBOARD.Currentteststatus = "Warn";
            DASHBOARD.Currentfieldstatus="Warn";
            Demo1.gbTestCaseStatus="Warn";
            Demo1.TestStepWarningCount=Demo1.TestStepWarningCount+1;
            Demo1.logger.warn("Warning in "+Demo1.gbCurrTestCaseName+"  --->"+ex);
            System.out.println(ex);

            }
        }
        if (!Oraclechecksum.checksumvariable)
        {
            Demo1.Linkflag=true;
            if(Demo1.gbTestCaseStatus.equals("Warn"))
            {
                Demo1.SCBindexpage=  "..\\..\\logs\\application.html";
                Demo1.ReportStep(2,Description,ExpectedResult + " should be available",ExpectedResult + " unable to find ");
                System.out.println("ReportStep + Demo1.gbTestCaseStatus - " + Demo1.gbTestCaseStatus);
            }
            else if(!DBconnect) {
                Demo1.Linkflag=false;
                Demo1.ReportStep(2,Description,ExpectedResult + " should be available","Problem with Connection, Correct your Oracle DB URL & Credentials");
                System.out.println("ReportStep");
            }
            else
            {Demo1.SCBindexpage=indexinformation[0];
            if(args[0].contains("NEGATIVE"))
            {
                if(Demo1.gbTestCaseStatus.equals("Pass"))
                {
                    Demo1.gbTestCaseStatus="Fail";
                }
                else if(Demo1.gbTestCaseStatus.equals("Fail"))
                {
                    Demo1.gbTestCaseStatus="Pass";
                }
            }

            if (Demo1.gbTestCaseStatus.equals("Pass")){
                Demo1.ReportStep(2,Description,ExpectedResult + " should be available",ExpectedResult + " is available ");
            }else if (Demo1.gbTestCaseStatus.equals("Fail")){
                Demo1.ReportStep(2,Description,ExpectedResult + " should be available",ExpectedResult + " is not available ");
            }
            //Demo1.ReportStep(2,Description,ExpectedResult + " should be available",ExpectedResult + " is available <b>" + Demo1.gbTestCaseStatus + "</b>");
            System.out.println("mainoracle ReportStep " + Demo1.gbTestCaseStatus);
            }
        }


    }

    public static boolean typefindint(String[] typearg) throws SQLException
    {
        String sqltype = "SELECT DATA_TYPE FROM all_tab_columns  WHERE TABLE_NAME= '"+typearg[1].toUpperCase()+"' AND COLUMN_NAME='"+typearg[0].toUpperCase()+"'";
        //String sqltype = "SELECT sc.type FROM syscolumns sc INNER JOIN sysobjects so ON sc.id = so.id and sc.name='"+typearg[0]+"'  WHERE so.name = '"+typearg[1]+"'";
        //stmt.executeUpdate("USE "+sybdbname);
        System.out.println(sqltype);
        ResultSet rstype = stmt.executeQuery(sqltype);
        rstype.next();
        System.out.println("Type COLUMN:"+typearg[0]+": TABLE "+typearg[1]+": "+rstype.getString("DATA_TYPE"));
        if(rstype.getString("DATA_TYPE").equals("NUMBER"))
        {
            return true;
        }
        else{
            return false;
        }
    }
    public static void ExecuteComponent()
            throws Exception
    {

        String[] paramArr = Demo1.arrParameters;
        try
        {
            main(paramArr);
        }
        catch (Exception e)
        {
            e.printStackTrace();

            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, paramArr[1], paramArr[2] + " should be available", e.getMessage());

        }
    }
}
