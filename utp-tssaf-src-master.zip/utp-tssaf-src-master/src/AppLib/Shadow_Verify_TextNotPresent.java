package AppLib;

import static org.apache.commons.lang3.StringEscapeUtils.escapeHtml3;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;
public class Shadow_Verify_TextNotPresent {
	static String parameters,locatorType,locator,expectedText,elementName;
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			expectedText= escapeHtml3(paramArr[0]);
			elementName=paramArr[1];
			locator =paramArr[2];
			Reuse.shadow_Verify_TextNotPresent(locator, expectedText,elementName);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>"+expectedText+"</b> present","<b>"+expectedText+"</b> text should be present","Unable to locate <b>"+ elementName+"</b>");
		}
	}
}
