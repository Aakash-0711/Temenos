package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class Focus{
	static String eleName,locTyep,locator;
	/**
	 * @param
	 *  elementType
	 *  elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			String[] paramArr=Demo1.arrParameters;
			eleName=paramArr[0];
			locTyep=paramArr[1];
			locator=paramArr[2];
			Reuse.Focus(eleName,locTyep, locator);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Focus on Element <b>"+eleName+"</b>","Should be Focussed on <b>"+eleName+"</b>",e.getMessage());
		}
	}
}
