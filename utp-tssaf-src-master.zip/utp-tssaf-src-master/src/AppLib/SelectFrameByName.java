package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class SelectFrameByName {
	static String frmName;
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;
		try{
			frmName=paramArr[0];
			Reuse.SelectFrame(frmName);
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}
