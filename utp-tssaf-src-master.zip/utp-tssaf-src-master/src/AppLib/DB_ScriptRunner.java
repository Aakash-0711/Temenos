package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.ExternalConnection;

public class DB_ScriptRunner{
	static String parameters,locatorType,locator,elementType,elementName,action,query,expectedValue,variableName,url,path;
	/**
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			By by=null;
			String[] paramArr=Demo1.arrParameters;
			url=paramArr[0];
			path=paramArr[1];


			ExternalConnection.dB_ExecuteScriptRunner(url, path);


		}catch(Exception e){
			Demo1.logger.error("Problem in Action class");
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, action+" <b>"+elementName+"</b>"+elementType,"Should be "+action+" <b>"+elementName+"</b> "+elementType,"Unable to locate <b>"+elementName+"</b> "+elementType);
		}
	}
}
