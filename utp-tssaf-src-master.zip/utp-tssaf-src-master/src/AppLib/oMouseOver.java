package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class oMouseOver {
	static String parameters,locatorType,locator,elementName;
	/**
	 * @param
	 *
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			elementName=paramArr[0];
			by=Reuse.GetLocator(paramArr[1]);
			Reuse.MouseOver(by,elementName);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Mouseover Event","Mouseover Event should be done","Element not found");
		}
	}
}
