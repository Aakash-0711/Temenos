package AppLib;

import Driver.Config;
import Driver.Demo1;
import Driver.Reuse;

public class Wait {
	static String parameters;
	static int timeOutInsec;
	/**
	 * @param args
	 * timeOutInsec
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{	
		
		String[] paramArr=Demo1.arrParameters;
		try{
			timeOutInsec=Integer.parseInt(paramArr[0]);

                int secToWait = timeOutInsec;
                Reuse.oWait(secToWait);

		}catch(Exception e){
			Demo1.logger.error("Wait "+e);
		}		
	}
}
