package AppLib;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import com.google.common.base.Throwables;

import Driver.Demo1;
import Driver.Reuse;

public class FireEvent {
    static String elementName, eventName;

    /**
     * @param args elementType elementName locator
     */
    public static void main(String[] args) throws Exception {
        // TODO Auto-generated method stub
        ExecuteComponent();
    }

    public static void ExecuteComponent() throws Exception {
        By by = null;
        try {
            String[] paramArr = Demo1.arrParameters;
            elementName = paramArr[0];
            eventName = paramArr[1];
            by = Reuse.GetLocator(paramArr[2]);

            if (eventName.equalsIgnoreCase("mousedown")) {
                JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
                String javaScript = "var event = new MouseEvent('mousedown', {\n" +
                      //  "    'view': window,\n" +
                        "    'bubbles': true\n" +
                      //  "    'cancelable': true,\n" +
                      //  "    'screenX': arguments[0].left,\n" +
                      //  "    'screenY': arguments[0].top\n" +
                        "});arguments[0].dispatchEvent(event);";
                js.executeScript(javaScript, Demo1.driver.findElement(by));
                Demo1.gbTestCaseStatus = "Pass";
                Demo1.ReportStep(2, "Element <b>" + elementName +"</b> should be clicked" , "Clicking on <b>" + elementName
                        + "</b> value should be selected", "<b>"+ elementName +"</b> has been clicked");
            } else {
                JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
                js.executeScript("var event = new Event('" + eventName + "');arguments[0].dispatchEvent(event);", Demo1.driver.findElement(by));
                Demo1.gbTestCaseStatus = "Pass";
                Demo1.ReportStep(2, eventName+" event should be fired on<b>" + elementName +"</b>" , "Firing <b>"+eventName+"</b> event on  <b>" + elementName
                        + "</b>", "<b>"+eventName+"</b>event has been fired successfully");
            }

        } catch (Exception e) {
            Reuse.log(e);
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, eventName+" event should be fired on<b>" + elementName +"</b>" , "Firing <b>"+eventName+"</b> event on  <b>" + elementName
                    + "</b>", Throwables.getStackTraceAsString(e));
         }
    }
}
