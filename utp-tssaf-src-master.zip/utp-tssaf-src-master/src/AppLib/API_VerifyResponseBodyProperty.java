package AppLib;

import Driver.Demo1;
import Driver.Reuse;
import Driver.ReuseT24API;

public class API_VerifyResponseBodyProperty {
	static String userName,Password,URL,path,action;
	private static String appUrl;
	/**
	 * @param
	 * elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;


		path = paramArr[0];
		action = paramArr[1];


		try {
			if (action.equals("NULL")) {

				ReuseT24API.API_jsonPropertyShouldBeNull(path);
            }else if (action.equals("NOT_NULL")) {

//                ReuseT24API.API_xmlPropertyShouldExist(path);

            	ReuseT24API.API_jsonPropertyShouldBeNotNull(path);
            }else if (action.equals("EXISTS")) {

            	ReuseT24API.API_jsonPropertyShouldExist(path);
            }else if (action.equals("NOT_EXISTS")) {

            	ReuseT24API.API_jsonPropertyShouldNotExist(path);
            }else if (action.equals("DECIMAL")) {

                ReuseT24API.API_jsonPropertyShouldBeADecimalNumber(path);
            }else {
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Use property text", "Use property text as: <b>" + action + "</b>", "Wrong action <b>" + action + "</b>");
            }




		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);

			Demo1.gbTestCaseStatus = "Fail";
		    Demo1.ReportStep(2, "To verify property is failed",
		            " property should be verified",
		            "The property is null" );
		}
	}

}
