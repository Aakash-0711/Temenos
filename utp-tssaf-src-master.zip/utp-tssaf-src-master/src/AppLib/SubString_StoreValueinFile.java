package AppLib;


import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class SubString_StoreValueinFile {
	static String variable, elementName,action,removeChar;

	public static void main(String[] args) {
		ExecuteComponent();

	}

	public static void ExecuteComponent() {
		By by = null;
		String[] paramArr = Demo1.arrParameters;
		try {
			variable = paramArr[0];
			elementName = paramArr[1];
			action=paramArr[2].trim();
			by = Reuse.GetLocator(paramArr[3]);

			if(action.equalsIgnoreCase("REMOVE_SPL_CHARS")) {
				removeChar=paramArr[4].trim();
				Reuse.RemoveSpecialCharacters_StoreValueinFile(variable, elementName, by ,removeChar);
			}

			else if (action.equalsIgnoreCase("GET_LAST_FEW_CHARS")) {
				Reuse.SelectLastChars_StoreValueinFile(variable, elementName, by,Integer.parseInt(paramArr[4]));
			}

			else if (action.equalsIgnoreCase("GET_FIRST_FEW_CHARS")) {
				Reuse.SelectFirstChars_StoreValueinFile(variable, elementName, by,Integer.parseInt(paramArr[4]));
			}
			else if (action.equalsIgnoreCase("FETCH_SPECIFIC_CHARS")) {
				Reuse.SelectSpecificChars_StoreValueinFile(variable, elementName, by,Integer.parseInt(paramArr[4]),Integer.parseInt(paramArr[5]));
			}
			else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Store Text in file","store text as: <b>"+action+"</b>","Wrong action <b>"+action+"</b>");
			}


		} catch (Exception e) {
			Demo1.logger.error("Unable to locate element "+e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Store Text in file","store text as: <b>"+action+"</b>","Wrong action <b>"+action+"</b>");
		}
	}

}
