package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class DeleteAllCookies {

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			Reuse.DeleteAllCookies();
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Delete All Cookies","Should be Deleted all Cookies", e.getMessage());
		}
	}
}