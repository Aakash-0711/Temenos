package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class CompareImage {
	static String parameters,key,pathOfJar,jarName,fileName,actualText,replaceText;
	/**
	 * @param key
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception  {
		String[] paramArr=Demo1.arrParameters;
		try{
		    pathOfJar=paramArr[0];
		    jarName=paramArr[1];



//		    Reuse.compareImageBat( pathOfJar, jarName);

			Reuse.runCompImg(pathOfJar, jarName);

		}catch(Exception e){
			System.out.println(e.getMessage());

			  Demo1.gbTestCaseStatus = "Fail";
			  Demo1.ReportStep(2, "Check <b>" + "</b> " + " image is compared", "<b>" + "</b> should  be compared and verified",
			            "image is different");

		}
	}
}
