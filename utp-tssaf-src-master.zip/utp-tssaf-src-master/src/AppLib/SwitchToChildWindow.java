package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class SwitchToChildWindow {

	public static void main(String[] args) throws Exception {
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception {
		try{
			//Thread.sleep(10000);
			Reuse.SwitchToChildWindow();
			}catch(Exception e){
				Demo1.logger.error("Error SwitchToChildWindow execute component " +e.getMessage());
			//Demo1.gbTestCaseStatus = "Fail";
			//Demo1.ReportStep(2, "Switch to child window","Should be switched to child window",e.getMessage());
		}
	}
}
