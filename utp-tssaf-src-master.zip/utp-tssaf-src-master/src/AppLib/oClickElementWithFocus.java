package AppLib;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import Driver.Demo1;
import Driver.Reuse;

public class oClickElementWithFocus {
	static String elementType, elementName;
	/**
	 * @param args
	 *            elementType elementName locator
	 * @throws Exception
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() {
		By by = null;
		try{

			String[] paramArr = Demo1.arrParameters;
			elementType = paramArr[0];
			elementName = paramArr[1];
			by = Reuse.GetLocator(paramArr[2]);

			try {
				   WebElement element1 = Demo1.driver.findElement(by);
				   ((JavascriptExecutor) Demo1.driver).executeScript("arguments[0].scrollIntoView(true);", element1);
				Thread.sleep(3000);
			}catch (Exception x1) {

			}
			Reuse.Click_Element(by, elementType, elementName);
		}catch(Exception e){
			Demo1.logger.error("Click_Element "+e);
		}
	}
}
