package AppLib;

import java.io.File;

import Driver.Config;
import Driver.Demo1;
import Driver.Reuse;

public class FileUtils_Copy{
	static String source,destination,action;

	/**
	 * @param
	 *  elementType
	 *  elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

    public static void ExecuteComponent() {
        String[] paramArr = Demo1.arrParameters;
        try {
            source = paramArr[0].trim();
            destination = paramArr[1].trim();
            action = paramArr[2].trim();

            if (source.startsWith("userdir")) {
                source = new File(String.valueOf(Demo1.curDir) + source.replaceFirst("userdir", "")).getCanonicalFile()
                        .toString();
                Reuse.log("source path:" + source);
            } else if (source.startsWith("config.applicationserverhomepath")) {
                source = new File(String.valueOf(Config.applicationServerHomePath)
                        + source.replaceFirst("config.applicationserverhomepath", "")).getCanonicalPath().toString();
                Reuse.log("source path:" + source);
            }

            if (destination.startsWith("userdir")) {
                destination = new File(String.valueOf(Demo1.curDir) + destination.replaceFirst("userdir", ""))
                        .getCanonicalFile().toString();
            } else if (destination.startsWith("config.applicationserverhomepath")) {
                destination = new File(String.valueOf(Config.applicationServerHomePath)
                        + destination.replaceFirst("config.applicationserverhomepath", "")).getCanonicalPath()
                                .toString();
            }

            if (action.equalsIgnoreCase("DIRECTORY_TO_DIRECTORY")) {
                Reuse.CopyDirectoryToDirectory(source, destination);
            } else if (action.equalsIgnoreCase("FILE_TO_FILE")) {
                Reuse.CopyFile(source, destination);
            } else if (action.equalsIgnoreCase("FILES_TO_DIRECTORY")) {
                Reuse.CopyFilesToDirectory(source, destination);
            } else if (action.equalsIgnoreCase("FILE_TO_DIRECTORY")) {
                Reuse.CopyFileToDirectory(source, destination);
            } else {
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "File Utils", "File Utils: " + action, "Invalid action " + action);
            }
            // Reuse.CopyFile(source, destination);
        } catch (Exception e) {
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "File Utils", "File Utils: " + action, e.getMessage());
        }
    }
}
