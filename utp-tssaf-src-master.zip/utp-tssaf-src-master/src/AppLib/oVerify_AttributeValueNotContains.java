package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class oVerify_AttributeValueNotContains {
	static String parameters,locatorType,locator,attribute,attributeValue,elementName;
	/**
	 * @param args
	 * attribute
	 * attributeValue
	 * elementName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			attribute=paramArr[0];
			attributeValue=paramArr[1];
			elementName=paramArr[2];
			by=Reuse.GetLocator(paramArr[3]);
			Reuse.VerifyAttributeValueNotContains(attribute,attributeValue,by,elementName);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Vefify attribute value <b>"+attributeValue+"</b>","Attribute value should not be contains the text <b>"+attributeValue+" </b>","Unable to locate element");
		}
	}
}
