package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;

public class oSetCommandLine {
	static String parameters,command;

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();

	}
public static void ExecuteComponent() throws Exception {
	String[] paramArr=Demo1.arrParameters;
	try{
		command=paramArr[0];
		//Reuse.SelectChildPage("T24 - Model Bank R13");
		Demo1.driver.switchTo().frame(0);
		Demo1.driver.findElement(By.id("commandValue")).clear();
		Demo1.driver.findElement(By.id("commandValue")).sendKeys(command);
		Demo1.driver.findElement(By.id("cmdline_img")).click();

		/*String eveClick = "var event = new MouseEvent('click', {'bubbles': true});arguments[0].dispatchEvent(event);";
        JavascriptExecutor executor = (JavascriptExecutor) Demo1.driver;
        WebElement ele = Demo1.driver.findElement(By.id("cmdline_img"));
        executor.executeScript(eveClick, ele);*/

		Demo1.gbTestCaseStatus = "Pass";
		Demo1.ReportStep(2, "Set command in T24 Command line","Set Command <b>"+ command+"</b>","Command <b>"+ command+"</b> entered Successfully");
	}catch(Exception e){
		Demo1.gbTestCaseStatus = "Fail";
		Demo1.ReportStep(2, "Set command in T24 Command line","Set Command <b>"+ command+"</b>","Unable to locate element");
	}
}
}
