package AppLib;

import Driver.Demo1;
import Driver.Reuse;
public class LaunchURLWithAuthentication {

	/**
	 * @param args
	 */
	public static String parameters,URL,windowTitle,user,password;

	public static void main(String[] args) throws Exception
	{
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;
		try{
			URL=paramArr[0];
			windowTitle=paramArr[1];
			user=paramArr[2];
			password=paramArr[3];
			Demo1.driver.get(URL);
			Reuse.WinWindow_LoginAuthentication(windowTitle,user,password);
			if(Demo1.driver.getTitle().contains("ERROR")){
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Launch Application: "+URL,URL+" should be launched.","URL "+URL+" not launched");
			}else{
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Launch Application: "+URL,URL+" should be launched.","URL "+URL+" launched as expected");
			}
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Launch Application: "+URL,URL+" should be launched.",e.getMessage());
		}
	}
}
