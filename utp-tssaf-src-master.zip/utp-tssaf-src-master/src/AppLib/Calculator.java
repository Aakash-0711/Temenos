package AppLib;

import java.math.BigDecimal;
import java.text.DecimalFormat;

import com.google.common.base.Throwables;

import Driver.Demo1;
import Driver.Reuse;

/**
 * @author aakash.manohar
 *
 */
public class Calculator {

	static String action, firstNum, secondNum, result, NoOfDecimalPlaces;

	public static void main(String[] args) {
		ExecuteComponent();

	}

	public static void ExecuteComponent() {

		try {
			String[] paramArr = Demo1.arrParameters;

			firstNum = paramArr[0];
			secondNum = paramArr[1];
			result = paramArr[2];
			action = paramArr[3];

			if (action.equalsIgnoreCase("Addition")) {
				String num1 = getFistValue(firstNum);
				String num2 = getSecondValue(secondNum);
				Double v1 = Double.parseDouble(num1);
				Double v2 = Double.parseDouble(num2);
				Double v3 = v1 + v2;
				Reuse.WriteProperties(result, String.valueOf(v3));
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Calculate:ADDITION", v1 + "+" + v2, "Calculated:" + v3);
			} else if (action.equalsIgnoreCase("Subtraction")) {
				String num1 = getFistValue(firstNum);
				String num2 = getSecondValue(secondNum);
				Double v1 = Double.parseDouble(num1);
				Double v2 = Double.parseDouble(num2);
				Double v3 = v1 - v2;
				Reuse.WriteProperties(result, String.valueOf(v3));
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Calculate:Subtraction", v1 + "-" + v2, "Calculated:" + v3);

			} else if (action.equalsIgnoreCase("Multiplication")) {
				String num1 = getFistValue(firstNum);
				String num2 = getSecondValue(secondNum);
				Double v1 = Double.parseDouble(num1);
				Double v2 = Double.parseDouble(num2);
				Double v3 = v1 * v2;
				Reuse.WriteProperties(result, String.valueOf(v3));
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Calculate:Multiplication", v1 + "*" + v2, "Calculated:" + v3);

			} else if (action.equalsIgnoreCase("Division")) {
				String num1 = getFistValue(firstNum);
				String num2 = getSecondValue(secondNum);
				Double v1 = Double.parseDouble(num1);
				Double v2 = Double.parseDouble(num2);
				Double v3 = v1 / v2;
				Reuse.WriteProperties(result, String.valueOf(v3));
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Calculate:Division", v1 + "/" + v2, "Calculated:" + v3);
			} else if (action.equalsIgnoreCase("RoundOFF")) {
				NoOfDecimalPlaces = paramArr[4];
				String num1 = getFistValue(firstNum);
				Double v1 = Double.parseDouble(num1);
				BigDecimal a = new BigDecimal(v1);
				BigDecimal roundOff = a.setScale(Integer.parseInt(NoOfDecimalPlaces), BigDecimal.ROUND_HALF_EVEN);
				System.out.println(roundOff);
				String valueOf = String.valueOf(roundOff);
				Reuse.WriteProperties(result, valueOf);
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Calculate:Roundoff decimal places",
						" RoundOff " + NoOfDecimalPlaces + " decimal places for " + v1 + "", "Calculated:" + roundOff);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Calc", "Exception occured", Throwables.getStackTraceAsString(e));
		}

	}

	public static String getFistValue(String firstNum) {
		if (firstNum.contains("auto@")) {
			String runTimeVariableName = firstNum.replace("auto@", "");
			runTimeVariableName = runTimeVariableName.substring(0, runTimeVariableName.length() - 1);
			firstNum = Reuse.GetPropertyValue(runTimeVariableName).trim();
		}

		return firstNum;
	}

	public static String getSecondValue(String secondNum) {
		if (secondNum.contains("auto@")) {
			String runTimeVariableName = secondNum.replace("auto@", "");
			runTimeVariableName = runTimeVariableName.substring(0, runTimeVariableName.length() - 1);
			secondNum = Reuse.GetPropertyValue(runTimeVariableName).trim();
		}
		return secondNum;
	}

	public static String formatDouble(double value) {
		// Determine the number of digits before and after the decimal point
		String valueString = Double.toString(value);
		int integerDigits = valueString.indexOf('.');
		int decimalDigits = valueString.length() - integerDigits - 1;

		// Create a pattern dynamically based on the number of digits
		StringBuilder patternBuilder = new StringBuilder("#,##0");
		if (decimalDigits > 0) {
			patternBuilder.append('.');
			for (int i = 0; i < decimalDigits; i++) {
				patternBuilder.append('0');
			}
		}

		// Create a DecimalFormat object with the dynamically determined pattern
		DecimalFormat decimalFormat = new DecimalFormat(patternBuilder.toString());

		// Format the double value using the DecimalFormat
		return decimalFormat.format(value);
	}

}
