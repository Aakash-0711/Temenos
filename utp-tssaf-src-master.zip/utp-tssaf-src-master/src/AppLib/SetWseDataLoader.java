package AppLib;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import Driver.Demo1;
import Driver.Reuse;

public class SetWseDataLoader {
    static String action;

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        ExecuteComponent();
    }

    public static void ExecuteComponent() {
        String[] paramArr = Demo1.arrParameters;
        try {
            action = paramArr[0];
            Reuse.WriteProperties("wseLoader", action);
            // setValue();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void setValue() {
        Properties prop = new Properties();
        try {
            String currDir = Demo1.curDir;
            InputStream input = new FileInputStream(currDir + "\\Config\\config.properties");
            System.out.println("Properties Path:::" + currDir + "\\Config\\config.properties");
            prop.load(input);

            System.out.println("ACTION VALUE::" + action);
            if (!action.isEmpty()) {
                System.out.println("Action value " + action + " is written into config.properties file");
                prop.put("wseLoader", action);
            } else {
                System.out.println("Error: Parameter value is empty.");
            }

        } catch (Exception e1) {
            e1.printStackTrace();
            System.out.println("Unable to write to Config.properties file");
        }
    }

}
