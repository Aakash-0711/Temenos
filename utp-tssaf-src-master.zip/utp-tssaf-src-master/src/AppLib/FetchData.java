package AppLib;

import java.io.FileInputStream;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;
import jxl.Sheet;
import jxl.Workbook;

public class FetchData{
	static String fileName,sheetName;

	/**
	 * @param
	 *  elementType
	 *  elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;
		try{
			fileName=paramArr[0];
			sheetName=paramArr[1].trim();
			readExcel();
		}catch(Exception e){
			Demo1.logger.error("Error in FetchData Execute Component method. "+e);
		}
	}
	public static void readExcel() throws Exception {
		try{
			String FilePath = Demo1.curDir+"\\TestData\\"+fileName+".xls";
			//String FilePath = "D:\\SeleniumVersionTest\\CreditRiskModule\\Book2.xls";
			FileInputStream fs = new FileInputStream(FilePath);
			Workbook wb = Workbook.getWorkbook(fs);

			// TO get the access to the sheet
			Sheet sh = wb.getSheet(sheetName);

			// To get the number of rows present in sheet
			int totalNoOfRows = sh.getRows();

			// To get the number of columns present in sheet
			int totalNoOfCols = sh.getColumns();

			for (int row = 1; row < totalNoOfRows; row++) {
				for(int col=0;col<totalNoOfCols;col++){

					String businessData=sh.getCell(col, row).getContents();
					if(businessData.length() >0){
						String ObjType=getObjType(sh.getCell(col, 0).getContents());
						String locator=sh.getCell(col, 0).getContents();

						GetData(businessData,locator,ObjType);
					}
				}
				Reuse.Click_Element(By.xpath("//a[contains(@id,'LinkButton4') and text()='Add']"), "Link", "Add");
				//Click_Element(driver.findElement(By.xpath("//a[contains(@id,'LinkButton4') and text()='Add']")));
			}
		}catch(Exception e){
			Demo1.logger.error("Proble in readExcel in FetchData class. "+e);
		}
	}
	public static String getObjType(String objText){
		String obj="";

		try{
			if(objText.endsWith("EditBox")){
				obj="EditBox";
			}else if(objText.endsWith("Dropdown")){
				obj="Dropdown";
			}else if(objText.endsWith("Button")){
				obj="Button";
			}else{
				Demo1.logger.error("Error in getObjType in Fetch data component. Unknown Object elementName");
			}
			return obj;
		}catch(Exception e){
			System.out.println(e);
			return null;
		}
	}
	public static void GetData(String businessData,String locator,String ObjType) throws Exception{
		By by=null;
		try{

			String[] loc=locator.split("_");

			if(ObjType.contentEquals("EditBox")){
				Reuse.TextBox_InputText(By.xpath("//input[contains(@id,'"+loc[0]+"')]"), businessData, locator);
				//SetText(Demo1.driver.findElement(By.xpath("//input[contains(@id,'"+loc[0]+"')]")),businessData);
			}else if(ObjType.contentEquals("RadioButton")){

			}else if(ObjType.contentEquals("Dropdown")){
				Reuse.Dropdown_SelectItem(By.xpath("//select[contains(@id,'"+loc[0]+"')]"), businessData, locator);
				//DropdownSelect(driver.findElement(By.xpath("//select[contains(@id,'"+loc[0]+"')]")),businessData);
			}else if(ObjType.contentEquals("Button")){

			}else{
				Demo1.logger.error("Error in GetData in Fetch data component. Unknown Object elementName");
			}
		}catch(Exception e){
			Demo1.logger.error("Error in GetData in Fetch data component. "+e);
		}
	}
}
