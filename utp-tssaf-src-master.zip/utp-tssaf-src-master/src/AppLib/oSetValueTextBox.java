package AppLib;

import java.util.Random;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class oSetValueTextBox {
	static String parameters,text,locatorType,locator,textBoxName,mode;

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;
		By by;
		try{
			if(paramArr.length==3){
				//text=paramArr[0];
				//modified to replace with random numerals - random@6CUSTOMERID@
				String temp = paramArr[0];
				if(temp.contains("random@")){
					int start = temp.indexOf("random@");
					int randomLength = Integer.parseInt(temp.substring(start+7, start+8));
		            int end = temp.indexOf("@", start + 8);
		            String variable = temp.substring(start, end + 1);
		            String actualVariable = variable.substring(8, variable.length() - 1);

		            Random rnd = new Random();
					int randomValue = 0;
					if(randomLength > 0){ //this defines the no of digits for random value
						StringBuilder random1 = new StringBuilder(String.format("%0"+randomLength+"d", 1));
					    random1.reverse();
						Reuse.log(random1.toString());

						StringBuilder random9 = new StringBuilder(String.format("%0"+randomLength+"d", 9));
						random9.reverse();
						Reuse.log(random9.toString());

						//randomValue = 100000 + rnd.nextInt(900000);
						randomValue = Integer.parseInt(random1.toString()) + rnd.nextInt(Integer.parseInt(random9.toString()));
					}

					temp = temp.replaceAll(variable, Integer.toString(randomValue));
					Reuse.WriteProperties(actualVariable, Integer.toString(randomValue));
				}
				text=Reuse.getValueOfRunTimeVariables(temp);    //modified to replace dynamic variable(s)

				textBoxName=paramArr[1];
//				by=Reuse.GetLocator(paramArr[2]);
				by=Reuse.GetLocator(Reuse.getValueOfRunTimeVariables(paramArr[2]));
				Reuse.TextBox_InputText(by, text,textBoxName);
			}else if(paramArr.length==4){
				mode= paramArr[0];
//				text=paramArr[1];
				text=Reuse.getValueOfRunTimeVariables(paramArr[1].trim());
				textBoxName=paramArr[2];
//				by=Reuse.GetLocator(paramArr[3]);
			    by=Reuse.GetLocator(Reuse.getValueOfRunTimeVariables(paramArr[3]));

				Reuse.TextBox_InputText(mode,by, text,textBoxName);
			}else{
				throw new Exception("Array parameters mismatch");
			}

		}catch(Exception e){
			Demo1.logger.error("Problem in oSetValueTextBox. This may be because of the locator syntax error: " + paramArr[2]);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Input text in to the field <b>"+textBoxName+"</b>","Input text <b>"+ text+"</b>","Unbale to locate <b>"+textBoxName+"</b> Textbox");
		}
	}
}
