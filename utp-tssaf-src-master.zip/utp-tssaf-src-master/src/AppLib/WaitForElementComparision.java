package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class WaitForElementComparision{

	/**
	 * @param
	 *  elementType
	 *  elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		By expectedTextBy=null;
		By actualTextby=null;
		String expectedTextInSameElement = null;
		String withTimeoutInSec = null;
		By refreshElementBy = null;

		try{
			String[] paramArr = Demo1.arrParameters;
			expectedTextBy = Reuse.GetLocator(paramArr[0]);

			if(paramArr[1].startsWith("TEXT=")){
				expectedTextInSameElement = paramArr[1].split("=")[1];
			}else{
				actualTextby = Reuse.GetLocator(paramArr[1]);
			}

			withTimeoutInSec = paramArr[2];

			if(paramArr.length == 4){
				refreshElementBy = Reuse.GetLocator(paramArr[3]);
			}

			//if second parameter starts with "TEXT=" then we can assume it is for checking the same element
			if(paramArr[1].startsWith("TEXT=")){
				Reuse.waitForSameElementComparision(expectedTextBy, expectedTextInSameElement, withTimeoutInSec, refreshElementBy);
			}else{
				Reuse.waitForElementComparision(expectedTextBy, actualTextby, withTimeoutInSec, refreshElementBy);
			}

		}catch(Exception e){
		    e.printStackTrace();
			Demo1.logger.error("WaitForElementToAppear - "+e);
		}
	}
}
