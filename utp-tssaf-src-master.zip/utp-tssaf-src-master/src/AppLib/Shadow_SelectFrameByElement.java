package AppLib;


import Driver.Demo1;
import Driver.Reuse;

public class Shadow_SelectFrameByElement {	
	
	static String elementLocator;
	/**
	 * @param args
	 * @throws Exception 
	 * @author aakash.manohar
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{	
		String[] paramArr=Demo1.arrParameters;
		try{
			elementLocator=paramArr[0];
			Reuse.Shadow_SelectFrame(elementLocator);
		}catch(Exception e){
			Demo1.logger.error("Error in Shadow_SelectFrameByElement. "+e.getMessage());
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Switch to Shadow frame by element","Should be switched to shadow frame by element", e.getMessage());
		}			
	}
}
