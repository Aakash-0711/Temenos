package AppLib;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;
import java.util.Properties;

import com.google.common.base.Throwables;

import net.neoremind.sshxcute.core.ConnBean;
import net.neoremind.sshxcute.core.IOptionName;
import net.neoremind.sshxcute.core.Result;
import net.neoremind.sshxcute.core.SSHExec;
import net.neoremind.sshxcute.core.SysConfigOption;
import net.neoremind.sshxcute.task.CustomTask;
import net.neoremind.sshxcute.task.impl.ExecCommand;
import net.neoremind.sshxcute.task.impl.ExecShellScript;

/**
 * TODO: Document me!
 *
 * @author maheshkathirvel
 *
 */
public class SshExecuteOfsNew {

    private static boolean executorinitialized;
    private static SSHExec sshExecutor;

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }

    public static String ExecuteComponent(String CreateOfs1, String uniqueIdentifier, String OFSRESPONSE_DIR) {

        connectSshExecutor();

        Properties prop = new Properties();
        String curDir = System.getProperty("user.dir");
        InputStream input;

        try {
            input = new FileInputStream(curDir + "\\Config\\config.properties");
            prop.load(input);
        } catch (IOException e) {
            System.out.println("Unable to read the config file");
        }

        String TAFJBIN = prop.getProperty("TAFJBIN").trim();

        CustomTask task1 = new ExecCommand("cd " + TAFJBIN);
        CustomTask task2 = new ExecShellScript(TAFJBIN + "/executeofs.sh", CreateOfs1 + "%!%" + uniqueIdentifier +  "%!%" + OFSRESPONSE_DIR);

        //to read the file
        //CustomTask task3 = new ExecCommand("cd " + OFSRESPONSE_DIR);
        CustomTask fileReadTask = new ExecCommand("cat " + OFSRESPONSE_DIR + "/" +uniqueIdentifier);

        Result r1 = null;
        Result r2 = null;
        //Result r3 = null;
        Result res = null;

        boolean failed = false;

        try {
            System.out.println("OFS Request is executed now.");

            r1 = sshExecutor.exec(task1);
            r2 = sshExecutor.exec(task2);
            //r3 = sshExecutor.exec(task3);
            res = sshExecutor.exec(fileReadTask);

        } catch (Exception e) {
            System.out.println("Error while executing OFS Request using sshExecutor:::" + e.toString());
            sshExecutor.connect();

            try{
                r1 = sshExecutor.exec(task1);
                r2 = sshExecutor.exec(task2);
                //r3 = sshExecutor.exec(task3);
                try{
                	Thread.sleep(2500);
                }catch(Exception ee){
                	System.out.println("ERROR::" + Throwables.getStackTraceAsString(ee));
                }
                res = sshExecutor.exec(fileReadTask);

            }catch(Exception e1){
                System.out.println("Error while re-executing OFS Request using sshExecutor:::" + e.toString());
                failed = true;
            }
        }

        if(failed){
            System.out.println("Error - Unable to connect to sshExecutor on 2 tries...");
            return null;
        }

        //older approach - not catches with sshExecutor loses connectivity
        /*} catch (TaskExecFailException e) {

            System.out.println("Error while executing OFS Request using sshExecutor:::" + e.getMessage());
        }*/
        System.out.println("Return code: " + r1.rc);

        /*String ReturnString = r2.sysout;
        ReturnString = ReturnString.replace("<requests>", "");
        ReturnString = ReturnString.replace("<request>", "");*/

        System.out.println("FILE READ RESPONSE CODE::" + res.rc);
        System.out.println("FILE READ RESPONSE MSG::" + res.sysout);

        String ReturnString = res.sysout;
        ReturnString = ReturnString.replace("<requests>", "");
        ReturnString = ReturnString.replace("<request>", "");

        return ReturnString;
    }

    //this is to establish connection using sshExecutor only for the first time call
    private static void connectSshExecutor() {

        try{
            if(! executorinitialized){

                System.out.println("###sshExecutor is initialized for the first time.");
                executorinitialized = true;

                Properties prop = new Properties();
                InputStream input;
                String curDir = System.getProperty("user.dir");

                try {
                    input = new FileInputStream(curDir + "\\Config\\config.properties");
                    prop.load(input);
                } catch (IOException e) {
                    System.out.println("Unable to read the config file");
                }

                String host = prop.getProperty("host").trim();
                String user = prop.getProperty("user").trim();
                String password = prop.getProperty("password").trim();

                SSHExec.setOption(IOptionName.HALT_ON_FAILURE, true);
                ConnBean cb = new ConnBean(host, user, password);

                SSHExec.setOption(IOptionName.TIMEOUT, 100000L);	//timeout added for sshexecutor: 24-AUG-2020
                SSHExec.showEnvConfig();
                SysConfigOption.INTEVAL_TIME_BETWEEN_TASKS = 3000;
                //SysConfigOption.TIMEOUT = 200000L;		//timeout added for sshexecutor: 21-AUG-2020

                sshExecutor = SSHExec.getInstance(cb);

                sshExecutor.connect();

                System.out.println("sshExecutor is initialized successfully.");
            }else{

                System.out.println("sshExecutor is already available and alive.");
                SSHExec.setOption(IOptionName.TIMEOUT, 100000L);	//timeout added for sshexecutor: 24-AUG-2020
                SSHExec.showEnvConfig();
                if(Objects.isNull(sshExecutor)){
                    System.out.println("sshExecutor connection was lost.");
                    sshExecutor.connect();
                    System.out.println("sshExecutor connection is re-initialized successfully.");
                }

            }
        }catch(Exception e){
            System.out.println("Error while initializing SShExecutor:::" + e.getMessage());
        }
    }

    //OLDER APPROACH COMMENTED ON 2-MAY-2019
    /*public static String ExecuteComponent(String CreateOfs1) {
        Properties prop = new Properties();
        String curDir = System.getProperty("user.dir");
        InputStream input;



        try {
            input = new FileInputStream(curDir + "\\Config\\config.properties");
            prop.load(input);
        } catch (IOException e) {
            System.out.println("Unable to read the config file");
        }

        String TAFJBIN = prop.getProperty("TAFJBIN").trim();
        String host = prop.getProperty("host").trim();
        String user = prop.getProperty("user").trim();
        String password = prop.getProperty("password").trim();
        String java_home = prop.getProperty("java_home").trim();
        SSHExec.setOption(IOptionName.HALT_ON_FAILURE, true);
        ConnBean cb = new ConnBean(host,user,password);

        SysConfigOption.INTEVAL_TIME_BETWEEN_TASKS = 1000;

        SSHExec ssh = SSHExec.getInstance(cb);

        CustomTask ct1 = new ExecShellScript(TAFJBIN +"/executeofs.sh",CreateOfs1);
        CustomTask ct2 = new ExecCommand("cd " + TAFJBIN);

        //CustomTask ct3 = new ExecCommand("export JAVA_HOME=" + java_home);
        //CustomTask ct4 = new ExecCommand(TAFJBIN + "/tRun TEST.CHECK GCS '" + CreateOfs1 + "'");

        ssh.connect();

        Result r1 = null;

        //Result r2 = null;
        Result r3 = null;
        try {
            r1 = ssh.exec(ct2);
            //r2=ssh.exec(ct3);
            r3=ssh.exec(ct1);
        } catch (TaskExecFailException e) {
            // TODO Auto-generated catch block
            // Uncomment and replace with appropriate logger
            // LOGGER.error(e, e);
        }
        System.out.println("Return code: " + r1.rc);

        //System.out.println("Return code: " + r2.rc);

        String ReturnString = r3.sysout;
        ReturnString = ReturnString.replace("<requests>", "");
        ReturnString = ReturnString.replace("<request>", "");

        System.out.println("Return code: " + r3.rc);
        return ReturnString;

    }*/

}
