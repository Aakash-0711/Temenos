package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class oVerifyLinkExist {
	static String linkText;
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception {
		String[] paramArr=Demo1.arrParameters;
		try{
			linkText=paramArr[0];
			By by=By.linkText(linkText);
			Reuse.LinkPresent(by);
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}
