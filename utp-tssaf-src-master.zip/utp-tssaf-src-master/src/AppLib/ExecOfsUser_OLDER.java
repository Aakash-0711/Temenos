package AppLib;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Random;
import java.util.UUID;

import Driver.Demo1;
import Driver.Reuse;

/**
 * TODO: Document me!
 *
 * @author rashishkumar
 *
 */
public class ExecOfsUser_OLDER {

    public static String SooId;
    public static String CreateOfs = "";
    public static String Err = "";
    public static String ValofsFileName;
    public static BufferedWriter GetofsFieldValue;
    public static String Description;
    public static String ExpectedResult;

    public static void ExecuteComponent() throws Exception {

        try {

            String[] paramArr = Driver.Demo1.arrParameters;
            SooId = "";
            String FieldNameVal = "";
            String uniqueID = UUID.randomUUID().toString();
            String ApplicationName = paramArr[0];
            ValofsFileName = ApplicationName.replace(".", "_") + "_" + uniqueID + ".htm";
            String SooIdVar = paramArr[1];
            String function = paramArr[2];
            String NooFAuth = paramArr[3];
            int noAuth = 0;
            if (NooFAuth.matches("0")) {
                noAuth = 0;
            } else if (NooFAuth.matches("1")) {
                noAuth = 1;
            }

            //modified to have multiple dynamic valiables
            /*if (SooIdVar.startsWith("@auto")) {
                SooIdVar = SooIdVar.replace("@auto", "");
                SooId = StoreText.txtAndVal.get(SooIdVar);
            } else {
                SooId = SooIdVar;
            }*/

            /*if (SooIdVar.contains("#")) {       //if concatenation required between values using #
                StringBuffer buffer = new StringBuffer();
                String[] vars = SooIdVar.split("\\#");
                if(vars[0].startsWith("@auto")) {
                    SooIdVar = vars[0].replace("@auto", "");
                    buffer.append(StoreText.txtAndVal.get(SooIdVar));
                }

                if(vars[1].contains("@auto")) {
                    String delimiter = vars[1].substring(0, vars[1].indexOf("@auto"));

                    SooIdVar = vars[1].substring(vars[1].indexOf(delimiter));
                    SooIdVar = SooIdVar.replace("@auto", "");

                    buffer.append(delimiter);
                    buffer.append(StoreText.txtAndVal.get(SooIdVar));
                }else{
                    buffer.append(vars[1]);
                }

                SooId = buffer.toString();
            } else if(SooIdVar.startsWith("@auto")) {       //if runtime variable alone used
                SooIdVar = SooIdVar.replace("@auto", "");
                SooId = StoreText.txtAndVal.get(SooIdVar);
            }*/

            if(SooIdVar.contains("@auto")) {       //if one or more runtime variable is used
                int count = SooIdVar.split("\\@").length;

                if(count == 2){
                    SooIdVar = SooIdVar.replace("@auto", "");

                    //added to fetch value from properties file if value is not present
                    if(null == StoreText.txtAndVal.get(SooIdVar)){
                        SooIdVar = Reuse.GetPropertyValue(SooIdVar);
                    }else{
                        SooIdVar = StoreText.txtAndVal.get(SooIdVar);
                    }

                }else if(count > 2){
                    do{
                        int start = SooIdVar.indexOf("@auto");
                        int end = SooIdVar.indexOf("@", start + 5);
                        String variable = SooIdVar.substring(start, end + 1);
                        String actualVariable = variable.substring(5, variable.length()-1);

                        String value;

                        if(null == StoreText.txtAndVal.get(actualVariable)){
                            value = Reuse.GetPropertyValue(actualVariable);
                        }else{
                            value = StoreText.txtAndVal.get(actualVariable);
                        }

                        SooIdVar = SooIdVar.replaceFirst(variable, value);
                    }while(SooIdVar.contains("@auto"));
                }

            } /*else {                //if hard-coded value is used
                SooId = SooIdVar;
            }*/

            SooId = SooIdVar;

            System.out.println("RECORD ID:::" + SooId);
            System.out.println("REQUEST::" + paramArr[4]);
            System.out.println("REQUEST LENGTH::" + paramArr[4].length());
            if (!(paramArr[4].matches("null"))) {
                FieldNameVal = paramArr[4];

                String[] NameVal = FieldNameVal.split("\\^");
                FieldNameVal = "";
                for (int y = 0; y < NameVal.length; y++) {
                    String FieldName = NameVal[y].substring(0, NameVal[y].indexOf("="));
                    String FieldValue = NameVal[y].substring(NameVal[y].indexOf("=") + 1, NameVal[y].length());
                    if (FieldValue.contains("@auto")) {
                        /*FieldValue = FieldValue.replace("@auto", "");         //OLDER APPROACH - NOT WORKING
                        FieldValue = StoreText.txtAndVal.get(FieldValue);*/

                        int count = FieldValue.split("\\@", -1).length;

                        if(count == 2){
                            FieldValue = FieldValue.replace("@auto", "");

                            //added to fetch value from properties file if value is not present
                            if(null == StoreText.txtAndVal.get(FieldValue)){
                                FieldValue = Reuse.GetPropertyValue(FieldValue);
                            }else{
                                FieldValue = StoreText.txtAndVal.get(FieldValue);
                            }

                        }else if(count > 2){
                            do{
                                int start = FieldValue.indexOf("@auto");
                                int end = FieldValue.indexOf("@", start + 5);
                                String variable = FieldValue.substring(start, end + 1);
                                String actualVariable = variable.substring(5, variable.length()-1);

                                String value;

                                if(null == StoreText.txtAndVal.get(actualVariable)){
                                    value = Reuse.GetPropertyValue(actualVariable);
                                }else{
                                    value = StoreText.txtAndVal.get(actualVariable);
                                }

                                FieldValue = FieldValue.replaceFirst(variable, value);
                            }while(FieldValue.contains("@auto"));
                        }

                    }else if (FieldValue.equals("null")) {
                        FieldValue = "";
                    }else if (FieldValue.startsWith("@random")) {      //added to generate 7 digit random value to use in any field
                        String runTimeVariableName = FieldValue.replace("@random", "");
                        System.out.println("RUNTIME VARIABLE NAME:::" + runTimeVariableName);
                        Random rnd = new Random();
                        int randomValue = 0;
                        char c1 = ' ';
                        char c2 = ' ';

                        if(ApplicationName.equals("CUSTOMER") || ApplicationName.equals("DX.CONTRACT.MASTER")){
                            randomValue = 100000 + rnd.nextInt(900000);

                            c1 = (char) (rnd.nextInt(26) + 'A');
                            FieldValue = Character.toString(c1) + Integer.toString(randomValue);
                        }else if(ApplicationName.equals("ACCOUNT")){
                            StringBuffer b = new StringBuffer();

                            randomValue = 100 + rnd.nextInt(900);
                            c1 = (char) (rnd.nextInt(26) + 'A');
                            b.append(c1);
                            b.append(randomValue);

                            c2 = (char) (rnd.nextInt(26) + 'A');
                            randomValue = 100 + rnd.nextInt(900);
                            b.append(c2);
                            b.append(randomValue);

                            FieldValue = b.toString();
                        }

                        StoreText.txtAndVal.put(runTimeVariableName, FieldValue);
                    }

                    System.out.println(FieldName + "=" + FieldValue);
                    NameVal[y] = FieldName + "=" + FieldValue;
                }
                for (int y = 0; y < NameVal.length - 1; y++) {
                    FieldNameVal += NameVal[y] + ",";
                }
                FieldNameVal += NameVal[NameVal.length - 1];
            } else {
                FieldNameVal = "";
            }

            String Version = paramArr[5];
            String UserPass = paramArr[6];
            Description = paramArr[8];
            ExpectedResult = paramArr[9];

            String response = "";
            String ofsresponse = "";
            String TxnCommitted = "";
            String ResponseIdVar = paramArr[7];
            Properties prop = new Properties();
            String curDir = System.getProperty("user.dir");
            InputStream input;
            try {
                input = new FileInputStream(curDir + "\\Config\\config.properties");
                prop.load(input);
            } catch (IOException e) {
                System.out.println("Unable to read the config file");
            }

            GetofsFieldValue = new BufferedWriter(new FileWriter(curDir + "\\HTMLResults\\"
                    + prop.getProperty("resultsFolderName").trim() + "\\" + ValofsFileName));
            GetofsFieldValue
                    .write("<html>\n<head><link rel=\"stylesheet\" type=\"text/css\" href=\"../ReportInfo/report_theme.css\"></link>\n</head>\n\t<body>");
            GetofsFieldValue
                    .write("<hr class=\"divline\">\n<table class=\"rephead\" width='1200px'><tr><td height='300px'>WealthSuite Testing</td>");
            GetofsFieldValue
                    .write("<td height='63px' align='right'><img src = '../ReportInfo\\images\\New-Temenos-logo.png'></td>");
            GetofsFieldValue
                    .write("</tr></table><hr class=\"divline\"> <BR>\n<table class=\"subhead\" width='900px'><tr>\n\t");
            GetofsFieldValue
                    .write("<td width='400px' align='left' class=\"subhead\">System</td>\n\t<td width='200px' class=\"subhead\">Table Name</td>\n\t<td width='200px' align='right' class=\"subhead\">Record Id</td>\n</tr>");
            GetofsFieldValue.write("<tr>\n\t<td class=\"subcont\" align='left' width='400px'>T24</td>");
            GetofsFieldValue.write("\n\t<td class=\"subcont\" width='200px'>" + ApplicationName + "</td>");
            GetofsFieldValue.write("<td class=\"subcont\" align='right' width='200px'>" + SooId + "</td>");
            GetofsFieldValue.write(" </tr></table> <hr class=\"divline\"> <BR>");
            GetofsFieldValue
                    .write("<table width='1200px' style=\"table-layout:fixed\" class=\"tsteps\">\n<td class=\"tshead\" width='50px'>Check ID</td>\n<td class=\"tshead\" style=\"word-wrap: break-word;\" width='500px'>OFS Message</td>\n<td class=\"tshead\" style=\"word-wrap: break-word;\" width='500px'>OFS Response</td>\n</tr>");

            String TAFJBIN = prop.getProperty("TAFJBIN").trim();
            String host = prop.getProperty("host").trim();
            String user = prop.getProperty("user").trim();
            String password = prop.getProperty("password").trim();
            String java_home = prop.getProperty("java_home").trim();
            System.out.println("java_home " + java_home);
            CreateOfs = ApplicationName + "," + Version + "/" + function + "/PROCESS//" + noAuth + "," + UserPass + "," + SooId + "," + FieldNameVal;
            System.out.println(CreateOfs);
            String CreateOfs1 = CreateOfs.replace(" ", "#");
            System.out.println(CreateOfs1);

            //String command1 = "pwd && ls -ltr && cd " + TAFJBIN + " && pwd  && export JAVA_HOME=" + java_home + "&& echo $JAVA_HOME && ./tRun TEST.CHECK GCS " + CreateOfs;
           /* String command1 = "pwd && ls -ltr && cd " + TAFJBIN + " && pwd  && export JAVA_HOME=" + java_home + "&& echo $JAVA_HOME && ./tRun TEST.CHECK GCS '" + CreateOfs1 + "'";

            StringBuilder sb = new StringBuilder(" ");
            try {

                java.util.Properties config = new java.util.Properties();
                config.put("StrictHostKeyChecking", "no");
                JSch jsch = new JSch();
                Session session = jsch.getSession(user, host, 22);
                session.setPassword(password);
                session.setConfig(config);
                session.connect();
                System.out.println("Connected");

                Channel channel = session.openChannel("exec");
                ((ChannelExec) channel).setCommand(command1);
                Reuse.oWait(10);
                channel.setInputStream(null);
                ((ChannelExec) channel).setErrStream(System.err);

                InputStream in = channel.getInputStream();
                channel.connect();
                byte[] tmp = new byte[1024];
                while (true) {
                    while (in.available() > 0) {
                        int i = in.read(tmp, 0, 1024);
                        if (i < 0)
                            break;
                        // response = new String(tmp, 0, i);
                        System.out.print(new String(tmp, 0, i));
                        sb.append(new String(tmp, 0, i));
                    }
                    if (channel.isClosed()) {
                        System.out.println("exit-status: " + channel.getExitStatus());
                        break;
                    }
                    try {
                        Thread.sleep(1000);
                    } catch (Exception ee) {
                        System.out.println(ee);
                    }
                }*/

                String sb = SshExecuteOfs.ExecuteComponent(CreateOfs1);

                try {

                    System.out.println("Printing response");
                    System.out.println(sb);
                    System.out.println("Parsing response");
                    response = sb.toString();
                    response = response.replace("\r", "");
                    response = response.replace("\n", "");
                    String[] responselines1 = response.split("ARRAY = ");
                    String[] responselines = responselines1[1].split(" txnCommitted ");
                    System.out.println(responselines.length);
                    System.out.println(responselines[0].replace("Response ", "").trim());
                    System.out.println(responselines[1].trim());
                    ofsresponse = responselines[0].replace("Response ", "").trim();
                    String ResponseIdVarVal = "";
                    try {
                        /*ResponseIdVarVal = ofsresponse.substring(0, ofsresponse.indexOf("//") - 1); commented by sandeep actual recid index is -1 position*/
                        /*ResponseIdVarVal = ofsresponse.substring(0, ofsresponse.indexOf("//"));*/     //commented by mahesh as this is not correct

                        ResponseIdVarVal = ofsresponse.substring(0, ofsresponse.indexOf("/"));

                    } catch (Exception E) {
                        System.out.println("Unable to get recid into " + ResponseIdVar);
                    }
                    StoreText.txtAndVal.put(ResponseIdVar, ResponseIdVarVal);

                    //added to store the run time value in testVariables.properties file
                    Reuse.WriteProperties(ResponseIdVar, ResponseIdVarVal);

                    System.out.println("Store " + ResponseIdVarVal + "in Variable " + ResponseIdVar);
                    TxnCommitted = responselines[1].trim();

                } catch (Exception E) {
                    Err = "Unable to parse the OFS Respose";
                    System.out.println("Unable to parse the OFS Respose");
                }
                if (ofsresponse.matches("")) {
                    GetofsFieldValue
                            .write("<tr>\n<td class=\"tsnorm\" width='50px'> 1 </td>\n<td class=\"tsnorm\" style=\"word-wrap: break-word;\" width='500px'>"
                                    + CreateOfs
                                    + "</td>\n<td class=\"tsnorm\" style=\"word-wrap: break-word;\" width='500px'>"
                                    + sb.toString() + "</td>\n</tr>");
                } else {
                    GetofsFieldValue
                            .write("<tr>\n<td class=\"tsnorm\" width='50px'> 1 </td>\n<td class=\"tsnorm\" style=\"word-wrap: break-word;\" width='500px'>"
                                    + CreateOfs
                                    + "</td>\n<td class=\"tsnorm\" style=\"word-wrap: break-word;\" width='500px'>"
                                    + ofsresponse + "</td>\n</tr>");
                }

                GetofsFieldValue.write("</table>\n</body>\n</html>");
                GetofsFieldValue.close();

                /*
                 * response = response.replace("\r", ""); response =
                 * response.replace("\n",""); String[] responselines1 =
                 * response.split("ARRAY = "); String[] responselines =
                 * response.split(" txnCommitted ");
                 * System.out.println("responselines.length " +
                 * responselines.length); for (int k = 0;k <
                 * responselines.length;k++){
                 * System.out.println(responselines[k]); if
                 * (responselines[k].contains("txnCommitted ")){
                 * System.out.println(responselines[k]); TxnCommitted =
                 * responselines[k].replace("txnCommitted ", "").trim(); }else{
                 *
                 * TxnCommitted = "not found"; }
                 *
                 * System.out.println("TxnCommitted " + TxnCommitted); }
                 */

                if (TxnCommitted.equals("1")) {
                    Demo1.gbTestCaseStatus = "Pass";
                    //Demo1.ReportStep(2, "<a class=\"cindex\" href=\"" + ValofsFileName + "\"><b>Execute OFS Msg</b></a>", "OFS msg Executed<b> </b>", "<b> Transaction Committed " + TxnCommitted + "</b>");
                    Demo1.ReportStep(2, "<a class=\"cindex\" href=\"" + ValofsFileName + "\">" + Description + "</a>",   ExpectedResult + " should be executed", ExpectedResult + "<b> is executed </b>");
                } else {

                    Demo1.gbTestCaseStatus = "Fail";
                    //Demo1.ReportStep(2, "<a class=\"cindex\" href=\"" + ValofsFileName + "\"><b>Execute OFS Msg</b></a>", "OFS msg Execution Failed<b> </b>", "<b> Transaction Committed " + TxnCommitted + "</b>");
                    Demo1.ReportStep(2, "<a class=\"cindex\" href=\"" + ValofsFileName + "\">" + Description + "</a>", ExpectedResult + " should be executed", ExpectedResult + "<b> is not executed </b>");
                }

            /*} catch (Exception e) {
                Err = "Unable to execute OFS message ";
            }*/

        } catch (Exception E1) {

            GetofsFieldValue.write("</table>\n</body>\n</html>");
            GetofsFieldValue.close();
            Demo1.gbTestCaseStatus = "Fail";
            //Demo1.ReportStep(2, "<a class=\"cindex\" href=\"" + ValofsFileName + "\"><b>Execute OFS Msg</b></a>","<b> OFS msg Execution Failed<b> </b>", "<b> ofs response " + Err + "</b>");
            Demo1.ReportStep(2, "<a class=\"cindex\" href=\"" + ValofsFileName + "\">" + Description + "</a>", ExpectedResult + " should be executed", ExpectedResult + "<b> is not executed </b>");
        }

    }



    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }



}
