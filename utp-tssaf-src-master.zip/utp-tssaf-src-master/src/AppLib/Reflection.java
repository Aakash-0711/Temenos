package AppLib;

import java.lang.reflect.Method;

import Driver.Demo1;

public class Reflection {

	public static String aClass;
	public static String aMethod;

	public void testMain(Object[] args) {
		// TODO Insert code here
	}
	public static void execute(String cname, String mname) throws Exception {
		//System.out.println("CLASS::" + cname + "\tMETHOD::" + mname);
		Class cl;
		Method m=null;
		try {
			cl = Class.forName(cname);
			Object o = cl.newInstance();
			m = cl.getDeclaredMethod(mname, null);
			m.invoke(o, null);

		}catch(Exception e){
			e.printStackTrace();
			Demo1.logger.error("Error in Reflection class. "+Demo1.component+" function call having issue while executing the case "+Demo1.gbCurrTestCaseName);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2,"Run time exception in Component executon","Component name: "+Demo1.component+". Parameters: "+Demo1.arrParameters+". Test case ID: "+Demo1.gbCurrTestCaseName ,"An error has occured while executing the component. Pleae check the component call in Testware");
		}
	}
	

}
