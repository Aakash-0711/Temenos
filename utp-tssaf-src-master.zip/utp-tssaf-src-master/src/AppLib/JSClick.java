package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class JSClick {
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			//by=Reuse.GetLocator(paramArr[2]);
			Reuse.JSClick(paramArr[0], paramArr[1]);
		}catch(Exception e){
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Click "+paramArr[0]+" <b>"+paramArr[1] +"</b> ",""+paramArr[0]+" <b>"+paramArr[1] +"</b> should get clicked","Unable to locate "+paramArr[0]+" <b>"+paramArr[1]+"</b>");
		}
	}
}
