package AppLib;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;

import com.google.common.base.Function;
import com.google.common.base.Throwables;

import Driver.Demo1;
import Driver.Reuse;
import Driver.Synchronize;

public class DropdownSelectVisibleText {
    static String parameters, itemToSelect, locatorType, locator, dropdownName;
    static  boolean optional = false;

    /**
     * @param args itemToSelect dropdownName locator
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        ExecuteComponent();
    }

    public static void ExecuteComponent() {
        try {
            String selectedText = "";
            By by = null;
            String[] paramArr = Demo1.arrParameters;
            itemToSelect = paramArr[0];
            dropdownName = paramArr[1];
            by = Reuse.GetLocator(paramArr[2]);
            waitForElement(by);
            if(paramArr.length==4 && paramArr[paramArr.length-1].trim().equalsIgnoreCase("OPTIONAL")){
                optional=true;
            }
            try {
//                Reuse.DropdownSelectVisibleText(by, itemToSelect,dropdownName);
//                Thread.sleep(20000);

//                js.executeScript("var event = new Event('change');arguments[0].dispatchEvent(event);", Demo1.driver.findElement(by));
                JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;

                String fn = "function setSelectedValue(selectObj, valueToSet) {\n" +
                        "    for (var i = 0; i < selectObj.options.length; i++) {\n" +
                        "        if (selectObj.options[i].text== valueToSet) {\n" +
                        "            selectObj.options[i].selected = true;\n" +

                        "        }\n" +
                        "    }\n" +
                        "};setSelectedValue(arguments[0], arguments[1]);";
                try {


                    js.executeScript(fn, Demo1.driver.findElement(by), itemToSelect);



                    Select sel = new Select(Demo1.driver.findElement(by));
                    String selected = sel.getFirstSelectedOption().getText();
                    List<WebElement> opts = sel.getOptions();
                    for (WebElement e : opts) {
                        System.out.println("Available option=>" + e.getText());
                    }
                      selectedText =  (String)js.executeScript("return $(arguments[0]).find(':selected').text();;", Demo1.driver.findElement(by));

                    js.executeScript("$(arguments[0]).trigger('change');", Demo1.driver.findElement(by));

                }catch(Exception e){
                    e.printStackTrace();
                    Synchronize.defaultAjaxSync();
                    System.out.println("EXSTE - Handled stale element exception...");
                    Reuse.log(e);
                    Thread.sleep(10000);

                    js.executeScript(fn, Demo1.driver.findElement(by), itemToSelect);

                    js.executeScript("$(arguments[0]).trigger('change');", Demo1.driver.findElement(by));
                    Thread.sleep(5000);
                    selectedText =  (String)js.executeScript("return $(arguments[0]).find(':selected').text();;", Demo1.driver.findElement(by));
                }

                if (selectedText.trim().toLowerCase().contains(itemToSelect.trim().toLowerCase())) {
                    Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>"
                            + dropdownName + "</b> dropdown", "Item <b>" + itemToSelect
                            + "</b> should be selected", "<b>" + itemToSelect
                            + "</b> Selected");
                } else {
                    if(optional)return;
                    Demo1.gbTestCaseStatus = "Fail";
                    Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>"
                            + dropdownName + "</b> dropdown", "Item <b>" + itemToSelect
                            + "</b> should be selected", "<b>" + itemToSelect
                            + "</b> or element is not found in the application");
                }


            } catch (Exception e) {
                if(optional)return;
                Reuse.log(e);
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown", "Item <b>" + itemToSelect + "</b> should be selected", "<b>" + itemToSelect + "</b> not exist");

            }
        } catch (Exception e) {
            if(optional)return;
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown", "Should be select <b>" + itemToSelect + "</b>", Throwables.getStackTraceAsString(e));
        }
    }




    public static Boolean waitForElement(final By locator) {

        Wait<WebDriver> wait = new FluentWait<>(Demo1.driver).withTimeout(Duration.ofSeconds(40))
                .pollingEvery(Duration.ofMillis(600)).ignoring(NoSuchElementException.class);

        Boolean element = false;
        try {
            element = wait.until(new Function<WebDriver, Boolean>() {

                @Override
                public Boolean apply(WebDriver driver) {

                    return (new Select(Demo1.driver.findElement(locator)).getOptions().size() > 1);
                }
            });
        } catch (Exception e) {
            Reuse.log(e);

        }
        return element;
    }

}
