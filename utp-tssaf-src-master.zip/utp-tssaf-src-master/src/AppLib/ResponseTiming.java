package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class ResponseTiming {

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			if(Demo1.arrParameters[0].toLowerCase().contains("navigationstart")){
				Reuse.performanceTiming_NavigationStart();
			}else if(Demo1.arrParameters[0].toLowerCase().contains("navigationend")){
				Reuse.performanceTiming_NavigationEnd(Double.parseDouble(Demo1.arrParameters[1]));
			}else{
				Demo1.logger.error("Wrong option "+Demo1.arrParameters[0].toString());
			}
		}catch(Exception e){
			Demo1.logger.error("performanceTiming_NavigationStart "+e);
		}
	}
}
