package AppLib;

import java.io.File;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.jcraft.jsch.SftpProgressMonitor;

import Driver.Config;
import Driver.Demo1;


public class FileCopyToServer{
	static String parameters,locatorType,locator,copyFrom,copyTo,action;
	static Logger log = LogManager.getLogger(FileCopyToServer.class.getName());
	/**
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	final static SftpProgressMonitor monitor = new SftpProgressMonitor() {
        @Override
		public void init(final int op, final String source, final String target, final long max) {
            log.info("sftp start uploading file from:" + source + " to:" + target);
        }

        @Override
		public boolean count(final long count) {
            log.debug("sftp sending bytes: " + count);
            return true;
        }

        @Override
		public void end() {
            log.info("sftp uploading is done.");
        }
    };

	public static void ExecuteComponent() throws Exception{
		try{
			By by=null;
			String[] paramArr=Demo1.arrParameters;
			copyFrom=paramArr[0];
			copyTo=paramArr[1];




	        String hostname = Config.getProperty("UnixHost"); // "localhost";
	        String username = Config.getProperty("UnixUserName"); // "3456";
	        String password = Config.getProperty("UnixPassword"); // "9089";


	        System.out.println(copyFrom);
	        // String copyWinFrom = "d:/fromWindows.del";
	  /*      String copyWinTo = "/oams/prodb1_tds/import/tk/import";

	        String copyLinuxFrom = "/home/thin/ibrahim-scripts/fromLinux.del";
	        String copyLinuxTo = "fromLinux.del";*/

	        try {
	            putFile(hostname, username, password, Demo1.curDir+File.separator+copyFrom, copyTo);
//	            getFile(hostname, username, password, copyLinuxFrom, copyLinuxTo);


	        } catch (JSchException e1) {
	            e1.printStackTrace();
	            Demo1.gbTestCaseStatus = "Fail";
	            Demo1.ReportStep(2, action+" <b>"+copyTo+"</b>"+copyFrom,"Should be "+action+" <b>"+copyTo+"</b> "+copyFrom,"Unable to locate <b>"+copyTo+"</b> "+copyFrom+e1);

	        } catch (SftpException e1) {
	            e1.printStackTrace();
	            Demo1.gbTestCaseStatus = "Fail";
	            Demo1.ReportStep(2, action+" <b>"+copyTo+"</b>"+copyFrom,"Should be "+action+" <b>"+copyTo+"</b> "+copyFrom,"Unable to locate <b>"+copyTo+"</b> "+copyFrom+e1);

	        }catch (Exception e1) {
                e1.printStackTrace();
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, action+" <b>"+copyTo+"</b>"+copyFrom,"Should be "+action+" <b>"+copyTo+"</b> "+copyFrom,"Unable to locate <b>"+copyTo+"</b> "+copyFrom+e1);

            }




		}catch(Exception e){
			e.printStackTrace();
			Demo1.logger.error("Problem in Action class");
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, action+" <b>"+copyTo+"</b>"+copyFrom,"Should be "+action+" <b>"+copyTo+"</b> "+copyFrom,"Unable to locate <b>"+copyTo+"</b> "+copyFrom);
		}
	}

	public static void putFile(String hostname, String username, String password, String copyFrom, String copyTo)
            throws JSchException, SftpException {
        log.info("Initiate sending file to Linux Server...");
        JSch jsch = new JSch();
        Session session = null;
        log.info("Trying to connect.....");

        if(Config.unixPort.isEmpty())
        {
            session = jsch.getSession(username, hostname, 22);
        }else{
            session = jsch.getSession(username, hostname, Integer.parseInt(Config.unixPort));
        }
        session.setConfig("StrictHostKeyChecking", "no");
        session.setPassword(password);
        session.connect();
        log.info("is server connected? " + session.isConnected());

        Channel channel = session.openChannel("sftp");
        channel.connect();
        ChannelSftp sftpChannel = (ChannelSftp) channel;
        log.info("Server's home directory: " + sftpChannel.getHome());
        try {
            sftpChannel.put(copyFrom, copyTo, monitor, ChannelSftp.OVERWRITE);
        } catch (SftpException e) {
            log.error("file was not found: " + copyFrom);
        }

        sftpChannel.exit();
        session.disconnect();
        log.info("Finished sending file to Linux Server...");
    }
}
