package AppLib;

import java.util.Arrays;
import java.util.Map;

import org.openqa.selenium.By;

import com.google.common.base.Throwables;

import Driver.Demo1;
import Driver.Reuse;

public class DynamicXpathWithMultipleValues {
    static String parameters, locatorType, locator, harcodedValuesList, elementName, action, elementpresent;
    public static Map<String, String> txtAndVal = null;
    public static Boolean isMapInitialized = false;

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        ExecuteComponent();
    }

    public static void ExecuteComponent() {


        String[] paramArr = Demo1.arrParameters;
        try {


            if (paramArr.length == 4) {
                By by;
                harcodedValuesList = paramArr[0];
                elementName = paramArr[1];
                action = paramArr[2].trim();
                locator = paramArr[3].trim();

                String[] valuesList = harcodedValuesList.split(";");

                if(valuesList[0].trim().isEmpty()){
                    throw new Exception("Empty Values List");
                }


                for(int index = 0; index < valuesList.length; index++){
                    String value = valuesList[index];       //this is to use the hard-coded variable value from script itself

                    if(value.startsWith("DYNAMIC_")){       //this is to get the dynamic variable value from runtime
                        value = Reuse.GetPropertyValue(value);
                    }

                    locator = locator.replaceFirst("VARIABLE" + (index+1), value);
                }

                System.out.println("LOCATOR UPDATED:::" + locator);

                by = Reuse.GetLocator(locator);


                Reuse.VerifyOnClickPaginationElement(elementName, by, action, Arrays.asList(valuesList).toString());
            } else if (paramArr.length == 5) {

                By by;
                By next;
                harcodedValuesList = paramArr[0];
                elementName = paramArr[1];
                action = paramArr[2].trim();
                locator = paramArr[3].trim();

                if (action.equalsIgnoreCase("SELECT")) {

                    String[] valuesList = harcodedValuesList.split(";");

                    if(valuesList[0].trim().isEmpty()){
                        throw new Exception("Empty Values List");
                    }


                    for(String value : valuesList){
                        locator = locator.replaceFirst("$VARIABLE", value);
                    }

                    System.out.println("LOCATOR UPDATED:::" + locator);
                    by = Reuse.GetLocator(locator);

                    String item = paramArr[4];
                    Reuse.Dropdown_SelectItem(by, item, elementName);

                } else {

                    String[] valuesList = harcodedValuesList.split(";");

                    if(valuesList[0].trim().isEmpty()){
                        throw new Exception("Empty Values List");
                    }

                    for(String value : valuesList){
                        locator = locator.replaceFirst("$VARIABLE", value);
                    }

                    System.out.println("LOCATOR UPDATED:::" + locator);
                    by = Reuse.GetLocator(locator);
                    next = Reuse.GetLocator(paramArr[4]);

                    Reuse.VerifyOnClickPaginationElement(elementName, by, next, action, Arrays.asList(valuesList).toString());
                }
            } else {
                throw new Exception("Array parameters mismatch");
            }


        } catch (Exception e) {
            e.printStackTrace();
            String e1 = Throwables.getStackTraceAsString(e);
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Perform " + action + " for  <b>" + elementName + "<b>", "Verify that " + elementName + "=>" + action, "Unable to perform the action"+e1);

        }
    }
}
