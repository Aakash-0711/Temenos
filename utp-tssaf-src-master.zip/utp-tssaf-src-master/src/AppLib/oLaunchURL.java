package AppLib;

import java.util.concurrent.TimeUnit;

import Driver.Config;
import Driver.Demo1;
import Driver.Reuse;

public class oLaunchURL {

	/**
	 * @param args
	 */
	public static String parameters, URL;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() {
		String[] paramArr = Demo1.arrParameters;
		String appUrl = "";
		try {

			// Demo1.driver = Reuse.getIE();

			URL = paramArr[0];
//			if (URL.equalsIgnoreCase("Config.URL")) {
//				appUrl = Config.appURL;
//				System.out.println(">>" + appUrl);
//				Demo1.pingURL = appUrl;
//
//				launch(appUrl);
//
//			} else if (URL.equalsIgnoreCase("Config.URL1")) {
//				appUrl = Config.appURL1;
//				Demo1.pingURL = appUrl;
//				launch(appUrl);
//			} else if (URL.equalsIgnoreCase("Config.URL2")) {
//				appUrl = Config.appURL2;
//				Demo1.pingURL = appUrl;
//				launch(appUrl);
//			} else if (URL.equalsIgnoreCase("Config.URL3")) {
//				appUrl = Config.appURL3;
//				Demo1.pingURL = appUrl;
//				launch(appUrl);
//			} else if (URL.equalsIgnoreCase("Config.URL4")) {
//				appUrl = Config.appURL4;
//				Demo1.pingURL = appUrl;
//				launch(appUrl);
//			} else if (URL.equalsIgnoreCase("Config.URL5")) {
//				appUrl = Config.appURL5;
//				Demo1.pingURL = appUrl;
//				launch(appUrl);
//			} else {
//				launch(URL);
//				Demo1.pingURL = appUrl;
//				appUrl = URL;
//			}
			
			if(URL.trim().toLowerCase().startsWith("config")) {
				appUrl = Config.getProperty(URL.split("[.]")[1]);
				Demo1.pingURL = appUrl;
			    launch(appUrl);
			}
			else {
				launch(URL);
				Demo1.pingURL = appUrl;
				appUrl = URL;
			}
			Reuse.log(Demo1.driver.getTitle());
			Reuse.oWait(2);
			if (Demo1.driver.getTitle().contains("ERROR")) {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Launch Application: " + appUrl, appUrl + " should be launched.",
						"URL " + appUrl + " not launched");

			} else {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Launch Application: " + appUrl, appUrl + " should be launched.",
						"URL " + appUrl + " launched as expected");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Launch Application: " + appUrl, appUrl + " should be launched.", e.getMessage());
		}
	}

	public static void launch(String url) {

		/*
		 * for(int i=1;i<=10;i++){ if
		 * (Config.dedicatedBrowserInstance.toLowerCase().contains("yes")) {
		 * Reuse.CloseAllChildWindows(); Reuse.closeAllWindowAndLaunch(); }
		 * Demo1.driver.get(url); if(urlCheck()){ return; }
		 * 
		 * }
		 */
		System.out.println("URL::" + url);
		String[] paramArr = Demo1.arrParameters;

		if (paramArr.length == 1) {

			for (int i = 1; i <= 10; i++) {
				if (Config.dedicatedBrowserInstance.toLowerCase().contains("yes")) {
					//Reuse.CloseAllChildWindows();
					//Reuse.closeAllWindowAndLaunch();
				}
				Demo1.driver.get(url);
				if (urlCheck()) {
					return;
				}
			}
		} else if (paramArr.length == 2) {

			Demo1.driver.get(url);
			if (urlCheck()) {
				return;
			}
		} else {
			try {
				throw new Exception("Array parameters mismatch");
			} catch (Exception e) {

				e.printStackTrace();

			}
		}

	}

	public static boolean urlCheck() {
		System.out.println("Entering URL check");
		Demo1.driver.manage().timeouts().implicitlyWait(Config.ElementNotPresentWait, TimeUnit.SECONDS);

		try {
			if (!Demo1.driver.getTitle().toLowerCase().contains("problem loading page")) {
				System.out.println("Application has been launched");
				return true;
			} else {
				System.out.println("Error while launching application");
				return false;
			}
		} catch (Exception e) {
			Reuse.log(e);
		} finally {
			Demo1.driver.manage().timeouts().implicitlyWait(Config.TIME_OUT, TimeUnit.SECONDS);
		}
		return false;

	}
}
