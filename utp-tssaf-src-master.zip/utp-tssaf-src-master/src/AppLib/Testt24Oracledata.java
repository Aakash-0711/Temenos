package AppLib;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Driver.Demo1;

public class Testt24Oracledata {

    Connection conn = null;
    Statement stmt = null;


    public static void main(String[] args) throws IOException, SQLException {
        Properties prop = new Properties();

        String curDir;
        curDir = System.getProperty("user.dir");
        InputStream input = new FileInputStream(curDir + "\\Config\\config.properties");
        prop.load(input);

        GetPropertyValues properties = new GetPropertyValues();

        String JDBC_DRIVER = prop.getProperty("t24driver").trim();

        String DB_URL = prop.getProperty("t24url").trim();

        String USER = prop.getProperty("t24dbusername").trim();

        String PASS = prop.getProperty("t24dbpasswordt").trim();
        Date time = new Date(System.currentTimeMillis());
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HH_mm_ss").format(Calendar.getInstance().getTime());
        Demo1.gbTestCaseStatus = "Pass";
        Demo1.DB2flag = true;
        String outexcelFilePath = Createexcel.outexcelpath;

        Connection conn = null;
        Statement stmt = null;
        String Table_name = null;
        String Test_case = null;
        String Checkpoint = null;
        String RECID = null;
        String[] Field_name = new String[15];
        String[] Field_value = new String[15];
        String[] SplitRecord = new String[100];
        String Field_names = null;
        String Field_values = null;
        String indexinformation[] = new String[5];

        int rec;

        String excelFilePath = "TestWare\\TestWare.xlsx";

        String checkpointtestdata = args[0];
        String Description = args[1];
        String ExpectedResult = args[2];
        boolean DBconnect = true;
        FileInputStream inputStream = new FileInputStream(new File(excelFilePath));

        int i = 0;
        int j;
        String prefix = "<html><body><table>\n";
        final StringBuilder sb1 = new StringBuilder(prefix);
        try {
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement();
        } catch (java.sql.SQLException EX) {
            DBconnect = false;
            checksum.Teststatusflag = false;
            Demo1.gbTestCaseStatus = "Fail";
            System.out.println("Problem with Connection correct your T24 URL & Credential");
        }

        if (DBconnect) {
            try {

                Workbook workbook = new XSSFWorkbook(excelFilePath);
                Sheet firstSheet = workbook.getSheetAt(5);
                Workbook workbook1 = new XSSFWorkbook(outexcelFilePath);
                Sheet outsheet = workbook1.getSheetAt(0);
                Iterator<Row> iterator1 = outsheet.iterator();

                short rowcount = 0;
                while (iterator1.hasNext()) {
                    rowcount += 1;
                    iterator1.next();
                }
                DASHBOARD d3 = new DASHBOARD();

                indexinformation[0] = "T24" + checkpointtestdata;
                d3.indexDBDriver(indexinformation);
                String[] indexarg = new String[2];
                indexarg[0] = "T24";
                indexarg[1] = checkpointtestdata;
                d3.DBWriteindexReportHeader(indexarg);

                Iterator<Row> iterator = firstSheet.iterator();
                iterator.next();
                int testcasecount = DASHBOARD.testcasecount;

                while (iterator.hasNext()) {
                    Row nextRow = iterator.next();
                    Iterator<Cell> cellIterator = nextRow.cellIterator();
                    i = 0;

                    Checkpoint = cellIterator.next().getStringCellValue();
                    // System.out.println("debug "+Checkpoint);
                    DASHBOARD.Currentteststatus = "";
                    if (checkpointtestdata.equals(Checkpoint)) {
                        Row nextRow1 = outsheet.createRow(rowcount);
                        rowcount += 1;

                        Test_case = cellIterator.next().getStringCellValue();
                        Table_name = cellIterator.next().getStringCellValue();
                        Table_name = Table_name.replace("\"", "");

                        RECID = cellIterator.next().getStringCellValue();
                        String indirectfield = null;
                        System.out.println(Table_name);

                        RECID = RECID.replace("\"", "");
                        if (RECID.contains("*")) {
                            indirectfield = RECID.substring(RECID.lastIndexOf("*") + 1);
                            RECID = RECID.replace(RECID.substring(RECID.lastIndexOf("*") + 1), "");
                            RECID = RECID.replace("*", "");
                            System.out.println(RECID);
                        }
                        String RECIDtemp = RECID;
                        String suffix = null;
                        String prefixs = null;
                        if (RECID.contains("##")) {
                            suffix = RECID.substring(RECID.lastIndexOf("##"));
                            RECID = RECID.replace(RECID.substring(RECID.lastIndexOf("##")), "");
                            RECID = RECID.replace(suffix, "");
                            suffix = suffix.replace("##", "");
                        }
                        if (RECID.contains("#")) {
                            prefixs = RECID.substring(0, RECID.indexOf("#"));
                            RECID = RECID.replace(RECID.substring(0, RECID.indexOf("#") + 1), "");
                            RECID = RECID.replace(prefixs, "");
                            prefixs = prefixs.replace("#", "");
                        }
                        if (RECID.contains("auto@")) {
                            RECID = RECID.replace("auto@", "");
                            System.out.println(RECID);
                            RECID = StoreText.txtAndVal.get(RECID);
                            System.out.println(RECID);
                        }
                        if (suffix != null) {
                            RECID = RECID + suffix;
                        }
                        if (prefixs != null) {
                            RECID = prefixs + RECID;
                        }

                        System.out.println(RECID);

                        Test_case = Test_case.replace("\"", "");
                        String[] reportstring = new String[4];
                        reportstring[0] = "T24";
                        reportstring[1] = Checkpoint;
                        reportstring[2] = Test_case;
                        DASHBOARD.d2.reportindexbody(reportstring);

                        String arr1[] = new String[8];
                        arr1[0] = "T24_" + Checkpoint + "_" + Test_case;
                        DASHBOARD d1 = new DASHBOARD();
                        d1.testDriver(arr1);

                        i = 0;
                        int colcnt = nextRow.getLastCellNum();
                        System.out.println("colcnt " + colcnt);
                        for (int ii = 0; ii <= ((colcnt - 4) / 2) - 1; ii++) {

                            System.out.println(" i - " + i);
                            System.out.println("ii " + ii);

                            Field_names = cellIterator.next().getStringCellValue();
                            System.out.println(Field_names);
                            Field_names = Field_names.replace("\"", "");
                            Field_values = cellIterator.next().getStringCellValue();
                            System.out.println(Field_values);
                            Field_values = Field_values.replace("\"", "");
                            if (!Field_names.equals("")) {
                                Field_name[i] = Field_names;

                                System.out.println("FIELD NAME:::" + Field_names);
                                if(Field_values.startsWith("auto@")){
                                    System.out.println("FIELD VALUE BEFORE:::" + Field_values);

                                    String value = Field_values.replace("auto@", "");
                                    /*System.out.println("FIELD VALUE UPDTD:::" + value);*/

                                    Field_values = StoreText.txtAndVal.get(value);
                                    System.out.println("FIELD VALUE AFTER REPLACING auto@:::"+ Field_values);

                                    //Field_value[i] = Field_values;
                                }


                                Field_value[i] = Field_values;
                                System.out.print(Field_name[i]);
                                System.out.print(Field_value[i]);

                                System.out.print(" - ");
                                i += 1;
                            }/*else if(Field_names.startsWith("auto@")){
                                System.out.println("FIELD WITH VARIABLE NAME:::" + Field_names);

                                String name = Field_names.replace("auto@", "");
                                System.out.println("RUNTIME VARIABLE NAME:::" + name);

                                Field_name[i] = (String)StoreText.txtAndVal.get(name);
                                System.out.println("AFTER REPLACING auto@:::"+Field_name[i]);

                                Field_value[i] = Field_values;
                            }*/

                        }
                        ArrayList<String> list = new ArrayList<>();
                        for (String s : Field_name)
                            if (!(s == null))
                                list.add(s);
                        Field_name = list.toArray(new String[list.size()]);

                        ArrayList<String> list1 = new ArrayList<>();
                        for (String s1 : Field_value)
                            if (!(s1 == null))
                                list1.add(s1);
                        Field_value = list1.toArray(new String[list.size()]);
                        System.out.println();
                        String[] ActualFieldname = new String[Field_name.length];
                        String[] ActFieldname = new String[Field_value.length];
                        int l = 0;
                        String Multivaluepos[] = new String[ActFieldname.length];
                        String Subvaluepos[] = new String[ActFieldname.length];
                        int[] OrdPos = new int[Field_name.length];
                        for (l = 0; l < Field_name.length; l++) {
                            int CharPos = Field_name[l].indexOf(':');
                            if (CharPos != -1) {
                                ActualFieldname = Field_name[l].split(":");
                                System.out.println(ActualFieldname[0]);
                                ActFieldname[l] = ActualFieldname[0];
                                System.out.println(ActualFieldname[1]);
                                Multivaluepos[l] = ActualFieldname[1];
                                System.out.println(ActualFieldname[2]);
                                Subvaluepos[l] = ActualFieldname[2];
                            } else {
                                ActFieldname[l] = Field_name[l];
                                Multivaluepos[l] = "1";
                                Subvaluepos[l] = "1";

                            }

                        }
                        try {

                            Class.forName("org.h2.Driver");
                        } catch (ClassNotFoundException e) {

                        }

                        System.out.println("Connecting to database...");
                        try {
                            System.out.println(DB_URL);
                            conn = DriverManager.getConnection(DB_URL, USER, PASS);
                        } catch (SQLException e) {
                            System.out.println(e);

                        }

                        System.out.println("Creating statement...");
                        try {
                            stmt = conn.createStatement();
                        } catch (SQLException e) {

                        }
                        String record = null;
                        int StrLeng = Table_name.length();

                        int StrFileName = Table_name.indexOf('.');
                        String AppNAme = Table_name.substring(StrFileName + 1, StrLeng);
                        int NAUreplace = AppNAme.indexOf('$');
                        if (NAUreplace >= 0) {
                            AppNAme = AppNAme.substring(0, NAUreplace);
                        }
                        System.out.println("SS NAME " + AppNAme);

                        String sql1 = "SELECT  * FROM F_STANDARD_SELECTION WHERE RECID = '" + AppNAme + "'";
                        ResultSet rs = null;
                        try {
                            rs = stmt.executeQuery(sql1);
                        } catch (SQLException se) {

                            System.out.println("Invalid application");
                            se.printStackTrace();
                        }
                        while (rs.next()) {
                            record = rs.getString("XMLRECORD");
                        }
                        if (record == null) {
                            System.out.println("invalid application");

                        }
                        rs.close();
                        String aChar = null;
                        String bChar = null;
                        String cChar = null;
                        String[] FieldNameSS = null;
                        String[] UserFieldNameSS = null;
                        String[] FieldPosSS = null;
                        String[] UserFieldPosSS = null;
                        String[] PosField = null;
                        String[] localpos = new String[100];
                        PosField = new String[ActFieldname.length];
                        //System.out.println(record);
                        if (record != null) {
                            String c1[] = record.split("<c2>", 0);
                            String c2[]=record.split("<c16>", 0);
                            String c1args[] = new String[5];
                            // String Fieldpos1[]=new String[2] ;
                            for (int k = 0; k < ActFieldname.length; k++) {
                                c1args[0] = c1[0];
                                c1args[1] = ActFieldname[k];
                                c1args[2] = record;
                                c1args[3] = c2[0];
                                String Fieldpos[] = Fieldpos(c1args);
                                PosField[k] = Fieldpos[0];
                                if (!(Fieldpos[1].matches(""))){
                                    Subvaluepos[k] = Multivaluepos[k];
                                    Multivaluepos[k] = Fieldpos[1];
                                }
                            }
                            /*
                             * int FM = 63742; aChar = new
                             * Character((char)FM).toString(); SplitRecord =
                             * record.split(aChar); int VM = 63741; bChar = new
                             * Character((char)VM).toString(); int SM = 63740;
                             * cChar = new Character((char)SM).toString();
                             * FieldNameSS = SplitRecord[0].split(bChar);
                             * FieldPosSS = SplitRecord[2].split(bChar);
                             * UserFieldNameSS = SplitRecord[14].split(bChar);
                             * UserFieldPosSS = SplitRecord[16].split(bChar);
                             * PosField = new String[ActFieldname.length]; int
                             * userpos; for(int n=0;n<ActFieldname.length;n++){
                             * int pos =
                             * Arrays.asList(FieldNameSS).indexOf(ActFieldname
                             * [n]); if (pos==-1){ userpos =
                             * Arrays.asList(UserFieldNameSS
                             * ).indexOf(ActFieldname[n]); if(userpos==-1) {
                             * System.out.println("invalid field"); PosField[n]
                             * = "invalid field"; } else { // PosField[n]=
                             * Arrays.asList(FieldNameSS).indexOf(localpos[0]);
                             * System.out.println("userpos"+userpos);
                             * System.out.
                             * println("UserFieldNameSS"+UserFieldNameSS
                             * [userpos]);
                             * System.out.println("userposition"+UserFieldPosSS
                             * [userpos]); localpos[n]= UserFieldPosSS[userpos];
                             * pos =
                             * Arrays.asList(FieldNameSS).indexOf("LOCAL.REF");
                             * PosField[n] = FieldPosSS[pos];
                             * System.out.println(
                             * "userfield "+PosField[n]+userpos); } } else {
                             * localpos[n]="0"; PosField[n] = FieldPosSS[pos]; }
                             * }
                             */
                        }
                        ResultSet rs1 = null;
                        String Record1 = null;
                        if (record != null) {

                            try {
                                ResultSet tablers = null;
                                String sqltable = "SELECT ORCLFILENAME FROM TAFJ_VOC WHERE RECID = '" + Table_name
                                        + "'";
                                System.out.println("VOC SQL" + sqltable);
                                tablers = stmt.executeQuery(sqltable);
                                tablers.next();
                                System.out.println("oracle file name " + tablers.getString("ORCLFILENAME"));
                                String Sqlexe = "SELECT XMLRECORD FROM \"" + tablers.getString("ORCLFILENAME")
                                + "\" WHERE RECID = '" + RECID + "'";
                                rs1 = stmt.executeQuery(Sqlexe);

                                while (rs1.next()) {
                                    Record1 = rs1.getString("XMLRECORD");
                                }
                            } catch (SQLException se) {

                                System.out.println("Invalid record ID");
                                se.printStackTrace();
                            }
                        }

                        if (Record1 == null) {
                            System.out.println("invalid record");

                        }
                        System.out.println(Record1);
                        if (Record1 != null && record != null) {
                            String[] ActFldVal = new String[Field_value.length];
                            // String[] SplitRecord1 = Record1.split(aChar);
                            String args1[] = new String[4];
                            for (int p = 0; p < ActFieldname.length; p++) {

                                args1[0] = Record1;
                                args1[1] = PosField[p];
                                if (!(PosField[p].equals("invalid field")))
                                {
                                    if (Integer.parseInt(Multivaluepos[p]) == 1) {
                                        if (Integer.parseInt(Subvaluepos[p]) == 1) {
                                            Multivaluepos[p] = "1";// "<c"+args[1]+" m=\"2\""+">"
                                            Subvaluepos[p] = "1";
                                            args1[2] = "<c" + PosField[p] + ">";

                                        } else if (Integer.parseInt(Subvaluepos[p]) > 1) {
                                            //args1[2] = "<c" + PosField[p] + " m=\"" + Multivaluepos[p] + "\"" + " s=\"" + Subvaluepos[p] + "\">";
                                            args1[2] = "<c" + PosField[p] + " m='" + Multivaluepos[p] + "'" + " s='" + Subvaluepos[p] + "'>";
                                        }

                                    } else if (Integer.parseInt(Multivaluepos[p]) > 1) {
                                        if (Integer.parseInt(Subvaluepos[p]) > 1) {
                                            //args1[2] = "<c" + PosField[p] + " m=\"" + Multivaluepos[p] + "\"" + " s=\"" + Subvaluepos[p] + "\">";
                                            args1[2] = "<c" + PosField[p] + " m='" + Multivaluepos[p] + "'" + " s='" + Subvaluepos[p] + "'>";

                                        } else {
                                            //args1[2] = "<c" + PosField[p] + " m=\"" + Multivaluepos[p] + "\">";
                                            args1[2] = "<c" + PosField[p] + " m='" + Multivaluepos[p] + "'>";
                                        }
                                    }

                                    ActFldVal[p] = FieldValue(args1);

                                }
                            }

                            nextRow1.createCell(0).setCellValue("T24");
                            nextRow1.createCell(1).setCellValue(Checkpoint);

                            nextRow1.createCell(2).setCellValue(Test_case);
                            nextRow1.createCell(3).setCellValue(Table_name);
                            nextRow1.createCell(4).setCellValue(RECID);
                            arr1[0] = "T24";
                            arr1[1] = Checkpoint;
                            arr1[2] = Test_case;
                            arr1[3] = Table_name;
                            arr1[4] = RECID;
                            arr1[5] = "No Error";

                            d1.WriteReportHeader(arr1);
                            String arr2[] = new String[8];
                            for (j = 0; j < i; j++) {
                                String temp = Field_name[j];

                                Cell celltowritefieldname = nextRow1.createCell(4 * (j + 1) + 2);
                                System.out.println(Field_value[j]);
                                Cell celltowriteexpectedvalue = nextRow1.createCell(4 * (j + 1) + 3);
                                Cell celltowriteactualvalue = nextRow1.createCell(4 * (j + 1) + 4);
                                Cell celltowritecomments = nextRow1.createCell(4 * (j + 1) + 5);
                                celltowritefieldname.setCellValue(Field_name[j]);
                                celltowriteexpectedvalue.setCellValue(Field_value[j]);
                                celltowriteactualvalue.setCellValue(ActFldVal[j]);
                                arr2[0] = Field_name[j];
                                arr2[1] = Field_value[j];
                                arr2[3] = "No Error";
                                arr2[2] = "";
                                if (!(PosField[j].equals("invalid field"))) {
                                    arr2[2] = ActFldVal[j];

                                    if (!ActFldVal[j].equals(Field_value[j]))

                                    {
                                        checksum.Teststatusflag = false;
                                        DASHBOARD.Currentfieldstatus = "fail";
                                        DASHBOARD.Currentteststatus = "fail";
                                        checksum.teststatus = "fail";
                                        Demo1.gbTestCaseStatus = "Fail";
                                        String Err = "Error in " + Field_name[j] + " Expected Not Equal to Actual "
                                                + ActFldVal[j] + " != " + Field_value[j];
                                        System.out.println("Error in " + Field_name[j]
                                                + " Expected Not Equal to Actual " + ActFldVal[j] + " != "
                                                + Field_value[j]);

                                        Cell celltowrite = nextRow.createCell(2 * i + j + 3);

                                        celltowrite.setCellValue(Err);
                                        celltowritecomments.setCellValue(Err);
                                        arr2[3] = Err;
                                        System.out.println(celltowrite.getStringCellValue());

                                    }
                                } else {
                                    checksum.Teststatusflag = false;
                                    DASHBOARD.Currentfieldstatus = "fail";
                                    Demo1.gbTestCaseStatus = "Fail";
                                    DASHBOARD.Currentteststatus = "fail";
                                    checksum.teststatus = "fail";
                                    arr2[3] = "Invalid Field name '" + Field_name[j] + "' in" + Table_name;
                                    celltowritecomments.setCellValue("Invalid Field Name '" + Field_name[j] + "' in "
                                            + Table_name);

                                }
                                d1.reportbody(arr2);

                            }

                        } else {
                            checksum.Teststatusflag = false;
                            DASHBOARD.Currentteststatus = "fail";
                            Demo1.gbTestCaseStatus = "Fail";

                            if (record == null) {
                                checksum.teststatus = "fail";

                                arr1[5] = "Invalid '" + Table_name + "' T24 TABLE";
                            } else if (Record1 == null) {
                                checksum.teststatus = "fail";

                                arr1[5] = "Record '" + RECID + "' not found in " + Table_name;
                            }
                            nextRow1.createCell(0).setCellValue("T24");
                            nextRow1.createCell(1).setCellValue(Checkpoint);

                            nextRow1.createCell(2).setCellValue(Test_case);
                            nextRow1.createCell(3).setCellValue(Table_name);
                            nextRow1.createCell(4).setCellValue(RECID);
                            nextRow1.createCell(5).setCellValue(arr1[5]);
                            arr1[0] = "T24";
                            arr1[1] = Checkpoint;
                            arr1[2] = Test_case;
                            arr1[3] = Table_name;
                            arr1[4] = RECID;

                            d1.WriteReportHeader(arr1);
                        }
                        d1.reportclose();
                        String[] reportbody = new String[6];
                        reportbody[0] = "T24";
                        reportbody[1] = checkpointtestdata;
                        reportbody[2] = Test_case;
                        reportbody[3] = Table_name;
                        reportbody[4] = RECID;
                        DASHBOARD.testcasecount = DASHBOARD.testcasecount + 1;
                        reportbody[5] = Integer.toString(DASHBOARD.testcasecount);
                        if (args[0].contains("NEGATIVE")) {
                            if (DASHBOARD.Currentteststatus.equals("fail")) {
                                DASHBOARD.Currentteststatus = "";
                            } else if (DASHBOARD.Currentteststatus.equals("")) {
                                DASHBOARD.Currentteststatus = "fail";
                            }
                        }
                        d3.DBreportindexbody(reportbody);
                        if (rs1 != null) {
                            rs1.close();
                            stmt.close();
                            conn.close();

                        }

                    }

                    inputStream.close();

                }
                d3.indexDBclose();
                Workbook workbook2 = new XSSFWorkbook();
                workbook2 = workbook1;

                FileOutputStream fos = new FileOutputStream(outexcelFilePath, true);
                workbook2.write(fos);
                workbook2.close();
                workbook1.close();
            } catch (NoSuchElementException ex) {
                DASHBOARD.Currentteststatus = "Warn";
                DASHBOARD.Currentfieldstatus = "Warn";
                Demo1.gbTestCaseStatus = "Warn";
                Demo1.TestStepWarningCount = Demo1.TestStepWarningCount + 1;
                Demo1.logger.warn("Warning in " + Demo1.gbCurrTestCaseName + "  --->" + ex);
                System.out.println(ex);
                ex.printStackTrace();

            } catch (IllegalStateException ex) {
                DASHBOARD.Currentteststatus = "Warn";
                DASHBOARD.Currentfieldstatus = "Warn";
                Demo1.gbTestCaseStatus = "Warn";
                Demo1.TestStepWarningCount = Demo1.TestStepWarningCount + 1;
                Demo1.logger.warn("Warning in " + Demo1.gbCurrTestCaseName + "  --->" + ex.getStackTrace());
                System.out.println(ex);

            }
        }
        if (!checksum.checksumvariable) {
            Demo1.Linkflag = true;
            if (Demo1.gbTestCaseStatus.equals("Warn")) {
                Demo1.SCBindexpage = "..\\..\\logs\\application.html";
                //Demo1.ReportStep(2, "<b>T24 DB CHECK</b>", args[0], Demo1.gbTestCaseStatus);
                Demo1.ReportStep(2,Description,ExpectedResult + " should be available",ExpectedResult + " unable to find ");
                System.out.println("ReportStep");
            } else if (!DBconnect) {
                Demo1.Linkflag = false;
                //Demo1.ReportStep(2, "<b>T24 DB CHECK</b>", args[0], "Problem with Connection, Correct your T24 DB URL & DB Credential");
                Demo1.ReportStep(2,Description,ExpectedResult + " should be available","Problem with Connection, Correct your Sysbase DB URL & DB Credential");
                System.out.println("ReportStep");
            } else {
                Demo1.SCBindexpage = indexinformation[0];
                if (args[0].contains("NEGATIVE")) {
                    if (Demo1.gbTestCaseStatus.equals("Pass")) {
                        Demo1.gbTestCaseStatus = "Fail";
                    } else if (Demo1.gbTestCaseStatus.equals("Fail")) {
                        Demo1.gbTestCaseStatus = "Pass";
                    }
                }

                if (Demo1.gbTestCaseStatus.equals("Pass")){
                    Demo1.ReportStep(2,Description,ExpectedResult + " should be available",ExpectedResult + " is available ");
                }else if (Demo1.gbTestCaseStatus.equals("Fail")){
                    Demo1.ReportStep(2,Description,ExpectedResult + " should be available",ExpectedResult + " is not available ");
                }
                //Demo1.ReportStep(2, "<b>T24 DB CHECK</b>", args[0], Demo1.gbTestCaseStatus);
                //Demo1.ReportStep(2,Description,ExpectedResult + " should be available",ExpectedResult + " is available <b>" + Demo1.gbTestCaseStatus + "</b>");
                System.out.println("testt24oracledata ReportStep " + Demo1.gbTestCaseStatus);
            }
        }

    }

    public static void ExecuteComponent() throws Exception {

        String[] paramArr = Demo1.arrParameters;
        try {
            main(paramArr);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String[] Fieldpos(String[] args) {
        String Pos[] = new String[2];
        if (args[0].contains(args[1])) {
            String Field_tagpos[] = args[0].split(">" + args[1] + "<", 0);
            Field_tagpos = Field_tagpos[0].split("<c1 m=");
            String temp = Field_tagpos[Field_tagpos.length - 1];
            temp = temp.replace('>', ' ').trim();
            // System.out.println(temp);
            Field_tagpos = args[2].split("<c3 m=" + temp + ">", 0);
            Field_tagpos = Field_tagpos[1].split("</c3>", 0);
            Pos[0] = Field_tagpos[0];
            Pos[1] = "";
        }else if (args[3].contains(args[1])){
            String Field_tagpos[] = args[0].split(">LOCAL.REF<", 0);
            Field_tagpos = Field_tagpos[0].split("<c1 m=");
            String temp = Field_tagpos[Field_tagpos.length - 1];
            temp = temp.replace('>', ' ').trim();
            Field_tagpos = args[2].split("<c3 m=" + temp + ">", 0);
            Field_tagpos = Field_tagpos[1].split("</c3>", 0);
            Pos[0] = Field_tagpos[0];
            String s = args[2].substring(args[2].indexOf("<c15>") + 1);
            s = s.substring(0,s.indexOf("<c16>"));
            String s1 = args[2].substring(args[2].indexOf("</c16>") + 1);
            s1 = s1.substring(0,s1.indexOf("<c18"));
            String Field_tagpos1[] = s.split(">" + args[1] + "<", 0);
            String temp1 = null;
            System.out.println("Field_tagpos[0] - "+ Field_tagpos1[0]);
            if (Field_tagpos1[0].equals("c15")){
                Field_tagpos1 = Field_tagpos1[0].split("c15");
                temp1 = "1";
            }else{
                Field_tagpos1 = Field_tagpos1[0].split("<c15 m=");
                temp1 = Field_tagpos1[Field_tagpos1.length - 1];
                temp1 = temp1.replace('>', ' ').trim();
            }

            System.out.println("local field position - " + temp1);

            if (temp1.matches("1")){
                Field_tagpos1 = s1.split("<c17>", 0);
                System.out.println("in 1st local field");
            }else{
                Field_tagpos1 = s1.split("<c17 m=" + temp1 + ">", 0);
                System.out.println("in normal local field");

            }

            System.out.println(Field_tagpos1[1]);
            Field_tagpos1 = Field_tagpos1[1].split("</c17>", 0);
            System.out.println(Field_tagpos1[0]);
            String Pos1 = Field_tagpos1[0];
            Pos1 = Pos1.replace("LOCAL.REF&lt;1,","");
            Pos1 = Pos1.replace("&gt;", "");
            System.out.println(args[1] + "-" + Pos1);
            Pos[1] = Pos1;

        }
        else
        {
            Pos[0]="invalid field";
            Pos[1] = "";
        }


        // System.out.println("POSITION inside function "+Field_tagpos[0]);
        return Pos;

    }

    public static String FieldValue(String[] args) {
        System.out.println(args[2]);
        String[] Field_tagpos = args[0].split(args[2]);// ("<c"+args[1])
        if(args[0].contains(args[2]))
        {
            Field_tagpos = Field_tagpos[1].split("</c" + args[1] + ">", 0);// ("</c"+args[1]+">");

            System.out.println("tags value " + args[2] + " pos " + args[1] + " " + Field_tagpos[0]);

        }
        else
        {
            Field_tagpos[0]="";
        }
        // for(int i= 0;i<Field_tagpos.length-1;i++)
        // {
        // System.out.println("tags value "+args[1]+" "+Field_tagpos[i]);
        // }

        return Field_tagpos[0];

    }
}