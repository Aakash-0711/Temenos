package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;


public class ReadTextFromTextArea_AddInFile {
       
	static String fileName,locator,textBoxName;
	public static void main(String[] args) throws Exception {
		ExecuteComponent();
	}
	
	public static void ExecuteComponent() throws Exception{	
		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			fileName=paramArr[0];
			textBoxName=paramArr[1];
			by=Reuse.GetLocator(paramArr[2]);
			Reuse.ReadTextFromTextArea_AddInFile(fileName,textBoxName,by);
		}catch(Exception e){
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Read text from <b>"+textBoxName+"</b> and add it in file",
					"Text should be added to the file <b>"+fileName+"</b>", "Text is not added to the file");
		}		
	}

}
