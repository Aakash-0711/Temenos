package AppLib;

import java.util.Random;

import Driver.Demo1;
import Driver.Reuse;

public class GenerateRandomID {
    static String applicationName, variableName;

    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        // TODO Auto-generated method stub
        ExecuteComponent();
    }

    private static String generateId(){
        Random rnd = new Random();
        int randomValue = 100000 + rnd.nextInt(900000);

        return Integer.toString(randomValue);
    }

    public static void ExecuteComponent() throws Exception {
        try {
            String[] paramArr = Demo1.arrParameters;
            applicationName = paramArr[0].trim();
            variableName = paramArr[1].trim();

            String suffix = "";
            String randomId = "";

            if(applicationName.equals("PORTFOLIO")){

                suffix = "_PTF";
                randomId = generateId() + suffix;
            }else if(applicationName.equals("CLIENT")){

                suffix = generateId();
                randomId = "ACL_" + suffix;
            }else if(applicationName.equals("INSTRUMENT")){

                suffix = "_Inst";
                randomId = generateId() + suffix;
            }

            if(variableName.startsWith("auto@")){
                variableName = variableName.replace("auto@", "");
            }

            /*StoreText.txtAndVal.put(variableName, randomId);*/

            //added to store the run time value in testVariables.properties file
            Reuse.WriteProperties(variableName, randomId);

            Demo1.gbTestCaseStatus = "Pass";
            Demo1.ReportStep(2, "Random ID generation", "Expected to generate a random ID for " + applicationName,
                    "Random ID was successfully generated for " + applicationName + " application and stored in " + variableName);

        } catch (Exception e) {
            Reuse.log(e);
            Demo1.logger.error(e);
            Demo1.ReportStep(2, "Random ID generation", "Expected to generate a random ID for " + applicationName,
                    e.getMessage());
        }
    }
}
