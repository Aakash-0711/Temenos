package AppLib;
import org.apache.commons.text.diff.CommandVisitor;
import org.apache.commons.text.diff.StringsComparator;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class AAAA {

    public static void main(String[] args) {
    	File xmlFile1 = new File("C:\\APITESTING\\Samplefiles\\Sometags-missing\\SFD-BR109365BMJHFKB0-Baselined.xml");
        File xmlFile2 = new File("C:\\APITESTING\\Samplefiles\\Sometags-missing\\SFD-BR109365BMJHFKB0.xml");
        File ignoreTagsFile = new File("C:\\APITESTING\\Samplefiles\\Sometags-missing\\ignore.txt");

        Set<String> tagsToIgnore = loadTagsToIgnore(ignoreTagsFile);

        if (tagsToIgnore == null) {
            System.err.println("Failed to load tags to ignore.");
            return;
        }

        try {
            String xml1 = parseXML(xmlFile1, tagsToIgnore);
            String xml2 = parseXML(xmlFile2, tagsToIgnore);

            StringsComparator comparator = new StringsComparator(xml1, xml2);
            DifferenceVisitor visitor = new DifferenceVisitor();
            comparator.getScript().visit(visitor);

            if (visitor.hasDifferences()) {
                System.out.println("Differences found:");
                visitor.printDifferences();
            } else {
                System.out.println("No differences found.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Set<String> loadTagsToIgnore(File file) {
        try {
            return Files.lines(file.toPath()).map(String::trim).collect(Collectors.toSet());
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private static String parseXML(File xmlFile, Set<String> tagsToIgnore) throws JAXBException {
        JAXBContext context = JAXBContext.newInstance(AppLib.AA.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();
        Object xmlObject = unmarshaller.unmarshal(xmlFile);

        StringWriter writer = new StringWriter();
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        marshaller.marshal(xmlObject, writer);
        String xmlString = writer.toString();

        for (String tag : tagsToIgnore) {
            xmlString = xmlString.replaceAll("<" + tag + ".*?</" + tag + ">", "");
        }

        return xmlString;
    }

    static class DifferenceVisitor implements CommandVisitor<Character> {
        private boolean differencesFound = false;

        @Override
        public void visitKeepCommand(Character c) {
            // No action needed
        }

        @Override
        public void visitInsertCommand(Character c) {
            differencesFound = true;
            System.out.println("Insert: " + c);
        }

        @Override
        public void visitDeleteCommand(Character c) {
            differencesFound = true;
            System.out.println("Delete: " + c);
        }

        public boolean hasDifferences() {
            return differencesFound;
        }

        public void printDifferences() {
            // Additional logic to print differences can be added here
        }
    }
}
