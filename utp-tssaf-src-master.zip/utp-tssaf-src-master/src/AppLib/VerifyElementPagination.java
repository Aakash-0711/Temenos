package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class VerifyElementPagination {
	static String valueToFind,elementxpath;
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
        By by=null;
        try{
            String[] paramArr=Demo1.arrParameters;
            valueToFind=paramArr[0].trim();
          by=Reuse.GetLocator(paramArr[1]);
            Reuse.VerifyPagination(valueToFind,by);
        }catch(Exception e){
            Demo1.logger.error(e);
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Page not Navigated to <b>", " ","Unable to click next page tab");
        }
	}
}
