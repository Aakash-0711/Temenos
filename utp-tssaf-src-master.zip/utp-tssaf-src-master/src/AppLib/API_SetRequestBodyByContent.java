package AppLib;

import Driver.Demo1;
import Driver.Reuse;
import Driver.ReuseT24API;

public class API_SetRequestBodyByContent {
	static String userName,Password,URL,path,action;
	private static String appUrl;
	/**
	 * @param
	 * elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;


		path = paramArr[0];


		try {
			ReuseT24API.API_givenRequestBodyContent(path);
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "To request api ",
                    "API request of is should be sent",
                    "API request not set successfully");
		}
	}

}
