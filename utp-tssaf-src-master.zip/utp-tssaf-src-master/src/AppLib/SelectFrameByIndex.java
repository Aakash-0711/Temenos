package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class SelectFrameByIndex {
	static int index,param;
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception {
		String[] paramArr=Demo1.arrParameters;
		try{
			index=Integer.parseInt(paramArr[0]);
			Reuse.SelectFrame(index);
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}
