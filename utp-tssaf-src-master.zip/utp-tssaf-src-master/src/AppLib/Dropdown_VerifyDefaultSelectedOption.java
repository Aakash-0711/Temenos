package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class Dropdown_VerifyDefaultSelectedOption {
	static String dropdownName,expectedOption;
	/**
	 * @param args
	 * optionToCheck
	 * dropdownName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			dropdownName=paramArr[0];
			expectedOption=paramArr[1];
			by=Reuse.GetLocator(paramArr[2]);
			Reuse.Dropdown_VerifyDefaultSelectedOption(by,dropdownName,expectedOption);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
		    Demo1.ReportStep(2, "Vefify default selected option in <b>"+dropdownName+"</b> dropdown","Default selectd option should be <b>"+expectedOption+"</b>",e.getMessage());
		}
	}
}
