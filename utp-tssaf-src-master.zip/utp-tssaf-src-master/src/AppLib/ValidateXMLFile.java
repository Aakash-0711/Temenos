package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class ValidateXMLFile {
	static String parameters,key,pathOfXml,rootTag,position,tagName,expectedValue;
	/**
	 * @param key
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception  {
		String[] paramArr=Demo1.arrParameters;
		try{
		    pathOfXml=paramArr[0];
		    rootTag=paramArr[1];
		    position=paramArr[2];
		    tagName=paramArr[3];
		    expectedValue=paramArr[4];


			Reuse.XMLValidate(pathOfXml, rootTag, position, tagName, expectedValue);

		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}
