package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class Tomcat{
	static String path,action;
	/**
	 * @param
	 *  elementType
	 *  elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			By by=null;
			String[] paramArr=Demo1.arrParameters;
			path=paramArr[0];
			action=paramArr[1].trim();

			if(action.equals("START")){
				Reuse.TomcatStart(path);
			}else if(action.equals("STOP")){
				Reuse.TomcatStop(path);
			}

		}catch(Exception e){
			if(action.equals("START")){
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Start Tomcat server","Server should be started",e.getMessage());
			}else if(action.equals("STOP")){
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Stop Tomcat server","Server should be stopped",e.getMessage());
			}
		}
	}
}
