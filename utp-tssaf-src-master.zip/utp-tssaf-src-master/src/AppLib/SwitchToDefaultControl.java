package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class SwitchToDefaultControl {

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			Reuse.SwitchToDefaultControl();
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Switch to Default control","Should be switched to default control",e.getMessage());
		}
	}
}
