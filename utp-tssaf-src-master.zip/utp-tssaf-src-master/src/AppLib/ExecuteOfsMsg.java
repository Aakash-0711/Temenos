package AppLib;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

import com.google.common.base.Throwables;

import Driver.Demo1;
import Driver.Reuse;

/**
 * TODO: Document me!
 *
 * @author maheshkathirvel
 *
 */
public class ExecuteOfsMsg {

    public static String applicationName, ofsMessage, tafjHome, outputParams, javaHome, routineValue;
    private static String responseFileName = "OfsResponse.txt";
    private static String responseMessage = "", txnCommittedStatus = "";
    static String curDir = System.getProperty("user.dir");

    public static void ExecuteComponent() throws Exception {

        try {

            String[] paramArr = Driver.Demo1.arrParameters;

            applicationName = paramArr[0];
            ofsMessage = paramArr[1];
            outputParams = paramArr[2];



            Properties prop = new Properties();

            InputStream input;
            try {
                input = new FileInputStream(curDir + "\\Config\\config.properties");
                prop.load(input);

                tafjHome = prop.getProperty("TAFJHOME").trim();
                javaHome = prop.getProperty("JAVAHOME").trim();

            } catch (IOException e) {
                System.out.println("Unable to read the config file");
            }


            if (paramArr.length == 4){

                routineValue = paramArr[3];

                try{
                    FileWriter fw=new FileWriter(curDir + "\\TestData\\ExecuteOfs.bat");
                    fw.write("set JAVA_HOME="+javaHome+"\n");
                    fw.write("set TAFJ_HOME="+tafjHome+"\n");

                            fw.write("set OFSMSG=%1\n");
                            fw.write("CRT \"MESSAGE:::\" %OFSMSG%\n");
                            fw.write("cd %TAFJ_HOME%/bin\n");
                            fw.write("./tRun REG.PROCESS.OFS.MSG "+ routineValue+" %OFSMSG%\n");

                    fw.close();
                   }catch(Exception e){
                       e.printStackTrace();
                       System.out.println(e);
                       }


            }
            else{
                try{
                    FileWriter fw=new FileWriter(curDir + "\\TestData\\ExecuteOfs.bat");
                    fw.write("set JAVA_HOME="+javaHome+"\n");
                    fw.write("set TAFJ_HOME="+tafjHome+"\n");

                            fw.write("set OFSMSG=%1\n");
                            fw.write("CRT \"MESSAGE:::\" %OFSMSG%\n");
                            fw.write("cd %TAFJ_HOME%/bin\n");
                            fw.write("./tRun REG.PROCESS.OFS.MSG GCS %OFSMSG%\n");

                    fw.close();
                   }catch(Exception e){
                       e.printStackTrace();
                       System.out.println(e);
                       }
            }



            String response = executeOfsMessage(ofsMessage);

            System.out.println("Raw response before parsing :"+response);
          if(ofsMessage.contains("DECARRIER"))
          {
              Demo1.gbTestCaseStatus = "Pass";
              Demo1.ReportStep(2, "Execute Swift msg", "Expected to inject " + applicationName + " swift message ", applicationName + " swift message was successfully injected");

          }

          else{


            if(response.contains("<requests>") && response.contains("</requests>")){
                response = response.substring(response.indexOf("<requests>") + "<requests>".length(),
                        response.lastIndexOf("</requests>"));
                /*System.out.println(response + "\n");*/

                String res = response.substring(response.indexOf("<request>") + "<request>".length(),
                        response.lastIndexOf("</request>"));

                System.out.println("res:"+res);

                String[] parsed = null;
                if(res.contains("<request>")){
                    parsed = res.split("</request><request>");
                }else{
                    parsed = new String[1];
                    parsed[0] = res;
                }

              System.out.println("Parsed"+parsed);

                for(String str : parsed){
                    String[] responseArray = str.split(",");


                    if(! outputParams.isEmpty()){
                        Reuse.storeRunTimeParameters(responseArray, outputParams);
                    }

                    String responseStatus = responseArray[0];
                    responseStatus = responseStatus.substring(responseStatus.indexOf("//")+2);


                }



            }else
                if(! response.isEmpty()){
                String[] responseArray = response.split(",");

                if(! outputParams.isEmpty()){
                    Reuse.storeRunTimeParameters(responseArray, outputParams);
                }


            }else{
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Execute OFS msg", "Expected to inject the OFS" + applicationName + " ofs message ", "Execution failed as OFS response is empty");
            }

            if (txnCommittedStatus.equals("1")) {
                Demo1.gbTestCaseStatus = "Pass";
                Demo1.ReportStep(2, "Execute OFS msg", "Expected to inject " + applicationName + " ofs message ", applicationName + " OFS message was successfully injected");
            } else {
                Demo1.gbTestCaseStatus = "Fail";
                String error = response.split(",")[1];
                Demo1.ReportStep(2, "Execute OFS msg", "Expected to inject " + applicationName + " ofs message ", error);
            }

          }
        } catch (Exception E1) {
            System.out.println("ERROR::>" + Throwables.getStackTraceAsString(E1));
            Demo1.gbTestCaseStatus = "Fail";
            //Demo1.ReportStep(2, "<a class=\"cindex\" href=\"" + ValofsFileName + "\">" + Description + "</a>", ExpectedResult + " should be executed", ExpectedResult + "<b> is not executed </b>");
            Demo1.ReportStep(2, "Execute OFS msg", "Expected to inject " + applicationName + " ofs message ", "Failed to execute OFS message");
        }

    }

    private static String executeOfsMessage(String ofsMessage){
        System.out.println("MSG::>" + ofsMessage);
        if(ofsMessage.contains("auto@")){
            ofsMessage = Reuse.updateRuntimeValuesInOfs(ofsMessage);
        }

        StringBuffer buffer = new StringBuffer();
        try {
            String command = "cmd /c " + curDir + File.separator +"TestData" + File.separator + "ExecuteOfs.bat" + " \"" + ofsMessage + "\"";
            System.out.println("COMMAND USED::" + command);
            Process p = Runtime.getRuntime().exec(command);

            BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = null;

            while ((line = input.readLine()) != null) {
                if(line.contains("Response")){
                    line = line.substring(line.indexOf(32)).trim();
                    buffer.append(line);
                    System.out.println(">>" + line);
                }else if(line.contains("txnCommitted")){
                    txnCommittedStatus = line.substring(line.indexOf(32)).trim();
                }
            }

            /*response = getResponseFromFile(responseFileName);*/
            responseMessage = buffer.toString();



        } catch (IOException e) {
            System.out.println("ERROR::" + Throwables.getStackTraceAsString(e));
        }
        System.out.println("RESPONSE:::>" + responseMessage);
        return responseMessage;
    }


    /**
     *
     */
    private static String getResponseFromFile(String fileName) {
        StringBuffer buf = new StringBuffer();
        File file = new File(tafjHome);
        try{

            boolean found = false;
            if(file.exists()){
                file = new File(file.getParent() + File.separator + "t24home" + File.separator + "default" + File.separator + "&SAVEDLISTS&");
                if(file.exists()){
                    file = new File(file + File.separator + fileName);
                    int trial = 0;

                    do{
                        if(file.exists()){
                            found = true;
                            FileReader fr = new FileReader(file);
                            BufferedReader br = new BufferedReader(fr);
                            String line;
                            while((line = br.readLine()) != null){
                                buf.append(line);
                            }
                            System.out.println("RESPONSE FROM FILE::" + buf.toString());
                            break;
                        }else{
                            Thread.sleep(1000);
                            trial++;
                        }
                    }while(trial < 20);
                    System.out.println("FILE PATH::" + file.getAbsolutePath());
                }
            }

            if(! found){
                System.out.println("OFS RESPONSE FILE IS MISSING - TIMED OUT AFTER WAITING FOR 20 SECONDS...");
            }

        }catch(Exception e){
            System.out.println("FILE READING ERROR::>" + Throwables.getStackTraceAsString(e));
        }

        return buf.toString();
    }

    private static void createOfsExecutionBatchFile(){
        if(tafjHome.endsWith("bin")){
            File tafjAlone = (new File(tafjHome)).getParentFile();

            StringBuffer content = new StringBuffer();
            content.append("set TAFJ_HOME=" + tafjAlone.getAbsolutePath());
            content.append("set JAVA_HOME=D:\\UTP-DEV-2020.01.05-02-115-saf-retailsuite-developer-s08\\Temenos\\java\\jdk8");
        }
    }

    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        // TODO Auto-generated method stub
        ExecuteComponent();
    }
}
