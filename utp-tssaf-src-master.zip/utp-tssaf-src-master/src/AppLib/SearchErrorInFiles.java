package AppLib;

import org.openqa.selenium.By;

import Driver.Config;
import Driver.Demo1;
import Driver.Reuse;

public class SearchErrorInFiles {
	static String pathFolder,fileStartWith,expectedString;
	/**
	 * @param args
	 * elementType
	 * elementName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
	    String appUrl = "";
		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			pathFolder=paramArr[0];
			fileStartWith=paramArr[1];
			expectedString=paramArr[2];

			if (pathFolder.equalsIgnoreCase("Config.logFolder")) {
                appUrl = Config.logFolder;

                Reuse.SearchErrorInFile(appUrl, fileStartWith, expectedString);

            } else if (pathFolder.equalsIgnoreCase("Config.logFolder1")) {
                appUrl = Config.logFolder1;
                Reuse.SearchErrorInFile(appUrl, fileStartWith, expectedString);
            } else if (pathFolder.equalsIgnoreCase("Config.logFolder2")) {
                appUrl = Config.logFolder2;
                Reuse.SearchErrorInFile(appUrl, fileStartWith, expectedString);
            }  else {
                Reuse.SearchErrorInFile(pathFolder, fileStartWith, expectedString);
            }


		}catch(Exception e){
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Click "+pathFolder+" <b>"+fileStartWith +"</b>",""+pathFolder+" <b>"+fileStartWith +"</b> should get clicked","Unable to locate "+pathFolder+" <b>"+fileStartWith+"</b>");
		}
	}
}
