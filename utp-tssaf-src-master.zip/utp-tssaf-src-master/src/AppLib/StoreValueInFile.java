package AppLib;

import static org.apache.commons.lang3.StringEscapeUtils.escapeHtml3;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class StoreValueInFile {
	static String variable,elementName;
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() {
		String eleText="";
		String action = "";
		By by=null;
		String keyword = "";
		String[] paramArr=Demo1.arrParameters;
		try{
			variable=paramArr[0];
			elementName=paramArr[1];
			by=Reuse.GetLocator(paramArr[2]);
			if (paramArr.length == 4) {
				action = paramArr[3];
			}
			if (paramArr.length == 5) {
                action = paramArr[3];
                keyword = paramArr[4];

            }
			eleText=Demo1.driver.findElement(by).getText();
			if (eleText != null & eleText.trim().isEmpty()) {
				eleText = Demo1.driver.findElement(by).getAttribute("value");
				if (eleText == null) {
					eleText = "";
				}
			}
			if(eleText!=null && eleText.length()>0 && !eleText.equals("")) {

			    String strProcessed="";

			    if (paramArr.length == 5){

			        if(action.equalsIgnoreCase("APPEND_TEXT"))
			        {

			            strProcessed   = eleText + keyword ;

			        }
			        else{
			         strProcessed =  Reuse.getProcessedString(action,eleText.trim(),keyword);
			         System.out.println("paramter is 5"+strProcessed);
			         }
			    }
			    else{
			         strProcessed =  Reuse.getProcessedString(action,eleText.trim());
			         System.out.println("paramter "+strProcessed);
			    }

				Reuse.WriteProperties(variable, strProcessed);
				Demo1.gbTestCaseStatus = "Pass";
                eleText = escapeHtml3(eleText);
				Demo1.ReportStep(2, "Store <b>" + eleText + "</b> in <b>" + variable + "</b> ", "<b>" + eleText + "</b> should be stored in <b>" + variable + "</b> ", "Stored");
			}

			else{
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Store <b>"+eleText+"</b> in <b>"+variable+"</b> ","<b>"+eleText+"</b> should be stored in <b>"+variable+"</b> ","Value may not present in the element provided");
			}
		}catch(Exception e){
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Store <b>"+eleText+"</b> in <b>"+variable+"</b> ","<b>"+eleText+"</b> should be stored in <b>"+variable+"</b> ","Value may not present in the element provided");
		}
	}
}