package AppLib;

import java.math.BigDecimal;

import org.openqa.selenium.By;

import com.google.common.base.Throwables;

import Driver.Demo1;
import Driver.Reuse;

public class Calc {
    static String var1, var2, var3, action;
    static By by;
    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        ExecuteComponent();
    }

    public static void ExecuteComponent() {
        try {
            String[] paramArr = Demo1.arrParameters;

            if (paramArr.length == 3 || (paramArr.length == 4 && paramArr[paramArr.length - 1].trim().equalsIgnoreCase("ABSOLUTE"))) {
                var1 = Reuse.GetPropertyValue(paramArr[0]).trim().replace(" ", "").replace(",", "");
                action = paramArr[1];
                by = Reuse.GetLocator(paramArr[2]);
                boolean absolute = false;
                if (paramArr.length == 4 && paramArr[paramArr.length - 1].trim().equalsIgnoreCase("ABSOLUTE")) {
                    absolute = true;
                }

                String elementText = Demo1.driver.findElement(by).getText().trim().replace(" ", "").replace(",", "");
                if (elementText.isEmpty()) {
                    throw new Exception("Empty value in variable");
                }

                Double elementDouble;
                Double actualDouble;
                if (absolute) {
                    elementDouble = Math.abs(Double.parseDouble(elementText));
                    actualDouble = Math.abs(Double.parseDouble(var1));
                } else {
                    elementDouble = Double.parseDouble(elementText);
                    actualDouble = Double.parseDouble(var1);
                }


                if (action.trim().equalsIgnoreCase("EQUALS")) {


                    if (actualDouble.equals(elementDouble)) {
                        Demo1.gbTestCaseStatus = "Pass";
                        Demo1.ReportStep(2, "Compare values are equals", "Compare " + actualDouble + " Equals " + elementDouble, "Values are equal");
                    } else {
                        Demo1.gbTestCaseStatus = "Fail";
                        Demo1.ReportStep(2, "Compare values are  equals", "Compare " + actualDouble + " Equals " + elementDouble, "Values are not equal");
                    }
                }


                if (action.trim().equalsIgnoreCase("GREATERTHAN")) {


                    if (actualDouble > elementDouble) {
                        Demo1.gbTestCaseStatus = "Pass";
                        Demo1.ReportStep(2, "Action: Greater Than", "Check, value " + actualDouble + " is greater than " + elementDouble, "Value " + actualDouble + " is greater than " + elementDouble);
                    } else {
                        Demo1.gbTestCaseStatus = "Fail";
                        Demo1.ReportStep(2, "Action: Greater Than", "Check, value " + actualDouble + " is greater than " + elementDouble, "Value " + actualDouble + " is not greater than " + elementDouble);
                    }
                }

                if (action.trim().equalsIgnoreCase("LESSTHAN")) {


                    if (actualDouble < elementDouble) {
                        Demo1.gbTestCaseStatus = "Pass";
                        Demo1.ReportStep(2, "Action: Less Than", "Check, value " + actualDouble + " is Less than " + elementDouble, "Value " + actualDouble + " is Less than " + elementDouble);
                    } else {
                        Demo1.gbTestCaseStatus = "Fail";
                        Demo1.ReportStep(2, "Action: Less Than", "Check, value " + actualDouble + " is Less than " + elementDouble, "Value " + actualDouble + " is not Less than " + elementDouble);
                    }
                }


            }


            if ((paramArr.length == 4 && !"ABSOLUTEROUNDOFF".contains(paramArr[paramArr.length - 1].trim().toUpperCase())) || (paramArr.length == 5 && paramArr[paramArr.length - 1].trim().contains("ROUNDOFF"))) {
                int roundoff = -1;

                if (paramArr[paramArr.length - 1].trim().contains("ROUNDOFF")) {
                    try {
                        roundoff = Integer.parseInt(paramArr[paramArr.length - 1].trim().split(":")[1].replaceAll("[^a-zA-Z0-9]", ""));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
                action = paramArr[3];
                var1 = Reuse.GetPropertyValue(paramArr[0]).trim().replace(" ", "").replace(",", "");
                var2 = Reuse.GetPropertyValue(paramArr[1]).trim().replace(" ", "").replace(",", "");
                var3 = paramArr[2].trim().replace(" ", "").replace(",", "");
                if (action.trim().equalsIgnoreCase("POWER")) {

                    //If any of the variable has empty value the throw an exception
                    if (var1.isEmpty() || var2.isEmpty()) {
                        throw new Exception("Empty value in variable");
                    }
                    Double base = Math.abs(Double.parseDouble(var1));
                    Double power = Math.abs(Double.parseDouble(var2));
                    Double result = Math.pow(base, power);
                    if (!(roundoff == -1)) {
                        BigDecimal bigDecimal = new BigDecimal(result);
                        result = bigDecimal.divide(BigDecimal.ONE, roundoff, BigDecimal.ROUND_HALF_UP).doubleValue();
                    }
                    Reuse.WriteProperties(var3, String.valueOf(result));
                    Demo1.ReportStep(2, "Calculate:POWER", base + " to the power of " + power, "Calculated:" + result);

                }
                if (action.trim().equalsIgnoreCase("DIVIDE")) {

                    //If any of the variable has empty value the throw an exception
                    if (var1.isEmpty() || var2.isEmpty()) {
                        throw new Exception("Empty value in variable");
                    }

                    Double v1 = Math.abs(Double.parseDouble(var1));
                    Double v2 = Math.abs(Double.parseDouble(var2));
                    Double v3 = v1 / v2;
                    if (!(roundoff == -1)) {
                        BigDecimal bigDecimal = new BigDecimal(v3);
                        v3 = bigDecimal.divide(BigDecimal.ONE, roundoff, BigDecimal.ROUND_HALF_UP).doubleValue();
                    }
                    //Write the result of division
                    Reuse.WriteProperties(var3, String.valueOf(v3));
                    Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, "Calculate:DIVIDE", v1 + "/" + v2, "Calculated:" + v3);

                }
                if (action.trim().equalsIgnoreCase("ADD")) {

                    //If any of the variable has empty value the throw an exception
                    if (var1.isEmpty() || var2.isEmpty()) {
                        throw new Exception("Empty value in variable");
                    }

                    Double v1 = Double.parseDouble(var1);
                    Double v2 = Double.parseDouble(var2);
                    Double v3 = v1 + v2;
                    if (!(roundoff == -1)) {
                        BigDecimal bigDecimal = new BigDecimal(v3);
                        v3 = bigDecimal.divide(BigDecimal.ONE, roundoff, BigDecimal.ROUND_HALF_UP).doubleValue();
                    }
                    //Write the result of division
                    Reuse.WriteProperties(var3, String.valueOf(v3));
                    Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, "Calculate:ADDITION", v1 + "+" + v2, "Calculated:" + v3);

                }
                if (action.trim().equalsIgnoreCase("SUBTRACT")) {

                    //If any of the variable has empty value the throw an exception
                    if (var1.isEmpty() || var2.isEmpty()) {
                        throw new Exception("Empty value in variable");
                    }

                    Double v1 = Double.parseDouble(var1);
                    Double v2 = Double.parseDouble(var2);
                    Double v3 = (v1) - (v2);
                    if (!(roundoff == -1)) {
                        BigDecimal bigDecimal = new BigDecimal(v3);
                        v3 = bigDecimal.divide(BigDecimal.ONE, roundoff, BigDecimal.ROUND_HALF_UP).doubleValue();
                    }
                    //Write the result of division
                    Reuse.WriteProperties(var3, String.valueOf(v3));
                    Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, "Calculate:SUBTRACTION", v1 + "-" + v2, "Calculated:" + v3);

                }
                if (action.trim().equalsIgnoreCase("MULTIPLY")) {

                    //If any of the variable has empty value the throw an exception
                    if (var1.isEmpty() || var2.isEmpty()) {
                        throw new Exception("Empty value in variable");
                    }

                    Double v1 = Double.parseDouble(var1);
                    Double v2 = Double.parseDouble(var2);
                    Double v3 = v1 * v2;
                    if (!(roundoff == -1)) {
                        BigDecimal bigDecimal = new BigDecimal(v3);
                        v3 = bigDecimal.divide(BigDecimal.ONE, roundoff, BigDecimal.ROUND_HALF_UP).doubleValue();
                    }
                    //Write the result of division
                    Reuse.WriteProperties(var3, String.valueOf(v3));
                    Demo1.ReportStep(2, "Calculate:MULTIPLY", v1 + " * " + v2, "Calculated:" + v3);

                }


            }
        } catch (Exception e) {
        	e.printStackTrace();
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Calc", "Exception occured", Throwables.getStackTraceAsString(e));
        }
    }
}
