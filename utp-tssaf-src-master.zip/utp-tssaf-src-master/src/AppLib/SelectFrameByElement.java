package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class SelectFrameByElement {
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			by=Reuse.GetLocator(paramArr[0]);
			Reuse.SelectFrame(by);
		}catch(Exception e){
			Demo1.logger.error("Error in SelectFrameByElement. "+e.getMessage());
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Swithch to frame by element","Should be switched to fame by element", e.getMessage());
		}
	}
}
