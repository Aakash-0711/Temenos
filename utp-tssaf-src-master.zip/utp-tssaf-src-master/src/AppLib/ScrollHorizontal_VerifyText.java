package AppLib;

import static org.apache.commons.lang3.StringEscapeUtils.escapeHtml3;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

/**
 * Created by shanmugamarun on 26-04-2017.
 */
public class ScrollHorizontal_VerifyText {
    static String parameters,elementName,locatorType,locator,expectedText,pageNo;

    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        // TODO Auto-generated method stub
        ExecuteComponent();
    }
    public static void ExecuteComponent() throws Exception{
        String[] paramArr= Demo1.arrParameters;
        By by;
        try{


            expectedText= escapeHtml3(paramArr[0]);
            elementName=paramArr[1];
            by=Reuse.GetLocator(paramArr[2]);
            pageNo =paramArr[3];


            Reuse.Scroll_Horizontal_VerifyText(Integer.parseInt(pageNo), by, expectedText, elementName);
        }catch(Exception e){
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Scroll to Element <b>"+elementName+"</b>","Element should be scrolled and focus on <b>"+elementName+"</b>","Element not scrolled and focused.");
        }
    }
}
