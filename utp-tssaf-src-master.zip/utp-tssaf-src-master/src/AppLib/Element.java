package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class Element{
	static String elementType,elementName,validation;
	/**
	 * @param
	 *  elementType
	 *  elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() {
		try{
			By by=null;
			String[] paramArr=Demo1.arrParameters;
			elementType=paramArr[0];
			elementName=paramArr[1];
			validation=paramArr[2].trim();
			by=Reuse.GetLocator(Reuse.getValueOfRunTimeVariables(paramArr[3]));

			if(validation.equals("EXIST")){
				Reuse.ElementExist(by, elementType, elementName);
			}else if(validation.equals("VISIBLE")){
				Reuse.ElementVisible(by, elementType, elementName);
			}else if(validation.equals("NOT_EXIST")){

				Reuse.ElementNotExist(by, elementType, elementName);

			}else if(validation.equals("NOT_VISIBLE")){
				Reuse.ElementNotVisible(by, elementType, elementName);
			}else if(validation.equals("FOCUSED")){
				Reuse.ElementFocused(by, elementName, elementType);
			}else if(validation.equals("NOT_FOCUSED")){
				Reuse.ElementNotFocused(by, elementName, elementName);
			}else if(validation.equals("SELECTED")){
				Reuse.ElementSelected(by, elementType, elementName);
			}else if(validation.equals("NOT_SELECTED")){
				Reuse.ElementNotSelected(by, elementType, elementName);
			}else if(validation.equals("HIGHLIGHT")){
				Reuse.HighlightElement(by, elementType, elementName);
			}else if(validation.equals("ISNUM")){
                Reuse.TextIsNum(by, elementType, elementName);
            }else if(validation.equals("ISALPHANUM")){
                Reuse.TextIsAlphanum(by, elementType, elementName);
            }else if(validation.equals("GREATERTHAN")){
                Reuse.TextIsGreater(by, elementType, elementName);
            }else if(validation.equals("ENABLED")){
                Reuse.ElementEnabled(by, elementType, elementName);
            }else if(validation.equals("DISABLED")){
                Reuse.ElementNotEnabled(by, elementType, elementName);
            }else{
				Demo1.gbTestCaseStatus="Fail";
				Demo1.ReportStep(2,"Verify <b>"+elementType+" "+elementName+"</b> present",""+elementName+" should be presented","Validation Option not exist/Having some problem");
			}

		}catch(Exception e){
			if(validation.equals("EXIST")){
				Demo1.gbTestCaseStatus="Fail";
				Demo1.ReportStep(2,"Verify <b>"+elementType+" "+elementName+"</b> exist",""+elementName+" should be exist",e.getMessage());
			}else if(validation.equals("DISPLAYED")){
				Demo1.gbTestCaseStatus="Fail";
				Demo1.ReportStep(2,"Verify <b>"+elementType+" "+elementName+"</b> displayed",""+elementName+" should be displayed",e.getMessage());
			}else if(validation.equals("NOT_EXIST")){
				Demo1.gbTestCaseStatus="Fail";
				Demo1.ReportStep(2,"Verify <b>"+elementType+" "+elementName+"</b> present",""+elementName+" should not be exist",e.getMessage());
			}else if(validation.equals("FOCUSED")){
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check <b>"+elementName+"</b> "+elementType+" focused","<b>"+elementName+"</b> should be focused",e.getMessage());
			}else if(validation.equals("NOT_FOCUSED")){
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check <b>"+elementName+"</b> "+elementType+" not focused","<b>"+elementName+"</b> should not be focused",e.getMessage());
			}else if(validation.equals("SELECTED")){
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check <b>"+elementName+"</b> "+elementType+" selected","<b>"+elementName+"</b> should  be selected",e.getMessage());
			}else if(validation.equals("NOT_SELECTED")){
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check <b>"+elementName+"</b> "+elementType+" not selected","<b>"+elementName+"</b> should not be selected",e.getMessage());
			}else if(validation.equals("ISALPHANUM")){
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Check <b>"+elementName+"</b> "+elementType+" alphanum","<b>"+elementName+"</b> should  be alphanum",e.getMessage());
            }else if(validation.equals("GREATERTHAN")){
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Check <b>"+elementName+"</b> "+elementType+"  greater","<b>"+elementName+"</b> should be greater",e.getMessage());
            }
		}
	}
}
