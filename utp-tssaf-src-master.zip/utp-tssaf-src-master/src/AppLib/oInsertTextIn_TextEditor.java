package AppLib;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ById;

import Driver.Demo1;
import Driver.Reuse;

public class oInsertTextIn_TextEditor {
	
	static String fileName,locator,textBoxName;

	public static void main(String[] args) throws Exception {
		ExecuteComponent();
	}
	
	public static void ExecuteComponent() throws Exception{	
		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			fileName=paramArr[0];
			textBoxName=paramArr[1];
			by=Reuse.GetLocator(paramArr[2]);
			Reuse.oInsertTextIn_TextEditor(fileName,textBoxName, by);
		}catch(Exception e){
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Inserting the value in the <b>"+textBoxName+"</b> text box","<b>"+textBoxName+"</b> value should be inserted in text Editor",e.getMessage());
		}		
	}

}
