package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class WinWindow_SetText {
	static String winName,editBoxName,control,textToSet;

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;
		try{
			winName=paramArr[0];
			editBoxName=paramArr[1];
			control=paramArr[2];
			textToSet=paramArr[3];
			Reuse.WinWindowSetText(winName, editBoxName, control, textToSet);
		}catch(Exception e){
			Demo1.logger.error("Problem in WinWindowSetText");
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Set text in <b>" + editBoxName + "</b>","Text <b>" + editBoxName + "</b> should be inputted ","<b>" + editBoxName + "</b> not inserted");
		}
	}
}
