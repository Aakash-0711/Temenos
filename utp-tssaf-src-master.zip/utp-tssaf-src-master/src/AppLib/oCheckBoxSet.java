package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class oCheckBoxSet {
	static String parameters,locatorType,locator,setOnOff,checkBoxName;
	/**
	 * @param args
	 * checkBoxName
	 * setOnOff
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			checkBoxName=paramArr[0];
			setOnOff=paramArr[1];
			by=Reuse.GetLocator(paramArr[2]);
			Reuse.CheckBoxSet(by,setOnOff,checkBoxName);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Set checkBox <b>"+checkBoxName+"</b>","Should be able to set checkBox <b>"+checkBoxName+"</b>","Unable to locate checkbox <b>"+checkBoxName+"</b>");
		}
	}
}
