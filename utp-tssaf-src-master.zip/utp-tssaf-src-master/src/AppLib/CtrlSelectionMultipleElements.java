package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class CtrlSelectionMultipleElements {
	static String elements,elementsName;
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;
		try{
			elements = paramArr[0];
			elementsName = paramArr[1];

			Reuse.CtrlSelectionMultipleElements(elements.split("\\##"), elementsName);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			//Demo1.ReportStep(2, "Press Ctrl and Select <b>"+element1Name+"</b> and <b>"+element2Name+"</b>","Ctrl Selection action should be done",e.getMessage());
			Demo1.ReportStep(2, "Press Ctrl and Select all the elements <b>" + elementsName + "</b>", "Ctrl Selection action should be done", e.getMessage());
		}
	}
}
