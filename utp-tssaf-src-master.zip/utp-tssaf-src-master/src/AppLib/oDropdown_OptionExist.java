package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class oDropdown_OptionExist {
	static String parameters,optionToCheck,locatorType,locator,dropdownName;
	/**
	 * @param args
	 * optionToCheck
	 * dropdownName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			By by=null;
			String[] paramArr=Demo1.arrParameters;
			optionToCheck=paramArr[0];
			dropdownName=paramArr[1];
			by=Reuse.GetLocator(paramArr[2]);
			Reuse.Dropdown_OptionExist(by, optionToCheck,dropdownName);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify option <b>"+optionToCheck+"</b> in <b>"+dropdownName+"</> dropdown","<b>"+optionToCheck+"</b> option should be exist","Unable to locate <b>"+dropdownName+"</b> dropdown");
		}
	}
}
