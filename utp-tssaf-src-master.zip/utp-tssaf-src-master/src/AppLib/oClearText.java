package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class oClearText {
	static String parameters,key,by;
	/**
	 * @param key
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception  {
		String[] paramArr=Demo1.arrParameters;
		By by = null;
		try{
			key=paramArr[0];
			by = Reuse.GetLocator(paramArr[1]);
			Reuse.TextBox_Clear(by, key);
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}
