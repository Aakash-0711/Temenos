package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class Table_SetText {
	static String searchElementText,ExpElementName,action,textToSet,tableLocator;
	static int columnNoToPerformAction;
	/**
	 * @param args
	 * elementType
	 * elementName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{

		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			searchElementText=paramArr[0];
			ExpElementName=paramArr[1];
			columnNoToPerformAction=Integer.parseInt(paramArr[2]);
			action=paramArr[3].trim();
			textToSet=paramArr[4];
			by=Reuse.GetLocator(paramArr[5]);
			Reuse.Table_SetText(searchElementText, ExpElementName, columnNoToPerformAction, action, textToSet, by);
		}catch(Exception e){
			Demo1.logger.error(e.getMessage());
		}
	}
}
