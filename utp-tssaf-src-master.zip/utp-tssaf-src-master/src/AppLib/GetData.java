package AppLib;

import java.io.File;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;
import jxl.Cell;
import jxl.JXLException;
import jxl.Sheet;
import jxl.Workbook;

public class GetData {
	static String XLSheetName;
	public static String field;
	/**
	 * @param XLSheetName
	 * @throws Exception
	 * @throws JXLException
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;
		XLSheetName=paramArr[0];
		ReadExcelFiel();
	}
	private static void ReadExcelFiel() throws JXLException, Exception{
		int cId_UserDefined,cId_ID = 0,cId_Tag=0,cId_Xpath=0,cId_FrameID=0,cId_CSSPath=0,cId_CSSubPath=0,cId_FieldValue=0;
		String inputFile=Demo1.curDir + "\\TestData\\"+XLSheetName+".xls";
		//String locator;
		File inputWorkbook = new File(inputFile);
	    Workbook wb;
	    wb = Workbook.getWorkbook(inputWorkbook);
	      // Get the first sheet
	      Sheet sheet = wb.getSheet(0);
	      int cCount=sheet.getColumns();
	      //int rCount=sheet.getRows();
	      for(int c=0;c<cCount;c++){
	    	  Cell cell=sheet.getCell(c, 0);
	    	  if(cell.getContents().length()!=0){
	    		  if(cell.getContents().contentEquals("UserDefined")){
	    			  cId_UserDefined=c;
	    		  }else if(cell.getContents().contentEquals("ID")){
	    			  cId_ID=c;
	    		  }else if(cell.getContents().contentEquals("Tag")){
	    			  cId_Tag=c;
	    		  }else if(cell.getContents().contentEquals("Xpath")){
	    			  cId_Xpath=c;
	    		  }else if(cell.getContents().contentEquals("FrameID")){
	    			  cId_FrameID=c;
	    		  }else if(cell.getContents().contentEquals("CSSPath")){
	    			  cId_CSSPath=c;
	    		  }else if(cell.getContents().contentEquals("CSSSubPath")){
	    			  cId_CSSubPath=c;
	    		  }
	    	  }
	      }

	      String SCID=Demo1.getTC_Id;
	      Sheet sheet1 = wb.getSheet(1);
	      int clmCntS1=sheet1.getColumns();
	      int rowCntS1=sheet1.getRows();
	      for(int s1r=1;s1r<rowCntS1;s1r++){
	    	  Cell s1Cell=sheet1.getCell(0, s1r);
	    	  if(s1Cell.getContents().contentEquals(SCID)){
	    		  //int rowCnt=s1Cell.getRow();
	    		  for(int s1c=1;s1c<clmCntS1;s1c++){
	    			  String fieldValue=sheet1.getCell(s1c, s1r).getContents();
	    			  field=sheet1.getCell(s1c, 0).getContents();
	    			  String objectType=sheet.getCell(cId_Tag, s1c).getContents();
	    			  if(!fieldValue.isEmpty()){
	    				  if(field.contentEquals(sheet.getCell(0, s1c).getContents())){
	    					  By by;
	    					  String objLocater_ID=sheet.getCell(cId_ID, s1c).getContents();
	    					  by=By.id(objLocater_ID);
	    					  //Reuse.TextBox_InputText(by, fieldValue);
	    					  if(Reuse.isElementPresent(by)){
	    						  if(objectType.equals("SELECT")){
	    							  Reuse.Dropdown_SelectItem(by, fieldValue,field);
	    						  }else if(objectType.equals("INPUT")){
	    							  Reuse.TextBox_InputText(by, fieldValue,field);
	    						  }else if(objectType.equals("BUTTON")){
	    							  Reuse.Click_Element(by,"Button",field);
	    						  }else if(objectType.equals("RADIO")){
	    							  Reuse.RadioButton_Select(by,field);
	    						  }else if(objectType.equals("CHECKBOX")){
	    							  Reuse.CheckBoxSet(by,fieldValue,field);
	    						  }
	    					  }else{  // if not located using id then
	    						  String objLocater_xpath=sheet.getCell(cId_Xpath, s1c).getContents();
	    						  by=By.xpath(objLocater_xpath);
	    						  if(Reuse.isElementPresent(by)){
		    						  if(objectType.equals("SELECT")){
		    							  Reuse.Dropdown_SelectItem(by, fieldValue,field);
		    						  }else if(objectType.equals("INPUT")){
		    							  Reuse.TextBox_InputText(by, fieldValue,field);
		    						  }else if(objectType.equals("BUTTON")){
		    							  Reuse.Click_Element(by,"Button",field);
		    						  }else if(objectType.equals("RADIO")){
		    							  Reuse.RadioButton_Select(by,field);
		    						  }else if(objectType.equals("CHECKBOX")){
		    							  Reuse.CheckBoxSet(by,fieldValue,field);
		    						  }
		    					  }else{
		    						  String objLocater_cssSelector=sheet.getCell(cId_CSSubPath, s1c).getContents();
		    						  by=By.cssSelector(objLocater_cssSelector);
		    						  if(Reuse.isElementPresent(by)){
		    							  if(objectType.equals("SELECT")){
			    							  Reuse.Dropdown_SelectItem(by, fieldValue,field);
			    						  }else if(objectType.equals("INPUT")){
			    							  Reuse.TextBox_InputText(by, fieldValue,field);
			    						  }else if(objectType.equals("BUTTON")){
			    							  Reuse.Click_Element(by,"Button",field);
			    						  }else if(objectType.equals("RADIO")){
			    							  Reuse.RadioButton_Select(by,field);
			    						  }else if(objectType.equals("CHECKBOX")){
			    							  Reuse.CheckBoxSet(by,fieldValue,field);
			    						  }
		    						  }
		    					  }
	    					  }
	    				  }
	    			  }
	    		  }
	    	  }
	      }

	    //validation
          Sheet sheet2 = wb.getSheet(2);
          int s2row=sheet2.getRows();
          for(int s2r=1;s2r<s2row;s2r++){
             String valTCID=sheet2.getCell(0, s2r).getContents();
             if(valTCID.contentEquals(SCID)){
                    String validationMessage=sheet2.getCell(2, s2r).getContents();
                    if(!validationMessage.isEmpty()){
                           String msgLocator=sheet2.getCell(3, s2r).getContents();
                           By by=By.xpath(msgLocator);
                           Reuse.Verify_MultiMessages(by, validationMessage);
                    }else{
                           break;
                    }
             }
          }
	}
}


