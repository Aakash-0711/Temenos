package AppLib;

import Driver.Config;
import Driver.Demo1;
import Driver.Reuse;

public class LaunchURLWithBrowserAuthentication {

	/**
	 * @param args
	 * @author aakash.manohar
	 */
	public static String parameters, URL, userName, password,appUrl;

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception {
		String[] paramArr = Demo1.arrParameters;
		try {
			URL = paramArr[0];
			userName = paramArr[1];
			password = paramArr[2];
			if (URL.trim().toLowerCase().startsWith("config")) {
				appUrl = Config.getProperty(URL.split("[.]")[1]);
				if (appUrl.startsWith("https")) {
					appUrl = appUrl.substring(0, 8) + userName + ":" + password + "@" + appUrl.substring(8);
				} else if (appUrl.startsWith("http")) {
					appUrl = appUrl.substring(0, 7) + userName + ":" + password + "@" + appUrl.substring(7);
				}
			}
			Demo1.driver.get(appUrl);
			if (Demo1.driver.getTitle().contains("ERROR")) {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Launch Application: " + appUrl, appUrl + " should be launched.",
						"URL " + appUrl + " not launched");
			} else {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Launch Application: " + appUrl, appUrl + " should be launched.",
						"URL " + appUrl + " launched as expected");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Launch Application: " + appUrl, appUrl + " should be launched.", e.getMessage());
		}
	}
}
