package AppLib;

import Driver.Config;
import Driver.Demo1;
import Driver.Reuse;

import Driver.ReuseT24API;

public class API_NewSession_Keycloak {
	static String userName,Password,URL,path;
	private static String appUrl;
	/**
	 * @param
	 * elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;

		try {

			URL = paramArr[0];

//			if (URL.equalsIgnoreCase("Config.defaultURL")) {
//			    appUrl = Config.defaultURL;
//			}
//			else if (URL.equalsIgnoreCase("Config.URL")) {
//			    appUrl = Config.appURL;
//
//			} else if (URL.equalsIgnoreCase("Config.URL1")) {
//			    appUrl = Config.appURL1;
//
//			} else if (URL.equalsIgnoreCase("Config.URL2")) {
//			    appUrl = Config.appURL2;
//
//			} else if (URL.equalsIgnoreCase("Config.URL3")) {
//			    appUrl = Config.appURL3;
//			}
//			else if (URL.equalsIgnoreCase("Config.URL4")) {
//				appUrl = Config.appURL4;
//
//			}
//			else if (URL.equalsIgnoreCase("Config.URL5")) {
//				appUrl = Config.appURL5;
//
//			}
			if(URL.trim().toLowerCase().startsWith("config")) {
				appUrl = Config.getProperty(URL.split("[.]")[1]);
			}
			else {
			    appUrl = URL;
			}

			path=paramArr[1];
			
			ReuseT24API.API_SetUp_KeyCloak(appUrl, path);
		} catch (Exception e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
			 Demo1.gbTestCaseStatus = "Fail";
			 Demo1.ReportStep(2, "To start api session",
		             "API seesion of " + path + "is not started",
		             "API seesion not successfully started");

		}
	}

}
