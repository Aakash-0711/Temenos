package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class WinWindow_Input {
	static String parameters,winName,editName,control,setText;
	/**
	 * @param args
	 * elementType
	 * elementName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{

		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			winName=paramArr[0];
			editName=paramArr[1];
			control=paramArr[2];
			setText=paramArr[3];

			Reuse.WinWindowSetText(winName, editName, control, setText);
		}catch(Exception e){
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Set text in <b>" + editName + "</b>","Text <b>" + editName + "</b> should be inputted ","<b>" + editName + "</b> not inserted"+e);
		}
	}
}
