package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class ValidateCSV {
	static String file, recid,  header,  expectedValue;
	/**
	 * @param
	 * elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;
		file=paramArr[0];
		recid=paramArr[1];
		header=paramArr[2];
		expectedValue=paramArr[3];
		Reuse.readDataLineByLine(file, recid, header, expectedValue);
	}

}
