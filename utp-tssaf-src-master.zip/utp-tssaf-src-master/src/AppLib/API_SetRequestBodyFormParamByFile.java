package AppLib;

import Driver.Config;
import Driver.Demo1;
import Driver.Reuse;
import Driver.ReuseT24API;

public class API_SetRequestBodyFormParamByFile {
	static String key,value;
	/**
	 * @param
	 * elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	
	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;
		key = paramArr[0];
		value = paramArr[1];

		try {
			ReuseT24API.API_SetRequestBodyFormParamByFile(key, value);
		
		} catch (Throwable e) {
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To set request body by form data multipart value", "Set request body by form data using keys as "+key+" and value as "+value+" should be successful",
					"Set request body by form data using key as "+key+" and value as "+value+" is not successful");
		}
	}

}
