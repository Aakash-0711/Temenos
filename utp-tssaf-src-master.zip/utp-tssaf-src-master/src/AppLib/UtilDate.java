package AppLib;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.imageio.ImageIO;

import Driver.Demo1;


public class UtilDate {
	public static Calendar cc = null;
	public static String Second;
	public static String[] STarraySecs;
	public static String SThoursInSecs;
	public static String STminInSecs;
	public static String STsecs;
	public static String STtotalSecs;
	public static String[] ETarraySecs;
	public static String EThoursInSecs;
	public static String ETminInSecs;
	public static String ETsecs;
	public static String ETtotalSecs;
	public static int durInSec;
	public static int findDuration;
	public static Boolean debug = false;

	public static String getCurrentDatenTime(String format) {
		Calendar cal = Calendar.getInstance();
		cc = cal;
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.format(cal.getTime());
	}

	public static long getLastsetTimeinmili() {
		long lDateTime = new Date().getTime();
		return lDateTime;
	}

	public static String getFormattedTime(long time) {
		long timeMillis = time;
		long time1 = timeMillis / 1000;
		String seconds = Integer.toString((int) (time1 % 60));
		String minutes = Integer.toString((int) ((time1 % 3600) / 60));
		String hours = Integer.toString((int) (time1 / 3600));
		for (int i = 0; i < 2; i++) {
			if (seconds.length() < 2) {
				seconds = "0" + seconds;
			}
			if (minutes.length() < 2) {
				minutes = "0" + minutes;
			}
			if (hours.length() < 2) {
				hours = "0" + hours;
			}
		}
		return hours + ": " + minutes + ": " + seconds;
	}

	public static void takeScreenShot(String path) {
		try {
			// Get the screen size
			Toolkit toolkit = Toolkit.getDefaultToolkit();
			Dimension screenSize = toolkit.getScreenSize();
			Rectangle rect = new Rectangle(0, 0, screenSize.width,
					screenSize.height);
			Robot robot = new Robot();
			BufferedImage image = robot.createScreenCapture(rect);
			File file;

			// Save the screenshot as a png
			// file = new File(path);
			// ImageIO.write(image, "png", file);

			// Save the screenshot as a jpg
			file = new File(path);
			ImageIO.write(image, "jpg", file);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static long findDuration(String startTime, String Endtime) {

		SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");

		Date d1 = null;
		Date d2 = null;
		try {
		    d1 = format.parse(startTime);
		    d2 = format.parse(Endtime);
		} catch (Exception e) {
		    e.printStackTrace();
		}

		// Get msec from each, and subtract.
		long diff = d2.getTime() - d1.getTime();
		long newTime=Math.abs(diff);

		return newTime;
	}
	public static String timeDifference(String StartTime, String endTime,String dateFormat){
		SimpleDateFormat format=null;
		try{
			//"dd-MM-yy HH:mm:ss"
			format = new SimpleDateFormat(dateFormat);
			Date FStartTime = format.parse(StartTime);

			Calendar calendar1 = Calendar.getInstance();
			calendar1.setTime(FStartTime);

			Date FEndTime = format.parse(endTime);

			Calendar calendar2 = Calendar.getInstance();
			calendar2.setTime(FEndTime);

			if(FStartTime.compareTo(FEndTime)<0)
			{
				calendar1.add(Calendar.DATE, 1);
				FStartTime = calendar1.getTime();
			}

			calendar2.add(Calendar.DATE, 1);
			FEndTime = calendar2.getTime();

			long diff = FEndTime.getTime()-FStartTime.getTime();

			long newTime=Math.abs(diff);

			long diffSeconds = (newTime/1000)%60;
			long diffMinutes = (newTime / (60 * 1000))%60;
			long diffHours = newTime / (60 * 60 * 1000)%24;

			String hrs,mins,secs;
			if(diffHours<=0){
				hrs="";
			}else{
				hrs=diffHours+" hrs, ";
			}
			if(diffMinutes<=0){
				mins="";
			}else{
				mins=diffMinutes+" mins, ";
			}
			if(diffSeconds<=0){
				secs="";
			}else{
				secs=diffSeconds+" sec";
			}
			return hrs+mins+secs;
		}catch(Exception e){
			Demo1.logger.error("UtilDate.timeDifference "+e);
			return null;
		}
	}

	public static String getValue(String key, String def) {
		BufferedReader br = null;

		String Path1 = null;
		try {
			Path1 = new File(".").getCanonicalPath();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String path = Path1 + "\\selenium.ini";
		if (UtilDate.debug) {
			System.out.println("get val path=" + path + ", key = " + key);
		}
		String line = "";
		String val = "";
		boolean found = false;
		try {
			File f = new File(path);
			f.createNewFile();

			br = new BufferedReader(new FileReader(path));

			String regex = "=";

			while ((line = br.readLine()) != null) {
				if (line.trim().length() > 0) {
					String[] pairs = line.split(regex);

					if (pairs[0].trim().equals(key)) {
						val = pairs[1];
						found = true;
					}
				}
			}
		} catch (Exception ex) {
		} finally {
			try {
				br.close();
			} catch (Exception ex) {
			}
			if (!found) {
				val = def;
				try {
					// Util.SetValue(key, def);
				} catch (Exception ex) {
				}
			}
		}
		System.out.print(val);
		return val;
	}

	public static void getTestParameter() throws IOException {

		FileInputStream fstream = new FileInputStream("textfile.txt");
		// Get the object of DataInputStream
		DataInputStream in = new DataInputStream(fstream);
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		String strLine;
		// Read File Line By Line
		while ((strLine = br.readLine()) != null) {
			// Print the content on the console
			System.out.println(strLine);
		}
		// Close the input stream
		in.close();

	}

	public static String timeDifferenceInTimeFormat(String StartTime, String endTime, String dateFormat){
        SimpleDateFormat format=null;
        try{
            //"dd-MM-yy HH:mm:ss"
            format = new SimpleDateFormat(dateFormat);
            Date FStartTime = format.parse(StartTime);

            Calendar calendar1 = Calendar.getInstance();
            calendar1.setTime(FStartTime);

            Date FEndTime = format.parse(endTime);

            Calendar calendar2 = Calendar.getInstance();
            calendar2.setTime(FEndTime);

            if(FStartTime.compareTo(FEndTime)<0)
            {
                calendar1.add(Calendar.DATE, 1);
                FStartTime = calendar1.getTime();
            }

            calendar2.add(Calendar.DATE, 1);
            FEndTime = calendar2.getTime();

            long diff = FEndTime.getTime()-FStartTime.getTime();

            long newTime=Math.abs(diff);

            long diffSeconds = (newTime/1000)%60;
            long diffMinutes = (newTime / (60 * 1000))%60;
            long diffHours = newTime / (60 * 60 * 1000)%24;

            /*String hrs,mins,secs;
            if(diffHours<=0){
                hrs="";
            }else{
                hrs=diffHours+" hrs, ";
            }
            if(diffMinutes<=0){
                mins="";
            }else{
                mins=diffMinutes+" mins, ";
            }
            if(diffSeconds<=0){
                secs="";
            }else{
                secs=diffSeconds+" sec";
            }*/

            return diffHours + ":" + diffMinutes + ":" + diffSeconds;
        }catch(Exception e){
            Demo1.logger.error("UtilDate.timeDifference "+e);
            e.printStackTrace();
            return null;
        }
    }


}
