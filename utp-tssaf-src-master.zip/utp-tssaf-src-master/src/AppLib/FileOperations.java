package AppLib;

import java.io.File;

import Driver.Config;
import Driver.Demo1;
import Driver.Reuse;

public class FileOperations{
	static String path,action;
	/**
	 * @param
	 *  elementType
	 *  elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			String[] paramArr=Demo1.arrParameters;
			path=paramArr[0];
			action=paramArr[1].trim();

			if (path.toLowerCase().startsWith("userdir")) {
		        path = new File(String.valueOf(Demo1.curDir) + path.replaceFirst("userdir", "")).getCanonicalFile().toString();
		        Reuse.log("source path:"+path);
		      } else if (path.toLowerCase().startsWith("config.applicationserverhomepath")) {
		        path = new File(String.valueOf(Config.applicationServerHomePath) + path.replaceFirst("config.applicationserverhomepath", "")).getCanonicalPath().toString();
		        Reuse.log("source path:"+path);
		      }



			if(action.equals("CREATE_FILE")){
				Reuse.createFile(path);
			}else if(action.equals("DELETE_FILE")){
				Reuse.deleteFile(path);
			}else if(action.equals("DELETE_DIRECTORY")){
				Reuse.DeleteDirectory(path);
			}else if(action.equals("DELETE_DIRECTORY_CONTENT")){
				Reuse.DeleteDirectoryContent(path);
			}else if(action.equals("EXIST_FILE")){
				Reuse.fileExist(path);
			}else if(action.equals("WAIT_FOR_FILE_EXIST")){
				Reuse.waitForFileExist(path);
			}else{
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "File Operations","File Operation - "+action,action+" not matched. Check the action in Testware.xlsx");
			}

		}catch(Exception e){
			Demo1.logger.error(e.getMessage());
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "File Operations","File Operation - "+action,action+" not matched. Check the action in Testware.xlsx");
		}
	}
}
