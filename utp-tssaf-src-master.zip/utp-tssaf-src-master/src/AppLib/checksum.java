package AppLib;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.NoSuchElementException;
import java.util.Properties;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Driver.Demo1;


public class checksum {
    public static boolean checksumvariable;
    public static Statement tapstmt;
    public static Statement t24stmt;
    public static String teststatus;
    public static Boolean Teststatusflag = true;
    public static void main(String[] args) throws Exception {
        Properties prop = new Properties();
        String curDir;
        curDir = System.getProperty("user.dir");
        InputStream input = new FileInputStream(curDir + "\\Config\\config.properties");
        prop.load(input);
        Connection tapconn=null;
        Connection t24conn=null;
        DASHBOARD D = new DASHBOARD();
        String url    =    prop.getProperty("tapurl").trim();
        int intialcount = 0;
        int checksumcount = 0;
        int samplecount = 0;
        int flowcount = 0;
        String username    =    prop.getProperty("tapusername").trim();

        String password    =    prop.getProperty("tappassword").trim();
        String sybasedriver    =    prop.getProperty("sybdriver").trim();

        String sybdbname   =    prop.getProperty("tapdb").trim();
        String JDBC_DRIVER    =    prop.getProperty("t24driver").trim();

        String t24DB_URL    =    prop.getProperty("t24url").trim();

        String t24USER    =    prop.getProperty("t24dbusername").trim();


        String t24PASS    =    prop.getProperty("t24dbpasswordt").trim();
        String[] indexinformation = new String[3];
        indexinformation[0] = "intialload";
        D.initialloadDriver(indexinformation);
        D.initialloadReportHeader();

        boolean  DBconnect =true;

        Class.forName(sybasedriver).newInstance();
        System.out.println("connected");


        try{
            t24conn = DriverManager.getConnection(t24DB_URL,t24USER,t24PASS);
            t24stmt = t24conn.createStatement();
            tapconn = DriverManager.getConnection(url,username,password);
            tapstmt = tapconn.createStatement();
        }
        catch(java.sql.SQLException EX)
        {DBconnect=false;
        Demo1.gbTestCaseStatus = "Fail";
        System.out.println("Problem with Connection correct your Sysbase URL & Credential"+EX);
        }

        if(DBconnect)
        {
            try
            {

                Class.forName(sybasedriver).newInstance();
                System.out.println("connected");

                tapstmt.executeUpdate("USE "+sybdbname);
                String excelFilePath = "TestWare\\TestWare.xlsx";
                File path=new File(curDir + "\\Testware\\Testware.xlsx");
                FileInputStream fis=new FileInputStream(path);
                XSSFWorkbook wb=new XSSFWorkbook(fis);
                XSSFSheet tokensheet= wb.getSheetAt(7);
                int testPlanRowCnt=tokensheet.getLastRowNum();
                String[] intialarg = new String[13];


                for(int i=1;i<=testPlanRowCnt;i++)
                {
                    if(tokensheet.getRow(i).getCell(0)!=null )
                    {
                        String Checkpoint=tokensheet.getRow(i).getCell(0).getStringCellValue();
                        String t24table=tokensheet.getRow(i).getCell(1).getStringCellValue();
                        String taptable=tokensheet.getRow(i).getCell(2).getStringCellValue();
                        String t24query=tokensheet.getRow(i).getCell(3).getStringCellValue();
                        String tapquery=tokensheet.getRow(i).getCell(4).getStringCellValue();
                        String t24checksumfield=tokensheet.getRow(i).getCell(5).getStringCellValue();
                        String tapchecksumfield=tokensheet.getRow(i).getCell(6).getStringCellValue();

                        tapquery =  tapquery.replace("\"", "");
                        t24query =  t24query.replace("\"", "");
                        tapchecksumfield =  tapchecksumfield.replace("\"", "");
                        t24checksumfield = t24checksumfield.replace("\"", "");
                        String Sql = tapquery;
                        long  tapchecksum = 0;

                        int tapcount = 0;
                        String taprecid;
                        int  t24checksum = 0;
                        int t24count = 0;
                        String t24recid;

                        if ( (!tapquery.equals("")) && (!tapquery.equals(null)))

                        {
                            System.out.println("TAP QUERY "+tapquery);
                            ResultSet taprs = tapstmt.executeQuery(Sql);
                            taprs.next();
                            if ( (!tapchecksumfield.equals("")) && (!tapchecksumfield.equals(null)))

                            {
                                tapchecksum = Integer.parseInt(taprs.getString("checksum"));
                            }
                            tapcount= Integer.parseInt(taprs.getString("reccount"));



                        }
                        if ( (!t24query.equals("")) && (!t24query.equals(null)))

                        {
                            ResultSet t24rs = t24stmt.executeQuery(t24query);
                            t24rs.next();
                            if( (!t24checksumfield.equals("")) && (!t24checksumfield.equals(null)))
                            {
                                t24checksum= Integer.parseInt(t24rs.getString("checksum"));
                            }
                            t24count = Integer.parseInt(t24rs.getString("reccount"));
                        }

                        checksum.teststatus="";
                        Checkpoint=  Checkpoint.replace("\"", "");
                        System.out.println("CHECKPOINT "+Checkpoint);
                        t24table=  t24table.replace("\"", "");
                        taptable=  taptable.replace("\"", "");
                        System.out.println("T24 TABLE "+t24table);
                        System.out.println("TAP TABLE "+taptable);
                        System.out.println("T24 QUERY "+t24query);
                        System.out.println("TAP QUERY "+tapquery);
                        System.out.println("TAP CHECKSUM "+tapchecksum);

                        System.out.println("T24 CHECKSUM "+t24checksum);
                        System.out.println("TAP COUNT "+tapcount);
                        System.out.println("T24 COUNT "+t24count);
                        System.out.println("*******************************************************");
                        if (tapchecksum!=t24checksum)
                        { Teststatusflag =false;
                        Demo1.gbTestCaseStatus="Fail";
                        checksum.teststatus="fail";
                        }
                        if(tapcount!=t24count)
                        { Teststatusflag =false;
                        Demo1.gbTestCaseStatus="Fail";
                        checksum.teststatus="fail";
                        }
                        intialcount+=1;
                        intialarg[0]= ""+intialcount+"";
                        intialarg[1]=Checkpoint;
                        intialarg[2]=t24table;
                        intialarg[3]=taptable;
                        if(t24count != 0)
                        {
                            flowcount+=1;
                            intialarg[4]=""+t24count+"";
                        }
                        else
                        {
                            intialarg[4]="NA";
                        }
                        if(tapcount != 0)
                        {
                            intialarg[5]=""+tapcount+"";
                        }
                        else
                        {
                            intialarg[5]="NA";
                        }
                        if (t24checksum != 0)
                        {
                            checksumcount+=1;
                            intialarg[6]=""+t24checksum+"";
                        }
                        else
                        {
                            intialarg[6]="NA";
                        }
                        if(tapchecksum != 0)
                        {
                            intialarg[7]=""+tapchecksum+"";
                        }
                        else
                        {
                            intialarg[7]="NA";
                        }
                        intialarg[8]="T24 DB Check";
                        intialarg[9]="TAP DB Check";
                        intialarg[10]="";

                        checksum.checksumvariable = true;
                        String t24checkpoint = Checkpoint;
                        String tapcheckpoint = Checkpoint;
                        if(Checkpoint.contains("NEGATIVETAP"))
                        {
                            t24checkpoint = Checkpoint.replace("NEGATIVETAP","");
                        }
                        else if(Checkpoint.contains("NEGATIVET24"))
                        {
                            tapcheckpoint = Checkpoint.replace("NEGATIVET24","");
                        }
                        Demo1.arrParameters[0]=tapcheckpoint;
                        AppLib.TestTAPdata.ExecuteComponent();
                        Demo1.arrParameters[0]=t24checkpoint;
                        AppLib.Testt24Oracledata.ExecuteComponent();
                        if(Checkpoint.contains("NEGATIVE"))
                        {
                            if(checksum.teststatus.equals("fail"))
                            {
                                checksum.teststatus="" ;
                            }
                            else if(checksum.teststatus.equals(""))
                            {
                                checksum.teststatus="fail";
                            }
                        }
                        intialarg[11]=t24checkpoint;
                        intialarg[12]=tapcheckpoint;
                        D.initialloadreportbody(intialarg);
                    }
                }
            }
            catch(NoSuchElementException ex)
            {

            }
            if(!checksum.Teststatusflag)
            {
                System.out.println("checksum fail");
                Demo1.TestCaseFlag =1;
                Demo1.gbTestCaseStatus="Fail";
            }
            else
            {
                Demo1.TestCaseFlag =0;
                Demo1.gbTestCaseStatus="Pass";
            }
            Demo1.Linkflag=true;
            checksum.checksumvariable = false;
            Demo1.SCBindexpage="intialload";
            Demo1.gbTestCaseStatus="Pass";
            Demo1.ReportStep(2,"<b>Intial Load Check</b>","Initial Load ",Demo1.gbTestCaseStatus);
            System.out.println("ReportStep");
            String[] footerarg= new String[6];
            footerarg[0]=""+flowcount+"";
            footerarg[1]=""+checksumcount+"";
            footerarg[2]=""+intialcount*2+"";
            int totalsteps=flowcount+checksumcount+intialcount*2;
            footerarg[3]=""+totalsteps+"";
            D.initialloadFooter(footerarg);
        }
        D.intialloadclose();
        t24conn.close();
        t24stmt.close();
        tapconn.close();
        tapstmt.close();

    }
    public static void ExecuteComponent()
            throws Exception
    {

        String[] paramArr = Demo1.arrParameters;
        try
        {
            main(paramArr);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
