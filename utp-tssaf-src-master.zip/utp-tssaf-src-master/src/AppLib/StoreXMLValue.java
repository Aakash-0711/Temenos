package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class StoreXMLValue {
	static String parameters,key,pathOfXml,rootTag,position,tagName,variableName;
	/**
	 * @param key
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception  {
		String[] paramArr=Demo1.arrParameters;
		try{
		    pathOfXml=paramArr[0];
		    rootTag=paramArr[1];
		    position=paramArr[2];
		    tagName=paramArr[3];
		    variableName=paramArr[4];


			Reuse.StoreXMLValue(pathOfXml, rootTag, position, tagName, variableName);

		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}
