package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class Shadow_Click {
	static String elementType,elementName,condition;
	/**
	 * @param args
	 * elementType
	 * elementName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{

		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			condition=paramArr[0];
			elementType=paramArr[1];
			elementName=paramArr[2];

			Reuse.Shadow_Click(condition, elementType, elementName);
		}catch(Exception e){
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Click "+elementType+" <b>"+elementName +"</b>",""+elementType+" <b>"+elementName +"</b> should get clicked","Unable to locate "+elementType+" <b>"+elementName+"</b>");
		}
	}
}
