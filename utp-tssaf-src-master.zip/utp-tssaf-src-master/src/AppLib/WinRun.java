package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class WinRun {
	static String applicationName,filePath,workingDirectory, inputParams;

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;
		try{
			applicationName=paramArr[0];
			filePath=paramArr[1];
			//workingDirectory=paramArr[2];

			inputParams=paramArr[2];
			Reuse.WinRun(applicationName, filePath.trim(), inputParams.trim());
		}catch(Exception e){
			Demo1.logger.error("Problem in WinRun. "+e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Run Application <b>" + applicationName + "</b>", "Application <b>" + applicationName + "</b>Should be Launched","Application <b>" + applicationName + "</b> not launched");
		}
	}
}
