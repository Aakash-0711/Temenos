package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class WaitForExternalProcess {
	static String parameters;
	static int timeOutInsec;
	/**
	 * @param args
	 * timeOutInsec
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{

		String[] paramArr=Demo1.arrParameters;
		try{
			timeOutInsec=Integer.parseInt(paramArr[0]);
			Reuse.oWait(timeOutInsec);
		}catch(Exception e){
			Demo1.logger.error("Wait "+e);
		}
	}
	
//	public static void ExecuteComponent() throws Exception
//    {
//        String[] paramArr = Demo1.arrParameters;
//        
//        try
//        {
//            final int origTimeOutInSec = Reuse.parseIntSafely("WaitForExternalProcess.origTimeOutInSec", paramArr, 0, 10);
//
//            int timeOutInSec = origTimeOutInSec;
//
//            if ( Driver.Config.waitForExternalProcessAdjustment != null )
//            {
//                timeOutInSec = Math.max( (int) ( timeOutInSec * Driver.Config.waitForExternalProcessAdjustment ), 1 );
//            }
//
//            if ( Driver.Config.waitForExternalProcessMaxInSecs != null )
//            {
//                timeOutInSec = Math.min( timeOutInSec, Driver.Config.waitForExternalProcessMaxInSecs );
//            }
//
//            if ( Driver.Config.waitForExternalProcessMinInSecs != null )
//            {
//                timeOutInSec = Math.max( timeOutInSec, Driver.Config.waitForExternalProcessMinInSecs );
//            }
//
//            if ( origTimeOutInSec != timeOutInSec )
//            {
//                Reuse.log( "WaitForExternalProcess: " + timeOutInSec + " Originally: " + origTimeOutInSec );
//            }
//
//            Reuse.oWait( timeOutInSec );
//            
//            if ( Driver.Config.UXPBRun )
//            {
//                Demo1.gbTestCaseStatus = "Pass";
//                Demo1.ReportStep(2, "WaitForExternalProcess <b>" + timeOutInSec + "</b> secs, originally <b>" + origTimeOutInSec + "</b> secs",
//                                    "WaitForExternalProcess <b>" + timeOutInSec + "</b> secs",
//                                    "WaitForExternalProcess <b>" + timeOutInSec + "</b> secs");
//            }
//        }
//        catch (Exception e)
//        {
//            Demo1.logger.error( "WaitForExternalProcess " + e );
//        }
//    }
}
