package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class ReadPropertiesFile_UpdateInJSON {	
	static String propertyKey,jsonkey,jsonFilename;
	
	public static void main(String[] args) throws Exception {
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		
		String[] paramArr=Demo1.arrParameters;
		     propertyKey= paramArr[0];
		     jsonkey= paramArr[1];
		     jsonFilename= paramArr[2];
		try{		
			Reuse.ReadPropertiesFile_UpdateInJSON(propertyKey,jsonkey,jsonFilename);
		}catch(Exception e){
			e.printStackTrace();
			Demo1.logger.error(e);
			Demo1.ReportStep(2, "Read property file and update in json file",
					"Property file value should be updated to json file", "Property file value is not updated to json file"+e.getMessage());
		}
	}
}
