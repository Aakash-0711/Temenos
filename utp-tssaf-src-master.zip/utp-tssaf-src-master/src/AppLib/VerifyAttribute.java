package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class VerifyAttribute{
	static String parameters,locatorType,locator,elementType,elementName,attributeName,verificationType;
	/**
	 * @param
	 *  elementType
	 *  elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		By by=null;
		String[] paramArr=Demo1.arrParameters;

		try{
			elementType=paramArr[0];
			elementName=paramArr[1];
			attributeName=paramArr[2];
			verificationType=paramArr[3];
			by=Reuse.GetLocator(paramArr[4]);

			if(verificationType.equals("Exist")){
				Reuse.AttributeExist(by, elementName, elementType, attributeName);
			}else{
				Reuse.AttributeNotExist(by, elementName, elementType, attributeName);
			}

		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify <b>"+elementName+"</b> "+elementType+" attribute <b>"+attributeName+"</b> "+verificationType,"Attribute <b>"+attributeName+"</b> should "+verificationType,e.getMessage());
		}
	}
}
