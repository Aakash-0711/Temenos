package AppLib;

import Driver.Demo1;
import Driver.Reuse;
import Driver.ReuseT24API;

public class API_StorePrimaryApplicant {
	static String userName,Password,URL,path,action,pCif , pParty , cCif, cParty , status, processId;
	private static String appUrl;
	/**
	 * @param
	 * elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;


		pCif = paramArr[0];
        pParty = paramArr[1];
        status = paramArr[2];
        processId = paramArr[3];



		try {
			ReuseT24API.API_jsonPropertyPrimaryApp(pCif , pParty , status, processId);
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "To get request api data ",
                    "API request of is should be sent",
                    "API request not sent successfully");
		}
	}

}
