package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class LogOffT24 {
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		Reuse.SelectFrame(0);
		if(Reuse.isElementPresent(By.xpath("//img[@title='Sign off']"))){
			Reuse.Click_Element(By.xpath("//img[@title='Sign off']"),"Button","Sign off");
			}
			else{
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Click Button <b>Sign off</b>","Button <b>Sign off</b> should get clicked","Unable to locate Button <b>Sign off</b>");
			}
	}

}
