package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.ExternalConnection;

public class DB_ExecuteQueryBasedOnTimeout{
	static String action,query,expectedValue,variableName,url,path,table, timeOut;
	/**
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			By by=null;
			String[] paramArr=Demo1.arrParameters;
			url=paramArr[0];
			query=paramArr[1];
			expectedValue=paramArr[2];
			action=paramArr[3];
			timeOut=paramArr[4];

			ExternalConnection.dB_ExecuteQueryBasedOnTimeout(url, query, expectedValue, action, Integer.parseInt(timeOut));

		}catch(Exception e){
			Demo1.logger.error("Problem in Action class");
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Execute query", "Given query should be executed", "Given query was not executed properly");
		}
	}
}
