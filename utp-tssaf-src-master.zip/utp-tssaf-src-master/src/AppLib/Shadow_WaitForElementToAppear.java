package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class Shadow_WaitForElementToAppear{
     
	static String elementLocator,action;
	/**
	 * @param
	 *  elementType
	 *  elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			String[] paramArr = Demo1.arrParameters;
			elementLocator = paramArr[0];
			action=paramArr[3];
			Reuse.Shadow_waitForElementToAppear(elementLocator, Integer.parseInt(paramArr[1]), Integer.parseInt(paramArr[2]),action);
		}catch(Exception e){
			Demo1.logger.error("WaitForElementToAppear - "+e);
		}
	}
}
