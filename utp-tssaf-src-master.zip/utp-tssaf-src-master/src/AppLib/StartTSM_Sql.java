package AppLib;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Properties;

import org.apache.commons.exec.ExecuteWatchdog;

import com.google.common.base.Throwables;

import Driver.Config;
import Driver.Demo1;
import Driver.Reuse;

public class StartTSM_Sql {
    // JDBC driver name and database URL
    static final String JDBC_DRIVER = "org.h2.Driver";
    static final String DB_URL = "jdbc:h2:~/test";

    public static LinkedHashMap<String, ArrayList<String>> beforeCobDetails = new LinkedHashMap<>();
    public static LinkedHashMap<String, Integer> dateTableColumnDetails = new LinkedHashMap<>();

    private static Connection conn; // connection variable
    private static Statement statement; // statements variable
    private static ResultSet resultset; // result sets variable
    public static String timeOutSandC, serviceOrCOB;

    /*
     * private static final String SERVER_IP = "localhost"; //"10.92.4.42";
     * private static final String SERVER_PORT = "3456";
     */

    private static String startTimeOfCob = "";

    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        // TODO Auto-generated method stub
        ExecuteComponent();
    }

    public static void ExecuteComponent() throws Exception {
        try {


            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");



            String SERVER_IP = Config.getProperty("SERVER_IP"); // "localhost";
            String H2_PORT = Config.getProperty("H2_PORT"); // "3456";
            String jBossPort = Config.getProperty("JBossPort"); // "9089";
            String utpPath = Config.getProperty("UTPPath");

            String jbossPath = Config.getProperty("JBOSSHOME");
            String javaPath = Config.getProperty("JAVAHOME");
           String tafjPath = Config.getProperty("TAFJHOME");
           String h2Path = Config.getProperty("H2HOME");
           String t24Path = Config.getProperty("T24HOME");



           String url =Reuse.GetTafjPropertyValue(tafjPath, "temn.tafj.jdbc.url");
//            String url = "jdbc:h2:tcp://" + SERVER_IP + ":" + H2_PORT + "/"+dbName; // "jdbc:h2:tcp://10.92.4.42:3456/TAFJDB";
            System.out.println(url);

            String uName =Reuse.GetTafjPropertyValue(tafjPath, "temn.tafj.jdbc.username");
            String pName =Reuse.GetTafjPropertyValue(tafjPath, "temn.tafj.jdbc.password");

            conn = DriverManager.getConnection(url, uName, pName);

            System.out.println("CATALOG::" + conn.getCatalog());

            WriteProperties("com.temenos.jmsinjector.port",jBossPort,tafjPath);

//            InetAddress ip = InetAddress.getLocalHost();
//            WriteProperties("com.temenos.jmsinjector.host",ip.toString(),tafjPath);
            setupEnvironment(utpPath, H2_PORT, jBossPort,tafjPath,h2Path,t24Path,javaPath,jbossPath);
            createWLaunchServiceBatchFile(tafjPath);



            File script = getScript(utpPath,tafjPath,h2Path,t24Path,javaPath,jbossPath);


            triggerCobNew(script);

            Thread.sleep(120000);




            if (getAgentStatusForTSM(conn).contains("STOP") || getAgentStatusForTSM(conn) == "" ) {

                if (getAgentStatusForTSM(conn).contains("STOP") || getAgentStatusForTSM(conn) == "")
                {
                    triggerCobNew(script);
                    System.out.println("trying second to start tsm"); }
                Thread.sleep(120000);
                if (getAgentStatusForTSM(conn).contains("STOP") || getAgentStatusForTSM(conn) == "")
                {   triggerCobNew(script);
                System.out.println("trying third to start tsm"); }
            }



            if (getAgentStatusForTSM(conn).contains("RUN")) {
            Demo1.gbTestCaseStatus = "Pass";
            Demo1.ReportStep(2, "Verify Service is successful:" + "TSM", "Service should be succesful",
                    "Service process completed successfully with status" + "TSM");
            }
            else{
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Issue in TSM", " TSM  is not running", "TSM should be running");

            }

            statement.close();
            resultset.close();
            conn.close();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Reuse.log("Error:" + Throwables.getStackTraceAsString(e));
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Issue in TSM", "Verify TSM parameter are correct", "TSM parameter should be correct");
        }
    }

    public static void WriteProperties(String key, String value, String path) {
        FileOutputStream fileOut = null;
        FileInputStream fileIn = null;
        try {
            Properties configProperty = new Properties();
            File file = new File(path + "\\JMSInjector\\conf\\jmsinjector.properties");
            fileIn = new FileInputStream(file);
            configProperty.load(fileIn);
            configProperty.setProperty(key, value);
            fileOut = new FileOutputStream(file);
            configProperty.store(fileOut, null);
        } catch (Exception ex) {
            Reuse.log(ex);
            //  Reuse.log(ex);
        } finally {
            try {
                fileOut.close();
            } catch (Exception e) {
                Reuse.log(e);
                //   Reuse.log(e);
            }
        }
    }
    /*public static void WriteProperties(String key, String value, String path) {
        FileOutputStream fileOut = null;
        FileInputStream fileIn = null;
        try {
            Properties configProperty = new Properties();
            File file = new File(path + "\\TAFJ\\JMSInjector\\conf\\jmsinjector.properties");
            fileIn = new FileInputStream(file);
            configProperty.load(fileIn);
            configProperty.setProperty(key, value);
            fileOut = new FileOutputStream(file);
            configProperty.store(fileOut, null);
        } catch (Exception ex) {
            Reuse.log(ex);
            //  Reuse.log(ex);
        } finally {
            try {
                fileOut.close();
            } catch (Exception e) {
                Reuse.log(e);
                //   Reuse.log(e);
            }
        }
    }*/

    private static void getDateColumnDetails(Connection connt) {

        try {
            statement = connt.createStatement();
            String table = "SHOW COLUMNS FROM V_F_DATES";
            resultset = statement.executeQuery(table);

            int fieldIndex = 0;
            while (resultset.next()) {
                fieldIndex++;
                String columnValue = resultset.getString(1);
                if (columnValue.trim().equals("COMPANY_CODE")) {
                    dateTableColumnDetails.put("COMPANY_CODE", fieldIndex);
                } else if (columnValue.trim().equals("TODAY")) {
                    dateTableColumnDetails.put("TODAY", fieldIndex);
                } else if (columnValue.trim().equals("NEXT_WORKING_DAY")) {
                    dateTableColumnDetails.put("NEXT_WORKING_DAY", fieldIndex);
                } else if (columnValue.trim().equals("CO_BATCH_STATUS")) {
                    dateTableColumnDetails.put("CO_BATCH_STATUS", fieldIndex);
                }

                if (dateTableColumnDetails.size() == 4) {
                    break;
                }
            }
            System.out.println("getDateColumnDetailsCompleted");
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    private static String getServiceControl(Connection connt, String serviceName) {
        String serviceControl = null;
        try {

            statement = connt.createStatement();
            String table = "SELECT SERVICE_CONTROL FROM V_F_TSA_SERVICE where RECID='" + serviceName + "'";

            resultset = statement.executeQuery(table);
System.out.println("Resultset"+resultset);
            while (resultset.next()) {

                serviceControl = resultset.getString(1);

                System.out.println("ServiceControl of the service::" + serviceControl);

            }
System.out.println(serviceName +"has servicecontrol as "+ serviceControl);
        } catch (SQLException e) {
            Reuse.log(e);

            Demo1.logger.error(e);
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return serviceControl;
    }

    private static String getAgentStatusForTSM(Connection connt) {
        String serviceControl = "";
        try {

            statement = connt.createStatement();
            String table = "SELECT AGENT_STATUS FROM V_F_TSA_STATUS WHERE CURRENT_SERVICE='TSM'";

            resultset = statement.executeQuery(table);

            System.out.println("Resultset"+resultset);


            while (resultset.next()) {

                serviceControl = resultset.getString(1);

                System.out.println("AGENT_STATUS of the service::" + serviceControl);

            }

            if(serviceControl == "")
                System.out.println("the agent status has no record");



        } catch (SQLException e) {
            Reuse.log(e);

            Demo1.logger.error(e);
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return serviceControl;
    }

    private static String getBatchProcessServiceControl(Connection connt, String serviceName) {
        String batchProcess = null;
        try {
            statement = connt.createStatement();
            String table = "SELECT PROCESS_STATUS FROM V_F_BATCH WHERE RECID='" + serviceName + "'";
            resultset = statement.executeQuery(table);

            while (resultset.next()) {

                batchProcess = resultset.getString(1);

                System.out.println("BatchProcess of the service::" + batchProcess);

            }

        } catch (SQLException e) {
            Reuse.log(e);

            Demo1.logger.error(e);
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return batchProcess;
    }

    private static Connection getDateDetailsBeforeCob(Connection connt) throws ParseException {

        try {
            statement = connt.createStatement();
            // statement.setMaxRows(25);
            try {

                String sqltable = "SELECT * FROM V_F_DATES where COMPANY_CODE like '%-COB%'";
                resultset = statement.executeQuery(sqltable);

                ArrayList<String> details;
                System.out.println("COMPANY_CODE\tTODAY\tNEXT_WORKING_DAY\tCO_BATCH_STATUS");
                while (resultset.next()) {
                    details = new ArrayList<>();

                    String company = resultset.getString(dateTableColumnDetails.get("COMPANY_CODE"));
                    System.out.print(company + ",\t");
                    String today = resultset.getString(dateTableColumnDetails.get("TODAY"));
                    details.add(today);
                    System.out.print(today + ",\t");

                    String next = resultset.getString(dateTableColumnDetails.get("NEXT_WORKING_DAY"));
                    details.add(next);
                    System.out.print(next + ",\t");

                    String status = resultset.getString(dateTableColumnDetails.get("CO_BATCH_STATUS"));
                    details.add(status);
                    System.out.print(status + ",\t");

                    System.out.println();
                    beforeCobDetails.put(company, details);
                }

            } catch (SQLException e1) {
                e1.printStackTrace();
            }

        } catch (SQLException ex) { // Any error associated with the Database
                                    // Engine
            System.out.println("SQL error: " + ex.getMessage());
        }
        return connt;
    }

    private static Connection getDateDetails(Connection connt) throws ParseException {

        try {
            statement = connt.createStatement();
            // statement.setMaxRows(25);
            try {

                String sqltable = "SELECT * FROM V_F_DATES where COMPANY_CODE like '%-COB%'";
                resultset = statement.executeQuery(sqltable);

                ArrayList<String> details;
                System.out.println("COMPANY_CODE\tTODAY\tNEXT_WORKING_DAY\tCO_BATCH_STATUS");
                while (resultset.next()) {
                    details = new ArrayList<>();

                    String company = resultset.getString(dateTableColumnDetails.get("COMPANY_CODE"));
                    System.out.print(company + ",\t");
                    String today = resultset.getString(dateTableColumnDetails.get("TODAY"));
                    details.add(today);
                    System.out.print(today + ",\t");

                    String next = resultset.getString(dateTableColumnDetails.get("NEXT_WORKING_DAY"));
                    details.add(next);
                    System.out.print(next + ",\t");

                    String status = resultset.getString(dateTableColumnDetails.get("CO_BATCH_STATUS"));
                    details.add(status);
                    System.out.print(status + ",\t");

                    System.out.println("");

                }

            } catch (SQLException e1) {
                e1.printStackTrace();
            }

        } catch (SQLException ex) { // Any error associated with the Database
                                    // Engine
            System.out.println("SQL error: " + ex.getMessage());
        }
        return connt;
    }

    @SuppressWarnings("unchecked")
    private static void compareDateDetailsDuringCob(Connection connt) {

        LinkedHashMap<String, ArrayList<String>> currentCobDetails = new LinkedHashMap<>();
        boolean completed;
        long durationSoFar = 0;
        boolean booleanFlag = true;

        do {
            completed = true;
            try {
                statement = connt.createStatement();
                // statement.setMaxRows(25);

                String sqltable = "SELECT * FROM V_F_DATES where COMPANY_CODE like '%-COB%'";
                resultset = statement.executeQuery(sqltable);

                ArrayList<String> details;
                /*
                 * System.out.println(
                 * "COMPANY_CODE\tTODAY\tNEXT_WORKING_DAY\tCO_BATCH_STATUS");
                 */
                while (resultset.next()) {
                    details = new ArrayList<>();

                    String company = resultset.getString(dateTableColumnDetails.get("COMPANY_CODE"));
                    /* System.out.print(company + ",\t"); */
                    String today = resultset.getString(dateTableColumnDetails.get("TODAY"));
                    details.add(today);
                    /* System.out.print(today + ",\t"); */

                    String next = resultset.getString(dateTableColumnDetails.get("NEXT_WORKING_DAY"));
                    details.add(next);
                    /* System.out.print(next + ",\t"); */

                    String status = resultset.getString(dateTableColumnDetails.get("CO_BATCH_STATUS"));
                    details.add(status);
                    /* System.out.print(status + ",\t"); */

                    /* System.out.println(); */
                    currentCobDetails.put(company, details);
                }

            } catch (SQLException ex) { // Any error associated with the
                                        // Database Engine
                System.out.println("SQL error: " + ex.getMessage());
            }

            // checking if CO_BATCH_STATUS has reached "O" - ONLINE status for
            // all records
            for (Entry entry : currentCobDetails.entrySet()) {
                ArrayList<String> detail = (ArrayList<String>) entry.getValue();
                // System.out.println("LIST DETAIL:::" + detail.toString() +
                // ":::COMPLETED?" + completed);
                if (!detail.get(2).equalsIgnoreCase("O")) {
                    completed = false;
                    break;
                }
            }

            if (completed) {
                // compare if TODAY updated as NEXT_WORKING_DAY
                // System.out.println("Cob details iteration started");
                for (Entry entry : currentCobDetails.entrySet()) {
                    ArrayList<String> oldDetails = beforeCobDetails.get(entry.getKey());
                    ArrayList<String> newDetails = (ArrayList<String>) entry.getValue();

                    Date today = null, nextDay = null;
                    try {
                        today = new SimpleDateFormat("yyyyMMdd").parse(newDetails.get(0));
                        nextDay = new SimpleDateFormat("yyyyMMdd").parse(oldDetails.get(1));
                        // System.out.println("TODAY:::" + today + ":::NEXT:::"
                        // + nextDay);
                    } catch (ParseException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                    if (today.compareTo(nextDay) != 0) {
                        completed = false;

                        try {
                            String currentTimeOfCob = getCurrentDatenTime("HH:mm:ss");
                            durationSoFar = timeDifference(startTimeOfCob, currentTimeOfCob, "HH:mm:ss");
                            System.out.println("TIME SO FAR DATE::" + durationSoFar + " Minutes");

                            if (durationSoFar >= Long.parseLong(timeOutSandC)) { // max
                                                                                 // time
                                                                                 // limit
                                                                                 // is
                                try {
                                    System.out.println("Dates Just Before Break");
                                    getDateDetails(conn);
                                } catch (ParseException e) {

                                    e.printStackTrace();
                                    // TODO Auto-generated catch block
                                    // Uncomment and replace with appropriate logger
                                    // LOGGER.error(e, e);
                                }                                            // 2
                                                                                 // hours
                                System.out.println("BREAKING INTERMITTENTLY!");
                                completed = true;
                                booleanFlag = false;
                                break;
                            } else {
                                Thread.sleep(120000);
                                continue;
                            }

                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        break;
                    }

                }

            } else {
                try {
                    String currentTimeOfCob = getCurrentDatenTime("HH:mm:ss");
                    durationSoFar = timeDifference(startTimeOfCob, currentTimeOfCob, "HH:mm:ss");
                    System.out.println("TIME SO FAR BATCH::" + durationSoFar + " Minutes");

                    if (durationSoFar >= Long.parseLong(timeOutSandC)) { // max
                                                                         // time
                                                                         // limit
                        try {
                            System.out.println("Dates Just Before Break");
                            getDateDetails(conn);
                        } catch (ParseException e) {

                            e.printStackTrace();
                            // TODO Auto-generated catch block
                            // Uncomment and replace with appropriate logger
                            // LOGGER.error(e, e);
                        }                                          // is 2
                                                                         // hours
                        System.out.println("BREAKING INTERMITTENTLY!");

                        break;
                    } else {
                        Thread.sleep(120000);
                        continue;
                    }

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        } while (!completed);

        if (completed && booleanFlag) {
            String finalTimeOfCob = getCurrentDatenTime("HH:mm:ss");
            System.out.println("COB Process completed successfully.");
            System.out.println("End Time of COB:::" + finalTimeOfCob);
            System.out.println("TOTAL TIME TAKEN:::" + durationSoFar + " Minutes");
            Demo1.gbTestCaseStatus = "Pass";
            Demo1.ReportStep(2, "Verify COB is successful", "COB should be succesfull",
                    "COB process completed successfully");

        } else {
            System.out.println("COB Process has some issues, so it was terminated after 2 hours.");
            String finalTimeOfCob = getCurrentDatenTime("HH:mm:ss");
            System.out.println("COB discontinued at:::" + finalTimeOfCob);
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Verify COB is successful", "COB is not succesfull", "COB date is not updated in total time"+finalTimeOfCob);
        }
    }

    private static void compareServiceDetails(Connection connt, String serViceName) {

        try {
            long durationSoFar = 0;

            String serviceStatus = getServiceControl(conn, serViceName);
            if (serviceStatus.equalsIgnoreCase("STOP")) {
                System.out.println(serViceName + "=" + serviceStatus);
                Demo1.gbTestCaseStatus = "Pass";
                Demo1.ReportStep(2, "Verify Service is successful:" + serViceName, "Service should be succesful",
                        "Service process completed successfully with status" + serviceStatus);

            } else if (serviceStatus.equalsIgnoreCase("START")) {
                boolean status = true;
                do {

                    try {
                        String currentTimeOfCob = getCurrentDatenTime("HH:mm:ss");
                        durationSoFar = timeDifference(startTimeOfCob, currentTimeOfCob, "HH:mm:ss");
                        System.out.println("TIME SO FAR::" + durationSoFar + " Minutes");

                        if (durationSoFar == Long.parseLong(timeOutSandC)) {
                            System.out.println("BREAKING INTERMITTENTLY!");
                            status = false;
                            break;
                        } else {
                            Thread.sleep(60000);
                        }

                    } catch (Exception e) {
                        Reuse.log(e);

                        Demo1.logger.error(e);
                        e.printStackTrace();
                    }

                } while (serviceStatus.equalsIgnoreCase("START"));

                if (status) {
                    System.out.println(serViceName + " of Service status=" + serviceStatus);
                    Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, "Verify Service is successful:" + serViceName, "Service should be succesful",
                            "Service process completed successfully with status" + serviceStatus);
                } else {
                    System.out.println(serViceName + " of Service status=" + serviceStatus);
                    Demo1.gbTestCaseStatus = "Fail";
                    Demo1.ReportStep(2, "Verify Service is successful:" + serViceName, "Service is not succesful",
                            "Service process completed unsuccessfully with status" + serviceStatus);
                }

            } else if (serviceStatus.equalsIgnoreCase("AUTO")) {
                String batchStatus = getBatchProcessServiceControl(conn, serViceName);

                if (batchStatus.equalsIgnoreCase("0")) {
                    System.out.println(serViceName + " of Batch status=" + batchStatus);
                    Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, "Verify Service is successful:" + serViceName, "Service should be succesful",
                            "Service process completed successfully with status" + batchStatus);

                } else if (batchStatus.equalsIgnoreCase("1")) {
                    boolean status = true;
                    do {

                        try {
                            batchStatus = getBatchProcessServiceControl(conn, serViceName);
                            String currentTimeOfCob = getCurrentDatenTime("HH:mm:ss");
                            durationSoFar = timeDifference(startTimeOfCob, currentTimeOfCob, "HH:mm:ss");
                            System.out.println("TIME SO FAR::" + durationSoFar + " Minutes");

                            if (durationSoFar == Long.parseLong(timeOutSandC)) {
                                System.out.println("BREAKING INTERMITTENTLY!");
                                status = false;
                                break;
                            } else {
                                Thread.sleep(60000);
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    } while (batchStatus.equalsIgnoreCase("1"));

                    if (status) {
                        System.out.println(serViceName + " of Batch status=" + batchStatus);
                        Demo1.gbTestCaseStatus = "Pass";
                        Demo1.ReportStep(2, "Verify Service is successful:" + serViceName, "Service should be succesful",
                                "Service process completed successfully with status" + batchStatus);
                    } else {
                        System.out.println(serViceName + " of Batch status=" + batchStatus);
                        Demo1.gbTestCaseStatus = "Fail";
                        Demo1.ReportStep(2, "Verify Service is successful:" + serViceName, "Service is not succesful",
                                "Service process completed unsuccessfully with status" + batchStatus);
                    }

                } else if (batchStatus.equalsIgnoreCase("2")) {
                    System.out.println(serViceName + " of Batch status=" + batchStatus);
                    Demo1.gbTestCaseStatus = "Pass";
                    Demo1.ReportStep(2, "Verify Service is successful:" + serViceName, "Service should be succesful",
                            "Service process completed successfully with status" + batchStatus);

                }

            }
        } catch (Exception e) {
            Reuse.log(e);

            Demo1.logger.error(e);
            // TODO Auto-generated catch block
            // Uncomment and replace with appropriate logger
            // LOGGER.error(e, e);
        }

    }

    private static String getCurrentDatenTime(String format) {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        return sdf.format(cal.getTime());
    }

    private static long timeDifference(String StartTime, String endTime, String dateFormat) {
        SimpleDateFormat format = null;
        long diffMinutes = 0;
        try {
            // "dd-MM-yy HH:mm:ss"
            format = new SimpleDateFormat(dateFormat);
            Date FStartTime = format.parse(StartTime);
            Date FEndTime = format.parse(endTime);
            long diff = FEndTime.getTime() - FStartTime.getTime();

            long newTime = Math.abs(diff);
//            diffMinutes = (newTime / (60 * 1000)) % 60;
            diffMinutes = (newTime / (60 * 1000));

            /*
             * long diffSeconds = (newTime/1000)%60; long diffMinutes = (newTime
             * / (60 * 1000))%60; long diffHours = newTime / (60 * 60 *
             * 1000)%24;
             *
             * String hrs,mins,secs; if(diffHours<=0){ hrs=""; }else{
             * hrs=diffHours+" hrs, "; } if(diffMinutes<=0){ mins=""; }else{
             * mins=diffMinutes+" mins, "; } if(diffSeconds<=0){ secs=""; }else{
             * secs=diffSeconds+" sec"; } return hrs+mins+secs;
             */
        } catch (Exception e) {
            System.out.println("UtilDate.timeDifference " + e);
            /* return null; */
        }

        return diffMinutes;
    }

    private static void storeCobDetails() {
        String path = System.getProperty("user.dir");
        File file = new File(path + File.separator + "details.txt");

        StringBuffer buffer = new StringBuffer();
        for (Entry entry : beforeCobDetails.entrySet()) {
            buffer.append(entry.getKey() + ";");
            ArrayList<String> list = (ArrayList<String>) entry.getValue();
            System.out.println(list + "list of cob details");
            for (int i = 0; i < list.size(); i++) {
                if (i == (list.size() - 1)) {
                    buffer.append(list.get(i));
                } else {
                    buffer.append(list.get(i) + ";");
                }
            }
            buffer.append("\n");
        }
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            writer.write(buffer.toString());
            writer.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    private static void fetchCobDetails() {
        beforeCobDetails = new LinkedHashMap<>();
        String path = System.getProperty("user.dir");
        File file = new File(path + File.separator + "details.txt");

        BufferedReader br;
        ArrayList<String> list;
        try {
            br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                list = new ArrayList<>();
                // System.out.println(line);
                String[] array = line.split("\\;");
                String company = "";
                for (int index = 0; index < array.length; index++) {
                    if (index == 0) {
                        company = array[index];
                    } else {
                        list.add(array[index]);
                    }
                }
                beforeCobDetails.put(company, list);
                System.out.println(company + ":::" + list.toString());
            }

        } catch (FileNotFoundException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }



    private static File getScript(String utpPath,String tafjPath,String h2Path,String t24Path,String javaPath,String jbossPath) {

        StringBuffer script = new StringBuffer();

        script.append("$env:UTP_HOME = \"" + utpPath + "\"\n");
        script.append("$env:BRP_HOME = \"$env:UTP_HOME\\BRP\"" + "\n");
        script.append("$env:LOG_HOME = \"$env:UTP_HOME\\logs\"" + "\n");
        script.append("$env:GENERATED = \"$env:BRP_HOME\\generated\"" + "\n");
        script.append("$env:MANUAL = \"$env:BRP_HOME\\manual\"" + "\n");
        script.append("$env:GENERATED_TCIB = \"$env:UTP_HOME\\Channels_Generated\"" + "\n");


        script.append("$env:H2_HOME = \"" + h2Path + "\"\n");
        script.append("$env:TAFJ_HOME = \"" + tafjPath + "\"\n");
        script.append("$env:PATH += \";$env:TAFJ_HOME\\bin\"" + "\n");
        script.append("$env:JBOSS_HOME = \"" + jbossPath + "\"\n");
        script.append("$env:T24_HOME = \"" + t24Path + "\"\n");
        script.append("$env:JAVA_HOME = \"" + javaPath + "\"\n");


        script.append("cd $env:TAFJ_HOME\\bin\n");


        script.append("tUserMgnt.bat --Del -u t24user -p Temenos_123\n");
        script.append("tUserMgnt.bat --Add -u t24user -p Temenos_123\n");

        script.append("DBTools -s -u t24user -p Temenos_123 JQL CLEAR-FILE F.RECORD.LOCK" + "\n");
        script.append("DBTools -s -u t24user -p Temenos_123 JQL CLEAR-FILE F.TSA.STATUS" + "\n\n");


        script.append("cd $env:TAFJ_HOME" + "\n");
        script.append("Start-Process -FilePath .\\WLaunchService.bat" + "\n\n");




        File scriptFile = new File(
                tafjPath + File.separator + "bin" + File.separator + "TriggerCob.ps1");
        System.out.println("PATH:::" + scriptFile.getAbsolutePath());
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(scriptFile));
            writer.write(script.toString());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return scriptFile;
    }
   /* private static File getScript(String utpPath) {

        StringBuffer script = new StringBuffer();
        script.append("$env:TAFJDIR = \"TAFJ\"" + "\n");
        script.append("$env:H2DIR = \"db\\h2\"" + "\n");
        script.append("$env:JBOSSDIR = \"jboss\"" + "\n");
        script.append("$env:UTP_HOME = \"" + utpPath + "\"\n");
        script.append("$env:BRP_HOME = \"$env:UTP_HOME\\BRP\"" + "\n");
        script.append("$env:LOG_HOME = \"$env:UTP_HOME\\logs\"" + "\n");
        script.append("$env:GENERATED = \"$env:BRP_HOME\\generated\"" + "\n");
        script.append("$env:MANUAL = \"$env:BRP_HOME\\manual\"" + "\n");
        script.append("$env:GENERATED_TCIB = \"$env:UTP_HOME\\Channels_Generated\"" + "\n");

        script.append("$env:PP_HOME = \"$env:UTP_HOME\\db\\h2\\PPServices\"" + "\n");
        script.append("$env:H2_HOME = \"$env:UTP_HOME\\$env:H2DIR\"" + "\n");
        script.append("$env:TAFJ_HOME = \"$env:UTP_HOME\\$env:TAFJDIR\"" + "\n");
        script.append("$env:PATH += \";$env:TAFJ_HOME\\bin\"" + "\n");
        script.append("$env:JBOSS_HOME = \"$env:UTP_HOME\\$env:JBOSSDIR\"" + "\n");
        script.append("$env:T24_HOME = \"$env:UTP_HOME\\t24home\\default\"" + "\n");
        script.append("$env:JAVA_HOME = \"$env:UTP_HOME\\java\\jdk8\"" + "\n");

        script.append("$ScriptGroups = \"\"" + "\n");
        script.append("$SeatService = \"BNK/SEAT.CHECK.RESULTS.COB\"" + "\n");
        script.append("$SortOption = \"DSND\"" + "\n");
        script.append("$OSType = \"NT\"" + "\n");
        script.append("$global:ScriptGroups" + "\n");

        script.append("$txtfilepath = \"$env:JBOSS_HOME\\standalone\\deployments\\TAFJJEE_EAR.ear.deployed\"" + "\n");
        script.append(
                "$txtfilepath1 = \"$env:JBOSS_HOME\\standalone\\deployments\\TAFJJEE_EAR.ear.isdeploying\"" + "\n");
        script.append("$jbossfailed = \"$env:JBOSS_HOME\\standalone\\deployments\\TAFJJEE_EAR.ear.failed\"" + "\n");
        script.append("$testpath = test-path $txtfilepath" + "\n");
        script.append("$testpath1 = test-path $txtfilepath1" + "\n");
        script.append("$jbosscheck = \"\"" + "\n");
        script.append("$SEQBuild = $args" + "\n");
        script.append("$COBSeq = 1" + "\n\n");

        script.append("DBTools -s -u t24user -p Temenos_123 JQL CLEAR-FILE F.RECORD.LOCK" + "\n");
        script.append("DBTools -s -u t24user -p Temenos_123 JQL CLEAR-FILE F.TSA.STATUS" + "\n\n");

        // ***********
        script.append("$logdata = \" - Starting Service\"" + "\n");
        script.append("tRun AR.UpdateRlog $logdata" + "\n");
        script.append("tRun AR.StartService TSM" + "\n");
        script.append("$logdata = \" - Service Started\"" + "\n");
        script.append("tRun AR.UpdateRlog $logdata" + "\n");
        script.append("$logdata = \" - Starting LaunchServices\"" + "\n");
        script.append("tRun AR.UpdateRlog $logdata" + "\n");
        script.append("<#tRun AR.LaunchServices#>" + "\n\n");
        // *****************
        script.append("cd $env:H2_HOME" + "\n");
        script.append("Start-Process -FilePath .\\WLaunchService.bat" + "\n\n");

        script.append("#CD $env:TAFJ_HOME\\JMSInjector\\bin" + "\n");
        script.append("#.\\JMSSender.bat -i t24EXECQueue -fn START.SERVICES" + "\n\n");

        script.append("$logdata = \" - LaunchServices Completed\"" + "\n");

        // *****
        if (serviceOrCOB.equalsIgnoreCase("COB")){
        script.append("tRun AR.UpdateRlog $logdat" + "\n");
        script.append("write-output \"Calling FixEODerros Before COB\"" + "\n");
        script.append("tRun AR.FixEODerrors" + "\n");
        script.append("write-output \"Starting Cob Service\"" + "\n");
        script.append("tRun AR.StartService COB" + "\n");
        }
        // script.append("tRun AR.StartService COB-1" + "\n");
        // ***********

        File scriptFile = new File(
                utpPath + File.separator + "TAFJ" + File.separator + "bin" + File.separator + "TriggerCob.ps1");
        System.out.println("PATH:::" + scriptFile.getAbsolutePath());
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(scriptFile));
            writer.write(script.toString());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return scriptFile;
    }*/

    private static void triggerCobNew(File scriptFile) {

        System.out.println("PATH NEW:::" + scriptFile.getAbsolutePath());

        // lauching COB using powershell script
        Runtime runtime = Runtime.getRuntime();
        Process proc;

        try {
            String command = "powershell.exe " + scriptFile.getAbsolutePath();
            ExecuteWatchdog watchdog = new ExecuteWatchdog(20000);
            Process powerShellProcess = Runtime.getRuntime().exec(command);
            if (watchdog != null) {
                watchdog.start(powerShellProcess);
            }
            String line;
            System.out.println("Standard Output:");
            BufferedReader stdout = new BufferedReader(new InputStreamReader(powerShellProcess.getInputStream()));
            while ((line = stdout.readLine()) != null) {
                System.out.println(line);
            }
            stdout.close();
            System.out.println("Standard Error:");
            BufferedReader stderr = new BufferedReader(new InputStreamReader(powerShellProcess.getErrorStream()));
            while ((line = stderr.readLine()) != null) {
                System.out.println(line);
            }
            stderr.close();
            System.out.println("Done");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private static void setupEnvironment(String utpPath, String h2Port, String jBossPort, String tafjPath, String h2Path, String t24Path,
            String javaPath,String jbossPath) {
        StringBuffer commands = new StringBuffer();

        commands.append("@SET UTP_HOME=\"" + utpPath + "\"\n");
        commands.append("@SET UTP_TOOL_HOME=%UTP_HOME%\\..\\tools\\utptool" + "\n");


        commands.append("@SET H2_HOME="+h2Path + "\n");
        commands.append("@SET JAVA_HOME=" + javaPath + "\n");
        commands.append("@SET TAFJ_HOME="+ tafjPath + "\n");
        commands.append("@SET JBOSS_HOME=" + jbossPath + "\n");
        commands.append("@SET T24_HOME="+ t24Path + "\n");
        commands.append("@SET PATH=%PATH%;%TAFJ_HOME%\\bin;%H2_HOME%\\bin" + "\n");

        commands.append("@SET H2_PORT_NO=\"" + h2Port + "\"" + "\n");
        commands.append("@SET JBOSS_PORT_NO=\"" + jBossPort + "\"" + "\n");
        commands.append("@SET JMSINJECT_PORT_NO=\"" + jBossPort + "\"");

        File envBatFile = new File(
                tafjPath + File.separator + "setenv_aut.bat");
        System.out.println("ENV BAT PATH:::" + envBatFile.getAbsolutePath());
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(envBatFile));
            writer.write(commands.toString());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /*private static void setupEnvironment(String utpPath, String h2Port, String jBossPort) {
        StringBuffer commands = new StringBuffer();
        commands.append("@SET JDKDIR=java\\jdk8" + "\n");
        commands.append("@SET TAFJDIR=TAFJ" + "\n");
        commands.append("@SET H2DIR=db\\h2" + "\n");
        commands.append("@SET JBOSSDIR=jboss" + "\n");
        commands.append("@SET UTP_HOME=\"" + utpPath + "\"\n");
        commands.append("@SET UTP_TOOL_HOME=%UTP_HOME%\\..\\tools\\utptool" + "\n");

        commands.append("@SET PP_HOME=%UTP_HOME%\\db\\h2\\PPServices" + "\n");
        commands.append("@SET H2_HOME=%UTP_HOME%\\%H2DIR%" + "\n");
        commands.append("@SET JAVA_HOME=%UTP_HOME%\\%JDKDIR%" + "\n");
        commands.append("@SET TAFJ_HOME=%UTP_HOME%\\%TAFJDIR%" + "\n");
        commands.append("@SET JBOSS_HOME=%UTP_HOME%\\%JBOSSDIR%" + "\n");
        commands.append("@SET T24_HOME=%UTP_HOME%\\t24home\\default" + "\n");
        commands.append("@SET PATH=%PATH%;%TAFJ_HOME%\\bin;%H2_HOME%\\bin" + "\n");

        commands.append("@SET H2_PORT_NO=\"" + h2Port + "\"" + "\n");
        commands.append("@SET JBOSS_PORT_NO=\"" + jBossPort + "\"" + "\n");
        commands.append("@SET JMSINJECT_PORT_NO=\"" + jBossPort + "\"");

        File envBatFile = new File(
                utpPath + File.separator + "db" + File.separator + "h2" + File.separator + "setenv_aut.bat");
        System.out.println("ENV BAT PATH:::" + envBatFile.getAbsolutePath());
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(envBatFile));
            writer.write(commands.toString());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }*/

    private static void createWLaunchServiceBatchFile(String h2Path) {
        StringBuffer commands = new StringBuffer();
        commands.append("@CALL \"" + h2Path + "\\setenv_aut.bat\"" + "\n\n");

//        commands.append("CD %TAFJ_HOME%\\JMSInjector\\bin" + "\n");
//        commands.append(".\\JMSSender.bat -i t24EXECQueue -fn START.SERVICES" + "\n");

        commands.append("CD %TAFJ_HOME%\\bin" + "\n");
        commands.append("tRun START.TSM" + "\n");


        File launchServiceBatFile = new File(
                h2Path + File.separator + "WLaunchService.bat");
        System.out.println("LAUNCHER PATH:::" + launchServiceBatFile.getAbsolutePath());
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(launchServiceBatFile));
            writer.write(commands.toString());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /*private static void createWLaunchServiceBatchFile(String utpPath) {
        StringBuffer commands = new StringBuffer();
        commands.append("@CALL \"" + utpPath + "\\db\\h2\\setenv_aut.bat\"" + "\n\n");

        commands.append("CD %TAFJ_HOME%\\JMSInjector\\bin" + "\n");
        commands.append(".\\JMSSender.bat -i t24EXECQueue -fn START.SERVICES" + "\n");

        File launchServiceBatFile = new File(
                utpPath + File.separator + "db" + File.separator + "h2" + File.separator + "WLaunchService.bat");
        System.out.println("LAUNCHER PATH:::" + launchServiceBatFile.getAbsolutePath());
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(launchServiceBatFile));
            writer.write(commands.toString());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }*/
}
