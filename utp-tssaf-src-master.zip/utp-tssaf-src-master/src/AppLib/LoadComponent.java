package AppLib;

import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Paths;
import java.util.Arrays;

import Driver.Demo1;
import Driver.Reuse;


/**
 * @author aakash.manohar
 * 
 * To load DW.JAR file and jar should be kept inside lib folder
 *
 */
public class LoadComponent {
	public static void ExecuteComponent() throws Exception {
		Reuse.log("Launching of External Component.\r\n");
		try {
			String curDir = System.getProperty("user.dir");
			String testCaseDescription="Validating "+Demo1.arrParameters[1]+"."+ Demo1.arrParameters[3];
			String JARFile = Demo1.arrParameters[0];
			URL[] urls = new URL[1];
			urls[0] = Paths.get(curDir, "lib/", JARFile + ".jar").toFile().toURI().toURL();
			URLClassLoader child = new URLClassLoader(urls);
			Class<?> classToLoad = Class.forName("com.temenos.dw." + Demo1.arrParameters[1], true, child);
			java.lang.reflect.Method method = classToLoad.getDeclaredMethod("executeComponent", String[].class);
			Object instance = classToLoad.getDeclaredConstructor().newInstance();
			Object result = method.invoke(instance, new Object[] { Demo1.arrParameters });
			System.out.println(((Boolean) result).toString());
			if (((Boolean) result).toString().equalsIgnoreCase("true")) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(
						2, testCaseDescription, "Component name: " + Demo1.component + ". Parameters: "
								+ Arrays.asList(Demo1.arrParameters) + " . Test case ID: " + Demo1.gbCurrTestCaseName,
						"Passed");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(
						2, testCaseDescription, "Component name: " + Demo1.component + ". Parameters:  "
								+ Arrays.asList(Demo1.arrParameters) + " . Test case ID: " + Demo1.gbCurrTestCaseName,
						"Failed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Demo1.logger.error("Error in Reflection class. " + Demo1.component
					+ " function call having issue while executing the case " + Demo1.gbCurrTestCaseName);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Run time exception in Component execution",
					"Component name: " + Demo1.component + ". Parameters: " + Arrays.asList(Demo1.arrParameters)
							+ " . Test case ID: " + Demo1.gbCurrTestCaseName,
					e.toString());
			Reuse.log(e);
		}
	}
}
