package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

/**
 * Created by shanmugamarun on 26-04-2017.
 */
public class ScrollToElement {
    static String parameters,eleName,locatorType,locator,date;

    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        // TODO Auto-generated method stub
        ExecuteComponent();
    }
    public static void ExecuteComponent() throws Exception{
        String[] paramArr= Demo1.arrParameters;
        By by;
        try{
            eleName=paramArr[0];
            //locatorType=paramArr[1];
            by= Reuse.GetLocator(paramArr[1]);
            Reuse.Scroll_Element(by,eleName);
        }catch(Exception e){
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Scroll to Element <b>"+eleName+"</b>","Element should be scrolled and focus on <b>"+eleName+"</b>","Element not scrolled and focused.");
        }
    }
}
