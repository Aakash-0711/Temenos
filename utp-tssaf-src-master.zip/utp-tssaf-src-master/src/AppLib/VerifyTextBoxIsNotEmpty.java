package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class VerifyTextBoxIsNotEmpty  {
	static String parameters,locatorType,locator,expectedText,elementName;
	/**
	 * @param args
	 * expectedText
	 * elementName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{

		By by=null;
		String[] paramArr=Demo1.arrParameters;
		elementName=paramArr[0];
 		by=Reuse.GetLocator(paramArr[1]);
		try{
			Reuse.VerifyTextBoxContainsSomeText(by, elementName);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>"+expectedText+"</b> contains","Should be contains <b>"+expectedText+"</b>","Unable to locate <b>"+elementName+"</b> element");
		}
	}
}
