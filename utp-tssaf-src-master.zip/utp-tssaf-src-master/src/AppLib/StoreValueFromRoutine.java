package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class StoreValueFromRoutine {
	static String elementType, RoutineName, arg1, arg2, arg3, arg4, applicationName, ofsMessage, outputParams, routineValue;

	/**
	 * @param args
	 *            elementType elementName locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception {
		By by = null;
		try{
			String[] paramArr = Demo1.arrParameters;

			RoutineName = paramArr[0];
			arg1 = paramArr[1];
			arg2 = paramArr[2];
			arg3 = paramArr[3];
			arg4 = paramArr[4];

			applicationName = paramArr[5];


		          Reuse.runPaymentsRoutine1(RoutineName, arg1, arg2, arg3, arg4, applicationName);





		}catch(Exception e){
			Demo1.logger.error("Click_Element "+e);
		}
	}



}
