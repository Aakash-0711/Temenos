package AppLib;

import org.openqa.selenium.By;
import Driver.Demo1;
import Driver.Reuse;

public class Shadow_DropdownMultipleValue {
	static String parameters,itemToSelect,locatorType,locator,dropdownName;
	/**
	 * @param args
	 * itemToSelect
	 * dropdownName
	 * locator
	 * @throws Exception
	 * @author aakash.manohar 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			String by=null;
			String[] paramArr=Demo1.arrParameters;
			itemToSelect=paramArr[0];
			dropdownName=paramArr[1];		
			by=paramArr[2];
			Reuse.Shadow_DropdownMultipleValue(by, itemToSelect,dropdownName);
		}catch(Exception e){
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";				
			Demo1.ReportStep(2, "Select <b>"+itemToSelect+"</b> from <b>"+dropdownName+"</b> dropdown","Should be select <b>"+itemToSelect+"</b>",e.getMessage());
		}
	}
}
