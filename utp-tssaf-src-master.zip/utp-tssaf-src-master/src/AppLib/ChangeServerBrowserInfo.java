package AppLib;

import Driver.Demo1;


public class ChangeServerBrowserInfo {
	static String parameters,Switch;
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;
		Switch=paramArr[0].trim();
		try{
			if(Switch.equals("BROWSER_INFO")){
				Demo1.BrowserInfo=paramArr[1];
			}else if(Switch.equals("SERVER_INFO")){
				Demo1.ServerInfo=paramArr[1];
			}

		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Switch Server/Browser","Should be switched",e.getMessage());
		}
	}
}