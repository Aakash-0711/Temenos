package AppLib;

/**
 * TODO: Document me!
 *
 * @author ssandeep
 *
 */
public class Dashboardclose {
    public static void ExecuteComponent()
            throws Exception

          {
        DASHBOARD.d2.indexclose();

          }
    public static void main(String[] args)
    {try {
        ExecuteComponent();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }}

}
