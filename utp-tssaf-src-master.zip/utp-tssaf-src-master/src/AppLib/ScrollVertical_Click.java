package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

/**
 * Created by shanmugamarun on 26-04-2017.
 */
public class ScrollVertical_Click {
    static String parameters,eleName,locatorType,locator,date,pageNo;

    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        // TODO Auto-generated method stub
        ExecuteComponent();
    }
    public static void ExecuteComponent() throws Exception{
        String[] paramArr= Demo1.arrParameters;
        By by;
        By by1;
        try{

            locatorType=paramArr[0];
            eleName=paramArr[1];
            by= Reuse.GetLocator(paramArr[2]);
            pageNo =paramArr[3];
            by1= Reuse.GetLocator(paramArr[4]);

            Reuse.Scroll_Vertical_click(Integer.parseInt(pageNo), by, by1, locatorType, eleName);
        }catch(Exception e){
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Scroll to Element <b>"+eleName+"</b>","Element should be scrolled and focus on <b>"+eleName+"</b>","Element not scrolled and focused.");
        }
    }
}
