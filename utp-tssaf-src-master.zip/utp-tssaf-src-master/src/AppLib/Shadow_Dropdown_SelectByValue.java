package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class Shadow_Dropdown_SelectByValue {
	static String parameters,itemToSelect,locatorType,locator,dropdownName;
	/**
	 * @param args
	 * itemToSelect
	 * dropdownName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			String by=null;
			String[] paramArr=Demo1.arrParameters;
			itemToSelect=paramArr[0];
			dropdownName=paramArr[1];
			by=paramArr[2];

			Reuse.shadow_DropdownSelectByValue(by, itemToSelect,dropdownName);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Select <b>"+itemToSelect+"</b> from <b>"+dropdownName+"</b> dropdown","Should be select <b>"+itemToSelect+"</b>",e.getMessage());
		}
	}
}
