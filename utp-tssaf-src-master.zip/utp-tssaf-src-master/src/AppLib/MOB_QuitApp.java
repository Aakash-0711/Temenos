package AppLib;

import Driver.Reuse;

public class MOB_QuitApp{
	static String action;
	/**
	 * @param
	 *  elementType
	 *  elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{

			Reuse.MOB_DriverQuit();

	}
}
