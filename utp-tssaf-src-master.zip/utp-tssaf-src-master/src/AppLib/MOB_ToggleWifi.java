package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class MOB_ToggleWifi{
	static String action;
	/**
	 * @param
	 *  elementType
	 *  elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{

		String[] paramArr=Demo1.arrParameters;
		action=paramArr[0];

			Reuse.MOB_ToggleWifi();

	}
}
