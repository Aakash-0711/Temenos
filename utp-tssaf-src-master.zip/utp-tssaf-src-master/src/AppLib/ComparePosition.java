package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class ComparePosition {
	static String parameters,locatorType1,locator1,locatorType2,locator2;
	static String nameElementToCompare,nameElementToCompareWith,rowWiseOrColumnWise,expPosition;
	/**
	 * @param args
	 * nameElementToCompare
	 * nameElementToCompareWith
	 * rowWiseOrColumnWise
	 * expPosition
	 * locator1
	 * locator2
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;
		By elementToCompare,compareWith;
		try{
		nameElementToCompare=paramArr[0];
		nameElementToCompareWith=paramArr[1];
		rowWiseOrColumnWise=paramArr[2];
		expPosition=paramArr[3];
		//Element to compare
		elementToCompare=Reuse.GetLocator(paramArr[4]);
		//Element to compare with
		compareWith=Reuse.GetLocator(paramArr[5]);
		Reuse.oComparePosition(elementToCompare,nameElementToCompare,compareWith,nameElementToCompareWith,rowWiseOrColumnWise,expPosition);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Compare <b>"+nameElementToCompare+"</b> position with <b>"+nameElementToCompareWith+"</b>","<b>"+nameElementToCompareWith+"</b> position should be above the <b>"+nameElementToCompare+" position",e.getMessage());
		}
	}
}
