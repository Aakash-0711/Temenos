package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class WaitForElementToAppear{

	/**
	 * @param
	 *  elementType
	 *  elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		By by=null;
		try{
			String[] paramArr = Demo1.arrParameters;
			by = Reuse.GetLocator(paramArr[0]);
			Reuse.waitForElementToAppear(by, Integer.parseInt(paramArr[1]), Integer.parseInt(paramArr[2]));
		}catch(Exception e){
			Demo1.logger.error("WaitForElementToAppear - "+e);
		}
	}
}
