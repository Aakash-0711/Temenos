package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class ValidateDeal {

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			Reuse.CommitDeal();
			Reuse.oWait(10);
			Reuse.AcceptOverrides();

		}catch(Exception e){
			Demo1.logger.error(e);
		}
	}
}
