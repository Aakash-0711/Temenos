package AppLib;

import java.util.Map;

import org.openqa.selenium.By;

import com.google.common.base.Throwables;

import Driver.Demo1;
import Driver.Reuse;

public class Dynamicxpath {
    static String parameters, locatorType, locator, variableName, elementName, action, elementpresent;
    public static Map<String, String> txtAndVal = null;
    public static Boolean isMapInitialized = false;

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        ExecuteComponent();
    }

    public static void ExecuteComponent() {


        String[] paramArr = Demo1.arrParameters;
        try {


            if (paramArr.length == 4) {
                By by;
                variableName = paramArr[0];
                elementName = paramArr[1];

                action = paramArr[2].trim();
                String text = Reuse.GetPropertyValue(variableName);

                if(text.trim().isEmpty()){
                    throw new Exception("Empty variable");
                }
                by = Reuse.GetLocator(paramArr[3].replace("$VARIABLE", text.trim()));


                Reuse.VerifyOnClickPaginationElement(elementName, by, action, text);
            } else if (paramArr.length == 5) {

                By by;
                By next;
                variableName = paramArr[0];
                elementName = paramArr[1];
                action = paramArr[2].trim();

                if (action.equalsIgnoreCase("SELECT")) {

                    String text = Reuse.GetPropertyValue(variableName);
                    if(text.trim().isEmpty()){
                        throw new Exception("Empty variable");
                    }
                    by = Reuse.GetLocator(paramArr[3].replace("$VARIABLE", text.trim()));
                    String item = paramArr[4];
                    Reuse.Dropdown_SelectItem(by, item, elementName);
                } else {
                    String text = Reuse.GetPropertyValue(variableName);
                    if(text.trim().isEmpty()){
                        throw new Exception("Empty variable");
                    }
                    by = Reuse.GetLocator(paramArr[3].replace("$VARIABLE", text.trim()));
                    next = Reuse.GetLocator(paramArr[4]);
                    Reuse.VerifyOnClickPaginationElement(elementName, by, next, action, text);
                }
            } else if (paramArr.length == 6) {
                By by;
                By next;
                variableName = paramArr[0];
                String variableName1 = paramArr[1];
                elementName = paramArr[2];
                action = paramArr[3].trim();
                String text = Reuse.GetPropertyValue(variableName);
                String text1 = Reuse.GetPropertyValue(variableName1);
                String firstReplace = paramArr[4].replace("$VARIABLE_1", text.trim());
                by = Reuse.GetLocator(firstReplace.replace("$VARIABLE_2", text1.trim()));
                if (action.equalsIgnoreCase("SELECT")) {
                    String item = paramArr[5];
                    Reuse.Dropdown_SelectItem(by, item, elementName);
                } else {
                    next = Reuse.GetLocator(paramArr[5]);
                    Reuse.VerifyOnClickPaginationElement(elementName, by, next, action, text);
                }
            } else {
                throw new Exception("Array parameters mismatch");
            }


        } catch (Exception e) {
            e.printStackTrace();
            String e1 = Throwables.getStackTraceAsString(e);
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Perform " + action + " for  <b>" + elementName + "<b>", "Verify that " + elementName + "=>" + action, "Unable to perform the action"+e1);

        }
    }
}


    //

