package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class Shadow_ClearText {
	static String ElementName,ElementLocator;
	/**
	 * @param key
	 * @throws Exception
	 * @author aakash.manohar 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception  {		
		String[] paramArr=Demo1.arrParameters;
		try{
			ElementName=paramArr[0];	
			ElementLocator=paramArr[1];
			Reuse.Shadow_TextBox_Clear(ElementLocator, ElementName);
		}catch(Exception e){
			e.printStackTrace();
			System.out.println(e.getMessage());
		}						
	}
}
