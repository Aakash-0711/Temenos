package AppLib;

import org.openqa.selenium.By;

import Driver.Config;
import Driver.Demo1;
import Driver.Reuse;

/**
 * Created by vijayabharathi on 28-04-2017.
 */
public class LoginT24NewBrowser {

	static String URL, userName, password;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public static void ExecuteComponent() {

		String[] paramArr = Demo1.arrParameters;
		String appUrl = "http:\\localhost";
		try {
			userName = paramArr[1];
			password = paramArr[2];
			Reuse.closeAllWindowAndLaunch();
			URL = paramArr[0];
//			if (URL.equalsIgnoreCase("Config.URL")) {
//				appUrl = Config.appURL;
//				Demo1.pingURL = appUrl;
//				Demo1.driver.get(appUrl);
//			} else if (URL.equalsIgnoreCase("Config.URL1")) {
//				appUrl = Config.appURL1;
//				Demo1.pingURL = appUrl;
//				Demo1.driver.get(appUrl);
//			} else if (URL.equalsIgnoreCase("Config.URL2")) {
//				appUrl = Config.appURL2;
//				Demo1.pingURL = appUrl;
//				Demo1.driver.get(appUrl);
//			} else if (URL.equalsIgnoreCase("Config.URL3")) {
//				appUrl = Config.appURL3;
//				Demo1.pingURL = appUrl;
//				Demo1.driver.get(appUrl);
//			} else if (URL.equalsIgnoreCase("Config.URL4")) {
//				appUrl = Config.appURL4;
//				Demo1.pingURL = appUrl;
//				Demo1.driver.get(appUrl);
//			} else if (URL.equalsIgnoreCase("Config.URL5")) {
//				appUrl = Config.appURL5;
//				Demo1.pingURL = appUrl;
//				Demo1.driver.get(appUrl);
//			}
			if(URL.trim().toLowerCase().startsWith("config")) {
				appUrl = Config.getProperty(URL.split("[.]")[1]);
				Demo1.pingURL = appUrl;
				Demo1.driver.get(appUrl);
			}
			else {
				Demo1.driver.get(URL);
				Demo1.pingURL = appUrl;
				appUrl = URL;
			}
			if (Demo1.driver.getTitle().contains("ERROR")) {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Launch Application: " + URL, URL + " should be launched.",
						"URL " + URL + " not launched");

			} else {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Launch Application: " + URL, URL + " should be launched.",
						"URL " + URL + " launched");

				Reuse.TextBox_InputText(By.id("userId"), userName, "User Id");
				Reuse.TextBox_InputText(By.id("password"), password, "Password");
				Reuse.Click_Element(By.name("commit"), "WebEdit", "Login");
			}
			// Reuse.SwitchToWindow("T24 Sign in");

		} catch (Exception e) {
			Demo1.logger.error(e);
		}
	}

}
