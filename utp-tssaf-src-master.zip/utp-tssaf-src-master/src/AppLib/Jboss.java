package AppLib;

import Driver.Config;
import Driver.Demo1;
import Driver.Reuse;

public class Jboss{
	static String path,warFileName,action;
	/**
	 * @param
	 *  elementType
	 *  elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			String[] paramArr=Demo1.arrParameters;
			action=paramArr[1].trim();

			if(action.equals("START")){
				if(paramArr[0].trim().toLowerCase().startsWith("config.applicationserverhomepath")){
					Reuse.JbossStart(Config.applicationServerHomePath);
				}else{
					Reuse.JbossStart(paramArr[0]);
				}

			}else if(action.equals("STOP")){
				if(paramArr[0].trim().toLowerCase().startsWith("config.applicationserverhomepath")){
					Reuse.JbossStop(Config.applicationServerHomePath);
				}else{
					Reuse.JbossStop(paramArr[0]);
				}
			}

		}catch(Exception e){
			if(action.equals("START")){
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Start Jboss server","Server should be started",e.getMessage());
			}else if(action.equals("STOP")){
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Start Jboss server","Server should be started",e.getMessage());
			}
		}
	}
}
