package AppLib;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import Driver.Demo1;
import jxl.JXLException;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class ReadPageElements {
	static String XLSheetName;
	/**
	 * @param XLSheetName
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public static void ExecuteComponent() throws JXLException, Exception{
		String[] paramArr=Demo1.arrParameters;
		XLSheetName=paramArr[0];
		readElements();
	}

	private static void readElements(){
		try{
			XSSFWorkbook workbook = new XSSFWorkbook();

	        //Create a blank sheet
	        XSSFSheet sheetOR = workbook.createSheet("OR");

	        XSSFSheet sheetData = workbook.createSheet("TestData");
	        XSSFSheet sheetValidation = workbook.createSheet("Validation");


	        XSSFRow  rowData =sheetData.createRow(0);

	      //Create new cell for TestCase id Header  in Sheet TestData
	        XSSFCell cellTD_Header_TestCase=rowData.createCell(0);
	        cellTD_Header_TestCase.setCellType(CellType.STRING);
	        cellTD_Header_TestCase.setCellValue("TestCaseID");

	        //Create new cell for Field name in Sheet OR
	        XSSFCell cellOR_Header_FieldName=sheetOR.createRow(0).createCell(0);
	        cellOR_Header_FieldName.setCellType(CellType.STRING);
	        cellOR_Header_FieldName.setCellValue("FieldName");

	        //Create new cell for Locator in Sheet OR
	        XSSFCell cellOR_Header_Locator=sheetOR.getRow(0).createCell(1);
	        cellOR_Header_Locator.setCellType(CellType.STRING);
	        cellOR_Header_Locator.setCellValue("Locator");

	      //Create new cell for Locator in Sheet OR
	        XSSFCell cellOR_Header_ElementType=sheetOR.getRow(0).createCell(2);
	        cellOR_Header_ElementType.setCellType(CellType.STRING);
	        cellOR_Header_ElementType.setCellValue("ElementType");


			List<WebElement> elements= Demo1.driver.findElements(By.cssSelector("*"));
			boolean isElement=false;
			String locator="";
			String elementType="";
			String fieldName="";
			int indx=1;
			for(WebElement element:elements){
				String tageName=element.getTagName();

				// RadioButton TextBox CheckBox
				if(tageName.equals("input")){

					// RadioButton
					if(element.getAttribute("type").equals("radio")){
						locator="//input[@id='"+element.getAttribute("id")+"' and @value='"+element.getAttribute("value")+"']";
						elementType="RadioButton";
						isElement=true;
					// TextBox
					}else if(element.getAttribute("type").equals("text")){
						locator=element.getAttribute("id");
						elementType="WebEdit";
						isElement=true;

					// CheckBox
					}else if(element.getAttribute("type").equals("checkbox")){
						locator=element.getAttribute("id");
						elementType="CheckBox";
						isElement=true;
					}

				// DropDown
				}else if(tageName.equals("select")){
					locator=element.getAttribute("id");
					elementType="Dropdown";
					isElement=true;

				//TextArea
				}else if(tageName.equals("textarea")){
					locator=element.getAttribute("id");
					elementType="TextArea";
					isElement=true;
				}
				if(isElement){
					if(locator.length()>0){
						//Create new Row for Sheet OR
				        XSSFRow  rowOR =sheetOR.createRow(indx);
				        //Create new Cell for Field name
				        XSSFCell  cellFieldName=rowOR.createCell(0);
				        cellFieldName.setCellType(CellType.STRING);


				        //Set Cell data
				        if(locator.startsWith("//")){

				        	String radioVal=element.getAttribute("value");
				        	if(radioVal.length()>0){
				        		fieldName=getFieldName(element.getAttribute("id")+"_"+radioVal);
				        	}else{
				        		fieldName=getFieldName(element.getAttribute("id")+"_None");
				        	}
				        	cellFieldName.setCellValue(fieldName);
				        	Highlight(Demo1.driver.findElement(By.xpath(locator)));
				        }else{
				        	fieldName=getFieldName(locator);
				        	cellFieldName.setCellValue(fieldName);
				        	Highlight(Demo1.driver.findElement(By.id(locator)));
				        }


				        //Create new Cell for Locator
				        XSSFCell  cellLocator=rowOR.createCell(1);
				        //Set Data in Locator cell
				        cellLocator.setCellType(CellType.STRING);
				        cellLocator.setCellValue(locator);


				        //Create new Cell for ElementType
				        XSSFCell  cellType=rowOR.createCell(2);
				        //Set Data in Locator cell
				        cellType.setCellType(CellType.STRING);
				        if(elementType.length()>0){
				        	cellType.setCellValue(elementType);
				        }

				        //Test Data sheet
				        XSSFCell  cellDataFieldName=rowData.createCell(indx);
				        cellDataFieldName.setCellType(CellType.STRING);
				        cellDataFieldName.setCellValue(fieldName);

				        indx=indx+1;
					}
					elementType="";
					fieldName="";
					isElement=false;
				}
			}
			FileOutputStream file=new FileOutputStream(Demo1.curDir + "\\TestData\\"+XLSheetName+".xlsx");
	        workbook.write(file);
	        workbook.close();
	        file.close();
		}catch(Exception e){
			Demo1.logger.error(e);
		}
	}
	private static String getFieldName(String id){
		String fn="";
		try{
			if(id.contains(":")){
				fn=id.substring(id.indexOf(":")+1);
			}else{
				fn=id;
			}
			return fn;
		}catch(Exception e){
			Demo1.logger.error(e);
			return null;
		}
	}
public static void Highlight(WebElement element) throws Exception {

		try {

			JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
			js.executeScript("arguments[0].setAttribute('style', arguments[1]);",element, "color: green; border: 4px solid green;");
			js.executeScript("arguments[0].setAttribute('style', arguments[1]);",element, "");

			/*for (int i = 0; i < 1; i++) {
				JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
				js.executeScript("arguments[0].setAttribute('style', arguments[1]);",element, "color: green; border: 4px solid green;");
				js.executeScript("arguments[0].setAttribute('style', arguments[1]);",element, "");
			}*/
		} catch (Exception e) {
			Demo1.logger.error("Problem in HighlightElement in ReadPageElement class "+e);
		}
	}

	private static void FetchElements() throws JXLException, Exception{
		try{
			String existingXLName="APPLICATION_FIELDS_TEMPLATE.xls";
			String newXLName=XLSheetName+"_OR.xls";

			String existingXLPath=Demo1.curDir + "\\TestData\\"+existingXLName;
			String newXLPath=Demo1.curDir + "\\TestData\\"+newXLName;

			File existingWorkbook = new File(existingXLPath);
			File newWorkBook = new File(newXLPath);

			Workbook workbook = Workbook.getWorkbook(existingWorkbook);
			WritableWorkbook copy = Workbook.createWorkbook(newWorkBook, workbook);
			WritableSheet wSheet = copy.getSheet(0);
			WritableSheet wSheetTD = copy.getSheet(1);

			// WebEdit, RadioButton, Checkbox
					List<WebElement> webEditAndRadioElements= Demo1.driver.findElements(By.tagName("input"));
					int eleIndx=0;
					for(WebElement webElement:webEditAndRadioElements){
							String attributeType=webElement.getAttribute("type");
							if(attributeType.contains("text")){
								String webEdit_Id=webElement.getAttribute("id");
								if(!webEdit_Id.isEmpty()){
									if(eleIndx<webEditAndRadioElements.size()){
										eleIndx++;
									}
									wSheet.addCell(new Label(1,eleIndx,webEdit_Id));
									wSheet.addCell(new Label(2,eleIndx,"WebEdit"));
									StringBuffer sb = new StringBuffer();
									String[] webEditFNameParam=webEdit_Id.split(":");
									for(int i=1;i<webEditFNameParam.length;i++){
										if(webEditFNameParam.length==2){
											sb=sb.append(webEditFNameParam[i]);
										}else if(webEditFNameParam.length==3){
											if(i<=1)
												sb=sb.append(webEditFNameParam[i]).append(":");
											else
												sb=sb.append(webEditFNameParam[i]);
										}else if(webEditFNameParam.length==4){
											if(i<=2)
												sb=sb.append(webEditFNameParam[i]).append(":");
											else
												sb=sb.append(webEditFNameParam[i]);
										}
									}
									String webEdit_FieldName=sb.toString();
									if(!webEdit_FieldName.isEmpty()){
										wSheet.addCell(new Label(0,eleIndx,webEdit_FieldName));
										wSheetTD.addCell(new Label(eleIndx, 0, webEdit_FieldName));
									}
									sb=null;
								}
							// Radio Button
							}else if(attributeType.contains("radio")){
								String radio_Id=webElement.getAttribute("id");
								if(!radio_Id.isEmpty()){
									if(eleIndx<webEditAndRadioElements.size()){
										eleIndx++;
									}
									wSheet.addCell(new Label(1,eleIndx,radio_Id));
									wSheet.addCell(new Label(2,eleIndx,"RadioButton"));
									StringBuffer sb = new StringBuffer();
									String[] radioFNameParam=radio_Id.split(":");
									for(int i=2;i<radioFNameParam.length;i++){
										sb=sb.append(radioFNameParam[i]);
									}
									String radioButtonFieldName=sb.toString();
									if(!radioButtonFieldName.isEmpty()){
										String radio_Value=webElement.getAttribute("value");
										if(radio_Value.isEmpty()){
											radioButtonFieldName=radioButtonFieldName+"_NONE";
										}else{
											radioButtonFieldName=radioButtonFieldName+"_"+radio_Value;
										}
										wSheet.addCell(new Label(0,eleIndx,radioButtonFieldName));
										wSheetTD.addCell(new Label(eleIndx, 0, radioButtonFieldName));
									}
									sb=null;
								}
							// Checkbox
							}else if(attributeType.contains("checkbox")){
								String checkbox_Id=webElement.getAttribute("id");
								if(!checkbox_Id.isEmpty()){
									if(eleIndx<webEditAndRadioElements.size()){
										eleIndx++;
									}
									wSheet.addCell(new Label(1,eleIndx,checkbox_Id));
									wSheet.addCell(new Label(2,eleIndx,"CheckBox"));
									StringBuffer sb = new StringBuffer();
									String[] checkboxParam=checkbox_Id.split(":");
									/*for(int i=1;i<checkboxParam.length;i++){
										if(checkboxParam.length==2){
											sb=sb.append(checkboxParam[i]);
										}else if(checkboxParam.length==3){
											if(i<=1)
												sb=sb.append(checkboxParam[i]).append(":");
											else
												sb=sb.append(checkboxParam[i]);
										}else if(checkboxParam.length==4){
											if(i<=2)
												sb=sb.append(checkboxParam[i]).append(":");
											else
												sb=sb.append(checkboxParam[i]);
										}
									}*/

									String checkboxName=checkboxParam[checkboxParam.length-1];
									if(!checkboxName.isEmpty()){
										wSheet.addCell(new Label(0,eleIndx,checkboxName));
										wSheetTD.addCell(new Label(eleIndx, 0, checkboxName));
									}
									sb=null;
								}
							}

					}
					// List box(Dropdown)
					List<WebElement> webListElements= Demo1.driver.findElements(By.tagName("select"));
					for(WebElement webElement:webListElements){
						String attributeType=webElement.getAttribute("class");
						if(attributeType.contains("dealbox")){
							String webList_Id=webElement.getAttribute("id");
							if(!webList_Id.isEmpty()){
								if(eleIndx<webEditAndRadioElements.size()){
									eleIndx++;
								}
								wSheet.addCell(new Label(1,eleIndx,webList_Id));
								wSheet.addCell(new Label(2,eleIndx,"Dropdown"));
								StringBuffer sb = new StringBuffer();
								String[] listParam=webList_Id.split(":");
								for(int i=1;i<listParam.length;i++){
									sb=sb.append(listParam[i]);
								}
								String listboxName=sb.toString();
								if(!listboxName.isEmpty()){
									wSheet.addCell(new Label(0,eleIndx,listboxName));
									wSheetTD.addCell(new Label(eleIndx, 0, listboxName));
								}
								sb=null;
							}
						}
					}
					//Text area
					List<WebElement> textAreaElements= Demo1.driver.findElements(By.tagName("textarea"));
					for(WebElement textAreaElement:textAreaElements){
						String attributeType=textAreaElement.getAttribute("class");
						if(attributeType.contains("textbox")){
							String textArea_Id=textAreaElement.getAttribute("id");
							if(!textArea_Id.isEmpty()){
								if(eleIndx<webEditAndRadioElements.size()){
									eleIndx++;
								}
								wSheet.addCell(new Label(1,eleIndx,textArea_Id));
								wSheet.addCell(new Label(2,eleIndx,"TextArea"));
								StringBuffer sb = new StringBuffer();
								String[] textAreaParam=textArea_Id.split(":");
								for(int i=1;i<textAreaParam.length;i++){
									if(textAreaParam.length==2){
										sb=sb.append(textAreaParam[i]);
									}else if(textAreaParam.length==3){
										if(i<=1)
											sb=sb.append(textAreaParam[i]).append(":");
										else
											sb=sb.append(textAreaParam[i]);
									}else if(textAreaParam.length==4){
										if(i<=2)
											sb=sb.append(textAreaParam[i]).append(":");
										else
											sb=sb.append(textAreaParam[i]);
									}
								}
								String textAreaName=sb.toString();
								if(!textAreaName.isEmpty()){
									wSheet.addCell(new Label(0,eleIndx,textAreaName));
									wSheetTD.addCell(new Label(eleIndx, 0, textAreaName));
								}
								sb=null;
							}
						}
					}
					copy.write();
					copy.close();
					workbook.close();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}
