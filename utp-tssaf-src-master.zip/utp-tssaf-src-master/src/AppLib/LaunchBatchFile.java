package AppLib;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;

import com.google.common.base.Throwables;

import Driver.Config;
import Driver.Demo1;
import Driver.Reuse;

public class LaunchBatchFile {

	static String batFileName, batFilePath;

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception {
		try {
			String[] paramArr = Demo1.arrParameters;
			batFileName = paramArr[0];
			batFilePath = paramArr[1];
			String path = null;
			
			if (batFilePath.toLowerCase().startsWith("userdir")) {
		        path = new File(String.valueOf(Demo1.curDir) + batFilePath.replaceFirst("userdir", "")).getCanonicalFile().toString();
		        Reuse.log("source path:"+path);
		      } else if (batFilePath.toLowerCase().startsWith("config.applicationserverhomepath")) {
		        path = new File(String.valueOf(Config.applicationServerHomePath) + batFilePath.replaceFirst("config.applicationserverhomepath", "")).getCanonicalPath().toString();
		        Reuse.log("source path:"+path);
		      }
		      else {
		    	  String curDir = System.getProperty("user.dir");
					path = curDir + File.separator + "Batch" + File.separator + batFilePath;
					System.out.println("path of the dir: " + path);  
		      }
			String s;
			//Process exec=Runtime.getRuntime().exec("java -version");
			//Process exec = Runtime.getRuntime().exec("cmd.exe /c cd " + path + " & start cmd.exe /k java -version");
			//BufferedReader read=new BufferedReader(new InputStreamReader(exec.getInputStream()));
//			while ((s = read.readLine()) != null) {
//			     System.out.println(s);
//			}
			Runtime.getRuntime().exec("cmd.exe /c cd " + path + " & start cmd.exe /k " + batFileName + "");
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Executing <b>" + batFileName, batFileName + " should be executed successfully",
					   batFileName + " has been executed successfully");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Executing <b>" + batFileName, batFileName + " should be executed successfully",
					"Could not trigger" + batFileName + "::" + Throwables.getStackTraceAsString(e));
		}
	}
}
