package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class oClickElement {
	static String elementType, elementName;

	/**
	 * @param args elementType elementName locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}

	public static void ExecuteComponent() throws Exception {
		By by = null;
		try {
			String[] paramArr = Demo1.arrParameters;
			elementType = paramArr[0];
			elementName = paramArr[1];
//			by = Reuse.GetLocator(paramArr[2]);
			by = Reuse.GetLocator(Reuse.getValueOfRunTimeVariables(paramArr[2]));
			// Test

			Reuse.Click_Element(by, elementType, elementName);


		} catch (Exception e) {
			Demo1.logger.error("Click_Element " + e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Click element <b>" + elementName + "</b>",
					"Should be able to click on <b>" + elementName + "</b>",
					"Element <b>" + elementName + "</b> not present/unable to locate element");
		}
	}

}
