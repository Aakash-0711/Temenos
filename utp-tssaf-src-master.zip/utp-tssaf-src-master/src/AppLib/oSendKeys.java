package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class oSendKeys {
	static String parameters,key;
	/**
	 * @param key
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception  {
		String[] paramArr=Demo1.arrParameters;
		try{
			key=paramArr[0];
			Reuse.SendKeys(key);
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}
