package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class Switch_BackFrom_Frame {

	/**
	 * @param args
	 * @throws Exception
	 * @author aakash.manohar 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		try{
			Reuse.Switch_BackFrom_Frame();
		}catch(Exception e){
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";				
			Demo1.ReportStep(2, "Switch back from iframe","unable to switch back from iframe",e.getMessage());
		}
	}
}
