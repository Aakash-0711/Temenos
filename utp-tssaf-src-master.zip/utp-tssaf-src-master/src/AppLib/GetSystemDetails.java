package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class GetSystemDetails{
	static String action,VariableName;
	/**
	 * @param
	 *  elementType
	 *  elementName
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{

		String[] paramArr=Demo1.arrParameters;
		action=paramArr[0];
		VariableName=paramArr[1];

		if(action.equals("HOSTNAME")){
			Reuse.getSystemDetailsHost(VariableName);
		}else if(action.equals("DISMISS")){
			Reuse.Alert_Dismiss();
		}else if(action.equals("PRESENT")){
			Reuse.Alert_Present();
		}
	}
}
