package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class ElementSelected {
	static String elementType,elementName;
	/**
	 * @param args
	 * elementType
	 * elementName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{

		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			elementType=paramArr[0];
			elementName=paramArr[1];
			by=Reuse.GetLocator(paramArr[2]);
			Reuse.ElementSelected(by,elementType,elementName);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Click "+elementType+" <b>"+elementName +"</b>",""+elementType+" <b>"+elementName +"</b> should get clicked","Unable to locate "+elementType+" <b>"+elementName+"</b>");
		}
	}
}
