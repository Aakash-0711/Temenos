package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class oLinkClick {
	static String linkText,parameters;

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();

	}
public static void ExecuteComponent() throws Exception {
	try{
		String[] paramArr=Demo1.arrParameters;
		linkText=paramArr[0];
		By by=By.linkText(linkText);
		if(Reuse.isElementPresent(by)){
			Reuse.Link_Click(by,linkText);
		}
	}
	catch(Exception e){
		System.out.println(e.getMessage());
	}
}
}
