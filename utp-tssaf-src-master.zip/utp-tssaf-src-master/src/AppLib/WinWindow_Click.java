package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class WinWindow_Click {
	static String winName,buttonName,controlText,control;

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;
		try{
			winName=paramArr[0];
			buttonName=paramArr[1];
			controlText=paramArr[2];
			control=paramArr[3];
			Reuse.WinWindowClick(winName, buttonName, controlText, control);
		}catch(Exception e){
			Demo1.logger.error("Problem in WinWindowClick. "+e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Click  <b>" + buttonName + "</b> on Window <b>"+winName +"</b> ", "Should be clicked on <b>"+ buttonName + "</b>",e.getMessage());
		}
	}
}
