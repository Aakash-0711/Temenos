package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class ReadTestData {
	/**
	 * @param args
	 * elementType
	 * elementName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{

		String[] paramArr=Demo1.arrParameters;
		try{
			Reuse.ReadTestData(paramArr[0],paramArr[1]);
		}catch(Exception e){
			Demo1.logger.error(e);
			//Demo1.gbTestCaseStatus = "Fail";
			//Demo1.ReportStep(2, "Featch data from <b>"+testDtFileName+"</b>","Test data should be featched",e.getMessage());
		}
	}
}
