package AppLib;

import Driver.Demo1;
import Driver.Reuse;

public class UpdateTextFile {
	static String parameters,locatorType,locator,replaceText,path,SaveAsPath,lineNo, startPos, endPos;

	/**
	 * @param args
	 * expectedText
	 * elementName
	 * locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{

		String[] paramArr=Demo1.arrParameters;
		replaceText=paramArr[0];
		lineNo=paramArr[1];
		startPos=paramArr[2];
		endPos=paramArr[3];
		path=paramArr[4];
        SaveAsPath=paramArr[5];


		try{

		    Reuse.editTextFile(path, Integer.parseInt(lineNo), Integer.parseInt(startPos), Integer.parseInt(endPos), replaceText, SaveAsPath);



		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>"+replaceText+"</b> contains","Should be contains <b>"+replaceText+"</b>","Unable to locate <b>"+path+"</b> element");
		}
	}
}
