package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class Add_JSONObjects_To_ExistingJSONFile {
	static String JSONObjectsFileName,JSONExistingFileName;
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	
	public static void ExecuteComponent() throws Exception{	
		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			JSONExistingFileName=paramArr[0];
			JSONObjectsFileName=paramArr[1];
			Reuse.Add_JSONObjects_To_ExistingJSONFile(JSONExistingFileName,JSONObjectsFileName);
		}catch(Exception e){
			e.printStackTrace();
			Demo1.logger.error("Error in function parameter - "+e);
		}		
	}

}
