package AppLib;

import Driver.Config;
import Driver.Demo1;
import Driver.Reuse;
public class AppendToDefaultURL {


	public static String parameters,URL;

	public static void main(String[] args) throws Exception
	{
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		String[] paramArr=Demo1.arrParameters;
		String appUrl="";
		try{
			if(paramArr[0].equalsIgnoreCase("Config.defaultURL")){
				appUrl=Config.defaultURL+"/"+paramArr[1];
				Demo1.driver.get(appUrl);
				Reuse.oWait(5);
				if(Demo1.driver.getTitle().contains("ERROR")){
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Launch Application: "+appUrl,appUrl+" should be launched.","URL "+appUrl+" not launched");

				}else{
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Launch Application: "+appUrl,appUrl+" should be launched.","URL "+appUrl+" launched as expected");
				}
			}else{
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Launch Application: "+appUrl,"Application URL should be launched.","Check the paramteres provided in Testware/config.properters (defaultURL)");
			}
		}catch(Exception e){
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Launch Application: "+appUrl,appUrl+" should be launched.",e.getMessage());
		}
	}
}
