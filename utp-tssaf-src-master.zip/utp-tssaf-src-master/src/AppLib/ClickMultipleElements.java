package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;



public class ClickMultipleElements {
	
	static String elementType, elementName;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	
	public static void ExecuteComponent() {
		By by = null;
		By by1 = null;
		By by2 = null;
		try {
			String[] paramArr = Demo1.arrParameters;
			elementName = paramArr[0];
            by = Reuse.GetLocator(Reuse.getValueOfRunTimeVariables(paramArr[1]));
            by1 = Reuse.GetLocator(Reuse.getValueOfRunTimeVariables(paramArr[2]));
            by2 = Reuse.GetLocator(Reuse.getValueOfRunTimeVariables(paramArr[3]));
            String toClickOtherElement=paramArr[4];
			Reuse.click_MultipleElements(elementName, by,by1,by2,Boolean.valueOf(toClickOtherElement.toLowerCase()));

		} catch (Exception e) {
			e.printStackTrace();
			Demo1.logger.error("Click_Element " + e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Click Multiple elements <b>" + elementName + "</b>",
					"Should be able to click on <b>" + elementName + "</b>",
					"Element <b>" + elementName + "</b> not present/unable to locate element");
		}
	}

}
