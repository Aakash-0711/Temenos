package AppLib;

import org.openqa.selenium.By;

import Driver.Demo1;
import Driver.Reuse;

public class Styles {
	static String element,elementName,action,expected;
	/**
	 * @param
	 * path
	 *  locator
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExecuteComponent();
	}
	public static void ExecuteComponent() throws Exception{
		By by=null;
		String[] paramArr=Demo1.arrParameters;
		try{
			element=paramArr[0];
			elementName=paramArr[1];
			action=paramArr[2];
			expected=paramArr[3];

			by=Reuse.GetLocator(element);

			if(action.equals("COLOR")){
				Reuse.CompareColor(by, elementName, expected);
			}else if(action.equals("BG_COLOR")){
				Reuse.CompareBGColor(by, elementName, expected);
			}else{
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Action: <b>"+action+"</b> validation","<b>"+action+"</b> validation should be done","Action not found");
			}
			//Reuse.MouseOver(by,elementName);
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Action: <b>"+action+"</b> validation","<b>"+action+"</b> validation should be done",e.getMessage());
		}
	}
}
