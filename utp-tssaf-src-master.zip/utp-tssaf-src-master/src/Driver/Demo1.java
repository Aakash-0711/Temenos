package Driver;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.Writer;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.net.InetAddress;
import java.net.URL;
import java.net.URLClassLoader;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.output.TeeOutputStream;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariOptions;

import com.google.common.base.Throwables;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jacob.com.LibraryLoader;
import com.monitorjbl.xlsx.StreamingReader;

import AppLib.Reflection;
import AppLib.StoreText;
import AppLib.UtilDate;
import autoitx4java.AutoItX;
import groovyjarjarasm.asm.tree.TryCatchBlockNode;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

//import org.openqa.selenium.opera.OperaOptions;

public class Demo1 {

	// public static final Object Parameters = null;

	// public static FirefoxDriver driver;
	public static WebDriver driver;
	public static String hostname;
	public static String pingURL = "";

	public static String gbHostName;
	public static String gbUserName;
	public static int gbReportLevelNumber;
	public static String gbResultFolderName;
	public static String BrowserInfo, ServerInfo;
	public static String curDir;
	public static String ReportFilePath;
	public static Writer HTMLIndexFile;
	public static Writer HTMLReportFile;
	public static int TestCasePassCount;
	public static int TestCaseFailCount;
	public static int TestCaseWarningCount;
	public static int TestCaseNo;
	public static int gbTestStepCount;
	public static int TestCaseCount;
	public static int TestCaseIteration;
	public static int testcasesCount;
	public static int RowIteration;
	public static int GetTestPlanRow;
	public static String CurrTestCase;
	public static String gbCurrTestCaseName;
	public static String gbComplexity;
	public static String gbFunIndexing;
	public static String gbCurrTestGroup;
	public static String gbCurrTestCaseDesc;
	public static int GetTestScriptRow;
	public static double TestStepNo;
	public static String Date;
	public static int TestStepPassCount;
	public static int TestStepFailCount;
	public static int TestStepWarningCount;
	public static int FunctionIteration;
	public static int LastFailedStep;
	public static int LastWarningMessage;
	public static double Level1Value;
	public static double Level2Value;
	public static double Level3Value;
	public static String BatchStartTime, commanTextExeStartTime;
	public static String curDate;
	public static String TCStartTime;
	public static String EndTime;
	public static String duration;
	public static String FunctionName;
	public static String FunctionParameter;
	public static double GetTestStepNo;
	public static String CurrStepFailed;
	public static String gbTestCaseStatus = "";
	public static String ClassForStepNo;
	public static String ClassForStepDesc;
	public static String ClassForIcons;
	public static int TestCaseFlag = 0, TestCaseWarningFlag = 0;
	public static String ReportStep;
	public static String ScreenShotName;
	public static int totalStepCount;
	public static int testStepCountIndex;
	public static int totalTestCaseCount;
	public static String gbReturnValue;
	public static String gbCurrTestScenario;
	public static Object obj;
	// public static String Browser;
	public static String[] cellValue;
	public static int j;
	// public static String parameters;
	public static String actStartTime;
	public static String actEndTime;
	public static String BatchEndTime;
	public static String currentTestFile;
	public static String strPro;
	public static long timeStamp;
	public static String getTC_Id;
	public static int TIME_OUT = 0;
	// using this in StorTest.java
	public static boolean isStoreTxtInitialized = false, isTestStepFailed = false, isTestStepHasWarnings = false,
			isTestStepPass = false;
	// WebDriver parameters
	public static String storeTextData;
	// Logs - Lgo4j
	public static Logger logger = null;
	// AutoItX
	public static AutoItX autoItX;
	// Double codes
	public static String[] arrParameters;
	public static String component;
	public static String Nextcomponent = "";
	public static boolean exitCodeNonZero = false;
	public static TeeOutputStream out;
	static String RunNo, resWithDateAndTime;
	static Boolean isMBTestRun = false;
	static Boolean isChannelsTestRun = false;
	public int StepLevel;
	public String StepName;
	public String ExpectedResult;
	public String ActualResult;
	public String getTP_Id;
	public int getTC_Column, getClmLenght, TC_Clm, TC_RowCnt, TP_RowCnt;
	String gbApplicationName;
	static String BrowName;
	String deviceName;
	String deviceVersion;
	String platform;
	String android_appPackageName;
	String android_appActivityName;
	String hostIP;
	// Test driver report
	BufferedWriter testDriverReport;
	String testDri_Vertical;
	static java.util.List<String> listCSV = new ArrayList<>();
	static java.util.List<String> listretry = new ArrayList<>();
	static java.util.List<String> retryList = new ArrayList<>();
	static HashSet<String> failedTestList = new LinkedHashSet<>();
	int testCaseRetryCounter = 1;
	public static String parametersListGlobalRef = "";
	public static String strVerticalName = "", priorityTest = "";
	public static String envName = "";
	public static AndroidDriver driver1 = null;
	public static AppiumDriver appiumDriver = null;

	public static String testStepStartTime;

	public static Boolean DB2flag = Boolean.valueOf(false);
	public static Boolean isDB2flag = Boolean.valueOf(false);
	public static boolean Linkflag = false;
	public static String SCBindexpage;
	public static ArrayList<String> wealthTestCaseList = new ArrayList<>();
	public Workbook workbook;

	public static void ExitCodeBasedOnTestResults() {

		if (TestCaseFailCount > 0 || exitCodeNonZero) {
			org.junit.Assert.assertEquals(0, 1);
			// proBuilder(curDir+"\\Server\\run_STATUS_TEST.bat", "1",
			// curDir+"\\logs\\run_STATUS.txt");
		} else {
			// proBuilder(curDir+"\\Server\\run_STATUS_TEST.bat", "0",
			// curDir+"\\logs\\run_STATUS.txt");
			org.junit.Assert.assertEquals(0, 0);
		}
	}

	public static void ReportStep(int StepLevel, String StepName, String ExpectedResult, String ActualResult) {

		try {

			TestStepNo = GetTestStepNo(StepLevel);
			CurrStepFailed = "";
			// Reporting of failed step in HTML report
			if (gbTestCaseStatus == "Fail") {
				// if(LastFailedStep = vbNullString) {
				CurrStepFailed = "fail";
				if (StepLevel == 2) {
					// TestStepPassCount = TestStepPassCount - 1;
					if (TestStepPassCount <= 0) {
						TestStepPassCount = 0;
					}
					TestStepFailCount = TestStepFailCount + 1;
				}
			}
			ClassForStepNo = "\"" + "tsind" + CurrStepFailed + "lvl" + StepLevel + "\""; // -
																							// not
																							// copied

			if (StepLevel == 1) {
				ClassForStepDesc = "\"" + "tsnorm" + CurrStepFailed + "lvl1" + "\"";
				ClassForIcons = "\"" + "tsind" + CurrStepFailed + "lvl1" + "\"";

			} else {
				ClassForStepDesc = "\"" + "tsnorm" + CurrStepFailed + "\"" + "\"";
				ClassForIcons = "\"" + "tsind" + CurrStepFailed + "\"" + "\"";
			}

			HTMLReportFile.write("<tr vertical=" + strVerticalName + ">");
			HTMLReportFile.write("<td class=" + ClassForStepNo + " width=50px>" + TestStepNo + "</td>");

			if (Config.wealthRun) { // ADDED FOR WEALTH
				if ((Linkflag) && (gbTestCaseStatus.equals("Warn"))) {
					HTMLReportFile.write(
							"<td class=" + ClassForStepDesc + " width=155px><a class=\tcindex\" id=\"DBCHECK\" href=\""
									+ SCBindexpage + "\">" + StepName + "</a></td>");
				} else if (Linkflag) {
					HTMLReportFile.write(
							"<td class=" + ClassForStepDesc + " width=155px><a class=\tcindex\" id=\"DBCHECK\" href=\""
									+ SCBindexpage + ".htm\">" + StepName + "</a></td>");
				} else {
					HTMLReportFile.write("<td class=" + ClassForStepDesc + " width=155px>" + StepName + "</td>");
				}
			} else {

				HTMLReportFile.write("<td class=" + ClassForStepDesc + " width=155px>" + StepName + "</td>");
			}
			HTMLReportFile.write("<td class=" + ClassForStepDesc + " width=285px>" + ExpectedResult + "</td>");
			HTMLReportFile.write("<td class=" + ClassForStepDesc + " width=285px>" + ActualResult + "</td>");

			ReportStep = "";

			ScreenShotName = "";

			// this is to calculate the duration for the current teststep
			/*
			 * String timeTakenByCurrentStep = ; String timeNow =
			 * UtilDate.getFormattedTime(currentTime);
			 */

			String currentTime = UtilDate.getCurrentDatenTime("hh:mm:ss");
			/* System.out.println("CURRENT TIME:::" + currentTime); */

			String timeTakenByCurrentStep = UtilDate.timeDifferenceInTimeFormat(testStepStartTime, currentTime,
					"hh:mm:ss");

			SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
			/*
			 * System.out.println("TIME FOUND:::" +
			 * dateFormat.parse(timeTakenByCurrentStep).toString());
			 */

			Calendar calendar = Calendar.getInstance();
			calendar.setTime(dateFormat.parse(timeTakenByCurrentStep));
			timeTakenByCurrentStep = dateFormat.format(calendar.getTime());


			if (gbTestCaseStatus == "Pass") {
				if (Config.ScreenshotsForPassedSteps.contains("true")
						&& !Nextcomponent.toLowerCase().contains("alert")) {
					timeStamp = UtilDate.getLastsetTimeinmili();
					ScreenShotName = ReportFilePath + gbCurrTestCaseName + timeStamp + ".jpg";
					// UtilDate.takeScreenShot(ScreenShotName);
					RemoteScreenCapture(ScreenShotName);
					// HTMLReportFile.write("<td class=" + ClassForIcons + "
					// width=50px><img class=\"screen\" src =
					// \"../ReportInfo/images/pass.gif\"></td>");
				}

				// Newly added to display time taken by each test step
				HTMLReportFile.write("<td style=\"text-align:center\" class=" + ClassForStepDesc + " width=75px>"
						+ timeTakenByCurrentStep + "</td>");

				HTMLReportFile.write("<td style=\"text-align:center\" class=" + ClassForIcons
						+ " width=50px><img class=\"screen\" src = \"../ReportInfo/images/pass.gif\"></td>");
				ReportStep = "Pass";
				// CaptureScreenShot("Desktop")

				if (StepLevel == 2) {
					if (TestStepPassCount <= 0) {
						TestStepPassCount = 0;
					}
					TestStepPassCount = TestStepPassCount + 1;

				}
			} else if (gbTestCaseStatus == "Fail") {

				if (Config.ScreenshotsForFailedSteps.contains("true")) {
					timeStamp = UtilDate.getLastsetTimeinmili();
					ScreenShotName = ReportFilePath + gbCurrTestCaseName + timeStamp + ".jpg";
					// UtilDate.takeScreenShot(ScreenShotName);
					RemoteScreenCapture(ScreenShotName);
					// HTMLReportFile.write("<td class="+ ClassForIcons+ "
					// width=50px><img class=\"screen\" src =
					// \"../ReportInfo/images/fail.jpg\"></td>");
				}

				// Newly added to display time taken by each test step
				HTMLReportFile.write("<td style=\"text-align:center\" class=" + ClassForStepDesc + " width=75px>"
						+ timeTakenByCurrentStep + "</td>");

				HTMLReportFile.write("<td style=\"text-align:center\" class=" + ClassForIcons
						+ " width=50px><img class=\"screen\" src = \"../ReportInfo/images/fail.jpg\"></td>");
				ReportStep = "Fail";
			} else if (gbTestCaseStatus == "Warning") {

				if (Config.ScreenshotsForFailedSteps.contains("true")) {
					timeStamp = UtilDate.getLastsetTimeinmili();
					ScreenShotName = ReportFilePath + gbCurrTestCaseName + timeStamp + ".jpg";
					// UtilDate.takeScreenShot(ScreenShotName);
					RemoteScreenCapture(ScreenShotName);
					// HTMLReportFile.write("<td class="+ ClassForIcons+ "
					// width=50px><img class=\"screen\" src =
					// \"../ReportInfo/images/fail.jpg\"></td>");
				}

				// Newly added to display time taken by each test step
				HTMLReportFile.write("<td style=\"text-align:center\" class=" + ClassForStepDesc + " width=75px>"
						+ timeTakenByCurrentStep + "</td>");

				HTMLReportFile.write("<td style=\"text-align:center\" class=" + ClassForIcons
						+ " width=50px><img class=\"screen\" src = \"../ReportInfo/images/warning1.jpg\"></td>");
				ReportStep = "Warning";
				if (StepLevel == 2) {
					if (TestStepWarningCount <= 0) {
						TestStepWarningCount = 0;
					}
					TestStepWarningCount = TestStepWarningCount + 1;

				}
			} else {

				/*
				 * //Newly added to display time taken by each test step
				 * HTMLReportFile.write("<td class ='centerText' width=75px>" + "00:00:00" +
				 * "</td>");
				 */

				if (ActualResult.contains("SEVERE")) {
					HTMLReportFile.write("<td style=\"text-align:center\" class=" + ClassForStepDesc + " width=75px>"
							+ timeTakenByCurrentStep + "</td>");

					HTMLReportFile.write("<td style=\"text-align:center\" class=" + ClassForIcons
							+ " width=50px><img class=\"screen\" src = \"../ReportInfo/images/fail.jpg\"></td>");

					TestStepFailCount = TestStepFailCount + 1;
				} else if (ActualResult.contains("WARNING")) {
					HTMLReportFile.write("<td style=\"text-align:center\" class=" + ClassForStepDesc + " width=75px>"
							+ timeTakenByCurrentStep + "</td>");

					HTMLReportFile.write("<td style=\"text-align:center\" class=" + ClassForIcons
							+ " width=50px><img class=\"screen\" src = \"../ReportInfo/images/warning1.jpg\"></td>");

					TestStepWarningCount = TestStepWarningCount + 1;
				} else if (ActualResult.contains("INFO")) {
					HTMLReportFile.write("<td style=\"text-align:center\" class=" + ClassForStepDesc + " width=75px>"
							+ timeTakenByCurrentStep + "</td>");

					HTMLReportFile.write("<td style=\"text-align:center\" class=" + ClassForIcons
							+ " width=50px><img class=\"screen\" src = \"../ReportInfo/images/pass.gif\"></td>");

					TestStepPassCount = TestStepPassCount + 1;
				} else {

					HTMLReportFile.write("<td style=\"text-align:center\" class=" + ClassForStepDesc + " width=75px>"
							+ timeTakenByCurrentStep + "</td>");

					HTMLReportFile.write("<td style=\"text-align:center\" class=" + ClassForIcons
							+ " width=50px><img class=\"screen\" src = \"../ReportInfo/images/pass.gif\"></td>");

					TestStepPassCount = TestStepPassCount + 1;
				}
			}

			if (ScreenShotName != "") {

				/*
				 * //Newly added to display time taken by each test step
				 * HTMLReportFile.write("<td class ='centerText' width=75px>" + "00:00:00" +
				 * "</td>");
				 */

				HTMLReportFile.write("<td style=\"text-align:center\" class=" + ClassForIcons
						+ " width=50px><a target=\"_blank\" class=\"anibutton\" href=\"" + gbCurrTestCaseName
						+ timeStamp + ".jpg"
						+ "\"><img class=\"screen\" src = \"../ReportInfo/images/screenshot.gif\"></a></td>");
				ScreenShotName = "";
			} else {

				/*
				 * //Newly added to display time taken by each test step
				 * HTMLReportFile.write("<td class ='centerText' width=75px>" + "00:00:00" +
				 * "</td>");
				 */

				HTMLReportFile.write("<td class=" + ClassForIcons + " width=50px>&nbsp</td>");
			}
			HTMLReportFile.write("</tr>");

			if (Config.wealthRun) { // ADDED FOR WEALTH
				// ADDED FOR MAINORACLE
				if ((DB2flag.booleanValue()) && (!isDB2flag.booleanValue())) {
					if (ReportStep == "Fail") {
						TestCaseFlag = 1;
						isTestStepFailed = true;
						isDB2flag = Boolean.valueOf(true);
					} else if (ReportStep == "Pass") {
						TestCaseFlag = 0;
					} else if (ReportStep == "Warn") {
						TestCaseFlag = 2;
					}
				}
			}

			if (!isTestStepFailed) {
				if (ReportStep == "Fail") {
					TestCaseFlag = 1;
					isTestStepFailed = true;
					isTestStepPass = true;
				} else if (ReportStep == "Pass" && isTestStepPass) {
					TestCaseFlag = 0;
				}
			}
			if (!isTestStepHasWarnings && !isTestStepFailed) {
				if (ReportStep == "Warning") {
					TestCaseFlag = 2;
					isTestStepHasWarnings = true;
					isTestStepPass = true;
				}
			}
		} catch (Exception e) {
			Reuse.log(e);
			logger.error(e.getMessage());

		}

		// resetting the start time of next teststep
		testStepStartTime = UtilDate.getCurrentDatenTime("hh:mm:ss");
		if (Config.wealthRun) { // ADDED FOR WEALTH
			Linkflag = false;
		}

		try {
			HTMLReportFile.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
		// gbTestCaseStatus = ""; //-COMMENTED BY ASHOK ON 17th Dec 2016
	}

	public static void RemoteScreenCapture(String path) {

		WebDriver augmentedDriver = null;
		File screenshot = null;
		try {
			// augmentedDriver = new Augmenter().augment(driver);

			if (Demo1.envName.equalsIgnoreCase("MOBILEAPP")) {
				screenshot = ((TakesScreenshot) Demo1.driver1).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(screenshot, new File(path), true);
				// API Testing
			} else if (Demo1.envName.equalsIgnoreCase("API")) {

			} else {
				try {
					screenshot = ((TakesScreenshot) Demo1.driver).getScreenshotAs(OutputType.FILE);
					FileUtils.copyFile(screenshot, new File(path), true);
				} catch (NoSuchWindowException e) {
		            System.out.println("No such window: The window you are trying to capture is not available.");
		        } catch (WebDriverException e) {
		            System.out.println("WebDriverException: An error occurred while taking the screenshot: " + e.getMessage());
		        } catch (IOException e) {
		            System.out.println("Failed to save screenshot: " + e.getMessage());
		        }
				catch (Exception e) {
		            System.out.println("Error taking screenshot: " + e.getMessage());
		        } 
			}
		} catch (Exception e) {
			Reuse.log(e);
			// TODO Auto-generated catch block
			logger.error("error in RemoteScreenCapture.  " + e.getMessage());
		} finally {
			augmentedDriver = null;
			screenshot = null;
		}
		/*
		 * WebDriver augmentedDriver=null; File screenshot=null; try { augmentedDriver =
		 * new Augmenter().augment(driver); screenshot =
		 * ((TakesScreenshot)augmentedDriver). getScreenshotAs(OutputType.FILE);
		 * FileUtils.copyFile(screenshot, new File(path)); } catch (IOException e) { //
		 * TODO Auto-generated catch block logger.error(
		 * "error in RemoteScreenCapture.  "+e.getMessage()); }finally{
		 * augmentedDriver=null; screenshot=null; }
		 */
	}

	public static double GetTestStepNo(float StepLevel) {
		if (StepLevel == 1) {
			Level1Value = Level1Value + 1;
			Level2Value = 0;
			Level3Value = 0;
			GetTestStepNo = Level1Value;
			BigDecimal bd = new BigDecimal(GetTestStepNo);
			int decimalPlaces = 1;
			bd = bd.setScale(decimalPlaces, BigDecimal.ROUND_HALF_UP); // setScale
			// is
			// immutable
			GetTestStepNo = bd.doubleValue();

		} else if (StepLevel == 2) {
			Level2Value = (float) (Level2Value + 0.1);
			Level3Value = 0;
			GetTestStepNo = Level1Value + Level2Value;
			BigDecimal bd = new BigDecimal(GetTestStepNo);
			int decimalPlaces = 1;
			bd = bd.setScale(decimalPlaces, BigDecimal.ROUND_HALF_UP); // setScale
			// is
			// immutable
			GetTestStepNo = bd.doubleValue();
		} else if (StepLevel == 3) {
			Level3Value = (float) (Level3Value + 0.1);
			GetTestStepNo = Level1Value + Level2Value + Level3Value;
			BigDecimal bd = new BigDecimal(GetTestStepNo);
			int decimalPlaces = 1;
			bd = bd.setScale(decimalPlaces, BigDecimal.ROUND_HALF_UP); // setScale
			// is
			// immutable
			GetTestStepNo = bd.doubleValue();
		}
		return GetTestStepNo;
	}

	public static void CaptureScreenShot() {
		try {
			// Get the screen size
			Toolkit toolkit = Toolkit.getDefaultToolkit();
			Dimension screenSize = toolkit.getScreenSize();
			Rectangle rect = new Rectangle(0, 0, screenSize.width, screenSize.height);
			Robot robot = new Robot();
			BufferedImage image = robot.createScreenCapture(rect);
			File file;
		} catch (Exception e) {
			Reuse.log(e);
			logger.error("error in CaptureScreenShot method " + e.getClass().getMethods());
		}
	}

	public static void EndTestCaseReport() throws IOException {
		// Complete the test case report
		WriteReportFooter();
		HTMLReportFile.close();
		// Write the test case status to the index file
		// TestStepPassCount + TestStepFailCount
		// TestCaseFlag
		System.out.println("Pre:ENDREP:" + TestStepFailCount + TestStepPassCount + TestCaseFlag);
		if (TestStepFailCount > 0) {
			TestCaseFlag = 1;
		}

		else if (TestStepPassCount == 0) {
			TestCaseFlag = 0;
		}
		System.out.println(TestStepFailCount + TestStepPassCount + TestCaseFlag);
		ReportTestCaseIndex();
	}

	public static void CloseReporter() throws IOException {
		// Complete index information
		WriteIndexFooter();
		// Close and release the index file
		HTMLIndexFile.close();
	}

	public static void WriteReportFooter() throws IOException {
		// Test steps table header
		HTMLReportFile.write("<table>");
		// Blank line
		HTMLReportFile.write("<BR><BR>");
		// Link to index page and other links
		HTMLReportFile.write("<!-- links to index and other pages-->");
		HTMLReportFile.write("<table class=\"tblinks\" width=250px align=left>");
		HTMLReportFile.write("<tr><td class=\"tshead\">Links</td></tr>");
		HTMLReportFile.write(
				"<tr><td class=\"pfind\"><a href=\"" + "index_" + RunNo + ".htm" + "\">Index Page</a></td></tr>");
		HTMLReportFile.write("</table>");

		// TC Execution time
		HTMLReportFile.write("<!-- TC Execution time-->");
		HTMLReportFile.write("<table width=250px class=\"tbtime\">");
		HTMLReportFile.write("<tr><td colspan=2 class=\"tshead\">Execution Time</td></tr>");
		HTMLReportFile.write("<tr>");
		HTMLReportFile.write("<td class=\"pfhead\" width=120px>Start Time</td>");
		HTMLReportFile.write("<td class=\"pfind\" width=130px>" + TCStartTime + "</td>");
		HTMLReportFile.write("</tr><tr>");
		HTMLReportFile.write("<td class=\"pfhead\" width=120px>End Time</td>");
		EndTime = UtilDate.getCurrentDatenTime("HH:mm:ss");
		HTMLReportFile.write("<td class=\"pfind\" width=130px>" + EndTime + "</td>");
		HTMLReportFile.write("</tr><tr>");

		// GetTimeDifference(curDate,TCStartTime);
		HTMLReportFile.write("<td class=\"pfhead\" width=120px> Duration </td>");

		String tcDur = UtilDate.timeDifference(TCStartTime, EndTime, "HH:mm:ss");

		/*
		 * long timeDiff = UtilDate.findDuration(TCStartTime, EndTime);
		 *
		 * long diffSeconds = timeDiff / 1000 % 60; long diffMinutes = timeDiff / (60 *
		 * 1000) % 60; long diffHours = timeDiff / (60 * 60 * 1000) % 24;
		 *
		 * String hrs,mins,secs; if(diffHours<=0){ hrs=""; }else{ hrs=diffHours+
		 * " hrs, "; } if(diffMinutes<=0){ mins=""; }else{ mins=diffMinutes+ " mins, ";
		 * } if(diffSeconds<=0){ secs=""; }else{ secs=diffSeconds+ " secs"; } String
		 * tcDur=hrs+mins+secs;
		 */

		/*
		 * float tcDurinMins = tcDurinSecs / 60; BigDecimal bd = new
		 * BigDecimal(tcDurinMins); int decimalPlaces = 2; bd =
		 * bd.setScale(decimalPlaces, BigDecimal.ROUND_HALF_UP); // setScale
		 *
		 * double tcDur = bd.doubleValue();
		 */

		HTMLReportFile.write("<td class=\"pfind\" width=130px>" + tcDur + "</td>");
		HTMLReportFile.write("</tr></table>");

		// Report pass fail count
		HTMLReportFile.write("<!-- pass fail count-->");
		HTMLReportFile.write("<table width=250px class=\"pfsummary\">");
		HTMLReportFile.write("<tr><td colspan=2 class=\"tshead\">Test Case Summary</td></tr>");
		HTMLReportFile.write("<tr>");
		HTMLReportFile.write("<td class=\"pfhead\" width=200px>Total Steps</td>");
		totalStepCount = TestStepPassCount + TestStepFailCount + TestStepWarningCount;
		HTMLReportFile.write("<td class=\"pfind\" width=50px>" + totalStepCount + "</td>");
		HTMLReportFile.write("</tr><tr>");
		HTMLReportFile.write("<td class=\"pfhead\" width=200px>Steps Passed</td>");
		HTMLReportFile.write("<td class=\"pfind\" width=50px>" + TestStepPassCount + "</td>");
		HTMLReportFile.write("</tr><tr>");
		HTMLReportFile.write("<td class=\"pfhead\" width=200px>Warnings</td>");
		HTMLReportFile.write("<td class=\"pfind\" width=50px>" + TestStepWarningCount + "</td>");
		HTMLReportFile.write("</tr><tr>");
		HTMLReportFile.write("<td class=\"pfhead\" width=200px>Steps Failed</td>");
		HTMLReportFile.write("<td class=\"pfind\" width=50px>" + TestStepFailCount + "</td>");
		HTMLReportFile.write("</tr></table><BR><BR>");

		// HTML Footer
		HTMLReportFile.write("</body> </html>");

		// java.util.List<String> listCSV = new ArrayList<>();

		String str = TestCaseNo + "," + gbCurrTestCaseName + "," + TCStartTime + "," + EndTime + "," + tcDur;
		listCSV.add(str);
	}

	public static void ReportTestCaseIndex() throws IOException {
		// Write index

		HTMLIndexFile.write("<tr vertical=" + strVerticalName + ">");
		HTMLIndexFile.write("<td class=\"tsind\" width=50px>" + TestCaseNo + "</td>");
		HTMLIndexFile.write("<td class=\"tsnorm\" width=200px><a class=\tcindex\" href=\"" + gbCurrTestCaseName
				+ ".htm\">" + gbCurrTestCaseName + "</a></td>");
		// HTMLIndexFile.write("<td class=\"tsnorm\" width=200px><a
		// class=\"tcindex\" href=\"" + gbCurrTestCaseName + ".htm\">" +
		// gbCurrTestCaseName + "</a></td>");
		HTMLIndexFile.write("<td class=\"tsnorm\" width=300px>" + gbFunIndexing + "</td>"); // Fun.Index
		HTMLIndexFile.write("<td class=\"tsnorm\" width=1500px>" + gbCurrTestCaseDesc + "</td>"); // Description
		HTMLIndexFile.write("<td class=\"tsnorm\" width=300px>" + gbComplexity + "</td>"); // Complexity
		HTMLIndexFile.write("<td class=\"tsnorm\" width=300px>" + BrowserInfo + " / " + ServerInfo + "</td>"); // Environment
																												// details

		testStepCountIndex = TestStepPassCount + TestStepFailCount + TestStepWarningCount;
		HTMLIndexFile.write("<td class=\"tsind\" width=50px>" + testStepCountIndex + "</td>");
		HTMLIndexFile.write("<td class=\"tsind\" width=50px>" + TestStepPassCount + "</td>");
		HTMLIndexFile.write("<td class=\"tsind\" width=50px>" + TestStepWarningCount + "</td>");
		HTMLIndexFile.write("<td class=\"tsind\" width=50px>" + TestStepFailCount + "</td>");

		// added for showing Duration
		// String tcTotalDuration = UtilDate.timeDifference(BatchStartTime,
		// BatchEndTime, "HH:mm:ss");
		String tcTotalDuration = UtilDate.timeDifference(TCStartTime, EndTime, "HH:mm:ss");
		HTMLIndexFile.write("<td class=\"tsind\" width=50px>" + tcTotalDuration + "</td>");

		TestCaseNo = TestCaseNo + 1;
		System.out.println("REPINDEX:Flag " + TestCaseFlag);

		String testCaseResultStatus = "";

		if (TestCaseFlag == 0) {
			HTMLIndexFile.write(
					"<td class=\"tsind\" width=50px><img src = \"../ReportInfo/images/pass.gif\" width=\"20\" height=\"20\"></td>");
			TestCasePassCount = TestCasePassCount + 1;

			// writing the pass status
			testCaseResultStatus = "PASS";

		} else if (TestCaseFlag == 1) {
			HTMLIndexFile.write(
					"<td class=\"tsind\" width=50px><img src = \"../ReportInfo/images/fail.jpg\" width=\"20\" height=\"20\"></td>");
			TestCaseFailCount = TestCaseFailCount + 1;

			// writing the fail status
			testCaseResultStatus = "FAIL";
		} else if (TestCaseFlag == 2) {
			HTMLIndexFile.write(
					"<td class=\"tsind\" width=50px><img src = \"../ReportInfo/images/passWithWarns.jpg\" width=\"20\" height=\"20\"></td>");
			TestCaseWarningCount = TestCaseWarningCount + 1;

			// writing the pass status
			testCaseResultStatus = "PASS";
		}

		writeExecuteStatusToFile(testCaseResultStatus);

		isTestStepFailed = false;
		if (Config.wealthRun) { // ADDED FOR WEALTH
			isDB2flag = Boolean.valueOf(false); // ADDED FOR MAINORACLE
		}

		HTMLIndexFile.flush();
	}

	public static void WriteIndexFooter() throws IOException {
		HTMLIndexFile.write("<table>");
		// Linebreaks
		HTMLIndexFile.write("<BR><BR>");
		// Tablefooter
		HTMLIndexFile.write("</table>");

		// BatchExecutiontime
		HTMLIndexFile.write("<!--BatchExecutiontime-->");
		HTMLIndexFile.write("<table width=250px class=\"tbtime\">");
		HTMLIndexFile.write("<tr><td colspan=2 class=\"tshead\">ExecutionTime</td></tr>");
		HTMLIndexFile.write("<tr>");
		HTMLIndexFile.write("<td class=\"pfhead\" width=120px>Start Time</td>");
		HTMLIndexFile.write("<td class=\"pfind\" width=130px>" + BatchStartTime + "</td>");
		HTMLIndexFile.write("</tr><tr>");
		BatchEndTime = UtilDate.getCurrentDatenTime("HH:mm:ss");
		HTMLIndexFile.write("<td class=\"pfhead\" width=120px>End Time</td>");
		HTMLIndexFile.write("<td class=\"pfind\" width=130px>" + BatchEndTime + "</td>");
		HTMLIndexFile.write("</tr><tr>");

		String tcIndDur = UtilDate.timeDifference(BatchStartTime, BatchEndTime, "HH:mm:ss");

		/*
		 * long durInSec = UtilDate.findDuration(BatchStartTime, BatchEndTime);
		 *
		 *
		 * long diffSeconds = durInSec / 1000 % 60; long diffMinutes = durInSec / (60 *
		 * 1000) % 60; long diffHours = durInSec / (60 * 60 * 1000) % 24;
		 *
		 * String hrs,mins,secs; if(diffHours<=0){ hrs=""; }else{ hrs=diffHours+
		 * " hrs, "; } if(diffMinutes<=0){ mins=""; }else{ mins=diffMinutes+ " mins, ";
		 * } if(diffSeconds<=0){ secs=""; }else{ secs=diffSeconds+ " secs"; } String
		 * tcIndDur=hrs+mins+secs;
		 */

		/*
		 * float IndDurinMins = durInSec / 60; BigDecimal bd = new
		 * BigDecimal(IndDurinMins); int decimalPlaces = 2; bd =
		 * bd.setScale(decimalPlaces, BigDecimal.ROUND_HALF_UP); // setScale
		 *
		 * double tcIndDur = bd.doubleValue();
		 */

		HTMLIndexFile.write("<td class=\"pfhead\" width=120px>Duration</td>");
		HTMLIndexFile.write("<td class=\"pfind\" width=130px>" + tcIndDur + "</td>");
		HTMLIndexFile.write("</tr></table>");

		// Reportpassfailecount
		HTMLIndexFile.write("<!--passfailcount-->");
		HTMLIndexFile.write("<table width=250 class=\"pfsummary\">");
		HTMLIndexFile.write("<tr><td colspan=2 class=\"tshead\">TestCasesSummary</td></tr>");
		HTMLIndexFile.write("<tr>");
		HTMLIndexFile.write("<td class=\"pfhead\"width=200px>Total TestCases</td>");
		totalTestCaseCount = TestCasePassCount + TestCaseFailCount + TestCaseWarningCount;
		HTMLIndexFile.write("<td class=\"pfind\" width=50px>" + totalTestCaseCount + "</td>");
		HTMLIndexFile.write("</tr><tr>");
		HTMLIndexFile.write("<td class=\"pfhead\" width=200px>TestCases Passed</td>");
		HTMLIndexFile.write("<td class=\"pfind\" width=50px>" + TestCasePassCount + "</td>");
		HTMLIndexFile.write("</tr><tr>");
		HTMLIndexFile.write("<td class=\"pfhead\" width=200px>Passed with Warnings</td>");
		HTMLIndexFile.write("<td class=\"pfind\" width=50px>" + TestCaseWarningCount + "</td>");
		HTMLIndexFile.write("</tr><tr>");
		HTMLIndexFile.write("<td class=\"pfhead\" width=200px>TestCases Failed</td>");
		HTMLIndexFile.write("<td class=\"pfind\" width=50px>" + TestCaseFailCount + "</td>");
		HTMLIndexFile.write("</tr></table>");

		// HTMLFooter
		HTMLIndexFile.write("</body></html>");
	}

	public static void StartMBFWWait(String service) {
		// Reuse.log
		// Reuse.log
		Process p = null;
		try {
			p = Runtime.getRuntime().exec("cmd /c start /wait " + service, null, new File(curDir + "\\MBTest"));
			Reuse.log("Waiting for MB Test to be completed ...");
			p.waitFor();
			Reuse.log("MB Test Completed.");
		} catch (Exception e) {
			Reuse.log(e);
			logger.error("StartMBFWWait" + e);
		} finally {
			p = null;
		}
	}

	public static void StartMBFW(String service) {
		Process p = null;
		try {
			p = Runtime.getRuntime().exec("cmd /c start " + service, null, new File(curDir + "\\MBTest"));
			p.waitFor();
			int val = p.exitValue();
			Reuse.log("exit val: " + val);
			Reuse.log("MB Test completed in Parallel");
		} catch (Exception e) {
			Reuse.log(e);
			logger.error("Problem in StartMBFW. " + e);
		} finally {
			p = null;
		}
	}

	public static void main(String[] args) throws Exception {
		try {
			Demo1 demo1 = new Demo1();
			demo1.setUp();

			// Boolean isMBTestRun=false;
			// Boolean isChannelsTestRun=false;
			int mBPriority = 0;
			int channelsPriority = 0;
			if (Config.runMBTest.equalsIgnoreCase("true")) {
				isMBTestRun = true;
				mBPriority = Config.mbTestPriority;
			}
			if (Config.runChannelsTest.equalsIgnoreCase("true")) {
				isChannelsTestRun = true;
				channelsPriority = Config.channelsTestPriority;
			}
			if (isMBTestRun && isChannelsTestRun) {
				if (mBPriority != channelsPriority && mBPriority < channelsPriority) {
					// MB First
					StartMBFWWait("run.bat");
					// Channels Next
					demo1.testDemo1();
					demo1.tearDown();
				} else if (mBPriority != channelsPriority && mBPriority > channelsPriority) {
					// Channels First
					demo1.testDemo1();
					// MB Next
					StartMBFWWait("run.bat");
					demo1.tearDown();
				} else if (mBPriority == channelsPriority) {
					// Run Parallel
					StartMBFW("run.bat");
					demo1.testDemo1();
					demo1.tearDown();
				}
			} else if (isMBTestRun) {
				// MB only
				StartMBFWWait("run.bat");
				demo1.tearDown();
			} else if (isChannelsTestRun) {
				// Channels Only

				demo1.testDemo1();

				demo1.tearDown();

			} else if (Config.wealthRun) {

				demo1.testDemo1();

				StoreText.txtAndVal = new HashMap<>();
				StoreText.isMapInitialized = true;

				// newly added from wealth

				if (!Config.wealthWsc) {
					HtmlParser.main();
					System.out.println("Test cases were successfully consolidated");
					CreateIndexFile.main();
					System.out.println("Consolidated index is successfully created");
				}

				demo1.tearDown();
			}

			/*
			 * Demo1 demo1 =new Demo1(); demo1.setUp(); demo1.testDemo1(); demo1.tearDown();
			 */
		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();

			logger.error("error in main method. Current Test case id: " + gbCurrTestCaseName + ". Current method: "
					+ component + ". " + e.getMessage());
			EndTestCaseReport();
			istanbulDumpToFile(gbCurrTestCaseName);
			CloseReporter();
			// ExitCodeBasedOnTestResults();
		}
		System.out.println("Complete execution is done.");
	}

	public static void delete(long days, String fileExtension) {
		try {

			String dirPath = System.getProperty("user.dir");

			File folder = new File(dirPath);

			if (folder.exists()) {

				File[] listFiles = folder.listFiles();

				long eligibleForDeletion = System.currentTimeMillis() - (days * 24 * 60 * 60 * 1000L);

				for (File listFile : listFiles) {

					if (listFile.getName().endsWith(fileExtension) && listFile.lastModified() < eligibleForDeletion) {

						if (!listFile.delete()) {

							Reuse.log("Unable to Delete Log Files..");

						}
					}
				}
			}
		} catch (Exception e) {

		}
	}

	public static void deleteFile(File f) {
		try {
			if (f.exists()) {
				f.delete();
			}
		} catch (Exception e) {
			Reuse.log(e);
		}

	}

	@Before
	public void setUp() throws Exception {
		String logDIR = System.getProperty("user.dir");

		// String str =
		// TestCaseNo+","+gbCurrTestCaseName+","+TCStartTime+","+EndTime+","+tcDur;
		listCSV.add("TestCaseNo,TestCaseName,StartTime,EndTime,Duration,Status");
		// deleteFile(new File(logDIR+"/Duration.csv"));
		// delete(3, ".txt");
		// JavaConsole console = new JavaConsole();

		// console.initLog(f.getAbsolutePath());
		// Image im = Toolkit.getDefaultToolkit().getImage("MyIcon.png");
		// console.setIconImage(im);
		// console.setBackground(Color.BLUE);
		// console.setTitle("tSSAF Framework Console");
		// console.setForeground(Color.white);
		// console.setFont(new Font("Consolas", Font.BOLD, 18));

		// To Delete the existing ResponsTime.csv file
		File responsefile = new File(logDIR + File.separator + "TestData" + File.separator + "ResponseTime.csv");
		if (responsefile.exists()) {
			responsefile.delete();
		}
		InitializeVariables();
		InitializeReporter();
		File f = new File(gbResultFolderName + "/LOG" + Reuse.getDateTimeStamp() + ".txt");
		try {
			FileOutputStream fos = new FileOutputStream(f);
			// we will want to print in standard "System.out" and in "file"
			TeeOutputStream myOut = new TeeOutputStream(System.out, fos);
			PrintStream ps = new PrintStream(myOut, true); // true - auto-flush
															// after println
			System.setOut(ps);
		} catch (Exception e) {
			Reuse.log(e);
		}
	}

	@Test
	public void testDemo1() {
		try {

			// writing execution result in file
			writeExecuteStatusToFile("STARTED");

			BatchStartTime = UtilDate.getCurrentDatenTime("HH:mm:ss");
			URL url;
			DesiredCapabilities capabilities = new DesiredCapabilities();

			if (BrowName.equals("android") || BrowName.contentEquals("ios") || BrowName.equals("AndriodChrome")) {
				url = new URL("http", Config.mobileServer, Config.mobilePort, "/wd/hub");
			} else {
				url = new URL("http", hostIP, 4444, "/wd/hub");
				// capabilities.setJavascriptEnabled(true);
			}

			// Browser Initialization - INTERNET EXPLORER
			if (BrowName.contentEquals("iexplore")) {
				Reuse.log("====Selected Browser IE==========");
				File file = new File(curDir + "\\Server\\IEDriverServer.exe");
				// System.setProperty("webdriver.ie.driver",
				// curDir+"\\BrowserDrivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				Reuse.StartRemoteWebDriverServer("Start_IE_Server.bat");
				//capabilities = DesiredCapabilities.internetExplorer();
				//capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
				// capabilities.setCapability("requireWindowFocus",true);
				capabilities.setCapability(InternetExplorerDriver.ENABLE_PERSISTENT_HOVERING, false);
				capabilities.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS, false);
				// capabilities.setCapability(InternetExplorerDriver.NATIVE_EVENTS,true);
				// capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS,true);
				driver = new InternetExplorerDriver();
				// Browser Initialization - FIREFOX
			} else if (BrowName.contentEquals("firefox")) {
				Reuse.log("====Selected Browser FIREFOX==========");

				File file;

				if (!Config.TCDWebDriverEnvVar.isEmpty())
					file = new File(System.getenv(Config.getProperty("TCDWebDriverEnvVar")) + File.separator
							+ "geckodriver.exe");
				else {

					file = new File(curDir + "\\Server\\geckodriver.exe");

				}

				//System.setProperty("webdriver.gecko.driver", file.getAbsolutePath());
				if (!Config.dedicatedBrowserInstance.toLowerCase().contains("yes")) {
					try {
						// driver = new FirefoxDriver();
						System.out.println("hello");
						//driver = Reuse.getFF(Reuse.getFFOptions(Reuse.getFFProfile()));
					} catch (Exception e) {
						Reuse.log("Error while launching Firefox, Trying to launch 2nd time");
						Thread.sleep(1000);
						try {
							//driver = Reuse.getFF(Reuse.getFFOptions(Reuse.getFFProfile()));
						} catch (Exception e1) {
							//Reuse.log("Error while launching Firefox, Trying to launch 3nd time");
							Thread.sleep(5000);
							driver = Reuse.getFF(Reuse.getFFOptions(Reuse.getFFProfile()));
						}

					}

				} else {

					// driver =
					// Reuse.getFF(Reuse.getFFOptions(Reuse.getFFProfile()));
					FirefoxOptions options = new FirefoxOptions();
					//capabilities = DesiredCapabilities.firefox();
					Reuse.log("No parallel run");
					capabilities.setCapability(CapabilityType.UNHANDLED_PROMPT_BEHAVIOUR,UnexpectedAlertBehaviour.IGNORE);
					//options.setUnhandledPromptBehaviour(null)
					//Reuse.StartRemoteWebDriverServer("Start_Firefox_Server.bat");
				}
				// Browser Initialization - GOOGLE CHROME
			} else if (BrowName.contentEquals("googlechrome")) {
				Reuse.log("====Selected Browser CHROME==========");

				// File file = new File(curDir + "\\Server\\chromedriver.exe");

				File file;

				if (!Config.TCDWebDriverEnvVar.isEmpty())
					file = new File(System.getenv(Config.getProperty("TCDWebDriverEnvVar")) + File.separator
							+ "chromedriver.exe");
				else
					file = new File(curDir + "\\Server\\chromedriver.exe");

				//System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());

				/*
				 * ChromeOptions chromeOptions = new ChromeOptions();
				 *
				 * chromeOptions.addArguments("--headless");
				 *
				 * driver = new ChromeDriver( chromeOptions);
				 */

				if (Config.dedicatedBrowserInstance.toLowerCase().contains("yes")) {
					ChromeOptions options = new ChromeOptions();
					     options.setAcceptInsecureCerts(true);

					if (!Config.chromeBinaryPath.isEmpty()) {
						System.out.println("CHROME BINARY PATH::" + Config.chromeBinaryPath);
						Demo1.logger.info("CHROME BINARY PATH::" + Config.chromeBinaryPath);
						options.setBinary(Config.chromeBinaryPath);
					}

					if (Config.headLessMode.equalsIgnoreCase("Yes")) {
						// options.addArguments("--window-size=1920,1080");
						//options.addArguments("start-maximized");
						options.addArguments("--headless=old");
						 if (Config.wealthRun) {
							 options.addArguments("--window-size=1360,600");
						 }
						 else {
							 options.addArguments("--window-size=1920,1080");
						 }
						//options.addArguments("--window-size=1920,1080");
						/*
						 * options.addArguments("window-size=1280,800");
						 * options.addArguments("--disable-gpu");
						 * options.addArguments("--disable-extensions");
						 * options.addArguments("--proxy-server='direct://'");
						 * options.addArguments("--proxy-bypass-list=*");
						 * options.addArguments("--start-maximized");
						 */
						System.out.println("background");

						// options.addArguments("no-sandbox");
					}

					options.addArguments("disable-popup-blocking");
					// options.addArguments("--start-maximized");
					options.addArguments("--disable-extensions");
					options.addArguments("--remote-allow-origins=*");

//					try {
//						driver = Reuse.getChrome(options);
//					} catch (Exception e) {
//						Reuse.log("Error while launching Chrome, Trying to launch 2nd time");
//						Thread.sleep(5000);
//						try {
//							driver = Reuse.getChrome(options);
//						} catch (Exception e1) {
//							Reuse.log("Error while launching Chrome, Trying to launch 3nd time");
//							Thread.sleep(5000);
//							driver = Reuse.getChrome(options);
//						}
//
//					}

				} else {
					Reuse.StartRemoteWebDriverServer("Start_Chrome_Server.bat");
					//capabilities = DesiredCapabilities.chrome();
					ChromeOptions options = new ChromeOptions();
					options.addArguments("test-type");

					// options.addArguments("test-type",
					// "start-maximized","no-default-browser-check");
					capabilities.setCapability(ChromeOptions.CAPABILITY, options);
					// Browser Initialization - OPERA
				}
			} else if (BrowName.contentEquals("chromeEmulator")) {
				File file = new File(curDir + "\\Server\\chromedriver.exe");
				System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
				Reuse.StartRemoteWebDriverServer("Start_Chrome_Server.bat");
				//capabilities = DesiredCapabilities.chrome();
				Map<String, String> mobileEmulation = new HashMap<>();
				mobileEmulation.put("deviceName", Config.ChromeEmulatorName); // select
																				// the
																				// device
																				// to
																				// emulate
				Map<String, Object> chromeOptions = new HashMap<>();
				chromeOptions.put("mobileEmulation", mobileEmulation);
				capabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptions);

			} else if (BrowName.equalsIgnoreCase("opera")) {
				Reuse.log("====Selected Browser OPERA==========");
//				File file = new File(curDir + "\\Server\\chromedriver.exe");
//				System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
//				Reuse.StartRemoteWebDriverServer("Start_Opera_Server.bat");
                 
				Map<String, Object> prefs = new HashMap<>();
				prefs.put("profile.default_content_settings.popups", 0);
				ChromeOptions options = new ChromeOptions();
				// options.addArguments("start-maximized");
				options.addArguments("test-type", "start-maximized", "no-default-browser-check");
				// options.setExperimentalOption("prefs", prefs);
				//capabilities = DesiredCapabilities.chrome();
				capabilities.setCapability(ChromeOptions.CAPABILITY, options);
				// Browser Initialization - HTML
			} else if (BrowName.contentEquals("html")) {
				//capabilities = DesiredCapabilities.htmlUnit();
				// Browser Initialization - SAFARI
			} else if (BrowName.contentEquals("safari")) {
				// System.setProperty("webdriver.safari.noinstall", "true");
				Reuse.StartRemoteWebDriverServer("Start_Safari_Server.bat");
				SafariOptions options = new SafariOptions();
				// options.setUseCleanSession(true);
				//capabilities = DesiredCapabilities.safari();
				//capabilities.setCapability(SafariOptions.CAPABILITY, options);
				capabilities.setBrowserName("safari");
				capabilities.setPlatform(Platform.MAC);

			} else if (BrowName.contentEquals("android")) {
				System.out.println("Setting desired cap for andriod");
				capabilities.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
				capabilities.setCapability("device", "Android");
				capabilities.setCapability("platformName", "Android");
				capabilities.setCapability("deviceName", deviceName);
				capabilities.setCapability("automationName", "UiAutomator2");
				capabilities.setCapability(CapabilityType.BROWSER_NAME, "");

				// capabilities.setCapability("device ID", "emulator-5554");
				capabilities.setCapability(CapabilityType.BROWSER_VERSION, deviceVersion);
				capabilities.setCapability(CapabilityType.PLATFORM_NAME, platform);
				// capabilities.setCapability("app", app.getAbsolutePath());
				// //app.getAbsolutePath()
				// Here we mention the app's package name, to find the package
				// name we have to convert .apk file into java class files
				capabilities.setCapability("appPackage", android_appPackageName);
				// Here we mention the activity name, which is invoked initially
				// as app's first page.
				capabilities.setCapability("appActivity", android_appActivityName);

			} else if (BrowName.contentEquals("AndriodChrome")) {

				Reuse.log("====Selected Browser CHROME==========");

				File file = new File(curDir + "\\Server\\chromedriver.exe");
				System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
				if (Config.dedicatedBrowserInstance.toLowerCase().contains("yes")) {
					ChromeOptions options = new ChromeOptions();
					options.addArguments("disable-popup-blocking");
					// options.addArguments("--start-maximized");
					options.addArguments("--disable-extensions");
					try {
						driver = Reuse.getChrome(options);
					} catch (Exception e) {
						Reuse.log("Error while launching Chrome, Trying to launch 2nd time");
						Thread.sleep(5000);
						try {
							driver = Reuse.getChrome(options);
						} catch (Exception e1) {
							Reuse.log("Error while launching Chrome, Trying to launch 3nd time");
							Thread.sleep(5000);
							driver = Reuse.getChrome(options);
						}

					}

				}

				System.out.println("Setting desired cap for andriod");
				capabilities.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
				capabilities.setCapability("device", "Android");
				capabilities.setCapability("platformName", "Android");
				capabilities.setCapability("deviceName", deviceName);
				capabilities.setCapability("automationName", "UiAutomator2");
				capabilities.setCapability(CapabilityType.BROWSER_NAME, "");

				// capabilities.setCapability("device ID", "emulator-5554");
				capabilities.setCapability(CapabilityType.BROWSER_VERSION, deviceVersion);
				capabilities.setCapability(CapabilityType.PLATFORM_NAME, platform);
				// capabilities.setCapability("app", app.getAbsolutePath());
				// //app.getAbsolutePath()
				// Here we mention the app's package name, to find the package
				// name we have to convert .apk file into java class files
				capabilities.setCapability("appPackage", android_appPackageName);
				// Here we mention the activity name, which is invoked initially
				// as app's first page.
				capabilities.setCapability("appActivity", android_appActivityName);

			} else if (BrowName.contentEquals("ios")) {
				Reuse.log("IOS browser not implemented");
			} else if (BrowName.contentEquals("API-TESTING")) {
				Reuse.log("API TESTING is initiated");
			} else if (BrowName.equalsIgnoreCase("Edge")) {
				Reuse.log("Edge browser is initiated");

				if (Config.dedicatedBrowserInstance.toLowerCase().contains("yes")) {
					EdgeOptions options = new EdgeOptions();
					options.setAcceptInsecureCerts(true);
					
					if (Config.headLessMode.equalsIgnoreCase("Yes")) {
						// options.addArguments("--window-size=1920,1080");
						//options.addArguments("start-maximized");
						options.addArguments("--headless");
						 if (Config.wealthRun) {
							 options.addArguments("--window-size=1360,600");
						 }
						 else {
							 options.addArguments("--window-size=1920,1080");
						 }
						
						System.out.println("background");

						// options.addArguments("no-sandbox");
					}

					options.addArguments("disable-popup-blocking");
					// options.addArguments("--start-maximized");
					options.addArguments("--disable-extensions");
					options.addArguments("--remote-allow-origins=*");
				try {

//					EdgeOptions edgeOptions = new EdgeOptions();
//					edgeOptions.setBinary("C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe");
//					edgeOptions.setExperimentalOption("useAutomationExtension", false);
//					edgeOptions.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
					driver=new EdgeDriver(options);
					driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Demo1.TIME_OUT));
					driver.manage().window().maximize();
				} catch (Exception e) {
					System.out.println("Error on launching Edge::" + Throwables.getStackTraceAsString(e));

				}
			}
			}

			else {
				logger.warn(
						"INFO: Provided browser Option is not available or invalid, hence Launched the default browser - Firefox");
				//capabilities = DesiredCapabilities.firefox();
			}
			Reuse.log("");
			logger.info("INFO: Selected browser: " + BrowName);
			Reuse.log("INFO: Selected browser: " + BrowName);
			if (!BrowName.contentEquals("android") || BrowName.contentEquals("ios")) {

				if (Config.dedicatedBrowserInstance.toLowerCase().contains("no")
						& !BrowName.contentEquals("iexplore")) {
					if (driver == null || !(driver instanceof WebDriver)) {
						driver = null;
						driver = new RemoteWebDriver(url, capabilities);
						driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Demo1.TIME_OUT));
						driver.manage().window().maximize();
						// driver.get(Config.appURL);
					}

				}

			} else {

				if (Config.dedicatedBrowserInstance.toLowerCase().contains("no")) {
					System.out.println("NO Dedicated Browser Instance ");
					driver1 = new AndroidDriver(url, capabilities);
					driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(TIME_OUT));
					driver1.manage().window().maximize();
				} else {
					System.out.println("Andriod steps");
					driver1 = new AndroidDriver(url, capabilities);

				}

			}
			// Console Information
			Reuse.log("Default wait time: " + TIME_OUT + " SECONDS");
			Reuse.log("Browser " + BrowName.toString() + " initialized");
			Reuse.log("Launched in IP: " + hostIP);
			Reuse.log("");
			
			try {
				File tdFile = new File(ReportFilePath + "TestResultsReport.htm");
				testDriverReport = new BufferedWriter(new FileWriter(tdFile));
				testDriverReportHeader();
				testDriverReporBodyHeader();
				File path = new File(curDir + "\\Testware\\" + Config.testware + ".xlsx");
				ZipSecureFile.setMinInflateRatio(0.0d);
				workbook = StreamingReader.builder().rowCacheSize(100) // number of rows to keep in memory
			            .bufferSize(4096) // path
			            .open(path); // InputStream or File for XLSX file (required)

				Sheet sheetTestPlan = workbook.getSheetAt(1);
				int testPlanRowCnt = sheetTestPlan.getLastRowNum();
				Reuse.log("TestPlan: " + testPlanRowCnt);
				Sheet sheetTestScritp =workbook.getSheetAt(2);
				int testScriptRowCnt = sheetTestScritp.getLastRowNum();
				Reuse.log("TestScript: " + testScriptRowCnt);

				// ADDED FOR WEALTH
				if (Config.wealthRun) {
					Reflection.execute("AppLib." + "Tokenfetch", "ExecuteComponent");
					Reflection.execute("AppLib." + "Createexcel", "ExecuteComponent");
				}
				
				List<Row> testplancount = new ArrayList<>();
				for (Row row : sheetTestPlan) {
					testplancount.add(row);
				}
				
				List<Row> testscriptcount = new ArrayList<>();
				for (Row row : sheetTestScritp) {
					testscriptcount.add(row);
				}

				if (!Config.runPriority.equalsIgnoreCase("YES")) {

					breakTestLoop: for (int i = 1; i < testplancount.size(); i++) {
						
						try {
							if(testplancount.get(i).getCell(0)==null ||
									testplancount.get(i).getCell(0).getStringCellValue().isEmpty()
									|| testplancount.get(i).getCell(0).getStringCellValue().length()==0) 
								break;
							gbCurrTestCaseName = testplancount.get(i).getCell(0).getStringCellValue();
							gbFunIndexing = testplancount.get(i).getCell(1).getStringCellValue();
							gbCurrTestCaseDesc = testplancount.get(i).getCell(2).getStringCellValue();
							gbComplexity = testplancount.get(i).getCell(3).getStringCellValue();
							
							try {

								for (int k = 0; k < testplancount.get(0).getLastCellNum(); k++) {
									if (testplancount.get(0).getCell(k).getStringCellValue().trim()
											.equalsIgnoreCase("ReportGroup")) {
										strVerticalName = testplancount.get(i).getCell(k).getStringCellValue();
										System.out.println("XX=====XX Vertical Name:::" + strVerticalName);
										break;
									}
								}

							} catch (Exception e) {
								System.out.println("No Vertical name found");
							}
							
							try {

								for (int k = 0; k < testplancount.get(0).getLastCellNum(); k++) {
									if (testplancount.get(0).getCell(k).getStringCellValue().trim()
											.equalsIgnoreCase("Environment")) {
										envName = testplancount.get(i).getCell(k).getStringCellValue();
										System.out.println("Environment::" + envName);
										break;
									}
								}

							} catch (Exception e) {
								// e.printStackTrace();
								System.out.println("No Environment name inputtd, so it is BROWSER test by default");
								envName="BROWSER";
							}


							if (Config.wealthRun) {
								if (!(wealthTestCaseList.toString().contains(gbCurrTestCaseName))
										&& (!(gbCurrTestCaseName.contains("Wait")))) {
									wealthTestCaseList.add(gbCurrTestCaseName.trim());
								}
							}

							Reuse.log("xx==xx==xx==xx==xx==xx==xx==xx==xx==xx==xx==xx");
							Reuse.log("Current Testcase executing: " + gbCurrTestCaseName);
							Reuse.log("xx==xx==xx==xx==xx==xx==xx==xx==xx==xx==xx==xx");
							int failedTCSCounter = 1;
							testScriptloop:
							for (int j = 1; j <= testscriptcount.size(); j++) {
								testScriptRowloop: if (testscriptcount.get(j).getCell(2).getStringCellValue()
										.equalsIgnoreCase(gbCurrTestCaseName)) {
									
									// initialize the start time variable
									testStepStartTime = "";

									StartTestCaseReport();
									if (Config.dedicatedBrowserInstance.toLowerCase().contains("yes")) {
										Reuse.closeAllWindowAndLaunch();
									}
									int noOfCells = testscriptcount.get(j).getLastCellNum();

									boolean testCaseExecutionStatus = true;
									for (int k = 3; k < noOfCells; k++) {
										if ((testscriptcount.get(j).getCell(k) == null) || testscriptcount.get(j).getCell(k).getStringCellValue().isEmpty())
											break;
										component = testscriptcount.get(j).getCell(k).getStringCellValue();
										try {
											Nextcomponent = testscriptcount.get(j).getCell(k + 2)
													.getStringCellValue();

											String tempNextComp = testscriptcount.get(j).getCell(k + 4)
													.getStringCellValue();
											Nextcomponent = Nextcomponent + tempNextComp;

										} catch (Exception c) {
											Nextcomponent = "";
										}

										k = k + 1;
										String parametersList = "";
										arrParameters = null;
										if (testscriptcount.get(j).getCell(k) != null && !testscriptcount.get(j)
												.getCell(k).getStringCellValue().isEmpty()) {
											parametersList = testscriptcount.get(j).getCell(k).getStringCellValue();

											parametersListGlobalRef = parametersList;


											// this is to add testcaseid and
											// teststepno as parameter for
											// ExecOfsUser function
											String uniqueIdentifier = null;
											if (component.trim().equals("ExecOfsUser")) {
												uniqueIdentifier = gbCurrTestCaseName + (k - 1);
												String[] param = Reuse.ProcessParameters(parametersList);
												ArrayList<String> updated = new ArrayList(Arrays.asList(param));
												updated.add(uniqueIdentifier);
												arrParameters = updated.toArray(new String[updated.size()]);
											} else {
												arrParameters = Reuse.ProcessParameters(parametersList);
											}
										}

										// added to take the starting time of
										// the function call

										if (testStepStartTime.isEmpty()) {
											testStepStartTime = UtilDate.getCurrentDatenTime("hh:mm:ss");
										}

										System.out.println("XX=====XX Current method executing: " + component);
										Reuse.log("XX=====XX Parameters: " + parametersList);
										Reuse.log("XX=====XX Current Test StepNo: " + TestStepNo);
										try {
											// This is added for uxpb team to run the js function
											// before and after of each function to capture vertical name
											// TCName and step no
											 if(Config.UXPBRun) {
												 String preScript = Config.preJSfunction + "('" + strVerticalName + "', '" + gbCurrTestCaseName + "', '" + TestStepNo + "');";
												 String postScript = Config.postJSfunction + "('" + strVerticalName + "', '" + gbCurrTestCaseName + "', '" + TestStepNo + "')";
												 boolean isFunctionExists = (boolean) ((JavascriptExecutor)Demo1.driver).executeScript("return typeof " + Config.preJSfunction + " === 'function';");
												 if((k==4 && component.trim().equals("oReportStep")) 
														 || (component.trim().equals("oLaunchURL") || component.trim().equals("WaitForExternalProcess")) ) {
													 Reflection.execute("AppLib." + component.trim(), "ExecuteComponent"); 
												 }
												 else {
													 if(isFunctionExists) {
														 try {
															 ((JavascriptExecutor)Demo1.driver).executeScript(preScript); 
														 }catch (Exception e) {
															Reuse.log(e);
														}
													 
													 }
													 Reflection.execute("AppLib." + component.trim(), "ExecuteComponent");
													 //((JavascriptExecutor)Demo1.driver).executeScript(postScript);
												 } 
											 }
											 else {
												 Reflection.execute("AppLib." + component.trim(), "ExecuteComponent");
											 }
											 

											if (Config.wealthRun) {
												Demo1.DB2flag = false;
											}
											Synchronize.defaultAjaxSync();
										} catch (Exception e) {
											gbTestCaseStatus = "Fail";
											Reuse.log(e);

										}
										if (Config.skipTestCaseCheckPoint.equalsIgnoreCase("true")) {
											if (gbTestCaseStatus.equalsIgnoreCase("Fail")) {
												Reuse.isSkipTestCase = true;
												Reuse.CloseAllChildWindows();
											}
										}
										if (gbTestCaseStatus.equalsIgnoreCase("Fail")) {

											testCaseExecutionStatus = false;
											// Added below if condition to skip
											// test run
											if (!Config.skipTestRun.equalsIgnoreCase("True")) {
												if (Config.suiteRetryCounter > 0 && Config.failedRetryCounter > 0)
													if (testCaseRetryCounter <= Config.suiteRetryCounter) {
														if (failedTCSCounter <= Config.failedRetryCounter) {
															if (!retryList.contains(gbCurrTestCaseName)) {
																testCaseRetryCounter = testCaseRetryCounter + 1;
																listretry.add(gbCurrTestCaseName);
															}
															retryList.add(gbCurrTestCaseName);
															j--;
															Reuse.isSkipTestCase = false;
															// gbCurrTestCaseName
															// =
															// gbCurrTestCaseName
															// +
															// failedTCSCounter;
															// EndTestCaseReport();
															WriteReportFooter();
															HTMLReportFile.close();
															File f = new File(currentTestFile);
															f.renameTo(new File(f.getParent() + "\\"
																	+ gbCurrTestCaseName + "_tSSAF_RETRY_"
																	+ failedTCSCounter + ".htm"));
															gbTestCaseStatus = "";
															failedTCSCounter = failedTCSCounter + 1;

															Reuse.log("xx==xx==xx==xx==xx==xx==xx==xx==xx==xx==xx==xx");
															Reuse.log("Retry -  Test Script: " + gbCurrTestCaseName);
															Reuse.log("xx==xx==xx==xx==xx==xx==xx==xx==xx==xx==xx==xx");

															testCaseExecutionStatus = true;

															break testScriptRowloop;
														} else {
															TestCaseFlag = 1;
															gbCurrTestCaseName = gbCurrTestCaseName + "_tSSAF_RETRY_1";
														}

													} else {
														if (retryList.contains(gbCurrTestCaseName)) {
															gbTestCaseStatus = "Fail";
															TestCaseFlag = 1;
															gbCurrTestCaseName = gbCurrTestCaseName + "_tSSAF_RETRY_1";
														}
													}
											}
											// Added below if condition to skip
											// test run
											else if (Config.skipTestRun.equalsIgnoreCase("True")) {
												EndTestCaseReport();
												istanbulDumpToFile(gbCurrTestCaseName);
												System.out.println(
														"Test execution stopped becuase of the skiptestRun flag");
												break breakTestLoop;

											}
										} else {
											TestCaseFlag = 0;

										}
										gbTestCaseStatus = "";

										if (!testCaseExecutionStatus) {
											if (gbCurrTestCaseName.contains("_tSSAF_RETRY_")) {
												failedTestList.add(gbCurrTestCaseName.substring(0,
														gbCurrTestCaseName.indexOf("_tSSAF_RETRY_")));
											} else {
												failedTestList.add(gbCurrTestCaseName);
											}
										}

										if (Reuse.isSkipTest) {
											Reuse.isSkipTest = false;
											EndTestCaseReport();
											istanbulDumpToFile(gbCurrTestCaseName);
											break breakTestLoop;
										} else if (Reuse.isSkipTestCase) {
											Reuse.isSkipTestCase = false;
											EndTestCaseReport();
											istanbulDumpToFile(gbCurrTestCaseName);
											break testScriptloop;
										}

									}
									EndTestCaseReport();
									istanbulDumpToFile(gbCurrTestCaseName);
									break;
								}
							}
							
						} catch (Exception x) {
							Reuse.log(Throwables.getStackTraceAsString(x));
						}

						

					}

				}
				else {

					breakTestLoop: for (int i = 1; i <= testplancount.size(); i++) {

						try {
							if (testplancount.get(i).getCell(0) == null
									|| testplancount.get(i).getCell(0).getStringCellValue().isEmpty()
									|| testplancount.get(i).getCell(0).getStringCellValue().length() == 0)
								break;

							gbCurrTestCaseName = testplancount.get(i).getCell(0).getStringCellValue();
							gbFunIndexing = testplancount.get(i).getCell(1).getStringCellValue();
							gbCurrTestCaseDesc = testplancount.get(i).getCell(2).getStringCellValue();
							gbComplexity = testplancount.get(i).getCell(3).getStringCellValue();

							try {

								for (int k = 0; k < testplancount.get(0).getLastCellNum(); k++) {
									if (testplancount.get(0).getCell(k).getStringCellValue().trim()
											.equalsIgnoreCase("PriorityTest")) {
										priorityTest = testplancount.get(i).getCell(k).getStringCellValue();
										System.out.println("XX=====XX Priority Test:::" + priorityTest);
										break;
									}
								}

							} catch (Exception e) {
								System.out.println("No Priority name found");
							}

							try {

								for (int k = 0; k < testplancount.get(0).getLastCellNum(); k++) {
									if (testplancount.get(0).getCell(k).getStringCellValue().trim()
											.equalsIgnoreCase("ReportGroup")) {
										strVerticalName = testplancount.get(i).getCell(k).getStringCellValue();
										System.out.println("XX=====XX Vertical Name:::" + strVerticalName);
										break;
									}
								}

							} catch (Exception e) {
								System.out.println("No Vertical name found");
							}

							try {

								for (int k = 0; k < testplancount.get(0).getLastCellNum(); k++) {
									if (testplancount.get(0).getCell(k).getStringCellValue().trim()
											.equalsIgnoreCase("Environment")) {
										envName = testplancount.get(i).getCell(k).getStringCellValue();
										System.out.println("Environment::" + envName);
										break;
									}
								}

							} catch (Exception e) {
								e.printStackTrace();
								System.out.println("No Environment name found");
							}


							if (Config.wealthRun) {
								if (!(wealthTestCaseList.toString().contains(gbCurrTestCaseName))
										&& (!(gbCurrTestCaseName.contains("Wait")))) {
									wealthTestCaseList.add(gbCurrTestCaseName.trim());
								}
							}

							if (priorityTest.equalsIgnoreCase("YES")) {
								Reuse.log("xx==xx==xx==xx==xx==xx==xx==xx==xx==xx==xx==xx");
								Reuse.log("Current Testcase executing: " + gbCurrTestCaseName);
								Reuse.log("xx==xx==xx==xx==xx==xx==xx==xx==xx==xx==xx==xx");
								int failedTCSCounter = 1;
								testScriptloop:

								for (int j = 1; j <= testscriptcount.size(); j++) {
									testScriptRowloop: if (testscriptcount.get(j).getCell(2).getStringCellValue()
											.equalsIgnoreCase(gbCurrTestCaseName)) {

										// initialize the start time variable
										testStepStartTime = "";

										StartTestCaseReport();
										if (Config.dedicatedBrowserInstance.toLowerCase().contains("yes")) {

											Reuse.closeAllWindowAndLaunch();
										}
										int noOfCells = testscriptcount.get(j).getLastCellNum();

										boolean testCaseExecutionStatus = true;

										for (int k = 3; k < noOfCells; k++) {
											if ((testscriptcount.get(j).getCell(k) == null) || testscriptcount.get(j).getCell(k).getStringCellValue().isEmpty())
												break;
											component = testscriptcount.get(j).getCell(k).getStringCellValue();
											try {
												Nextcomponent = testscriptcount.get(j).getCell(k + 2)
														.getStringCellValue();

												String tempNextComp = testscriptcount.get(j).getCell(k + 4)
														.getStringCellValue();
												Nextcomponent = Nextcomponent + tempNextComp;

											} catch (Exception c) {
												Nextcomponent = "";
											}

											k = k + 1;
											String parametersList = "";
											arrParameters = null;
											if (testscriptcount.get(j).getCell(k) != null && !testscriptcount
													.get(j).getCell(k).getStringCellValue().isEmpty()) {
												parametersList = testscriptcount.get(j).getCell(k)
														.getStringCellValue();

												parametersListGlobalRef = parametersList;

												// this is to add testcaseid and
												// teststepno as parameter for
												// ExecOfsUser function
												String uniqueIdentifier = null;
												if (component.trim().equals("ExecOfsUser")) {
													uniqueIdentifier = gbCurrTestCaseName + (k - 1);
													String[] param = Reuse.ProcessParameters(parametersList);
													ArrayList<String> updated = new ArrayList(Arrays.asList(param));
													updated.add(uniqueIdentifier);
													arrParameters = updated.toArray(new String[updated.size()]);
												} else {
													arrParameters = Reuse.ProcessParameters(parametersList);
												}
											}

											// added to take the starting time
											// of the function call

											if (testStepStartTime.isEmpty()) {
												testStepStartTime = UtilDate.getCurrentDatenTime("hh:mm:ss");
											}

											System.out.println("XX=====XX Current method executing: " + component);
											Reuse.log("XX=====XX Parameters: " + parametersList);
											Reuse.log("XX=====XX Current Test StepNo: " + TestStepNo);
											try {
												
												// This is added for uxpb team to run the js function
												// before and after of each function to capture vertical name
												// TCName and step no
												 if(Config.UXPBRun) {
													 String preScript = Config.preJSfunction + "('" + strVerticalName + "', '" + gbCurrTestCaseName + "', '" + TestStepNo + "');";
													 String postScript = Config.postJSfunction + "('" + strVerticalName + "', '" + gbCurrTestCaseName + "', '" + TestStepNo + "')";
													 boolean isFunctionExists = (boolean) ((JavascriptExecutor)Demo1.driver).executeScript("return typeof " + Config.preJSfunction + " === 'function';");
													 if((k==4 && component.trim().equals("oReportStep")) 
															 || (component.trim().equals("oLaunchURL") || component.trim().equals("WaitForExternalProcess")) ) {
														 Reflection.execute("AppLib." + component.trim(), "ExecuteComponent"); 
													 }
													 else {
														 if(isFunctionExists) {
															 try {
																	((JavascriptExecutor)Demo1.driver).executeScript(preScript);
																}
																catch (Exception e) {
																	Reuse.log(e);
																}
														 }
														 Reflection.execute("AppLib." + component.trim(), "ExecuteComponent");
														// ((JavascriptExecutor)Demo1.driver).executeScript(postScript);
													 } 
												 }
												 else {
													 Reflection.execute("AppLib." + component.trim(), "ExecuteComponent");
												 }

												

												if (Config.wealthRun) {
													Demo1.DB2flag = false;
												}
												Synchronize.defaultAjaxSync();
											} catch (Exception e) {
												gbTestCaseStatus = "Fail";
												Reuse.log(e);

											}
											if (Config.skipTestCaseCheckPoint.equalsIgnoreCase("true")) {
												if (gbTestCaseStatus.equalsIgnoreCase("Fail")) {
													Reuse.isSkipTestCase = true;
													Reuse.CloseAllChildWindows();
												}
											}
											if (gbTestCaseStatus.equalsIgnoreCase("Fail")) {


												testCaseExecutionStatus = false;
												// Added below if condition to
												// skip test run
												if (!Config.skipTestRun.equalsIgnoreCase("True")) {
													if (Config.suiteRetryCounter > 0 && Config.failedRetryCounter > 0)
														if (testCaseRetryCounter <= Config.suiteRetryCounter) {
															if (failedTCSCounter <= Config.failedRetryCounter) {
																if (!retryList.contains(gbCurrTestCaseName)) {
																	testCaseRetryCounter = testCaseRetryCounter + 1;
																	listretry.add(gbCurrTestCaseName);
																}
																retryList.add(gbCurrTestCaseName);
																j--;
																Reuse.isSkipTestCase = false;
																// gbCurrTestCaseName
																// =
																// gbCurrTestCaseName
																// +
																// failedTCSCounter;
																// EndTestCaseReport();
																WriteReportFooter();
																HTMLReportFile.close();
																File f = new File(currentTestFile);
																f.renameTo(new File(f.getParent() + "\\"
																		+ gbCurrTestCaseName + "_tSSAF_RETRY_"
																		+ failedTCSCounter + ".htm"));
																gbTestCaseStatus = "";
																failedTCSCounter = failedTCSCounter + 1;

																Reuse.log(
																		"xx==xx==xx==xx==xx==xx==xx==xx==xx==xx==xx==xx");
																Reuse.log(
																		"Retry -  Test Script: " + gbCurrTestCaseName);
																Reuse.log(
																		"xx==xx==xx==xx==xx==xx==xx==xx==xx==xx==xx==xx");

																testCaseExecutionStatus = true;

																break testScriptRowloop;
															} else {
																TestCaseFlag = 1;
																gbCurrTestCaseName = gbCurrTestCaseName
																		+ "_tSSAF_RETRY_1";
															}

														} else {
															if (retryList.contains(gbCurrTestCaseName)) {
																gbTestCaseStatus = "Fail";
																TestCaseFlag = 1;
																gbCurrTestCaseName = gbCurrTestCaseName
																		+ "_tSSAF_RETRY_1";
															}
														}
												}
												// Added below if condition to
												// skip test run
												else if (Config.skipTestRun.equalsIgnoreCase("True")) {
													EndTestCaseReport();
													istanbulDumpToFile(gbCurrTestCaseName);
													System.out.println(
															"Test execution stopped becuase of the skiptestRun flag");
													break breakTestLoop;

												}
											} else {
												TestCaseFlag = 0;

												

											}
											gbTestCaseStatus = "";

											if (!testCaseExecutionStatus) {
												if (gbCurrTestCaseName.contains("_tSSAF_RETRY_")) {
													failedTestList.add(gbCurrTestCaseName.substring(0,
															gbCurrTestCaseName.indexOf("_tSSAF_RETRY_")));
												} else {
													failedTestList.add(gbCurrTestCaseName);
												}
											}

											if (Reuse.isSkipTest) {
												Reuse.isSkipTest = false;
												EndTestCaseReport();
												istanbulDumpToFile(gbCurrTestCaseName);
												break breakTestLoop;
											} else if (Reuse.isSkipTestCase) {
												Reuse.isSkipTestCase = false;
												EndTestCaseReport();
												istanbulDumpToFile(gbCurrTestCaseName);
												break testScriptloop;
											}

										}
										EndTestCaseReport();
										istanbulDumpToFile(gbCurrTestCaseName);
										break;
									}
								}

							}
						} catch (Exception x) {
							Reuse.log(Throwables.getStackTraceAsString(x));
						}
					}
				}
				// System.exit(0);
				CloseReporter();

				
				tdFile = null;
				path = null;
			} catch (Exception e) {
				CloseReporter();
				logger.error("Error while executing the method <b>" + component + "</b> in " + gbCurrTestCaseName
						+ " test case. Actual error: " + e);
				// TestExitCode(0, 1);
				exitCodeNonZero = true;
				Reuse.log(e);
				e.printStackTrace();
			}

		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
		}
		finally {
			try {
				workbook.close();
			} catch (IOException e) {
			}
		}
	}

	public static void istanbulDumpToFile(String testCase) throws IOException {

		try {

			if (!Config.istanbulDumpPath.isEmpty()) {

				File f1 = new File(Config.istanbulDumpPath);
				if (f1.exists()) {

				} else {
					f1.mkdir();
				}

				JavascriptExecutor js = (JavascriptExecutor) driver;

				// String coverageData =
				// (String)js.executeScript("alert(\"Hi\");");
				System.out.println("Going to Call return Coverage");

				Object str = js.executeScript("return window.__coverage__;");

				GsonBuilder builder = new GsonBuilder();
				Gson gson = builder.create();

				String coverage = gson.toJson(str);
				System.out.println(coverage);
				Files.write(Paths.get(Config.istanbulDumpPath + File.separator + testCase + ".json"),
						coverage.getBytes());

			}
		} catch (Exception e) {
			// e.printStackTrace();
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
		}

	}

	private static void writeExecuteStatusToFile(String executionStatus) {
		// Added to write the status of the current testcase execution
		File resultFile = new File(System.getProperty("user.dir") + File.separator + "ExecutionResult.txt");
		BufferedWriter writer;
		try {
			writer = new BufferedWriter(new FileWriter(resultFile));
			writer.write(executionStatus);
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
			logger.error("Error while writing the Execution Status in ExecutionResult.txt file : " + e);
		}
	}

	public void testDriverReportHeader() {
		try {
			testDriverReport.write("<html>\n");
			testDriverReport.write("<head>\n");
			testDriverReport.write("<title>Regression Report</title>\n");
			testDriverReport.write("</head>\n");
			testDriverReport.write("<body>\n");
			testDriverReport.write(
					"<table BORDER=\"3\" BORDERCOLOR=\"#000000\" BGCOLOR=\"#33ADFF\" CELLPADDING=\"1\" CELLSPACING=\"1\" WIDTH=\"80%\" VALIGN=\"MIDDLE\" ALIGN=\"CENTER\">\n");
			testDriverReport.write("<thead>\n");
			testDriverReport.write("<tr>\n");
			testDriverReport.write(
					"<th><font face=\"Verdana\" size=\"8\">tSSAF </font><BR><BR><font face=\"Verdana\" size=\"6\">Test execution status</font><br><br><font face=\"Verdana\" size=\"4\">As on "
							+ Reuse.dateFormat("dd-MM-yyyy") + "</font></th>\n");
			testDriverReport.write("</tr>\n");
			testDriverReport.write("</thead>\n");
			testDriverReport.write("</table>\n");
			testDriverReport.write("<br>\n");
		} catch (Exception e) {
			Reuse.log(e);
			logger.error("testDriverReportHeader" + e);
		}
	}

	public void testDriverReporFooter() {
		try {
			testDriverReport.write("</tbody>\n");
			testDriverReport.write("</table>\n");
			testDriverReport.write("<br>\n");
			testDriverReport.write(
					"<table BORDER=\"3\" BORDERCOLOR=\"#000000\" CELLPADDING=\"0\" CELLSPACING=\"0\" VALIGN=\"MIDDLE\" ALIGN=\"CENTER\" width=350px height=180px>\n");
			testDriverReport.write("<tr>\n");
			testDriverReport.write(
					"<td colspan=2 ALIGN=\"CENTER\" BGCOLOR=\"#33ADFF\"><font size=\"5\" face=\"Verdana\"><b>Execution Time</b></font></td>\n");
			testDriverReport.write("</tr>\n");
			testDriverReport.write("<tr ALIGN=\"CENTER\" BGCOLOR=\"#b0c4de\">\n");
			testDriverReport.write("<td><font size=\"3\" face=\"Verdana\"><b>Start Time</b></font></td>\n");
			testDriverReport
					.write("<td><font size=\"3\" face=\"Verdana\"><b>" + commanTextExeStartTime + "</b></font></td>\n");
			testDriverReport.write("</tr>\n");
			testDriverReport.write("<tr ALIGN=\"CENTER\" BGCOLOR=\"#b0c4de\">\n");
			testDriverReport.write("<td><font size=\"3\" face=\"Verdana\"><b>End Time</b></font></td>\n");
			String commonExeEndTime = UtilDate.getCurrentDatenTime("dd-MM-yy HH:mm:ss");
			testDriverReport
					.write("<td><font size=\"3\" face=\"Verdana\"><b>" + commonExeEndTime + "</b></font></td>\n");
			testDriverReport.write("</tr>\n");
			testDriverReport.write("<tr ALIGN=\"CENTER\" BGCOLOR=\"#b0c4de\">\n");
			testDriverReport.write("<td><font size=\"3\" face=\"Verdana\"><b>Duration</font></td>\n");
			String commonExeDuration = UtilDate.timeDifference(commanTextExeStartTime, commonExeEndTime,
					"dd-MM-yy HH:mm:ss");
			testDriverReport
					.write("<td><font size=\"3\" face=\"Verdana\"><b>" + commonExeDuration + "</b></font></td>\n");
			testDriverReport.write("</tr>\n");
			testDriverReport.write("</table>\n");
			testDriverReport.write("</body>\n");
			testDriverReport.write("</html>\n");
			testDriverReport.close();
		} catch (Exception e) {
			Reuse.log(e);
			logger.error("testDriverReporFooter" + e);
		}
	}

	public void testDriverReporBodyChannels() {
		try {
			testDriverReport.write("<tr>\n");
			String productName = Config.productName;

			if (Config.wealthRun) {
				this.testDriverReport.write("<td ><a href=\"index_Run.htm\">" + productName + "</a></td>\n");

				this.testDriverReport.write("<td>" + CreateIndexFile.TotalTestCases + "</td>\n");
				this.testDriverReport.write("<td>" + CreateIndexFile.TotalTestCasesPass + "</td>\n");
				this.testDriverReport.write("<td>" + CreateIndexFile.TotaltestCasesFail + "</td>\n");
				this.testDriverReport.write("<td>" + 0 + "</td>\n");

				if (CreateIndexFile.TotaltestCasesFail > 0) {
					this.testDriverReport.write("<td BGCOLOR=\"#FF8080\">Failed</td>\n");
				} else {
					this.testDriverReport.write("<td BGCOLOR=\"#85E085\">Success</td>\n");
				}
			} else { // for all the other environments
				testDriverReport.write("<td ><a href=\"index_" + RunNo + ".htm\">" + productName + "</a></td>\n");
				int tdriTotalTestCases = TestCasePassCount + TestCaseFailCount + TestCaseWarningCount;
				testDriverReport.write("<td>" + tdriTotalTestCases + "</td>\n");
				testDriverReport.write("<td>" + TestCasePassCount + "</td>\n");
				testDriverReport.write("<td>" + TestCaseFailCount + "</td>\n");
				testDriverReport.write("<td>" + TestCaseWarningCount + "</td>\n");
				if (TestCaseFailCount > 0) {
					testDriverReport.write("<td BGCOLOR=\"#FF8080\">Failed</td>\n");
				} else {
					testDriverReport.write("<td BGCOLOR=\"#85E085\">Success</td>\n");
				}
			}

			testDriverReport.write("</tr>\n");
		} catch (Exception e) {
			Reuse.log(e);
			logger.error("testDriverReporBodyChannels" + e);
		}
	}

	public void testDriverReporBodyForMB() {
		int mbFaildTCCount = 0;
		try {
			if (testDriverReport == null) {
				File tdFile = new File(ReportFilePath + "TestResultsReport.htm");
				testDriverReport = new BufferedWriter(new FileWriter(tdFile));
				testDriverReportHeader();
				testDriverReporBodyHeader();
			}
			testDriverReport.write("<tr>\n");
			String folderName = getDirectoryCreatedByToday(curDir + "\\MBTest\\HTMLResults");
			testDriverReport.write("<td ><a href=..\\..\\MBTest\\HTMLResults\\" + folderName + "\\index_" + folderName
					+ ".htm>ModelBank</a></td>\n");
			String[] execSummary = testDriverReportExecSummaryMB(
					curDir + "\\MBTest\\HTMLResults\\" + folderName + "\\index_" + folderName + ".htm");
			String mbTotalTC = execSummary[1].substring(0, execSummary[1].indexOf("<"));
			String mbPassed = execSummary[2].substring(0, execSummary[2].indexOf("<"));
			String mbWarnings = execSummary[3].substring(0, execSummary[3].indexOf("<"));
			String mbFailed = execSummary[4].substring(0, execSummary[4].indexOf("<"));

			testDriverReport.write("<td>" + mbTotalTC + "</td>\n");
			testDriverReport.write("<td>" + mbPassed + "</td>\n");
			testDriverReport.write("<td>" + mbFailed + "</td>\n");
			testDriverReport.write("<td>" + mbWarnings + "</td>\n");
			mbFaildTCCount = Integer.parseInt(mbFailed);
			if (mbFaildTCCount > 0) {
				testDriverReport.write("<td BGCOLOR=\"#FF8080\">Failed</td>\n");
			} else {
				testDriverReport.write("<td BGCOLOR=\"#85E085\">Success</td>\n");
			}
			testDriverReport.write("</tr>\n");
		} catch (Exception e) {
			Reuse.log(e);
			logger.error("testDriverReporBodyForMB " + e);
		}
	}

	public String[] testDriverReportExecSummaryMB(String dirPath) {
		try {
			BufferedReader br = null;
			br = new BufferedReader(new FileReader(dirPath));
			String sCurLine;
			String[] str = null;
			while ((sCurLine = br.readLine()) != null) {
				if (sCurLine.contains("TotalTestCases")) {
					str = sCurLine.split("<td class=\"pfind\" width=50px>");
					/*
					 * String mbTotalTC=str[1].substring(0, str[1].indexOf("<")); String
					 * mbTotalPassed=str[2].substring(0, str[1].indexOf("<")); String
					 * mbTotalFailed=str[3].substring(0, str[1].indexOf("<")); String
					 * mbTotalWarnings=str[4].substring(0, str[1].indexOf("<"));
					 */
				}
			}
			br = null;
			return str;
		} catch (Exception e) {
			Reuse.log(e);
			logger.error("testDriverReportExecSummaryMB" + e);
			return null;
		}
	}

	public void testDriverReporBodyHeader() {
		try {
			testDriverReport.write(
					"<table BORDER=\"3\" BORDERCOLOR=\"#000000\" CELLPADDING=\"0\" CELLSPACING=\"0\" WIDTH=\"80%\" VALIGN=\"MIDDLE\" ALIGN=\"CENTER\">\n");
			testDriverReport.write("<thead>\n");
			testDriverReport.write("<tr BGCOLOR=\"#33ADFF\">\n");
			testDriverReport.write("<th WIDTH=\"30%\"  ALIGN=\"CENTER\">Product</th>\n");
			testDriverReport.write("<th WIDTH=\"15%\"  ALIGN=\"CENTER\">Total TC's</th>\n");
			testDriverReport.write("<th WIDTH=\"15%\"  ALIGN=\"CENTER\">Passed</th>\n");
			testDriverReport.write("<th WIDTH=\"15%\"  ALIGN=\"CENTER\">Failed</th>\n");
			testDriverReport.write("<th WIDTH=\"15%\"  ALIGN=\"CENTER\">Warnings</th>\n");
			testDriverReport.write("<th WIDTH=\"15%\"  ALIGN=\"CENTER\">Status</th>	\n");
			testDriverReport.write("</tr>\n");
			testDriverReport.write("</thead>\n");
			testDriverReport.write("<tbody ALIGN=\"CENTER\" BGCOLOR=\"#b0c4de\">\n");
		} catch (Exception e) {
			Reuse.log(e);
			logger.error("testDriverReporBodyHeader" + e);
		}
	}

	public String getDirectoryCreatedByToday(String dirPath) {
		String fileName = "";
		try {
			final File directory = new File(dirPath);
			/*
			 * Date date = new Date(); SimpleDateFormat sdf = new
			 * SimpleDateFormat("yyyy-MM-dd HH_mm_ss"); String todaysDate=sdf.format(date);
			 */

			File files[] = directory.listFiles();
			for (File f : files) {
				// Reuse.log(f.getName() + " " + sdf.format(new
				// Date(f.lastModified())));
				/*
				 * if(todaysDate.compareTo(sdf.format(new Date(f.lastModified())))==0 &&
				 * f.getName().startsWith("Run_")){ fileName= f.getName(); }
				 */
				if (!f.getName().equalsIgnoreCase("ReportInfo")) {
					fileName = f.getName();
				}
			}
			return fileName;
		} catch (Exception e) {
			Reuse.log(e);
			logger.error("getDirectoryCreatedByToday" + e);
			return fileName;

		}
	}

	@After
	public void tearDown() throws Exception {

		try {
			FileWriter writer = new FileWriter(gbResultFolderName + "/Duration.csv");
			for (String str : listCSV) {
				writer.write(str);
				writer.write("\r\n ");
			}
			writer.close();

		} catch (Exception e) {
			logger.error("Error while writing Duration.csv file:::" + e.getMessage());
		}

		try {
			FileWriter writer = new FileWriter(gbResultFolderName + "/Retry.csv");
			for (String str : listretry) {
				writer.write(str);
				writer.write("\r\n ");
			}
			writer.close();

		} catch (Exception e) {
			logger.error("Error while writing Retry.csv file:::" + e.getMessage());
		}
		try {
			FileWriter writer = new FileWriter(gbResultFolderName + "/Summary.xml");

			if (Config.wealthRun) {
				writer.write("<failures>" + CreateIndexFile.TotaltestCasesFail + "</failures>");
			} else {
				writer.write("<failures>" + TestCaseFailCount + "</failures>");
			}

			writer.write("\r\n ");

			writer.close();

		} catch (Exception e) {
			logger.error("Error while writing Summary.xml file:::" + e.getMessage());
		}

		// writing failed script details to flat file - MAY2021
		if (Config.replayOfScripts) {
			writeFailedTestCasesForReplay();
		}

		/*
		 * try{
		 *
		 * File path = new File(curDir + "\\Testware\\" + Config.testware + " .xlsx");
		 * FileInputStream fis = new FileInputStream(path); XSSFWorkbook wb = new
		 * XSSFWorkbook(fis); XSSFSheet sheetTestPlan = wb.getSheetAt(1); int
		 * testPlanRowCnt = sheetTestPlan.getLastRowNum();
		 *
		 *
		 * for (int i = 1; i <= testPlanRowCnt; i++) {
		 *
		 * if (sheetTestPlan.getRow(i).getCell(0) == null ||
		 * sheetTestPlan.getRow(i).getCell(0).getStringCellValue().isEmpty() ||
		 * sheetTestPlan.getRow(i).getCell(0).getStringCellValue().length() == 0) break;
		 *
		 *
		 * gbCurrTestCaseName = sheetTestPlan.getRow(i).getCell(0).getStringCellValue();
		 *
		 *
		 * if(!failedTestList.contains(gbCurrTestCaseName)){ sheetTestPlan.shiftRows(i +
		 * 1, sheetTestPlan.getLastRowNum(), -1); i--; }
		 *
		 *
		 * }
		 *
		 *
		 * File outWB = new File(curDir + "\\TestData\\FailedTestware.xlsx");
		 * OutputStream out = new FileOutputStream(outWB); wb.write(out); out.flush();
		 * out.close();
		 *
		 *
		 * } catch (Exception e) { System.out.println(
		 * "Copying failed test case failed");
		 *
		 * }
		 */

		// nyc report –-reporter=html

		// CloseReporter();
		if (isMBTestRun) {
			if (Reuse.WaitUntilFileCreated(curDir + "\\MBTest\\TestLogs\\runCompleted.txt", 5)) {
				testDriverReporBody();
				testDriverReporFooter();
				// CloseReporter();
				// Close OR workBoRUN COMPLETEDok
				if (Reuse.fileForOR != null) {
					Reuse.fileForOR.close();
					Reuse.workbookForOR.close();
				}
				if (isChannelsTestRun) {
					// Console messages
					Reuse.log("");
					Reuse.log(" ... Please find the results under HTML Results folder");
					// Quit driver
					driver.quit();
					// Stop server
					Reuse.StopRemoteWebDriverServer("Shutdown_Server.bat");
					Reuse.oWait(2);
				}
			}
		} else {
			testDriverReporBody();
			testDriverReporFooter();
			// CloseReporter();
			// Close OR workBook
			if (Reuse.fileForOR != null) {
				Reuse.fileForOR.close();
				Reuse.workbookForOR.close();
			}
			if (isChannelsTestRun) {
				// Console messages
				Reuse.log("");
				Reuse.log("RUN COMPLETED ... Please find the results under HTML Results folder");
				// FlogForRunComplition();
				if (BrowName.contentEquals("andriod"))
					driver1.quit();
				if (!BrowName.contentEquals("API-TESTING") && !BrowName.contentEquals("android")
						&& !Demo1.envName.equalsIgnoreCase("API"))
					// Quit driver
					driver.quit();
				// Stop server
				Reuse.StopRemoteWebDriverServer("Shutdown_Server.bat");
				Reuse.oWait(2);
				// ExitCodeBasedOnTestResults();
			}
		}

	}

	public void TestExitCode(int actual, int expected) {
		try {
			org.junit.Assert.assertEquals(actual, expected);
		} catch (AssertionError e) {
			Reuse.log(e);
		}
	}

	public void testDriverReporBody() {
		try {
			if (Config.runMBTest.equalsIgnoreCase("true") && Config.runChannelsTest.equalsIgnoreCase("true")) {
				testDriverReporBodyForMB();
				testDriverReporBodyChannels();
			} else if (Config.runMBTest.equalsIgnoreCase("false") && Config.runChannelsTest.equalsIgnoreCase("true")) {
				testDriverReporBodyChannels();
			} else if (Config.runMBTest.equalsIgnoreCase("true") && Config.runChannelsTest.equalsIgnoreCase("false")) {
				testDriverReporBodyForMB();
			} else {
				logger.error("testDriverReportBody - Channels/MB must be ture");
			}
		} catch (Exception e) {
			Reuse.log(e);
			logger.error("testDriverReporBody " + e);
		}
	}

	public void proBuilder(String batFilePath, String argument, String statuLogFilePath) {
		try {
			// The batch file to execute
			final File batchFile = new File(batFilePath);

			// The output file. All activity is written to this file
			final File outputFile = new File(statuLogFilePath);

			// The argument to the batch file.
			// final String argument = "0";

			// Create the process
			final ProcessBuilder processBuilder = new ProcessBuilder(batchFile.getAbsolutePath(), argument);
			// Redirect any output (including error) to a file. This avoids
			// deadlocks
			// when the buffers get full.
			processBuilder.redirectErrorStream(true);
			processBuilder.redirectOutput(outputFile);

			// Add a new environment variable
			// processBuilder.environment().put("message", "Example of process
			// builder");

			// Set the working directory. The batch file will run as if you are
			// in this
			// directory.
			processBuilder.directory(new File(curDir + "\\Server"));

			// Start the process and wait for it to finish.
			final Process process = processBuilder.start();
			final int exitStatus = process.waitFor();
			// Reuse.log("Test finished with status: " + exitStatus);
		} catch (Exception e) {
			Reuse.log(e);
			Reuse.log(e);
		}
	}

	public void FlogForRunComplition() throws IOException, InterruptedException {
		File file = null;
		FileWriter fw = null;
		BufferedWriter bw = null;
		try {
			file = new File(curDir + "\\logs\\runStatus.log");
			if (file.exists()) {
				file.delete();
			}
			file.createNewFile();
			fw = new FileWriter(file.getAbsoluteFile());
			bw = new BufferedWriter(fw);
			if (TestCaseFailCount > 0) {
				bw.write("1");
				// Runtime.getRuntime().exec("cmd /c run_STATUS_TEST.bat",null,
				// new File("D:\\Temenos\\Development"));
				Process p = Runtime.getRuntime().exec("cmd /c D:\\Temenos\\Development\\run_STATUS_TEST.bat 1");
				p.waitFor();
				p = null;

			} else {
				bw.write("0");
				Process p = Runtime.getRuntime().exec("cmd /c D:\\Temenos\\Development\\run_STATUS_TEST.bat 0");
				p.waitFor();
				p = null;
			}
			bw.close();

		} catch (IOException e) {
			Reuse.log(e);
			Reuse.log("Problem with FlogForRunComplition method. for more info: " + e.getMessage());
		} finally {
			file = null;
			fw.close();
		}
	}

	public void InitializeVariables() {

		try {
			commanTextExeStartTime = UtilDate.getCurrentDatenTime("dd-MM-yy HH:mm:ss");
			// Current dir
			curDir = System.getProperty("user.dir");

			// Logs Initialization - Log4j
			logger = Logger.getLogger(this.getClass().getName());
			// LogManager.getLogger(this.getClass().getName());

			// configure log4j properties file
			PropertyConfigurator.configure(curDir + "\\Config\\log4j.properties");

			// Call the function to read all properties and store in appropriate
			// variables
			Config.ReadProFile();
			// RunNo = JOptionPane.showInputDialog("Please enter Run No",
			// "EnterHere");
			BrowserInfo = Config.BrowserInfo;
			ServerInfo = Config.Server;
			RunNo = Config.RunNo;
			resWithDateAndTime = Config.resultsWithDateAndTime;
			BrowName = Config.BrowName;
			deviceName = Config.deviceName;
			deviceVersion = Config.deviceVersion;
			platform = Config.platform;
			android_appPackageName = Config.android_appPackageName;
			android_appActivityName = Config.android_appActivityName;
			hostIP = Config.hostIP;

			// Machine name
			gbHostName = getHostName();
			// Machine user name (logged in user)
			gbUserName = System.getProperty("user.name");

			// Result folder name and path
			if (resWithDateAndTime.equalsIgnoreCase("true")) {
				gbResultFolderName = curDir + "\\HTMLResults\\" + RunNo + "_" + Reuse.dateFormat("yyyy_MM_dd_HH_mm_ss");
			} else {
				gbResultFolderName = curDir + "\\HTMLResults\\" + RunNo;
			}

			gbApplicationName = Config.gbApplicationName;
			TIME_OUT = Config.TIME_OUT;
			// Update date time
			Date();
			curDate();
			// AutoItX Initialization
			File fileAX;
			if (System.getProperty("os.arch").contains("x86")) {
				fileAX = new File(curDir + "\\dlls", "jacob-x86.dll"); // path
																		// of
																		// the
																		// jacob.dll
																		// - 32
																		// bit
																		// os
				System.setProperty(LibraryLoader.JACOB_DLL_PATH, fileAX.getAbsolutePath());
				// register autoIT.dll
				File file = new File(curDir + "\\dlls\\AutoItX3.dll");
				System.setProperty("java.library.path", file.getAbsolutePath());
				Runtime.getRuntime().exec("regsvr32.exe /s " + curDir + "" + "\\dlls\\AutoItX3.dll");
			} else {
				fileAX = new File(curDir + "\\dlls", "jacob-x64.dll"); // path
																		// for
																		// jacob.dll
																		// - 64
																		// bit
																		// os
				System.setProperty(LibraryLoader.JACOB_DLL_PATH, fileAX.getAbsolutePath());
				// register autoIT.dll
				// File file =new File(curDir+"\\dlls\\AutoItX3.dll");
				// System.setProperty("java.library.path",
				// file.getAbsolutePath());
				Runtime.getRuntime()
						.exec("regsvr32.exe /s runas /user:Administrator " + curDir + "" + "\\dlls\\AutoItX3_x64.dll");
			}

			autoItX = new AutoItX();
			// Date();
			// curDate();
		} catch (Exception e) {
			Reuse.log(e);
			logger.error("Error in class: " + e.getClass().getName());
			logger.error(e);
		}
	}

	public void FWPrioritize() {
		boolean isMBTestRun = false;
		boolean isChannelsTestRun = false;
		int mBPriority = 0;
		int channelsPriority = 0;
		try {
			if (Config.runMBTest.equalsIgnoreCase("true")) {
				isMBTestRun = true;
				mBPriority = Config.mbTestPriority;
			}
			if (Config.runChannelsTest.equalsIgnoreCase("true")) {
				isChannelsTestRun = true;
				channelsPriority = Config.channelsTestPriority;
			}
			if (isMBTestRun && isChannelsTestRun) {

				if (mBPriority != channelsPriority && mBPriority < channelsPriority) {
					// MB First
					// Channels Next
				} else if (mBPriority != channelsPriority && mBPriority > channelsPriority) {
					// Channels First
					// MB Next
				} else if (mBPriority == channelsPriority) {
					// Run Parallel
				}
			}
		} catch (Exception e) {
			Reuse.log(e);
			logger.error("Problem in FWPrioritize. " + e);
		}
	}

	public String getHostName() throws UnknownHostException {
		InetAddress addr = InetAddress.getLocalHost();
		hostname = addr.getHostName();
		return hostname;
	}

	public void Date() {
		Calendar cal = new GregorianCalendar();
		int month = cal.get(Calendar.MONTH);
		int year = cal.get(Calendar.YEAR);
		int day = cal.get(Calendar.DAY_OF_MONTH);
		Date = day + "/" + (month + 1) + "/" + year;
	}

	public void ScreenCapture() {
		WebDriver augmentedDriver = new Augmenter().augment(driver);
		File screenshot = ((TakesScreenshot) augmentedDriver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(screenshot, new File("D:\\Ashok\\Screenshots\\webdriverapi.png"));
		} catch (IOException e) {
			Reuse.log(e);
			// TODO Auto-generated catch block
			logger.error("error in ScreenCapture method " + e.getMessage());
		}
	}

	public void curDate() {
		Date now = new Date();
		curDate = now.toString();
	}

	public void InitializeReporter() throws IOException {
		File dir = new File(gbResultFolderName);
		dir.delete();
		dir.mkdir();
		ReportFilePath = gbResultFolderName;
		ReportFilePath = ReportFilePath + "\\";
		HTMLIndexFile = new BufferedWriter(new FileWriter(ReportFilePath + "index_" + RunNo + ".htm"));
		WriteIndexHeader();
		TestCasePassCount = 0;
		TestCaseFailCount = 0;
		TestCaseWarningCount = 0;
		TestCaseNo = 1;

		// Note the batch execution start time
		// BatchStartTime = UtilDate.getCurrentDatenTime("H:mm:ss");
	}

	public void WriteIndexHeader() throws IOException {
		// File file = new File (ReportFilePath+"index_"+ RunNo + ".htm");

		HTMLIndexFile.write("<html> \n");
		// HTMLIndexFile.write("");
		HTMLIndexFile.write(
				"\n<head><link rel=\"stylesheet\" type=\"text/css\" href=\"../ReportInfo/report_theme.css\"/></head><body>\n");
		// 'Pageheaderincludingprojecttitle&companyname
		// WriteGenericPageHeader ();

		HTMLIndexFile.write("\n");
		HTMLIndexFile.write("\n");
		HTMLIndexFile.write("\n<hr class=\"divline\">");
		// HTMLReportFile.write("<BR>");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\n<table class=\"rephead\" width=1200px><tr>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\n<td height=63px>" + gbApplicationName + "</td>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\n<td height=63px align=right><img src = ..\\ReportInfo\\images\\New-Temenos-logo.png></td>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write(" \n</tr></table><hr class=\"divline\"> <BR>\n");
		HTMLIndexFile.write("");
		// 'Testcasenameandexecutiondate&time

		HTMLIndexFile.write("\r \n<table  class=\"subhead\"  width=1200px><tr>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n\r \n<td width=400px  class=\"subhead\"align=left>TestRun</td>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n\r \n<td width=200px  class=\"subhead\">ExecutionDate</td>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n\r \n<td width=200px class=\"subhead\">Tested on</td>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n\r \n<td width=100px class=\"subhead\"align=right>Build/Release</td>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n</tr><tr>\n");
		HTMLIndexFile.write("");
		String testRun = Config.testRun;
		HTMLIndexFile.write("\r \n\r \n<td width=400px class=\"subcont\"align=left>" + testRun + "</td>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n\r \n<td width=300px class=\"subcont\">" + Date + "</td>\n");
		HTMLIndexFile.write("");
		String testedOn = Config.BrowName;
		HTMLIndexFile.write("\r \n\r \n<td width=200px class=\"subcont\">" + testedOn + "</td>\n");
		HTMLIndexFile.write("");
		String buildNo = Config.buildNo;
		HTMLIndexFile.write("\r \n\r \n<td width=100px class=\"subcont\"align=right>" + buildNo + "</td>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n</tr></table><hr class=\"divline\"><BR>\n");

		// 'Teststepstableheader

		HTMLIndexFile.write("\r \n<table width=1200 class=\"tsteps\">\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n<tr>");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n\r \n<td class=\"tshead\" width=50px>S.No</td>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n\r \n<td class=\"tshead\" width=200px>Test Case</td>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n\r \n<td class=\"tshead\" width=200px>Functionality Index</td>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n\r \n<td class=\"tshead\" width=300px>Description</td>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n\r \n<td class=\"tshead\" width=200px>Complexity</td>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n\r \n<td class=\"tshead\" width=200px>Environment / Module</td>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n\r \n<td class=\"tshead\" width=50px>Steps</td>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n\r \n<td class=\"tshead\" width=50px>Passed</td>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n\r \n<td class=\"tshead\" width=50px>Warnings</td>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n\r \n<td class=\"tshead\" width=50px>Failed</td>\n");

		// 28-jun-2019
		HTMLIndexFile.write("\r \n\r \n<td class=\"tshead\" width=50px>Duration</td>\n");
		HTMLIndexFile.write("");

		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n\r \n<td class=\"tshead\" width=50px>Status</td>\n");
		HTMLIndexFile.write("");

		/*
		 * //28-jun-2019 HTMLIndexFile.write(
		 * "\r \n\r \n<td class=\"tshead\" width=50px>Duration</td>\n");
		 * HTMLIndexFile.write("");
		 */

		HTMLIndexFile.write("\r \n</tr>");

	}

	public void WriteGenericPageHeader() throws IOException {
		HTMLIndexFile.write("");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n<hr class=\"divline\">");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n<table class=\"rephead\" width=1200px><tr>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n<td height=63px>" + gbApplicationName + "</td>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n<td height=63px align=right><img src = ..\\ReportInfo\\images\\New-Temenos-logo.png></td>\n");
		HTMLIndexFile.write("");
		HTMLIndexFile.write("\r \n</tr></table><hr class=\"divline\"> <BR>\n");
		HTMLIndexFile.write("");
	}

	public void StartTestCaseReport() throws IOException {
		currentTestFile = ReportFilePath + gbCurrTestCaseName + ".htm";
		HTMLReportFile = new BufferedWriter(new FileWriter(currentTestFile));

		// HTMLReportFile = new BufferedWriter
		// (new OutputStreamWriter(new FileOutputStream(currentTestFile)));

		TestStepNo = 1;
		WriteReportHeader();
		TestStepPassCount = 0;
		TestStepFailCount = 0;
		TestStepWarningCount = 0;

		// Reset test case error message
		// LastFailedStep = null;
		// LastWarningMessage = null;

		// Initialize step numbering variables
		Level1Value = 0;
		Level2Value = 0;
		Level3Value = 0;

		// TCStartTime = UtilDate.getLastsetTimeinmili();
		// TCStartDate =
		TCStartTime = UtilDate.getCurrentDatenTime("HH:mm:ss");
		// actStartTime=UtilDate.getFormattedTime(TCStartTime);
	}

	public void WriteReportHeader() throws IOException {
		HTMLReportFile.write("<html>");
		HTMLReportFile.write(
				"\n<head><link rel=\"stylesheet\" type=\"text/css\" href=\"../ReportInfo/report_theme.css\"></head>");
		HTMLReportFile.write("\n<body>");
		// WriteTCGenericPageHeader();
		// HTMLReportFile.write("");
		// HTMLReportFile.write("");
		HTMLReportFile.write("\r \n<hr class=\"divline\">");
		// HTMLReportFile.write("");
		HTMLReportFile.write("\r \n<table class=\"rephead\" width=1200px><tr>");
		// HTMLReportFile.write("");
		HTMLReportFile.write("\r \n<td height=63px>" + gbApplicationName + "</td>");
		// HTMLReportFile.write("");
		HTMLReportFile.write("\r \n<td height=63px align=right><img src = ..\\ReportInfo\\images\\New-Temenos-logo.png></td>");
		// HTMLReportFile.write("");
		HTMLReportFile.write("\r \n</tr></table><hr class=\"divline\"> <BR>");
		// HTMLReportFile.write("");
		// Test case name, execution date & time and user id
		// HTMLReportFile.write("");
		HTMLReportFile.write("\n<table class=\"subhead\" width=900px><tr>");
		HTMLReportFile.write("\n<td width=400px class=\"subhead\">Test Case</td>");
		HTMLReportFile.write("\n<td width=200px class=\"subhead\">Execution Date</td>");
		HTMLReportFile.write("\n<td width=200px class=\"subhead\">Executed By</td>");
		HTMLReportFile.write("\n</tr>");
		HTMLReportFile.write("\n<tr>");
		HTMLReportFile.write("\n<td width=400px class=\"subcont\">" + gbCurrTestCaseName + "</td>");
		HTMLReportFile.write(
				"\n<td width=200px class=\"subcont\">" + UtilDate.getCurrentDatenTime("dd MMMMM yyyy") + "</td>");
		HTMLReportFile.write("\n<td width=200px class=\"subcont\">" + gbUserName + "</td>");
		HTMLReportFile.write("\r </tr></table> <hr class=\"divline\"> <BR>");

		// Test case description
		HTMLReportFile.write("");
		HTMLReportFile.write("\n<table class=\"subhead\" width=900px><tr>");
		HTMLReportFile.write("\n<tr><td width=900px class=\"subhead\">Test Case Desription</td></tr>");
		HTMLReportFile.write("\n<tr><td width=900px class=\"subcont\">" + gbCurrTestCaseDesc + "</td></tr>");
		HTMLReportFile.write("\r \n</tr></table> <hr class=\"divline\"> <BR>");
		HTMLReportFile.write("\n<table width=1200px class=\"tsteps\">");
		// HTMLReportFile.write("<tr>");
		//
		HTMLReportFile.write("\n<td class=\"tshead\" width=50px>Step #</td>");
		HTMLReportFile.write("\n<td class=\"tshead\" width=155px>Step Description</td>");
		HTMLReportFile.write("\n<td class=\"tshead\" width=285px>Expected Result</td>");
		HTMLReportFile.write("\n<td class=\"tshead\" width=285px>Actual Result</td>");

		// Newly added to display the time taken by each step
		HTMLReportFile.write("\n<td class=\"tshead\" width=80px>Time Taken</td>");

		HTMLReportFile.write("\n<td class=\"tshead\" width=50px>Status</td>");
		HTMLReportFile.write("\n<td class=\"tshead\" width=50px>Screen Shot</td>");
		HTMLReportFile.write("\n</tr>");
	}

	public void WriteTCGenericPageHeader() throws IOException {
		HTMLReportFile.write("");
		HTMLReportFile.write("\r \n<hr class=\"divline\">");
		HTMLReportFile.write("\r \n<table class=\"rephead\" width=900px><tr>");
		HTMLReportFile.write("\r \n<td height=63px>" + gbApplicationName + "</td>");
		HTMLReportFile.write("\r \n<td height=63px align=right><img src = ..\\ReportInfo\\images\\New-Temenos-logo.png></td>");

		HTMLReportFile.write("\r \n</tr></table><hr class=\"divline\"> <BR>");
		HTMLReportFile.write("");
	}

	private void writeFailedTestCasesForReplay() {

		System.out.println("FAILED LIST SIZE::" + failedTestList.size());

		if (failedTestList.size() > 0) {

			String curDir = System.getProperty("user.dir");
			System.out.println("CURRENT DIR:::" + curDir);

			String testwareFolder = "";
			String threadName = (new File(curDir)).getName();

			Path path = Paths.get(curDir);

			if (path.getParent().endsWith("ParallelPipe") && path.getParent().getParent().endsWith("ParallelRun")) {
				testwareFolder = path.getParent().getParent() + File.separator + "Testwares";

				String filePath = testwareFolder + File.separator + threadName + "_FailedCases.txt";
				StringBuffer buffer = new StringBuffer();
				for (String testCase : failedTestList) {
					buffer.append(testCase + "\n");
				}

				FileWriter writer;
				try {
					writer = new FileWriter(new File(filePath));
					writer.write(buffer.toString());
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("ERROR::" + e.getStackTrace());
				}

				// writing testVariables.properties
				String destPath = testwareFolder + File.separator + threadName + "_testVariables.prperties";
				String sourcePath = System.getProperty("user.dir") + File.separator + "TestData" + File.separator
						+ "testVariables.prperties";
				String sourcePath1 = Config.TestDataFileLocation + "\\testVariables.prperties";

				try {
					if(Config.Mode.equals("LMS")) {
						FileUtils.copyFile(new File(sourcePath1), new File(destPath));
					}else {
						FileUtils.copyFile(new File(sourcePath), new File(destPath));
					}
				} catch (Exception e) {
					System.out.println("ERROR::" + e.getStackTrace());
				}

			}
			/*
			 * else { testwareFolder = path + File.separator + "TestWare"; }
			 */

		}
	}

}
