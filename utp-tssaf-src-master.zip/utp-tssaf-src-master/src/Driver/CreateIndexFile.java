package Driver;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.google.common.base.Throwables;

public class CreateIndexFile {

    public static int TestCaseCount = 0;
    public static String FunctionalityIndex;
    public static String TestCaseBrokenid;
    public static String ActualTestCaseId;
    public static String TestCaseDescription;
    public static String criticality;
    public static String DbTestCase = "flag";
    public static String NonDbTestCase;
    public static int passedsteps;
    public static int failedsteps;
    public static int warningsteps;
    public static int TotalTestCases = 0;
    public static int TotalTestCasesPass = 0;
    public static int TotaltestCasesFail = 0;
    public static int TestStepsCount = 0;
    public static String OverallStatus;
    public static int toTalSteps;
    public static String overallResult;
    public static List<String> myList = new ArrayList<>();
    public static BufferedWriter HtmlIndexFile;
    public static Document doc1;
    public static String readEcelreport[] = new String[2];
    public static Map<String, String> functionalityIndexDetailsMap = new HashMap<>();
    public static Map<String, String> criticalityDetailsMap = new HashMap<>();
    public static Map<String, String> reportGroupDetailsMap = new HashMap<>();

    private static Element executionTimeTable;
    public static LinkedHashMap<String, String> executionTimeDetails = new LinkedHashMap<>();
    private static LinkedHashMap<String, Integer> timeDetails = new LinkedHashMap<>();

    public static void main() throws Exception {
        // TODO Auto-generated method stub

        try {

            ReadExceiReport.main();
            Calendar cal = new GregorianCalendar();
            int month = cal.get(2);
            int year = cal.get(1);
            int day = cal.get(5);
            String Date = day + "/" + (month + 1) + "/" + year;

            String curDir = System.getProperty("user.dir");

            System.out.println("index_Run.htm file is about to be created.");
            /* String path = curDir + "\\HTMLResults\\RunTTITAP"; */ // commented
                                                                     // on
                                                                     // 15-APR-2020
                                                                     // -->
                                                                     // against
                                                                     // below
                                                                     // line
            String path = curDir + File.separator + "HTMLResults" + File.separator + Config.RunNo;

            /*
             * HtmlIndexFile = new BufferedWriter(new FileWriter(path +
             * "\\Con_index_RunTTITAP.htm"));
             */
            HtmlIndexFile = new BufferedWriter(new FileWriter(path + "\\index_Run.htm"));

            HtmlIndexFile.write("<html> \n");

            HtmlIndexFile.write(
                    "\n<head><link rel=\"stylesheet\" type=\"text/css\" href=\"../ReportInfo/report_theme.css\"/></head><body>\n");

            HtmlIndexFile.write("\n");
            HtmlIndexFile.write("\n");
            HtmlIndexFile.write("\n<hr class=\"divline\">");

            HtmlIndexFile.write("");
            HtmlIndexFile.write("\n<table class=\"rephead\" width=1200px><tr>\n");
            HtmlIndexFile.write("");
            HtmlIndexFile.write("\n<td height=63px>" + Config.gbApplicationName + "</td>\n");
            HtmlIndexFile.write("");
            HtmlIndexFile.write(
                    "\n<td height=63px align=right><img src = ..\\ReportInfo\\images\\New-Temenos-logo.png></td>\n");
            HtmlIndexFile.write("");
            HtmlIndexFile.write(" \n</tr></table><hr class=\"divline\"> <BR>\n");
            HtmlIndexFile.write("");

            HtmlIndexFile.write("\r \n<table  class=\"subhead\"  width=1200px><tr>\n");
            HtmlIndexFile.write("");
            HtmlIndexFile.write("\r \n\r \n<td width=400px  class=\"subhead\"align=left>TestRun</td>\n");
            HtmlIndexFile.write("");
            HtmlIndexFile.write("\r \n\r \n<td width=200px  class=\"subhead\">ExecutionDate</td>\n");
            HtmlIndexFile.write("");
            HtmlIndexFile.write("\r \n\r \n<td width=200px class=\"subhead\">Tested on</td>\n");
            HtmlIndexFile.write("");
            HtmlIndexFile.write("\r \n\r \n<td width=100px class=\"subhead\"align=right>Build/Release</td>\n");
            HtmlIndexFile.write("");
            HtmlIndexFile.write("\r \n</tr><tr>\n");
            HtmlIndexFile.write("");
            String testRun = Config.testRun;
            HtmlIndexFile.write("\r \n\r \n<td width=400px class=\"subcont\"align=left>" + testRun + "</td>\n");
            HtmlIndexFile.write("");
            HtmlIndexFile.write("\r \n\r \n<td width=300px class=\"subcont\">" + Date + "</td>\n");
            HtmlIndexFile.write("");
            String testedOn = Config.BrowName;
            HtmlIndexFile.write("\r \n\r \n<td width=200px class=\"subcont\">" + testedOn + "</td>\n");
            HtmlIndexFile.write("");
            String buildNo = Config.buildNo;
            HtmlIndexFile.write("\r \n\r \n<td width=100px class=\"subcont\"align=right>" + buildNo + "</td>\n");
            HtmlIndexFile.write("");
            HtmlIndexFile.write("\r \n</tr></table><hr class=\"divline\"><BR>\n");

            HtmlIndexFile.write("\r \n<table width=1200 class=\"tsteps\">\n");
            HtmlIndexFile.write("");
            HtmlIndexFile.write("\r \n<tr>");
            HtmlIndexFile.write("");
            HtmlIndexFile.write("\r \n\r \n<td class=\"tshead\" width=50px>S.No</td>\n");
            HtmlIndexFile.write("");
            HtmlIndexFile.write("\r \n\r \n<td class=\"tshead\" width=200px>Test Case</td>\n");
            HtmlIndexFile.write("");
            HtmlIndexFile.write("\r \n\r \n<td class=\"tshead\" width=200px>Functionality Index</td>\n");
            HtmlIndexFile.write("");

            HtmlIndexFile.write("\r \n\r \n<td class=\"tshead\" width=300px>Description</td>\n");
            HtmlIndexFile.write("");
            HtmlIndexFile.write("\r \n\r \n<td class=\"tshead\" width=200px>Criticality</td>\n");
            HtmlIndexFile.write("");

            // added this dummy td to sync with creation of indexMaster.html
            // file
            /*
             * HtmlIndexFile.
             * write("\r \n\r \n<td class=\"tshead\" width=200px>ENV</td>\n");
             */
            HtmlIndexFile.write("\r \n\r \n<td style=\"display:none;\" width=50px>ENV</td>\n");
            HtmlIndexFile.write("");

            HtmlIndexFile.write("\r \n\r \n<td class=\"tshead\" width=50px>Steps</td>\n");
            HtmlIndexFile.write("");
            HtmlIndexFile.write("\r \n\r \n<td class=\"tshead\" width=50px>Passed</td>\n");
            HtmlIndexFile.write("");
            HtmlIndexFile.write("\r \n\r \n<td class=\"tshead\" width=50px>Warnings</td>\n");
            HtmlIndexFile.write("");
            HtmlIndexFile.write("\r \n\r \n<td class=\"tshead\" width=50px>Failed</td>\n");
            HtmlIndexFile.write("");
            HtmlIndexFile.write("\r \n\r \n<td class=\"tshead\" width=50px>Status</td>\n");
            HtmlIndexFile.write("");
            HtmlIndexFile.write("\r \n</tr>");

            /*
             * Element table2 = doc.select("table").get(2);
             *
             * System.out.println(table2.toString());
             *
             *
             * Elements rows2 = table2.select("tr");
             *
             * HtmlIndexFile.write("<hr class=\"divline\"></hr>\n<body>");
             */

            // HtmlIndexFile.write("\n<table>");

            // File dir = new File(path);

            /*
             * File[] files = dir.listFiles(new FilenameFilter() {
             *
             * @Override public boolean accept(File dir, String name) { return
             * (name.startsWith("contc_") && name.endsWith(".htm")); } });
             */

            File[] files = new File[HtmlParser.contestcaseslist.size()];

            for (int testcasecount = 0; testcasecount < files.length; testcasecount++) {
                String FilePath = HtmlParser.contestcaseslist.get(testcasecount);
                System.out.println("File taken for concatination:::" + FilePath);
                File file = new File(FilePath);
                files[testcasecount] = file;
            }

            /*
             * Element row = rows2.get(0);
             *
             * System.out.println(row.toString());
             *
             * HtmlIndexFile.write(row.toString());
             */
            NonDbTestCase = "pass";
            int fileCount = 0;

            for (File htmfile : files) {

                fileCount++;

                CONTINUE: {

                    /*
                     * row = rows2.get(i);
                     *
                     * Elements cols = row.select("td");
                     *
                     * FunctionalityIndex = cols.get(1).text();
                     *
                     * TestCaseBrokenid = cols.get(2).text();
                     *
                     * TestCaseDescription = cols.get(3).text();
                     *
                     * criticality = cols.get(4).text();
                     */

                    doc1 = Jsoup.parse(htmfile, "UTF-8", "");

                    TestCaseBrokenid = doc1.select("table").get(1).select("tr").get(1).select("td").get(0).text()
                            .toString();

                    TestCaseDescription = doc1.select("table").get(2).select("tr").get(2).select("td").get(0).text()
                            .toString();

                    System.out.println("TestCaseBrokenid::" + TestCaseBrokenid);

                    if (TestCaseBrokenid.contains("~")) {

                        int a = TestCaseBrokenid.indexOf("~");

                        ActualTestCaseId = TestCaseBrokenid.substring(0, a);

                        if (myList.toString().contains(ActualTestCaseId)) {

                            break CONTINUE;

                        }

                        myList.add(ActualTestCaseId);

                        System.out.println("ActualTestCaseId::" + ActualTestCaseId);

                        /*
                         * System.out.
                         * println("ReadExceiReport.txtAndVal1.get(ActualTestCaseId) "
                         * +
                         * functionalityIndexDetailsMap.get(ActualTestCaseId));
                         */

                        FunctionalityIndex = functionalityIndexDetailsMap.get(ActualTestCaseId);

                        criticality = criticalityDetailsMap.get(ActualTestCaseId);

                        TestCaseCount++;

                        /* HtmlIndexFile.write("\n\t<tr>"); */
                        HtmlIndexFile.write("\n\t<tr vertical=" + reportGroupDetailsMap.get(ActualTestCaseId) + ">");

                        HtmlIndexFile.write("\n\t\t<td class=\"tsind\" width='50px'>" + TestCaseCount + "</td>");

                        // HtmlIndexFile.write("\n<td class=\"tsnorm\"
                        // width='300px'>"
                        // + FunctionalityIndex + "</td>");

                        HtmlIndexFile.write("\n<td class=\"tsnorm\" width='200px'><a class=\"cindex\" href=" + "contc_"
                                + ActualTestCaseId + ".htm>" + ActualTestCaseId + "</a></td>");

                        HtmlIndexFile.write(
                                "\r \n\r \n<td class=\"tsnorm\" width='200px'>" + FunctionalityIndex + "</td>\n");

                        HtmlIndexFile.write("\n<td class=\"tsnorm\" width='1500px'>" + TestCaseDescription + "</td>");

                        HtmlIndexFile.write("\n<td class=\"tsnorm\" width='300px'>" + criticality + "</td>");

                        // added this dummy td to sync with creation of
                        // indexMaster.html file
                        /*
                         * HtmlIndexFile.
                         * write("\n<td class=\"tsnorm\" width='300px'>" +
                         * "Environment" + "</td>");
                         */
                        HtmlIndexFile.write("\n<td style=\"display:none;\" width='50px'>" + "Environment" + "</td>");

                        Element table3 = doc1.select("table").get(3);

                        Elements rows3 = table3.select("tr");

                        for (int j = 1; j < rows3.size(); j++) {

                            toTalSteps = ++TestStepsCount;

                            String TestResultRow = rows3.get(j).toString();

                            if (TestResultRow.contains("pass.gif")) {

                                passedsteps++;

                                if (TestResultRow.contains("DBCHECK") && !(DbTestCase.matches("fail"))) {

                                    DbTestCase = "pass";

                                } else if (!(NonDbTestCase.matches("fail"))) {

                                    NonDbTestCase = "pass";
                                }

                            } else if (TestResultRow.contains("fail.jpg")) {

                                failedsteps++;

                                if (TestResultRow.contains("DBCHECK")) {

                                    DbTestCase = "fail";

                                } else {

                                    NonDbTestCase = "fail";
                                }
                            } else {

                                warningsteps++;
                            }

                        }

                        /*
                         * for (int j = 1; j < rows3.size(); j++) {
                         *
                         * toTalSteps = ++TestStepsCount;
                         *
                         * String TestResultRow = rows3.get(j).toString();
                         *
                         * if (TestResultRow.contains("pass.gif")) {
                         *
                         * passedsteps++;
                         *
                         * if (TestResultRow.contains("DB CHECK") &&
                         * !(DbTestCase.matches("fail"))) {
                         *
                         * DbTestCase = "pass";
                         *
                         * } else if (!(NonDbTestCase.matches("fail"))){
                         *
                         * NonDbTestCase = "pass"; }
                         *
                         * } else if (TestResultRow.contains("fail.jpg")) {
                         *
                         * failedsteps++;
                         *
                         * if (TestResultRow.contains("DB CHECK")) {
                         *
                         * DbTestCase = "fail";
                         *
                         * } else {
                         *
                         * NonDbTestCase = "fail"; } } else {
                         *
                         * warningsteps++; }
                         *
                         * }
                         */

                        if (DbTestCase.matches("flag")) {

                            OverallStatus = NonDbTestCase;

                            if (NonDbTestCase.matches("pass")) {
                                overallResult = "\n<td class=\"tsind\" width=\'50px\'><img src = \"../ReportInfo/images/pass.gif\" width=\"20\" height=\"20\"></img></td>";
                            } else {
                                overallResult = "\n<td class=\"tsind\" width=\'50px\'><img src = \"../ReportInfo/images/fail.jpg\" width=\"20\" height=\"20\"></img></td>";
                            }

                        } else {

                            OverallStatus = DbTestCase;
                        }
                        TotalTestCases++;
                        if (OverallStatus.matches("pass")) {
                            TotalTestCasesPass++;
                            overallResult = "\n<td class=\"tsind\" width=\'50px\'><img src = \"../ReportInfo/images/pass.gif\" width=\"20\" height=\"20\"></img></td>";

                        } else {
                            TotaltestCasesFail++;
                            overallResult = "\n<td class=\"tsind\" width=\'50px\'><img src = \"../ReportInfo/images/fail.jpg\" width=\"20\" height=\"20\"></img></td>";
                        }

                        HtmlIndexFile.write("\n<td class=\"tsind\" width='50px'>" + toTalSteps + "</td>");

                        HtmlIndexFile.write("\n<td class=\"tsind\" width='50px'>" + passedsteps + "</td>");

                        HtmlIndexFile.write("\n<td class=\"tsind\" width='50px'>" + warningsteps + "</td>");

                        HtmlIndexFile.write("\n<td class=\"tsind\" width='50px'>" + failedsteps + "</td>");

                        HtmlIndexFile.write(overallResult);

                        // this is to create ExecutionTime details table
                        readExecutionTimeDetails(doc1, fileCount);

                    } else {

                        myList.add(TestCaseBrokenid);

                        ActualTestCaseId = TestCaseBrokenid;

                        System.out.println("ActualTestCaseId::" + ActualTestCaseId);

                        /*
                         * System.out.
                         * println("ReadExceiReport.txtAndVal1.get(ActualTestCaseId) "
                         * +
                         * functionalityIndexDetailsMap.get(ActualTestCaseId));
                         */

                        FunctionalityIndex = functionalityIndexDetailsMap.get(ActualTestCaseId);

                        criticality = criticalityDetailsMap.get(ActualTestCaseId);

                        TestCaseCount++;

                        /* HtmlIndexFile.write("\n\t<tr>"); */
                        HtmlIndexFile.write("\n\t<tr vertical=" + reportGroupDetailsMap.get(ActualTestCaseId) + ">");

                        HtmlIndexFile.write("\n\t\t<td class=\"tsind\" width='50px'>" + TestCaseCount + "</td>");

                        HtmlIndexFile.write("\n<td class=\"tsnorm\" width='200px'><a class=\"cindex\" href=" + "contc_"
                                + ActualTestCaseId + ".htm>" + TestCaseBrokenid + "</a></td>");

                        HtmlIndexFile.write(
                                "\r \n\r \n<td class=\"tsnorm\" width='200px'>" + FunctionalityIndex + "</td>\n");

                        HtmlIndexFile.write("\n<td class=\"tsnorm\" width='1500px'>" + TestCaseDescription + "</td>");

                        HtmlIndexFile.write("\n<td class=\"tsnorm\" width='300px'>" + criticality + "</td>");

                        // added this dummy td to sync with creation of
                        // indexMaster.html file
                        /*
                         * HtmlIndexFile.
                         * write("\n<td class=\"tsnorm\" width='300px'>" +
                         * "Environment" + "</td>");
                         */
                        HtmlIndexFile.write("\n<td style=\"display:none;\" width='50px'>" + "Environment" + "</td>");

                        Element table3 = doc1.select("table").get(3);

                        Elements rows3 = table3.select("tr");

                        for (int j = 1; j < rows3.size(); j++) {

                            toTalSteps = ++TestStepsCount;

                            String TestResultRow = rows3.get(j).toString();

                            if (TestResultRow.contains("pass.gif")) {

                                passedsteps++;

                                if (TestResultRow.contains("DBCHECK") && !(DbTestCase.matches("fail"))) {

                                    DbTestCase = "pass";

                                } else if (!(NonDbTestCase.matches("fail"))) {

                                    NonDbTestCase = "pass";
                                }

                            } else if (TestResultRow.contains("fail.jpg")) {

                                failedsteps++;

                                if (TestResultRow.contains("DBCHECK")) {

                                    DbTestCase = "fail";

                                } else {

                                    NonDbTestCase = "fail";
                                }
                            } else {

                                warningsteps++;
                            }

                        }

                        /*
                         * for (int j = 1; j < rows3.size(); j++) {
                         *
                         * toTalSteps = ++TestStepsCount;
                         *
                         * String TestResultRow = rows3.get(j).toString();
                         *
                         * if (TestResultRow.contains("pass.gif")) {
                         *
                         * passedsteps++;
                         *
                         * if (TestResultRow.contains("DB CHECK") &&
                         * !(DbTestCase.matches("fail"))) {
                         *
                         * DbTestCase = "pass";
                         *
                         * } else if (!(NonDbTestCase.matches("fail"))){
                         *
                         * NonDbTestCase = "pass"; }
                         *
                         * } else if (TestResultRow.contains("fail.jpg")) {
                         *
                         * failedsteps++;
                         *
                         * if (TestResultRow.contains("DB CHECK")) {
                         *
                         * DbTestCase = "fail";
                         *
                         * } else {
                         *
                         * NonDbTestCase = "fail"; } } else {
                         *
                         * warningsteps++; }
                         *
                         * }
                         */

                        if (DbTestCase.matches("flag")) {

                            OverallStatus = NonDbTestCase;
                            overallResult = "\n<td class=\"tsind\" width=\'50px\'><img src = \"../ReportInfo/images/pass.gif\" width=\"20\" height=\"20\"></img></td>";

                        } else {

                            OverallStatus = DbTestCase;
                        }
                        TotalTestCases++;
                        if (OverallStatus.matches("pass")) {
                            TotalTestCasesPass++;
                            overallResult = "\n<td class=\"tsind\" width=\'50px\'><img src = \"../ReportInfo/images/pass.gif\" width=\"20\" height=\"20\"></img></td>";

                        } else {
                            TotaltestCasesFail++;
                            overallResult = "\n<td class=\"tsind\" width=\'50px\'><img src = \"../ReportInfo/images/fail.jpg\" width=\"20\" height=\"20\"></img></td>";
                        }

                        HtmlIndexFile.write("\n<td class=\"tsind\" width='50px'>" + toTalSteps + "</td>");

                        HtmlIndexFile.write("\n<td class=\"tsind\" width='50px'>" + passedsteps + "</td>");

                        HtmlIndexFile.write("\n<td class=\"tsind\" width='50px'>" + warningsteps + "</td>");

                        HtmlIndexFile.write("\n<td class=\"tsind\" width='50px'>" + failedsteps + "</td>");

                        HtmlIndexFile.write(overallResult);

                        // this is to create ExecutionTime details table
                        readExecutionTimeDetails(doc1, fileCount);
                    }

                    DbTestCase = "flag";
                    NonDbTestCase = "pass";
                    warningsteps = 0;
                    passedsteps = 0;
                    failedsteps = 0;
                    toTalSteps = 0;
                    TestStepsCount = 0;
                    HtmlIndexFile.write("\n</tr>");

                }

            }
            HtmlIndexFile.write("</table>");

            HtmlIndexFile.write("<BR><BR>");
            HtmlIndexFile.write(
                    "<table width='250' class=\"pfsummary\"><tr><td colspan='2' class=\"tshead\">TestCasesSummary</td></tr>");
            HtmlIndexFile.write("<tr><td class=\"pfhead\" width='200px'>Total TestCases</td>");
            HtmlIndexFile.write("<td class=\"pfind\" width='50px'>" + TotalTestCases + "</td>");
            HtmlIndexFile.write("</tr>\n<tr>\n<td class=\"pfhead\" width='200px'>TestCases Passed</td>");
            HtmlIndexFile.write("<td class=\"pfind\" width='50px'>" + TotalTestCasesPass + "</td></tr>");
            HtmlIndexFile.write(
                    "<tr><td class=\"pfhead\" width='200px'>TestCases with Warning</td><td class=\"pfind\" width='50px'>0</td></tr>");
            HtmlIndexFile
                    .write("<tr><td class=\"pfhead\" width='200px'>TestCases Failed</td><td class=\"pfind\" width='50px'>"
                            + TotaltestCasesFail + "</td></tr>");
            HtmlIndexFile.write("</table>");

            // added to write execution time table
            /* HtmlIndexFile.write(writeExecutionTimeTable().toString()); */

            HtmlIndexFile.write("</body></html>");
            HtmlIndexFile.close();

            System.out.println("index_Run.htm file is successfully created");

        } catch (Exception EE) {
            System.out.println("Unable to Create index file");
            EE.printStackTrace();
            System.out.println(EE.getCause());
        }

    }

    /**
     * added by mahesh - to read ExecutionTime table details
     **/
    private static void readExecutionTimeDetails(Document doc, int count) {
        try {
            executionTimeTable = doc.select("table.tbtime").get(0); // select
                                                                    // the first
                                                                    // table.

            Elements timeCells = executionTimeTable.getElementsByClass("pfind");

            for (int ind = 0; ind < timeCells.size(); ind++) {
                String value = timeCells.get(ind).ownText();

                if (count == 1 && ind == 0) {

                    executionTimeDetails.put("START", value);
                } else if (count >= 1 && ind == 1) {

                    executionTimeDetails.put("STOP", value);
                } else if (ind == 2) {

                    String[] totalTime = value.split(",");

                    if (totalTime.length == 1) {
                        int secs = Integer.parseInt(totalTime[0].split(" ")[0].trim());
                        if (timeDetails.containsKey("SECS")) {
                            timeDetails.put("SECS", timeDetails.get("SECS") + secs);
                        } else {
                            timeDetails.put("SECS", secs);
                        }

                    } else if (totalTime.length == 2) {
                        int mins = Integer.parseInt(totalTime[0].trim().split(" ")[0].trim());
                        if (timeDetails.containsKey("MINS")) {
                            timeDetails.put("MINS", timeDetails.get("MINS") + mins);
                        } else {
                            timeDetails.put("MINS", mins);
                        }

                        int secs = Integer.parseInt(totalTime[1].trim().split(" ")[0].trim());
                        if (timeDetails.containsKey("SECS")) {
                            timeDetails.put("SECS", timeDetails.get("SECS") + secs);
                        } else {
                            timeDetails.put("SECS", secs);
                        }
                    }
                }
            }

            String duration = null;
            if (null == timeDetails.get("MINS")) {

                duration = timeDetails.get("SECS") + " sec";
            } else {

                duration = timeDetails.get("MINS") + " mins, " + timeDetails.get("SECS") + " sec";
            }

            executionTimeDetails.put("DURATION", duration);
        } catch (Exception e) {
            System.out
                    .println("ERROR IN READING EXECUTION TIME TABLE DETAILS:::" + Throwables.getStackTraceAsString(e));
        }
    }

    /**
     * added by mahesh - to create ExecutionTime Table
     */
    private static Element writeExecutionTimeTable() {
        Element executionTable = executionTimeTable;
        try {
            Elements timeTableData = executionTable.getElementsByClass("pfind");
            for (int index = 0; index < timeTableData.size(); index++) {
                if (index == 0) {
                    timeTableData.get(index).text(executionTimeDetails.get("START"));
                } else if (index == 1) {
                    timeTableData.get(index).text(executionTimeDetails.get("STOP"));
                } else if (index == 2) {
                    timeTableData.get(index).text(executionTimeDetails.get("DURATION"));
                }
            }

            System.out.println("EXECUTION DETAILS PARSED:::" + executionTable.toString());

        } catch (Exception e) {
            System.out
                    .println("ERROR IN WRITING EXECUTION TIME TABLE DETAILS:::" + Throwables.getStackTraceAsString(e));
        }
        return executionTable;
    }

}