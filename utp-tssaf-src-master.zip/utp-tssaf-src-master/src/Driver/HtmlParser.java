package Driver;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.google.common.base.Throwables;

public class HtmlParser {

    public static BufferedWriter HTMLIndexFile;
    private final static Comparator<String> NATURAL_SORT = new WindowsExplorerStringComparator();
    public static List<String> contestcaseslist = new ArrayList<>();

    public static LinkedHashMap<String, Integer> testCasesSummaryDetails = new LinkedHashMap<>();
    private static Element summaryTable;
    private static Element executionTimeTable;
    public static LinkedHashMap<String, String> executionTimeDetails = new LinkedHashMap<>();
    private static LinkedHashMap<String, Integer> timeDetails = new LinkedHashMap<>();

    public static void main() throws Exception {
        try {

            String curDir = System.getProperty("user.dir");
            System.out.println("TestCaseList:::" + Demo1.wealthTestCaseList.toString());

            /*
             * File [] files = dir.listFiles(new FilenameFilter() {
             *
             * @Override public boolean accept(File dir, String name) { return
             * (name.startsWith("TC_") && name.endsWith(".htm")); } });
             */

            File[] files = new File[Demo1.wealthTestCaseList.size()];

            System.out.println("Test Case List size - " + Demo1.wealthTestCaseList.size());

            for (int testcasecount = 0; testcasecount < files.length; testcasecount++) {
                /*String FilePath = curDir + "\\HTMLResults\\RunTTITAP\\" + Demo1.wealthTestCaseList.get(testcasecount) + ".htm";*/
                String FilePath = curDir + File.separator + "HTMLResults" + File.separator + Demo1.gbResultFolderName + File.separator
                        + Demo1.wealthTestCaseList.get(testcasecount) + ".htm";

                //String FilePath = curDir + File.separator + "HTMLResults" + File.separator + Config.RunNo + File.separator + Demo1.TestCaseList.get(testcasecount) + ".htm";

                File file = new File(FilePath);
                files[testcasecount] = file;
            }

            Arrays.sort(files, new Comparator<File>() {
                @Override
                public int compare(File o1, File o2) {

                    return NATURAL_SORT.compare(o1.getName(), o2.getName());
                }
            });
            int TestcaseStart = 0;
            double TestStepNo = 0;
            String MyFile2 = null;
            String MyFile1 = null;
            int flag = 0;
            for (File htmfile : files) {
                System.out.println("HTML FILE::" + htmfile);
                String url = htmfile.getCanonicalPath();
                String url1 = FilenameUtils.getPrefix(url) + FilenameUtils.getPath(url);
                String myFile = FilenameUtils.getBaseName(url);
                System.out.println("TestCaseID:::" + myFile);
                int a = myFile.indexOf("~");
                if (a > 0) {
                    MyFile1 = myFile.substring(0, a);
                } else {
                    MyFile1 = myFile;
                }

                System.out.println("TestCaseID after parsing:::" + MyFile1);
                if (flag == 0) {
                    MyFile2 = MyFile1;
                    flag = 1;
                }
                String TestStepNo11 = null;

                Document doc = Jsoup.parse(htmfile, "UTF-8", "");

                if (MyFile1.matches(MyFile2)) {

                    if (TestcaseStart == 0) {

                        HTMLIndexFile = new BufferedWriter(new FileWriter(url1 + "contc_" + MyFile1 + ".htm"));
                        if (!(contestcaseslist.contains(url1 + "contc_" + MyFile1 + ".htm"))) {
                            contestcaseslist.add(url1 + "contc_" + MyFile1 + ".htm");
                            System.out.println(url1 + "contc_" + MyFile1 + ".htm");
                        }
                        TestStepNo = 1.0D;
                        // TestcaseStart++;
                        HTMLIndexFile.write("<html>\n\t");
                        Elements head1 = doc.getElementsByTag("head");
                        System.out.println(head1.toString());
                        HTMLIndexFile.write(head1.toString());
                        Elements hr1 = doc.getElementsByTag("hr");
                        System.out.println(hr1.get(0).toString());
                        HTMLIndexFile.write(hr1.get(0).toString());
                        HTMLIndexFile.write("</hr>");
                        Element table0 = doc.select("table").get(0);
                        System.out.println(table0.toString());
                        HTMLIndexFile.write(table0.toString());
                        /*
                         * HTMLIndexFile.
                         * write("\n<hr class=\"divline\"></hr> <BR></BR>");
                         */
                        HTMLIndexFile.write(hr1.get(1).toString());
                        HTMLIndexFile.write("</hr><BR>");

                        Element table1 = doc.select("table").get(1);
                        table1.getElementsByClass("subcont").get(0).text(MyFile1); // this
                                                                                   // is
                                                                                   // to
                                                                                   // update
                                                                                   // TESTCASE
                                                                                   // ID

                        System.out.println(table1.toString());
                        HTMLIndexFile.write(table1.toString());

                        HTMLIndexFile.write(hr1.get(2).toString()); // added
                                                                    // maggy
                        HTMLIndexFile.write("</hr><BR>");

                        Element table2 = doc.select("table").get(2);
                        System.out.println(table2.toString());
                        HTMLIndexFile.write(table2.toString());

                        HTMLIndexFile.write(hr1.get(3).toString()); // added
                                                                    // maggy
                        HTMLIndexFile.write("</hr><BR>");

                        Element table3 = doc.select("table").get(3); // select
                                                                     // the
                                                                     // first
                                                                     // table.
                        Elements rows3 = table3.select("tr");
                        /* HTMLIndexFile.write("\n<table>"); */
                        HTMLIndexFile.write("\n<table width=\"1200px\" class=\"tsteps\">");

                        for (Element row : rows3) { // first row is
                                                                 // the col
                                                                 // names so
                                                                 // skip it.

                            System.out.println(row.toString());
                            HTMLIndexFile.write(row.toString());
                            Elements cols = row.select("td");
                            System.out.println(cols.get(0).toString());
                            Element TestStepNo1 = cols.get(0);
                            TestStepNo11 = TestStepNo1.text();
                            HTMLIndexFile.write("\n\t\t</tr>");
                        }

                        System.out.println(TestStepNo11);
                        TestStepNo = Double.parseDouble(TestStepNo11);

                        readSummaryTableDetails(doc);

                        readExecutionTimeDetails(doc, TestcaseStart);
                        TestcaseStart++;

                    } else {
                        Element table = doc.select("table").get(3); // select
                                                                    // the first
                                                                    // table.
                        Elements rows = table.select("tr");

                        for (int i = 1; i < rows.size(); i++) { // first row is
                                                                // the col names
                                                                // so skip it.

                            Element row = rows.get(i);

                            Elements cols = row.select("td");

                            TestStepNo = TestStepNo + 0.1D;
                            System.out.println(TestStepNo);
                            DecimalFormat df = new DecimalFormat("0.0");
                            String TestStep = df.format(TestStepNo);
                            System.out.println(TestStep);
                            /* HTMLIndexFile.write("\n\t<tr>"); */
                            System.out.println("VERTICAL::" + row.attr("vertical"));
                            HTMLIndexFile.write("\n\t<tr vertical=" + row.attr("vertical") + ">");

                            HTMLIndexFile.write("<td class=\"tsindlvl2\" width=\'75px\'>" + TestStep + "</td>\n");
                            for (int j = 1; j < cols.size(); j++) {

                                HTMLIndexFile.write(cols.get(j).toString());
                            }
                            HTMLIndexFile.write("\n\t\t</tr>");
                        }

                        readSummaryTableDetails(doc);
                        readExecutionTimeDetails(doc, TestcaseStart);
                        TestcaseStart++;
                    }

                } else {

                    TestcaseStart = 0;
                    flag = 0;
                    MyFile2 = MyFile1;
                    flag = 1;

                    HTMLIndexFile.write("\n</table>\n<BR><BR>");
                    // below lines are newly added to write the summary and
                    // execution table details to concatinated testcase htmls
                    HTMLIndexFile.write(writeSummaryTableDetails().toString());
                    HTMLIndexFile.write(writeExecutionTimeTable().toString());

                    HTMLIndexFile.write("\n</table>\n</html>");
                    HTMLIndexFile.close();
                    HTMLIndexFile = new BufferedWriter(new FileWriter(url1 + "contc_" + MyFile1 + ".htm"));
                    if (!(contestcaseslist.contains(url1 + "contc_" + MyFile1 + ".htm"))) {
                        contestcaseslist.add(url1 + "contc_" + MyFile1 + ".htm");
                        System.out.println(url1 + "contc_" + MyFile1 + ".htm");
                    }
                    TestStepNo = 1.0D;
                    // TestcaseStart++;
                    HTMLIndexFile.write("<html>\n\t");
                    Elements head1 = doc.getElementsByTag("head");
                    System.out.println(head1.toString());
                    HTMLIndexFile.write(head1.toString());
                    Elements hr1 = doc.getElementsByTag("hr");
                    System.out.println(hr1.get(1).toString());
                    HTMLIndexFile.write(hr1.get(1).toString());
                    HTMLIndexFile.write("</hr>");
                    Element table0 = doc.select("table").get(0);
                    System.out.println(table0.toString());
                    HTMLIndexFile.write(table0.toString());
                    HTMLIndexFile.write("<hr class=\"divline\"></hr> <BR></BR>");

                    Element table1 = doc.select("table").get(1);
                    table1.getElementsByClass("subcont").get(0).text(MyFile1); // this
                                                                               // is
                                                                               // to
                                                                               // update
                                                                               // TESTCASE
                                                                               // ID
                    System.out.println(table1.toString());
                    HTMLIndexFile.write(table1.toString());

                    HTMLIndexFile.write("\n<hr class=\"divline\"></hr> <BR></BR>"); // added
                                                                                    // maggy

                    Element table2 = doc.select("table").get(2);
                    System.out.println(table2.toString());
                    HTMLIndexFile.write(table2.toString());

                    HTMLIndexFile.write("\n<hr class=\"divline\"></hr> <BR></BR>"); // added
                                                                                    // maggy

                    Element table3 = doc.select("table").get(3); // select the
                                                                 // first table.
                    Elements rows3 = table3.select("tr");
                    HTMLIndexFile.write("\n<table>");
                    for (Element row : rows3) { // first row is the
                                                             // col names so
                                                             // skip it.

                        System.out.println(row.toString());
                        HTMLIndexFile.write(row.toString());
                        Elements cols = row.select("td");
                        System.out.println(cols.get(0).toString());
                        Element TestStepNo1 = cols.get(0);
                        TestStepNo11 = TestStepNo1.text();
                        HTMLIndexFile.write("\n\t\t</tr>");
                    }

                    System.out.println(TestStepNo11);
                    TestStepNo = Double.parseDouble(TestStepNo11);

                    readSummaryTableDetails(doc);
                    readExecutionTimeDetails(doc, TestcaseStart);
                    TestcaseStart++;
                }
            }

            HTMLIndexFile.write("\n</table>\n<BR><BR>");

            HTMLIndexFile.write(writeSummaryTableDetails().toString());
            HTMLIndexFile.write(writeExecutionTimeTable().toString());

            HTMLIndexFile.write("\n</html>");

            HTMLIndexFile.close();

            Reuse.log("Consolidated html report file is successfully created");

        } catch (Exception Eeee) {
            System.out.println("ERROR IN WRITING CONCATINATED TESTRESULTS (contc_ files):::"
                    + Throwables.getStackTraceAsString(Eeee));
        }

    }

    /**
     * added by mahesh - to create ExecutionSummaryTable
     */
    private static Element writeSummaryTableDetails() {
        Element finalSummaryTable = summaryTable;
        // this is to update the TestcasesSummary table details
        try {
            Elements summaryData = finalSummaryTable.getElementsByClass("pfind");
            for (int index = 0; index < summaryData.size(); index++) {
                if (index == 0) {
                    summaryData.get(index).text(Integer.toString(testCasesSummaryDetails.get("TOTAL")));
                } else if (index == 1) {
                    summaryData.get(index).text(Integer.toString(testCasesSummaryDetails.get("PASS")));
                } else if (index == 2) {
                    summaryData.get(index).text(Integer.toString(testCasesSummaryDetails.get("WARN")));
                } else if (index == 3) {
                    summaryData.get(index).text(Integer.toString(testCasesSummaryDetails.get("FAIL")));
                }
            }
        } catch (Exception e) {
            System.out.println("ERROR ON WRITING SUMMARY TABLE DETAILS::" + Throwables.getStackTraceAsString(e));
        }
        return finalSummaryTable;
    }

    /**
     * added by mahesh - to read ExecutionSummaryTable details
     **/
    private static void readSummaryTableDetails(Document doc) {
        try {
            summaryTable = doc.select("table.pfsummary").get(0); // select the
                                                                 // first table.
            System.out.println(summaryTable.toString());

            Elements dataCells = summaryTable.getElementsByClass("pfind");
            for (int ind = 0; ind < dataCells.size(); ind++) {
                int value = Integer.parseInt(dataCells.get(ind).ownText());
                if (ind == 0) {
                    if (testCasesSummaryDetails.containsKey("TOTAL")) {
                        testCasesSummaryDetails.put("TOTAL", testCasesSummaryDetails.get("TOTAL") + value);
                    } else {
                        testCasesSummaryDetails.put("TOTAL", value);
                    }
                } else if (ind == 1) {
                    if (testCasesSummaryDetails.containsKey("PASS")) {
                        testCasesSummaryDetails.put("PASS", testCasesSummaryDetails.get("PASS") + value);
                    } else {
                        testCasesSummaryDetails.put("PASS", value);
                    }
                } else if (ind == 2) {
                    if (testCasesSummaryDetails.containsKey("WARN")) {
                        testCasesSummaryDetails.put("WARN", testCasesSummaryDetails.get("WARN") + value);
                    } else {
                        testCasesSummaryDetails.put("WARN", value);
                    }
                } else if (ind == 3) {
                    if (testCasesSummaryDetails.containsKey("FAIL")) {
                        testCasesSummaryDetails.put("FAIL", testCasesSummaryDetails.get("FAIL") + value);
                    } else {
                        testCasesSummaryDetails.put("FAIL", value);
                    }
                }
            }
            System.out.println(testCasesSummaryDetails);
        } catch (Exception e) {
            System.out.println("ERROR ON READING SUMMARY TABLE DETAILS::" + Throwables.getStackTraceAsString(e));
        }
    }

    /**
     * added by mahesh - to read ExecutionTime table details
     **/
    private static void readExecutionTimeDetails(Document doc, int count) {
        try {
            executionTimeTable = doc.select("table.tbtime").get(0); // select
                                                                    // the first
                                                                    // table.

            Elements timeCells = executionTimeTable.getElementsByClass("pfind");

            for (int ind = 0; ind < timeCells.size(); ind++) {
                String value = timeCells.get(ind).ownText();

                if (count == 0 && ind == 0) {

                    executionTimeDetails.put("START", value);
                } else if (count >= 0 && ind == 1) {

                    executionTimeDetails.put("STOP", value);
                } else if (ind == 2) {

                    String[] totalTime = value.split(",");

                    if (totalTime.length == 1) {
                        int secs = Integer.parseInt(totalTime[0].split(" ")[0].trim());
                        if (timeDetails.containsKey("SECS")) {
                            timeDetails.put("SECS", timeDetails.get("SECS") + secs);
                        } else {
                            timeDetails.put("SECS", secs);
                        }

                    } else if (totalTime.length == 2) {
                        int mins = Integer.parseInt(totalTime[0].trim().split(" ")[0].trim());
                        if (timeDetails.containsKey("MINS")) {
                            timeDetails.put("MINS", timeDetails.get("MINS") + mins);
                        } else {
                            timeDetails.put("MINS", mins);
                        }

                        int secs = Integer.parseInt(totalTime[1].trim().split(" ")[0].trim());
                        if (timeDetails.containsKey("SECS")) {
                            timeDetails.put("SECS", timeDetails.get("SECS") + secs);
                        } else {
                            timeDetails.put("SECS", secs);
                        }
                    }
                }
            }

            String duration = null;
            if (null == timeDetails.get("MINS")) {

                duration = timeDetails.get("SECS") + " sec";
            } else {

                duration = timeDetails.get("MINS") + " mins, " + timeDetails.get("SECS") + " sec";
            }

            executionTimeDetails.put("DURATION", duration);
            System.out.println(executionTimeDetails);
        } catch (Exception e) {
            System.out.println("ERROR ON READING EXECUTION TIME TABLE DETAILS::" + Throwables.getStackTraceAsString(e));
        }
    }

    /**
     * added by mahesh - to create ExecutionTime Table
     */
    private static Element writeExecutionTimeTable() {
        Element executionTable = executionTimeTable;
        try {
            Elements timeTableData = executionTable.getElementsByClass("pfind");
            for (int index = 0; index < timeTableData.size(); index++) {
                if (index == 0) {
                    timeTableData.get(index).text(executionTimeDetails.get("START"));
                } else if (index == 1) {
                    timeTableData.get(index).text(executionTimeDetails.get("STOP"));
                } else if (index == 2) {
                    timeTableData.get(index).text(executionTimeDetails.get("DURATION"));
                }
            }
        } catch (Exception e) {
            System.out
                    .println("ERROR ON WRITING EXECUTION TIME TABLE DETAILS:::" + Throwables.getStackTraceAsString(e));
        }

        return executionTable;
    }

}
