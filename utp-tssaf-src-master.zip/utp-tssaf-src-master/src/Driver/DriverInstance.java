package Driver;
import org.openqa.selenium.remote.RemoteWebDriver;

import io.appium.java_client.AppiumDriver;

public class DriverInstance {

	@SuppressWarnings("rawtypes")
	public static volatile ThreadLocal<AppiumDriver> driver = new ThreadLocal<>();
	public static volatile ThreadLocal<RemoteWebDriver> Rdriver = new ThreadLocal<>();
	@SuppressWarnings({ "rawtypes" })
	public void setMobileDriver(AppiumDriver Mobiledriver) {
		try{
		//System.out.println("i'm in SetMobileDriver class..."+Mobiledriver);

		driver.set(Mobiledriver);
		//System.out.println("After setting .... everthing");
		}catch(Exception e){e.getLocalizedMessage();}
	}

	@SuppressWarnings({ "rawtypes" })
	public void setMobileDriver(RemoteWebDriver Mobiledriver) {

		driver.set((AppiumDriver)Mobiledriver);
	}

	@SuppressWarnings({ "rawtypes" })
	public AppiumDriver getMobileDriver() {

		return driver.get();
	}

	public DriverInstance() {

	}

	public void setRemoteMobileDriver(RemoteWebDriver Mobiledriver) {

		Rdriver.set(Mobiledriver);
	}

}
