package Driver;

import static org.apache.commons.lang3.StringEscapeUtils.escapeHtml3;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;
import java.util.TimeZone;

import javax.imageio.ImageIO;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.Logs;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.deque.html.axecore.results.Check;
import com.deque.html.axecore.results.CheckedNode;
import com.deque.html.axecore.results.Results;
import com.deque.html.axecore.results.Rule;
import com.deque.html.axecore.selenium.AxeBuilder;
import com.google.common.base.Function;
import com.google.common.base.Throwables;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.opencsv.CSVReader;
import com.utils.Common;

import AppLib.StoreText;
import convert.dev.scripts.batfileCall;
import io.appium.java_client.MobileBy;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.offset.PointOption;
import io.github.sukgu.Shadow;
import net.neoremind.sshxcute.core.ConnBean;
import net.neoremind.sshxcute.core.IOptionName;
import net.neoremind.sshxcute.core.Result;
import net.neoremind.sshxcute.core.SSHExec;
import net.neoremind.sshxcute.core.SysConfigOption;
import net.neoremind.sshxcute.exception.TaskExecFailException;
import net.neoremind.sshxcute.task.CustomTask;
import net.neoremind.sshxcute.task.impl.ExecCommand;
import net.sourceforge.htmlunit.corejs.javascript.JavaScriptException;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

public class Reuse {
	public static final String CHAR_LIST = "abcdefghijklmnopqrstuvwxyz";
	public final static String NUM_LIST = "1234567890";
	public static Map<String, String> txtAndVal = null;
	public static Map<String, String> STORE_TEXT = null;
	public static Boolean isSkipTestCase = false;
	public static Boolean isSkipTest = false;
	protected static FileInputStream fileForOR = null;
	protected static XSSFWorkbook workbookForOR = null;
	protected static double perfTimingNavStart = 0;
	protected static double perfTimingLoadEventEnd = 0;
	static JavascriptExecutor perfTimingJs = null;

	public static Writer HTMLViolationReportFile;

	public static int totalPages = 0, passed = 0, serious = 0, critical = 0, moderate = 0, minor = 0,
			totalSeriousPages = 0, totalCriticalPages = 0, totalModeratePages = 0, totalMinorPages = 0;

	private static final URL scriptUrl = Reuse.class.getResource("axe.min.js");
	static String curDir = System.getProperty("user.dir");
	public static String tafjHome, javaHome, routineValue;

	private static String responseMessage = "", txnCommittedStatus = "";
	/*
	 * public static Map<String, String> generalDataMap = new HashMap<String,
	 * String>(); public static boolean isDataMapInitialized = true;
	 */

	public static String getDateTimeStamp() {
		String snewFileName = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());

		return snewFileName;
	}

	/**
	 * Function to perform click action
	 *
	 * @param linkText      - Link name
	 * @param timeInSeconds - time to wait in seconds Author: Creation Date:
	 *                      27-04-2012
	 */

	public static WebElement expand_shadow_element(WebElement element) {
		WebElement shadow_root = (WebElement) ((JavascriptExecutor) Demo1.driver)
				.executeScript("return arguments[0].shadowRoot", element);
		return shadow_root;
	}

	public static void Shadow_JsClick(By by, String elementType, String elementName) {

		WebElement element;
		try {

			// Shadow shadow = new Shadow(Demo1.driver);

			// element = Demo1.driver.findElement(By.linkText(linkText));

			element = Demo1.driver.findElement(by);

			WebElement shadow_root = (WebElement) ((JavascriptExecutor) Demo1.driver)
					.executeScript("return arguments[0].shadowRoot", element);

			if (shadow_root.isDisplayed()) {
				shadow_root.click();
				// msg
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Action: Click the shadow element",
						"Click the element: " + elementType + elementName, "Click action done successfully");
			} else {
				// msg
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Action: Click the shadow element",
						"Click the element: " + elementType + elementName, "Click action not done successfully");
			}
		} catch (Exception e) {

			Reuse.log(e);
			Demo1.logger.error("error in shadow_Click " + e.getMessage());
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Action: Click the shadow element", "Click the element: " + elementType + elementName,
					"Click action not done successfully");
		}
	}

	public static void Shadow_Click(String by, String elementType, String elementName) {

		WebElement element;
		try {

			Shadow shadow = new Shadow(Demo1.driver);

			element = shadow.findElement(by);
			if (element.isDisplayed()) {
				element.click();
				// msg
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Action: Click the shadow element",
						"Click the element: " + elementType + elementName, "Click action done successfully");
			} else {
				// msg
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Action: Click the shadow element",
						"Click the element: " + elementType + elementName, "Click action not done successfully");
			}
		} catch (Exception e) {

			Reuse.log(e);
			Demo1.logger.error("error in shadow_Click " + e.getMessage());
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Action: Click the shadow element", "Click the element: " + elementType + elementName,
					"Click action not done successfully");
		}
	}

	public static void Shadow_ScrollToElement(String by, String elementType, String elementName) {

		WebElement element;
		try {

			Shadow shadow = new Shadow(Demo1.driver);

			// element = Demo1.driver.findElement(By.linkText(linkText));

			element = shadow.findElement(by);

			shadow.scrollTo(element);

			// msg
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Action: Click the shadow element", "Click the element: " + elementType + elementName,
					"Click action done successfully");

		} catch (Exception e) {

			Reuse.log(e);
			Demo1.logger.error("error in shadow_Click " + e.getMessage());
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Action: Click the shadow element", "Click the element: " + elementType + elementName,
					"Click action not done successfully");
		}
	}

	public static void Shadow_SetText(String linkText, String Text, String textboxName) {

		WebElement element;
		try {

			Shadow shadow = new Shadow(Demo1.driver);
			
			try {
            	element = shadow.findElement(linkText);
                if (element.isDisplayed()) {
                    element.sendKeys(Text);
                    
                }
			} catch (Exception e) {
				// TODO: handle exception
				 Reuse.log(e);
				 System.out.println("using js");
				JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
				js.executeScript("arguments[0].value='" + Text + "';", shadow.findElement(linkText));
				js.executeScript("var event = new Event('input');arguments[0].dispatchEvent(event);",
						shadow.findElement(linkText));
				js.executeScript("var event = new Event('change');arguments[0].dispatchEvent(event);",
						shadow.findElement(linkText));
			}
            
            Demo1.gbTestCaseStatus = "Pass";
            Demo1.ReportStep(2, "Action: set text in shadow element", "set text the element: " + textboxName,
                    "set text action done successfully");
		} catch (Exception e) {

			Reuse.log(e);
			Demo1.logger.error("error in shadow_set text " + e.getMessage());
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Action: Set the shadow element", "Set the element: " ,
                    "Set the value not done successfully");
		}
	}

	public static void Link_Click(String linkText, int timeInSeconds) {

		WebElement element;
		try {
			element = Demo1.driver.findElement(By.linkText(linkText));
			if (element.isDisplayed()) {
				element.click();
				// msg
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Action: Click the Link element", "Click the element: " + element.getText(),
						"Click action done successfully");
			} else {
				// msg
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Action: Click the Link element", "Click the element: " + element.getText(),
						"Click action not done successfully");
			}
		} catch (Exception e) {

			Reuse.log(e);
			Demo1.logger.error("error in Link_Click " + e.getMessage());
			Demo1.logger.error(e);
		}
	}

	/**
	 * Verifies the Link existence
	 */
	public static void Link_TextVerification(String linkText, int timeInSeconds) {

		String element;
		Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(timeInSeconds));
		element = Demo1.driver.findElement(By.linkText(linkText)).getAttribute("value");
		if (element.contains(linkText)) {
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Action: Link verification", "Verifies the Link: <b>" + linkText + "</b>",
					"Link <b>" + linkText + "</b> exist");

		} else {
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Action: Link verification", "Verifies the Link: <b>" + linkText + "</b>",
					"Link <b>" + linkText + "</b> not exist");
		}

		Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Config.TIME_OUT));
	}

	/**
	 * Switch to other window
	 */
	public static void SwitchToWindow(String windowTitle) {
		try {
			String currentWindow = Demo1.driver.getWindowHandle();
			String prevWindow = Demo1.driver.switchTo().window(currentWindow).getTitle();
			// if (prevWindow != windowTitle) {
			Set<String> availableWindows = Demo1.driver.getWindowHandles();
			if (!availableWindows.isEmpty()) {
				for (String windowId : availableWindows) {
					if (Demo1.driver.switchTo().window(windowId).getTitle().equals(windowTitle)) {
						Demo1.driver.switchTo().window(windowId);
						Demo1.driver.manage().window().maximize();
						Demo1.gbTestCaseStatus = "Pass";
						Demo1.ReportStep(2, "Switch to <b>" + windowTitle + "</b> window",
								"Should be switched to <b>" + windowTitle + "</b> window",
								"Switched to <b>" + windowTitle + "</b> window");
						break;
					}
				}
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Switch to <b>" + windowTitle + "</b> window",
						"Should be switched to <b>" + windowTitle + "</b> window",
						"<b>" + windowTitle + "</b> window not exist");
			}
			// }
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("error in Switch to <b>" + windowTitle + "</b> window " + e.getMessage());
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Switch to <b>" + windowTitle + "</b> window",
					"Should be switched to <b>" + windowTitle + "</b> window", e.getMessage());
		}
	}

	public static void CloseAllChildWindows() {
		if (!Demo1.envName.equalsIgnoreCase("MOBILEAPP") && !Demo1.envName.equalsIgnoreCase("API")) {
			try {

				if (null == Demo1.driver) {

					System.out.println("Driver is null, so \"CloseAllChildWindows()\" does nothing!");
				} else {

					// int windowCnt=0;
					// String[] title;
					String patentWinId = Demo1.driver.getWindowHandles().toArray()[0].toString();
					String parentWinTitle = Demo1.driver.switchTo().window(patentWinId).getTitle();
					Set<String> availableWindows = Demo1.driver.getWindowHandles();
					// title=new String[availableWindows.size()];
					if (!availableWindows.isEmpty()) {
						for (String windowId : availableWindows) {
							if (!Demo1.driver.switchTo().window(windowId).getTitle().contains(parentWinTitle)) {
								String winTitle = Demo1.driver.switchTo().window(windowId).getTitle();
								// Demo1.driver.switchTo().window(windowId);
								Demo1.driver.switchTo().window(windowId).close();

								// windowCnt++;
								Demo1.logger.info("Testcase id: " + Demo1.gbCurrTestCaseName
										+ ". CloseAllChildWindows- Closed " + winTitle);
							}
						}
					}
					Demo1.driver.switchTo().window(patentWinId);
					// Demo1.gbTestCaseStatus = "Pass";
					// Demo1.ReportStep(2, "Close all child windows","All child
					// windows should be closed","Closed all child windows");
				}
			} catch (Exception e) {
				Reuse.log(e);
				Demo1.logger.error("CloseAllChildWindows - " + e);
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Close all child windows", "All child windows should be closed", e.getMessage());
			}
		}
	}

	public static void waitForLoad(WebDriver driver) {
		ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) Demo1.driver).executeScript("return document.readyState")
						.equals("complete");
			}
		};
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Config.TIME_OUT));
		wait.until(pageLoadCondition);
	}

	public static void windowSync(final String windowTitle) {

		if (waitForExpectedWindow(windowTitle))
			return;

		try {
			Thread.sleep(10000);
			if (!waitForExpectedWindow(windowTitle)) {
				System.out.println("Checking no. of windows to be more then one");
				WebDriverWait wait = new WebDriverWait(Demo1.driver, Duration.ofSeconds(10));
				wait.until(ExpectedConditions.numberOfWindowsToBe(2));
			}
		} catch (Exception e) {
			Reuse.log(e);

		}

		if (waitForExpectedWindow(windowTitle))
			return;

	}

	public static boolean waitForExpectedWindow(final String windowTitle) {
		boolean isWindowMatched = false;
		Set<String> availableWindows = Demo1.driver.getWindowHandles();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
		}
		try {
			for (String windowId : availableWindows) {
				System.out.println("Window name : " + Demo1.driver.switchTo().window(windowId).getTitle());
				if (Demo1.driver.switchTo().window(windowId).getTitle().trim().contains(windowTitle.trim())) {
					System.out.println();
					isWindowMatched = true;
					waitForLoad(Demo1.driver);
					break;
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
		}
		return isWindowMatched;
	}

	public static void WindowRegExp(String windowTitle, String regExp) {
		boolean isWindowMatched = false;
		windowSync(windowTitle);
		try {
			// if (prevWindow != windowTitle) {
			String patentWinId = Demo1.driver.getWindowHandles().toArray()[0].toString();
			Set<String> availableWindows = Demo1.driver.getWindowHandles();
			if (!availableWindows.isEmpty() && availableWindows != null) {
				for (String windowId : availableWindows) {
					// need to insert wait
					if (regExp.equalsIgnoreCase("SWITCHTO")) {
						if (Demo1.driver.switchTo().window(windowId).getTitle().equals(windowTitle)) {
							Demo1.driver.switchTo().window(windowId);
							isWindowMatched = true;
							break;
						}
					} else if (regExp.equalsIgnoreCase("CLOSE")) {
						if (Demo1.driver.switchTo().window(windowId).getTitle().equals(windowTitle)) {
							Demo1.driver.switchTo().window(windowId);
							Demo1.driver.switchTo().window(windowId).close();
							isWindowMatched = true;
							if (!Demo1.driver.switchTo().window(patentWinId).getTitle().isEmpty())
								Demo1.driver.switchTo().window(patentWinId);
							break;
						}
					} else if (regExp.equalsIgnoreCase("SWITCHTO_TITLE_Contains")) {
						if (Demo1.driver.switchTo().window(windowId).getTitle().contains(windowTitle)) {
							Demo1.driver.switchTo().window(windowId);
							isWindowMatched = true;
							break;
						}
					} else if (regExp.equalsIgnoreCase("SWITCHTO_TITLE_StartsWith")) {
						if (Demo1.driver.switchTo().window(windowId).getTitle().startsWith(windowTitle)) {
							Demo1.driver.switchTo().window(windowId);
							isWindowMatched = true;
							break;
						}
					} else if (regExp.equalsIgnoreCase("SWITCHTO_TITLE_EndsWith")) {
						if (Demo1.driver.switchTo().window(windowId).getTitle().endsWith(windowTitle)) {
							Demo1.driver.switchTo().window(windowId);
							isWindowMatched = true;
							break;
						}
					} else if (regExp.equalsIgnoreCase("CLOSE_TITLE_Contains")) {
						if (Demo1.driver.switchTo().window(windowId).getTitle().contains(windowTitle)) {
							Demo1.driver.switchTo().window(windowId);
							Demo1.driver.switchTo().window(windowId).close();
							isWindowMatched = true;
							if (!Demo1.driver.switchTo().window(patentWinId).getTitle().isEmpty())
								Demo1.driver.switchTo().window(patentWinId);
							break;
						}
					} else if (regExp.equalsIgnoreCase("CLOSE_TITLE_StartsWith")) {
						if (Demo1.driver.switchTo().window(windowId).getTitle().startsWith(windowTitle)) {
							Demo1.driver.switchTo().window(windowId);
							Demo1.driver.switchTo().window(windowId).close();
							isWindowMatched = true;
							if (!Demo1.driver.switchTo().window(patentWinId).getTitle().isEmpty())
								Demo1.driver.switchTo().window(patentWinId);
							break;
						}
					} else if (regExp.equalsIgnoreCase("CLOSE_TITLE_EndsWith")) {
						if (Demo1.driver.switchTo().window(windowId).getTitle().endsWith(windowTitle)) {
							Demo1.driver.switchTo().window(windowId);
							Demo1.driver.switchTo().window(windowId).close();
							isWindowMatched = true;
							if (!Demo1.driver.switchTo().window(patentWinId).getTitle().isEmpty())
								Demo1.driver.switchTo().window(patentWinId);
							break;
						}
					}
				}
				if (isWindowMatched) {
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, regExp + " <b>" + windowTitle + "</b>",
							regExp + " " + windowTitle + " should be performed",
							"Performed " + regExp + " on " + windowTitle + " window");
				} else {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, regExp + " <b>" + windowTitle + "</b>",
							regExp + " " + windowTitle + " should be performed",
							"Window title " + windowTitle + " not matched with the existing windows");
				}
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, regExp + " <b>" + windowTitle + "</b>",
						regExp + " " + windowTitle + " should be performed", "Window " + windowTitle + " not exist");
			}
			// }
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("Error in Swithch Window (WindowRegExp)." + e.getMessage());
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, regExp + "<b>" + windowTitle + "</b>", regExp + " should be performed", e.getMessage());
		}
	}

	public static void windowHandle(String regexp) {
		try {
			Boolean isWindowMatched = false;
			JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
			js.executeScript("window.open()");
			if (regexp.equalsIgnoreCase("NEWTAB")) {
				ArrayList<String> al = new ArrayList<String>(Demo1.driver.getWindowHandles());
				Demo1.driver.switchTo().window(al.get(1));
				isWindowMatched = true;
			}
			if (isWindowMatched) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Switch to a new tab", "Should be switched to new tab", "Switched to new tab");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Switch to a new tab", "Should be switched to new tab",
						"Unable to Switch to new tab");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reuse.log(e);
			Demo1.logger.error("Error in Switching Window (WindowRegExp)." + e.getMessage());
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Switch to a new tab", "Should be switched to new tab",
					"Unable to Switch to new tab" + e.getMessage());
		}
	}

	public static void SwitchToChildWindow() {
		String windowTitle = "";
		
		WebDriverWait wait = new WebDriverWait(Demo1.driver, Duration.ofSeconds(25));
		wait.until(ExpectedConditions.numberOfWindowsToBe(Demo1.driver.getWindowHandles().size()));
		System.out.println("window size: "+ Demo1.driver.getWindowHandles().size());
		try {
			for (String winHandl : Demo1.driver.getWindowHandles()) {
				Demo1.driver.switchTo().window(winHandl);
				windowTitle = Demo1.driver.switchTo().window(winHandl).getTitle();
			}
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Switch to child window <b>" + windowTitle + "</b>",
					"Should be switched to <b>" + windowTitle + "</b> window", "Switched to child window");

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Switch to child window", "Should be switched to child window", "Window not exist");
			Demo1.logger.error("Error in Switch to child window method. " + e.getMessage());
		}
	}

	public static void CloseChildWindow() {
		String windowTitle = "";
		String childWin = "";
		try {
			if (Demo1.driver.getWindowHandles().size() > 1) {
				for (String winHandl : Demo1.driver.getWindowHandles()) {
					Demo1.driver.switchTo().window(winHandl);
					childWin = winHandl;
				}
				windowTitle = Demo1.driver.switchTo().window(childWin).getTitle();
				Demo1.driver.close();
				Demo1.driver.switchTo().window((String) Demo1.driver.getWindowHandles().toArray()[0]);
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Close child window <b>" + windowTitle + "</b>", "Child window should  be closed",
						"Child window <b>" + windowTitle + "</b> closed");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Close child window", "Child window should  be closed", "Window not exist");

			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Close child window", "Child window should  be closed", "Window not exist");
			Demo1.logger.error("error in CloseChildWindow " + e.getMessage());
		}
	}

	/**
	 * Verifies the expected text
	 */
	public static void VerifyText(String tag, String expectedText) {
		if (Demo1.driver.findElement(By.tagName(tag)).getText().contains(expectedText)) {
			// Add Report step
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Text verification: <b>" + expectedText + "</b>",
					"Expected text <b>" + expectedText + "</b> should be present",
					"<b>" + expectedText + "</b> present as expected");

		} else {
			// Add Report step
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Vefify text: <b>" + expectedText + "</b>",
					"Text <b>" + expectedText + "</b> should be present", "<b>" + expectedText + "</b> not present");
		}
	}

	/**
	 * Compares the expected text with actual
	 */
	public static boolean TextCompare(final By locator, String textToCompare) {
		if (Demo1.driver.findElement(locator).getText().contains(textToCompare)) {
			// Add Report step
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Compare text: <b>" + textToCompare + "</b>",
					"Expected text <b>" + textToCompare + "</b> should be present",
					"<b>" + textToCompare + "</b> present as expected");
			return true;

		} else {
			// Add Report step
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Compare text: <b>" + textToCompare + "</b>",
					"Expected text <b>" + textToCompare + "</b> should be present", "Expected text not present");
			return false;
		}
	}

	/**
	 * Check whether the element is exist or not
	 */
	public static void Verify_ElementDisplayed(String locator, int timeInSeconds) {
		// String locator="id=signOnName";
		String[] param;
		String delimiter = "=";
		param = locator.split(delimiter);

		if (param[0].equals("id")) {
			WebElement element;
			Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(timeInSeconds));
			element = Demo1.driver.findElement(By.id(locator));
			if (element.isDisplayed()) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verifies element existence", "Element should be displayed", "Element displayed");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verifies element existence", "Element should be displayed",
						"Element not displayed");
			}
		} else if (param[0].equals("name")) {
			WebElement element;
			Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(timeInSeconds));
			element = Demo1.driver.findElement(By.name(locator));
			if (element.isDisplayed()) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verifies element existence", "Element should be displayed", "Element displayed");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verifies element existence", "Element should be displayed",
						"Element not displayed");
			}
		} else if (param[0].equals("xpath")) {
			WebElement element;
			Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(timeInSeconds));
			element = Demo1.driver.findElement(By.xpath(locator));
			if (element.isDisplayed()) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verifies element existence", "Element should be displayed", "Element displayed");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verifies element existence", "Element should be displayed",
						"Element not displayed");
			}
		} else if (param[0].equals("dom")) {

		} else if (param[0].equals("css")) {
			WebElement element;
			Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(timeInSeconds));
			element = Demo1.driver.findElement(By.cssSelector(locator));
			if (element.isDisplayed()) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verifies element existence", "Element should be displayed", "Element displayed");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verifies element existence", "Element should be displayed",
						"Element not displayed");
			}
		} else {
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verifies element existence", "Element should be displayed",
					"Lcater <b>" + param[0] + "</b> type not available");
		}

		Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Config.TIME_OUT));

	}

	/**
	 * returns true if the expected text is present else false
	 */
	public static boolean Verify_IsTextPresent(final By locator, String expectedText) {
		Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		WebElement element = Demo1.driver.findElement(locator);
		if (element.isDisplayed()) {
			return element.getText().contentEquals(expectedText);
		} else {
			return false;
		}
	}

	public static Boolean waitForTextToAppear(final By locator) {

		Wait<WebDriver> wait = new FluentWait<>(Demo1.driver).withTimeout(Duration.ofSeconds(Config.TIME_OUT))
				.pollingEvery(Duration.ofMillis(600)).ignoring(NoSuchElementException.class);

		Boolean element = false;
		try {
			element = wait.until(new Function<WebDriver, Boolean>() {

				@Override
				public Boolean apply(WebDriver driver) {
					String s = Demo1.driver.findElement(locator).getText();
					if (s == null || (s != null & s.trim().isEmpty())) {
						s = "";
					}
					return (!s.trim().isEmpty());
				}
			});
		} catch (Exception e) {
			Reuse.log(e);

		}
		return element;
	}

	/**
	 * Compares the expected text with actual
	 */
	public static void Verify_TextPresent(final By by, String expectedText, String elementName) {
		try {
			waitForTextToAppear(by);
			String actualText = Demo1.driver.findElement(by).getText();
			if (actualText != null & actualText.trim().isEmpty()) {
				actualText = Demo1.driver.findElement(by).getAttribute("value");
				if (actualText == null) {
					actualText = "";
				}
			}
			actualText = escapeHtml3(actualText);
			Reuse.log("actualText :" + actualText);

			System.out.println("EXPECTED TEXT:::" + expectedText);

			if (expectedText.contains("auto@")) {
				expectedText = expectedText.substring(expectedText.indexOf("auto@") + "auto@".length(),
						expectedText.length() - 1);

				System.out.println("RUNTIME VARIABLE:::" + expectedText);

				expectedText = StoreText.txtAndVal.get(expectedText);
				System.out.println("EXPECTED TEXT UPDATED:::" + expectedText);
			}

			Reuse.log("expectedText :" + expectedText);

			if (expectedText.toUpperCase().contentEquals("EMPTY") || expectedText.isEmpty()) {

				if (actualText.isEmpty()) {
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Verifying element <b>" + elementName + "</b> to be empty",
							"Element should be empty", "Element is empty");
				} else {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Verifying element <b>" + elementName + "</b> to be empty",
							"Element should be empty", "Element is not empty");
				}

			} else if (actualText.toUpperCase().contentEquals(expectedText.toUpperCase())) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2,
						"Verify text <b>" + expectedText + "</b> present for the element <b>" + elementName + "</b>",
						"<b>" + expectedText + "</b> text should be present", "<b>" + actualText + "</b> present");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> present",
						"<b>" + expectedText + "</b> text should be present", "Actual text <b>" + actualText + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);

			Demo1.logger.error("error method Verify_TextPresent in " + e.getClass().getName());
			Demo1.logger.error(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> present",
					"<b>" + expectedText + "</b> text should be present",
					"Unable to locate <b>" + elementName + "</b>");
		}
	}

	public static void shadow_Verify_TextPresent(String by, String expectedText, String elementName) {
		try {

			WebElement element;

//          Reuse.waitForTextToAppear(by);

			Shadow shadow = new Shadow(Demo1.driver);

			element = shadow.findElement(by);

			String actualText = element.getText();
			if (actualText != null & actualText.trim().isEmpty()) {
				actualText = element.getAttribute("value");
				if (actualText == null) {
					actualText = "";
				}
			}

			actualText = escapeHtml3(actualText);
			Reuse.log("actualText :" + actualText);

			System.out.println("EXPECTED TEXT:::" + expectedText);

			if (expectedText.contains("auto@")) {
				expectedText = expectedText.substring(expectedText.indexOf("auto@") + "auto@".length(),
						expectedText.length() - 1);

				System.out.println("RUNTIME VARIABLE:::" + expectedText);

				expectedText = StoreText.txtAndVal.get(expectedText);
				System.out.println("EXPECTED TEXT UPDATED:::" + expectedText);
			}

			Reuse.log("expectedText :" + expectedText);

			if (expectedText.toUpperCase().contentEquals("EMPTY") || expectedText.isEmpty()) {

				if (actualText.isEmpty()) {
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Verifying element <b>" + elementName + "</b> to be empty",
							"Element should be empty", "Element is empty");
				} else {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Verifying element <b>" + elementName + "</b> to be empty",
							"Element should be empty", "Element is not empty");
				}

			} else if (actualText.toUpperCase().contentEquals(expectedText.toUpperCase())) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2,
						"Verify text <b>" + expectedText + "</b> present for the element <b>" + elementName + "</b>",
						"<b>" + expectedText + "</b> text should be present", "<b>" + actualText + "</b> present");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> present",
						"<b>" + expectedText + "</b> text should be present", "Actual text <b>" + actualText + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);

			Demo1.logger.error("error method Verify_TextPresent in " + e.getClass().getName());
			Demo1.logger.error(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> present",
					"<b>" + expectedText + "</b> text should be present",
					"Unable to locate <b>" + elementName + "</b>");
		}
	}

	public static void Verify_TextPresent_IgnoreCase(final By by, String expectedText, String elementName) {
		try {
			String actualText = Demo1.driver.findElement(by).getText();
			if (actualText != null & actualText.trim().isEmpty()) {
				actualText = Demo1.driver.findElement(by).getAttribute("value");
				if (actualText == null) {
					actualText = "";
				}
			}
			actualText = escapeHtml3(actualText);
			Reuse.log("actualText :" + actualText);
			Reuse.log("expectedText :" + expectedText);
			if (actualText.equalsIgnoreCase(expectedText)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2,
						"Verify text <b>" + expectedText + "</b> present for the element <b>" + elementName + "</b>",
						"<b>" + expectedText + "</b> text should be present", "<b>" + actualText + "</b> present");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> present",
						"<b>" + expectedText + "</b> text should be present", "Actual text <b>" + actualText + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);

			Demo1.logger.error("error method Verify_TextPresent in " + e.getClass().getName());
			Demo1.logger.error(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> present",
					"<b>" + expectedText + "</b> text should be present",
					"Unable to locate <b>" + elementName + "</b>");
		}
	}

	/**
	 * Compares the expected text with actual
	 */

	public static void Verify_TextContains(final By by, String expectedText, String elementName) {
		try {
			Reuse.waitForTextToAppear(by);
			String actualText = Demo1.driver.findElement(by).getText();
			if (actualText != null & actualText.trim().isEmpty()) {
				actualText = Demo1.driver.findElement(by).getAttribute("value");
				if (actualText == null) {
					actualText = "";
				}
			}

			System.out
					.println("Actual Text ::::" + actualText.replace("\n", "").replace("\r\n", "").replace("\n\r", ""));

			System.out.println(expectedText + "expectedText");

			if (!Config.wealthWsc) {
				actualText = actualText.replace("\n", "").replace("\r\n", "").replace("\n\r", "");
			}
			actualText = escapeHtml3(actualText);

			if (expectedText.contains("auto@")) {
				String runTimeVariableName = expectedText.replace("auto@", "");
				runTimeVariableName = runTimeVariableName.substring(0, runTimeVariableName.length() - 1);

				expectedText = StoreText.txtAndVal.get(runTimeVariableName);

//                expectedText = GetPropertyValue(expectedText);
			}

			System.out.println(expectedText + "expectedText");

			if (actualText.toUpperCase().contains(expectedText.toUpperCase())) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify text <b>" + actualText + "</b> contains <b>" + expectedText + "</b>",
						"<b>" + actualText + "</b> should contains <b>" + expectedText + "</b>",
						"<b>" + actualText + "</b> text contains <b>" + expectedText + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + actualText + "</b> contains <b>" + expectedText + "</b>",
						"<b>" + actualText + "</b> should contains <b>" + expectedText + "</b>",
						"Actual text <b>" + actualText + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);

			Demo1.logger.error("error method Verify_TextContains in " + e.getMessage());
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> contains",
					"Should be contains <b>" + expectedText + "</b>",
					"Unable to locate <b>" + elementName + "</b> element");
		}
	}

	public static void Verify_TextContains2(final By by, String expectedText, String elementName) {
		try {
			Reuse.waitForTextToAppear(by);
			String actualText = Demo1.driver.findElement(by).getText();
			if (actualText != null & actualText.trim().isEmpty()) {
				actualText = Demo1.driver.findElement(by).getAttribute("value");
				if (actualText == null) {
					actualText = "";
				}
			}

			System.out.println(expectedText + "expectedText");

			if (!Config.wealthWsc) {
				actualText = actualText.replace("\n", "").replace("\r\n", "").replace("\n\r", "");
			}
//            actualText = escapeHtml3(actualText);

			System.out.println("Actual Text ::::" + actualText);

			/*
			 * if (expectedText.contains("auto@")) { String runTimeVariableName =
			 * expectedText.replace("auto@", ""); runTimeVariableName =
			 * runTimeVariableName.substring(0, runTimeVariableName.length() - 1);
			 * 
			 * expectedText = StoreText.txtAndVal.get(runTimeVariableName);
			 * 
			 * // expectedText = GetPropertyValue(expectedText); }
			 */

			if (expectedText.contains("auto@")) {
				expectedText = Reuse.updateRuntimeValuesInOfs(expectedText);
			}

			System.out.println(expectedText + "expectedText");

			if (actualText.contains(expectedText)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify text <b>" + actualText + "</b> contains <b>" + expectedText + "</b>",
						"<b>" + actualText + "</b> should contains <b>" + expectedText + "</b>",
						"<b>" + actualText + "</b> text contains <b>" + expectedText + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + actualText + "</b> contains <b>" + expectedText + "</b>",
						"<b>" + actualText + "</b> should contains <b>" + expectedText + "</b>",
						"Actual text <b>" + actualText + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);

			Demo1.logger.error("error method Verify_TextContains in " + e.getMessage());
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> contains",
					"Should be contains <b>" + expectedText + "</b>",
					"Unable to locate <b>" + elementName + "</b> element");
		}
	}

	public static void shadow_Verify_TextContains(String by, String expectedText, String elementName) {
		try {
			WebElement element;

//            Reuse.waitForTextToAppear(by);

			Shadow shadow = new Shadow(Demo1.driver);

			element = shadow.findElement(by);

			String actualText = element.getText();
			if (actualText != null & actualText.trim().isEmpty()) {
				actualText = element.getAttribute("value");
				if (actualText == null) {
					actualText = "";
				}
			}

			System.out
					.println("Actual Text ::::" + actualText.replace("\n", "").replace("\r\n", "").replace("\n\r", ""));

			if (!Config.wealthWsc) {
				actualText = actualText.replace("\n", "").replace("\r\n", "").replace("\n\r", "");
			}
			actualText = escapeHtml3(actualText);

			if (expectedText.contains("auto@")) {
				String runTimeVariableName = expectedText.replace("auto@", "");
				runTimeVariableName = runTimeVariableName.substring(0, runTimeVariableName.length() - 1);

				expectedText = StoreText.txtAndVal.get(runTimeVariableName);
			}

			if (actualText.toUpperCase().contains(expectedText.toUpperCase())) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify text <b>" + actualText + "</b> contains <b>" + expectedText + "</b>",
						"<b>" + actualText + "</b> should contains <b>" + expectedText + "</b>",
						"<b>" + actualText + "</b> text contains <b>" + expectedText + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + actualText + "</b> contains <b>" + expectedText + "</b>",
						"<b>" + actualText + "</b> should contains <b>" + expectedText + "</b>",
						"Actual text <b>" + actualText + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);

			Demo1.logger.error("error method Verify_TextContains in " + e.getMessage());
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> contains",
					"Should be contains <b>" + expectedText + "</b>",
					"Unable to locate <b>" + elementName + "</b> element");
		}
	}

	public static void Verify_TextNotContains(final By by, String expectedText, String elementName) {
		try {
			String actualText = Demo1.driver.findElement(by).getText();
			if (actualText != null & actualText.trim().isEmpty()) {
				actualText = Demo1.driver.findElement(by).getAttribute("value");
				if (actualText == null) {
					actualText = "";
				}
			}
			actualText = escapeHtml3(actualText);
			if (!actualText.contains(expectedText)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify text <b>" + actualText + "</b> not contains <b>" + expectedText + "</b>",
						"<b>" + actualText + "</b> should not contains <b>" + expectedText + "</b>",
						"Actual text <b>" + actualText + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + actualText + "</b> not contains <b>" + expectedText + "</b>",
						"<b>" + actualText + "</b> should not contains <b>" + expectedText + "</b>",
						"Actual text <b>" + actualText + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);

			Demo1.logger.error("error method Verify_TextNotContains in " + e.getClass().getName());
			Demo1.logger.error(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> not contains",
					"Should not be contains <b>" + expectedText + "</b>",
					"Unable to locate <b>" + elementName + "</b> element");
		}
	}

	public static void shadow_Verify_TextNotPresent(String by, String expectedText, String elementName) {
		try {

			WebElement element;

			// Reuse.waitForTextToAppear(by);

			Shadow shadow = new Shadow(Demo1.driver);

			element = shadow.findElement(by);

			String actualText = element.getText();
			if (actualText != null & actualText.trim().isEmpty()) {
				actualText = element.getAttribute("value");
				if (actualText == null) {
					actualText = "";
				}
			}
			actualText = escapeHtml3(actualText);
			if (!actualText.contains(expectedText)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> not present",
						"<b>" + expectedText + "</b> should not be present", "Actual text <b>" + actualText + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> not present",
						"<b>" + expectedText + "</b> should not be present", "Actual text <b>" + actualText + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "False";
			Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> not present",
					"<b>" + expectedText + "</b> should not be present", "Unable to locate <b>" + elementName + "</b>");
		}
	}

	/**
	 * Compares the expected text with actual
	 */
	public static void Verify_TextNotPresent(final By by, String text, String elementName) {
		try {
			String actualText = Demo1.driver.findElement(by).getText();
			if (actualText != null & actualText.trim().isEmpty()) {
				actualText = Demo1.driver.findElement(by).getAttribute("value");
				if (actualText == null) {
					actualText = "";
				}
			}
			actualText = escapeHtml3(actualText);
			if (!actualText.contains(text)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify text <b>" + text + "</b> not present",
						"<b>" + text + "</b> should not be present", "Actual text <b>" + actualText + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + text + "</b> not present",
						"<b>" + text + "</b> should not be present", "Actual text <b>" + actualText + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "False";
			Demo1.ReportStep(2, "Verify text <b>" + text + "</b> not present",
					"<b>" + text + "</b> should not be present", "Unable to locate <b>" + elementName + "</b>");
		}
	}

	public static void oVerify_TextNotPresentinTable(final By by, String expectedtext, String elementName) {

		try {
			if (expectedtext.contains("auto@"))
				expectedtext = Reuse.updateRuntimeValuesInOfs(expectedtext);
			Reuse.log("expectedText :" + expectedtext);
			List<WebElement> elements = Demo1.driver.findElements(by);
			boolean isOptExist = false;
			String actual = null;
			for (WebElement ele : elements) {
				actual = ele.getText();
				if (actual.equals(expectedtext)) {
					isOptExist = true;
					break;
				}
			}
			if (!isOptExist) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify text <b>" + expectedtext + "</b> not present",
						"<b>" + expectedtext + "</b> should not be present",
						"<b>" + expectedtext + "</b> is not present");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + expectedtext + "</b> not present",
						"<b>" + expectedtext + "</b> should not be present", "<b>" + expectedtext + "</b> is present");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>" + expectedtext + "</b> not present",
					"<b>" + expectedtext + "</b> should not be present", "Unable to locate <b>" + elementName + "</b>");
		}
	}

	public static void oVerify_TextPresentinTable(final By by, String expectedtext, String elementName) {
		try {

			if (expectedtext.contains("auto@"))
				expectedtext = Reuse.updateRuntimeValuesInOfs(expectedtext);
			Reuse.log("expectedText :" + expectedtext);
			List<WebElement> elements = Demo1.driver.findElements(by);
			boolean isOptExist = false;
			String actual = null;
			for (WebElement ele : elements) {
				actual = ele.getText();
				// System.out.println(actual);
				if (actual.equals(expectedtext)) {
					isOptExist = true;
					break;
				}
			}
			if (!isOptExist) {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + expectedtext + "</b> is present",
						"<b>" + expectedtext + "</b> should be present", "<b>" + expectedtext + "</b> is not present");
			} else {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify text <b>" + expectedtext + "</b> is present",
						"<b>" + expectedtext + "</b> should be present", "<b>" + expectedtext + "</b> is present");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>" + expectedtext + "</b> is present",
					"<b>" + expectedtext + "</b> should be present", "Unable to locate <b>" + elementName + "</b>");
		}
	}

	/**
	 * Maximize window
	 */
	public static void Maximize() {
		try {
			Demo1.driver.manage().window().maximize();
			Demo1.driver.switchTo().activeElement();
			Thread.sleep(1000);
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Maximize window", "Window should be maximized", e.getMessage());
		}
	}

	/**
	 * Closes browser
	 */
	public static void CloseWindow(String windowTitle) {
		try {
			boolean isWinClosed = false;
			String currentWindow = Demo1.driver.getWindowHandle();
			for (String winHandle : Demo1.driver.getWindowHandles()) {
				if (Demo1.driver.switchTo().window(winHandle).getTitle().equals(windowTitle)) {
					Demo1.driver.switchTo().window(winHandle).close();

					for (String winHandl : Demo1.driver.getWindowHandles()) {
						Demo1.driver.switchTo().window(winHandl);
						break;
					}

					isWinClosed = true;
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Close window <b>" + windowTitle + "</b>",
							"<b>" + windowTitle + "</b> window should be closed", "Closed");
					break;
				}
			}
			if (!isWinClosed) {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Close window <b>" + windowTitle + "</b>",
						"<b>" + windowTitle + "</b> window should be closed",
						"Window <b>" + windowTitle + "</b> not found. Please check the window title");
			}

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Close window <b>" + windowTitle + "</b>",
					"<b>" + windowTitle + "</b> window should be closed", e.getMessage());
		}

	}

	/**
	 * Splits the string
	 *
	 * @return array
	 */
	public static String[] SplitString(String str, String delimiter) {
		String[] params;
		try {
			return params = str.split(delimiter);
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Splits the string", "String should be split with the specified delimiter",
					e.getMessage());
		}
		return null;
	}

	/**
	 * Highlights the Element
	 */
	public static void HighlightElement(WebElement element) {

		try {
			for (int i = 0; i < 2; i++) {
				JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
				js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element,
						"color: black; border: 2px solid black;");
				js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Highlights the Element", "Should be Highlights the specified element",
					e.getMessage().toString());
		}
	}

	public static void HighlightElement(By by, String elementType, String elementName) {

		try {
			WebElement element = Demo1.driver.findElement(by);
			for (int i = 0; i < 2; i++) {
				JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
				js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element,
						"color: black; border: 2px solid black;");
				js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			// Demo1.gbTestCaseStatus = "Fail";
			// Demo1.ReportStep(2, "Highlights the Element","Should be
			// Highlights the specified element", e.getMessage().toString());
		}
	}

	public static void Focus(String eleName, String locTyep, String locator) {
		JavascriptExecutor js = null;
		try {
			js = (JavascriptExecutor) Demo1.driver;
			if (locTyep.equalsIgnoreCase("id")) {
				js.executeScript("document.getElementById('" + locator + "').focus();");

			} else if (locTyep.equalsIgnoreCase("xpath")) {
				WebElement element1 = Demo1.driver.findElement(By.xpath(locator));

				((JavascriptExecutor) Demo1.driver).executeScript("arguments[0].scrollIntoView(true);", element1);

				// js.executeScript("document.getElementByXPath('" + locator +
				// "').focus();");
			}
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Focus on Element <b>" + eleName + "</b>",
					"Should be Focussed on <b>" + eleName + "</b>", "Focussed");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Focus on Element <b>" + eleName + "</b>",
					"Should be Focussed on <b>" + eleName + "</b>", e.getMessage());
		}

	}

	public static void Focus(WebElement element) {
		Actions actions = null;
		try {
			actions = new Actions(Demo1.driver);
			actions.moveToElement(element).build().perform();
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("Error in Focus. " + e);
		} finally {
			actions = null;
		}
	}

	/**
	 * returns the specified text After splitting the string
	 */
	public static String GetText(String xpath, String strStrartsWith, String delimiter) {
		WebElement element;
		String[] strArray;
		try {
			element = Demo1.driver.findElement(By.xpath(xpath));
			String text = element.getText();
			strArray = SplitString(text, delimiter);
			for (String str : strArray) {
				if (str.startsWith(strStrartsWith)) {
					return str;
				}
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Get the text", "Returns the expected text from a specified string", e.getMessage());
		}
		return null;
	}

	/**
	 * returns true if the expected text is present else false
	 *
	 * @return true/false
	 */
	public static boolean GetText(final By locater) {
		WebElement element;
		String[] strArray;
		try {
			element = Demo1.driver.findElement(locater);
			String text = element.getText();
			// strArray=SplitString(text,delimiter);
			// for(String str:strArray){
			// if(str.startsWith(strStrartsWith)){
			// return true;
			// }
			// }
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Get the text", "Returns the expected text from a specified string",
					e.getMessage().toString());
		}
		return false;
	}

	/**
	 * Returns the text
	 */
	public static String GetText(String xpath) {
		WebElement element;
		try {
			element = Demo1.driver.findElement(By.xpath(xpath));
			String text = element.getText();
			return text;

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Get the text", "Returns the text", e.getMessage());
		}
		return null;
	}

	/**
	 * To initialize and launch the browser
	 *
	 * @param browser - required browser
	 * @param hostIp  - ip of the host machine
	 */
	public static void BrowserInitialization(String browser, String hostIp) throws Exception {
		DesiredCapabilities capabilities = new DesiredCapabilities();
		URL url = new URL("http", hostIp, 4444, "/wd/hub");

		if (browser == "iexplore") {
			// capabilities = DesiredCapabilities.internetExplorer();
		} else if (browser == "chrome") {
			// capabilities = DesiredCapabilities.firefox();
		} else if (browser == "googlechrome") {
			// capabilities = DesiredCapabilities.chrome();
		} else if (browser == "opera") {
			// capabilities = DesiredCapabilities.opera();
		} else if (browser == "safari") {
			// capabilities = DesiredCapabilities.safari();
		} else if (browser == "html") {
			// capabilities = DesiredCapabilities.htmlUnit();
		} else {
			System.out.println(
					"Browser <b>" + browser + "</b> not available, hence launching the default browser - FIREFOX");
			// capabilities = DesiredCapabilities.firefox();
		}
		// capabilities.setJavascriptEnabled(true);

		Demo1.driver = new RemoteWebDriver(url, capabilities);
	}

	public static void LaunchResultsFile() {
		// Code for Launch the HTML file
		// curDir = System.getProperty("user.dir");
		// String htmlFilePath = curDir + "\\HTMLResults\\index_qeda.htm"; //
		// path to your new file
		try {
			Runtime rTime = Runtime.getRuntime();
			String browser = "C:/Program Files/Internet Explorer/iexplore.exe ";
			String url = "D:Selenium\\FW\\AppWebDriver\\HTMLResults\\qeda\\index_qeda.htm";
			Process pc;
			pc = rTime.exec(browser + url);
			pc.waitFor();
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
		}
	}

	/**
	 * @param propertyType
	 * @param propertyName
	 * @param optionToSelect
	 * @throws IOException
	 */
	public static void SelectOptionFromList(String propertyType, String propertyName, String optionToSelect) {
		try {
			WebElement select = Demo1.driver
					.findElement(By.xpath("//*[contains(@" + propertyType + ",'" + propertyName + "')]"));
			Select dropDown = new Select(select);
			List<WebElement> Options = dropDown.getOptions();
			boolean isOptExist = false;
			for (WebElement option : Options) {
				if (option.getText().equals(optionToSelect)) {
					option.click(); // select option here;
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Select the Option " + optionToSelect,
							"The Option " + optionToSelect + " should be selected",
							"The Option " + optionToSelect + " selected");
					isOptExist = true;
					break;
				}
			}
			if (!isOptExist) {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Select the Option " + optionToSelect,
						"The Option " + optionToSelect + " should be selected",
						"The Option " + optionToSelect + " is not selected");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Select the Option " + optionToSelect,
					"The Option " + optionToSelect + " should be selected", e.getMessage().toString());
		}
	}

	/**
	 * @param propertyType
	 * @param propertyName
	 * @param expectedOption
	 * @throws IOException
	 */
	public static void CheckOptionExistInList(String propertyType, String propertyName, String expectedOption) {
		try {
			WebElement select = Demo1.driver
					.findElement(By.xpath("//*[contains(@" + propertyType + ",'" + propertyName + "')]"));
			Select dropDown = new Select(select);
			List<WebElement> Options = dropDown.getOptions();
			boolean isOptExist = false;
			for (WebElement option : Options) {
				if (option.getText().equals(expectedOption)) {
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Verify the Option Exist " + expectedOption,
							"The Option " + expectedOption + " should be exist",
							"The Option " + expectedOption + " exist");
					isOptExist = true;
					break;
				}
			}
			if (!isOptExist) {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify the Option Exist " + expectedOption,
						"The Option " + expectedOption + " should be exist",
						"The Option " + expectedOption + " is not exist");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify the Option Exist " + expectedOption,
					"The Option " + expectedOption + " should be exist", e.getMessage().toString());
		}
	}

	public static void Dropdown_OptionExist(By by, String expectedOption, String dropdownName) {
		Select dropDown = null;
		try {
			WebElement select = Demo1.driver.findElement(by);
			// Select class initialization
			dropDown = new Select(select);
			List<WebElement> Options = dropDown.getOptions();
			boolean isOptExist = false;
			for (WebElement option : Options) {
				if (option.getText().trim().equals(expectedOption.trim())) {
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2,
							"Verify item <b>" + expectedOption + "</b> in <b>" + dropdownName + "</> dropdown",
							"<b>" + expectedOption + "</b> should be exist", "<b>" + expectedOption + "</b> exist");
					isOptExist = true;
					break;
				}
			}
			if (!isOptExist) {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify item <b>" + expectedOption + "</b> in <b>" + dropdownName + "</> dropdown",
						"<b>" + expectedOption + "</b> should be exist", "<b>" + expectedOption + "</b> not exist");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify item <b>" + expectedOption + "</b> in <b>" + dropdownName + "</> dropdown",
					"<b>" + expectedOption + "</b> should be exist",
					"Unable to locate <b>" + dropdownName + "</b> dropdown");
		} finally {
			dropDown = null;
		}
	}

	public static void Dropdown_OptionsAvailable(By by, String dropdownName) {
		try {
			WebElement select = Demo1.driver.findElement(by);
			// Select class initialization
			Select dropDown = new Select(select);
			int optionsCnt = dropDown.getOptions().size();
			if (dropDown.getOptions().size() > 0) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Check Options exist in <b>" + dropdownName + "</b> dropdown",
						"Options should be exist", "Number of options count <b> " + optionsCnt + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check Options exist in <b>" + dropdownName + "</b> dropdown",
						"Options should be exist", "Number of options count <b> " + optionsCnt + "</b>");
			}

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check Options exist in <b>" + dropdownName + "</b> dropdown",
					"Options should be exist", "Unable to locate <b> " + dropdownName + "</b>");
		}
	}

	public static void Dropdown_OptionsCount(int expCount, String dropdownName, By by) {
		try {
			WebElement select = Demo1.driver.findElement(by);
			// Select class initialization
			Select dropDown = new Select(select);
			int optionsCnt = dropDown.getOptions().size();
			if (optionsCnt == expCount) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(
						2, "Check Options count in <b>" + dropdownName + "</b> dropdown", "The Dropdown " + dropdownName
								+ " options count should be matched with the expected count <b>" + expCount + "</b>",
						"Actual options count <b> " + optionsCnt + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(
						2, "Check Options count in <b>" + dropdownName + "</b> dropdown", "The Dropdown " + dropdownName
								+ " options count should be matched with the expected count <b>" + expCount + "</b>",
						"Actual options count <b> " + optionsCnt + "</b>");
			}

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check Options exist in <b>" + dropdownName + "</b> dropdown",
					"Options should be exist", "Unable to locate <b> " + dropdownName + "</b>");
		}
	}

	public static void Dropdown_OptionsNotAvailable(By by, String dropdownName) {
		try {
			WebElement select = Demo1.driver.findElement(by);
			// Select class initialization
			Select dropDown = new Select(select);
			int optionsCnt = dropDown.getOptions().size();
			if (dropDown.getOptions().size() > 0) {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check Options exist in <b>" + dropdownName + "</b> dropdown",
						"Options should be exist", "Number of options count <b> " + optionsCnt + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Check Options exist in <b>" + dropdownName + "</b> dropdown",
						"Options should be exist", "Number of options count <b> " + optionsCnt + "</b>");
			}

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check Options exist in <b>" + dropdownName + "</b> dropdown",
					"Options should be exist", "Unable to locate <b> " + dropdownName + "</b>");
		}
	}

	public static void Dropdown_SelectItem(By by, String itemToSelect, String dropdownName) {
		Demo1.logger.info("ITEM TO SELECT::" + itemToSelect);
		try {
			WebElement select = Demo1.driver.findElement(by);
			Focus(Demo1.driver.findElement(by));
			Select dropDown = new Select(select);

			List<WebElement> Options = dropDown.getOptions();
			boolean isOptExist = false;
			for (WebElement option : Options) {
				Demo1.logger.info("OPTION::" + option);
				if (option.getText().equals(itemToSelect)) {
					option.click();

					if (Config.wealthRun) {
						// newly added to test the loader element
						try {
							Thread.sleep(100);
						} catch (InterruptedException e) {
							e.printStackTrace();
							System.out.println("Error while adding sleep time");
						}
						checkWealthSpinnerElement();
					}

					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
							"Item <b>" + itemToSelect + "</b> should be selected",
							"<b>" + itemToSelect + "</b> Selected");
					isOptExist = true;
					break;
				}
			}
			if (!isOptExist) {

				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
						"Item <b>" + itemToSelect + "</b> should be selected", "<b>" + itemToSelect + "</b> not exist");
			}

		} catch (Exception e) {
			Reuse.log(e);
            e.printStackTrace();
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
					"Should be select <b>" + itemToSelect + "</b>",
					"Unable to locate dropdown <b>" + dropdownName + "</b>");
		}
	}

	public static void Shadow_Dropdown_SelectItem(String by, String itemToSelect, String dropdownName) {
		try {

			Shadow shadow = new Shadow(Demo1.driver);
//          shadow.findElement(by);

			WebElement select = shadow.findElement(by);
			Focus(shadow.findElement(by));
			Select dropDown = new Select(select);

			List<WebElement> Options = dropDown.getOptions();
			boolean isOptExist = false;
			for (WebElement option : Options) {
				if (option.getText().equals(itemToSelect)) {
					option.click();

					if (Config.wealthRun) {
						checkWealthSpinnerElement();
					}

					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
							"Item <b>" + itemToSelect + "</b> should be selected",
							"<b>" + itemToSelect + "</b> Selected");
					isOptExist = true;
					break;
				}
			}
			if (!isOptExist) {

				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
						"Item <b>" + itemToSelect + "</b> should be selected", "<b>" + itemToSelect + "</b> not exist");
			}

		} catch (Exception e) {
			Reuse.log(e);

			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
					"Should be select <b>" + itemToSelect + "</b>",
					"Unable to locate dropdown <b>" + dropdownName + "</b>");
		}
	}

	public static void DropdownSelectVisibleText(By by, String itemToSelect, String dropdownName) {
		try {
			if (isElementPresent(by)) {

				WebElement select = Demo1.driver.findElement(by);
				Select dropDown = new Select(select);
				dropDown.selectByVisibleText(itemToSelect);
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
						"Item <b>" + itemToSelect + "</b> should be selected", "<b>" + itemToSelect + "</b> Selected");
			} else {

				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
						"Item <b>" + itemToSelect + "</b> should be selected", "<b>" + itemToSelect + "</b> not exist");
			}

		} catch (Exception e) {
			Reuse.log(e);

			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
					"Should be select <b>" + itemToSelect + "</b>",
					"Unable to locate dropdown <b>" + dropdownName + "</b>");
		}
	}

	public static void shadow_DropdownSelectVisibleText(String by, String itemToSelect, String dropdownName) {
		try {

			Shadow shadow = new Shadow(Demo1.driver);
//            shadow.findElement(by);

			if (shadow.findElement(by).isDisplayed()) {

				Select dropDown = new Select(shadow.findElement(by));

				dropDown.selectByVisibleText(itemToSelect);
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
						"Item <b>" + itemToSelect + "</b> should be selected", "<b>" + itemToSelect + "</b> Selected");
			} else {

				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
						"Item <b>" + itemToSelect + "</b> should be selected", "<b>" + itemToSelect + "</b> not exist");
			}

		} catch (Exception e) {
			Reuse.log(e);

			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
					"Should be select <b>" + itemToSelect + "</b>",
					"Unable to locate dropdown <b>" + dropdownName + "</b>");
		}
	}

	public static void shadow_DropdownSelectByValue(String by, String itemToSelect, String dropdownName) {
		try {

			Shadow shadow = new Shadow(Demo1.driver);
//            shadow.findElement(by);

			if (shadow.findElement(by).isDisplayed()) {

				Select dropDown = new Select(shadow.findElement(by));

				dropDown.selectByValue(itemToSelect);
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
						"Item <b>" + itemToSelect + "</b> should be selected", "<b>" + itemToSelect + "</b> Selected");
			} else {

				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
						"Item <b>" + itemToSelect + "</b> should be selected", "<b>" + itemToSelect + "</b> not exist");
			}

		} catch (Exception e) {
			Reuse.log(e);

			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
					"Should be select <b>" + itemToSelect + "</b>",
					"Unable to locate dropdown <b>" + dropdownName + "</b>");
		}
	}

	public static void dropdownSelectItemContains(By by, String itemToSelect, String dropdownName) {
		try {
			if (isElementPresent(by)) {
				JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;

				String fn = "function setSelectedValue(selectObj, valueToSet) {\n"
						+ "    for (var i = 0; i < selectObj.options.length; i++) {\n"
						+ "        var itemName = selectObj.options[i].text;\n"
						+ "        if (itemName.indexOf(valueToSet)>=0) {\n"
						+ "            selectObj.options[i].selected = true;\n" +

						"        }\n" + "    }\n" + "};setSelectedValue(arguments[0], arguments[1]);";

				js.executeScript(fn, Demo1.driver.findElement(by), itemToSelect);
				Select sel = new Select(Demo1.driver.findElement(by));
				String selected = sel.getFirstSelectedOption().getText();
				List<WebElement> opts = sel.getOptions();
				for (WebElement e : opts) {
					System.out.println("Available option=>" + e.getText());
				}
				js.executeScript("$(arguments[0]).trigger('change');", Demo1.driver.findElement(by));
				if (selected.trim().toLowerCase().contains(itemToSelect.trim().toLowerCase())) {
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2,
							"Select dropdown item contains <b>" + itemToSelect + "</b> from <b>" + dropdownName
									+ "</b> dropdown",
							"Item contains <b>" + itemToSelect + "</b> value should be selected",
							"<b>" + itemToSelect + "</b> Selected");
				} else {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2,
							"Select dropdown item contains <b>" + itemToSelect + "</b> from <b>" + dropdownName
									+ "</b> dropdown",
							"Item contains <b>" + itemToSelect + "</b> value should be selected",
							"Item contains <b>" + itemToSelect + "</b> is not found");
				}

			} else {

				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2,
						"Select item contains <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
						"Item contains <b>" + itemToSelect + "</b> should be selected",
						"<b>" + itemToSelect + "</b> not exist");
			}

		} catch (Exception e) {
			Reuse.log(e);

			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
					"Should be select <b>" + itemToSelect + "</b>",
					"Unable to locate dropdown <b>" + dropdownName + "</b>");
		}
	}

	public static void SelectOptionByIndex(String dropdownName, int index, By by) {
		SelectOptionByIndex(dropdownName, index, by, false);
	}

	public static void Shadow_JavaScriptDragAndDrop(String by, String by1, String elementName) {
		try {
			WebElement From = (WebElement) ((JavascriptExecutor) Demo1.driver).executeScript("return " + by);
			WebElement To = (WebElement) ((JavascriptExecutor) Demo1.driver).executeScript("return " + by1);
			JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
			js.executeScript("function createEvent(typeOfEvent) {\n"
					+ "var event =document.createEvent(\"CustomEvent\");\n"
					+ "event.initCustomEvent(typeOfEvent,true, true, null);\n" + "event.dataTransfer = {\n"
					+ "data: {},\n" + "setData: function (key, value) {\n" + "this.data[key] = value;\n" + "},\n"
					+ "getData: function (key) {\n" + "return this.data[key];\n" + "}\n" + "};\n" + "return event;\n"
					+ "}\n" + "\n" + "function dispatchEvent(element, event,transferData) {\n"
					+ "if (transferData !== undefined) {\n" + "event.dataTransfer = transferData;\n" + "}\n"
					+ "if (element.dispatchEvent) {\n" + "element.dispatchEvent(event);\n"
					+ "} else if (element.fireEvent) {\n" + "element.fireEvent(\"on\" + event.type, event);\n" + "}\n"
					+ "}\n" + "\n" + "function simulateHTML5DragAndDrop(element, destination) {\n"
					+ "var dragStartEvent =createEvent('dragstart');\n" + "dispatchEvent(element, dragStartEvent);\n"
					+ "var dropEvent = createEvent('drop');\n"
					+ "dispatchEvent(destination, dropEvent,dragStartEvent.dataTransfer);\n"
					+ "var dragEndEvent = createEvent('dragend');\n"
					+ "dispatchEvent(element, dragEndEvent,dropEvent.dataTransfer);\n" + "}\n" + "\n"
					+ "var source = arguments[0];\n" + "var destination = arguments[1];\n"
					+ "simulateHTML5DragAndDrop(source,destination);", To, From);

			oWait(4);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Shadow Drag the element <b>" + elementName + " and Dropped ",
					"Drag the element <b>" + elementName + " and should be dropped", "Drag and Drop Event done");

			Synchronize.defaultAjaxSync();
		} catch (Exception e) {
			e.printStackTrace();
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Shadow Drag the element <b>" + elementName + " and Dropped ",
					"Drag the element <b>" + elementName + " and should be dropped",
					"Unable to locate element <b>" + elementName + "</b>");
		}
	}

	public static void SelectOptionByIndex(String dropdownName, int index, By by, boolean optional) {
		String itemToSelect = "";
		try {
			WebElement select = Demo1.driver.findElement(by);
			// Select class initialization
			Select dropDown = new Select(select);
			dropDown.selectByIndex(index);
			itemToSelect = dropDown.getOptions().get(index).getText();

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
					"Item <b>" + itemToSelect + "</b> should be selected", "<b>" + itemToSelect + "</b> Selected");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			if (optional)
				return;
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
					"Should be select <b>" + itemToSelect + "</b>",
					"Unable to locate dropdown <b>" + dropdownName + "</b>");
		}
	}

	public static void Dropdown_VerifyDefaultSelectedOption(By by, String dropdownName, String expDefaultOption) {
		Select dropDown = null;
		try {
			WebElement select = Demo1.driver.findElement(by);
			dropDown = new Select(select);
			String actDefaultOpt = dropDown.getFirstSelectedOption().getText().trim();
			if (expDefaultOption.trim().equals(actDefaultOpt)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify default selected option in <b>" + dropdownName + "</b> dropdown",
						"Default selectd option should be <b>" + expDefaultOption + "</b>",
						"Default selected option is <b>" + actDefaultOpt + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify default selected option in <b>" + dropdownName + "</b> dropdown",
						"Default selectd option should be <b>" + expDefaultOption + "</b>",
						"Default selected option is <b>" + actDefaultOpt + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify default selected option in <b>" + dropdownName + "</b> dropdown",
					"Default selected option should be <b>" + expDefaultOption + "</b>", e.getMessage());
		} finally {
			dropDown = null;
		}
	}

	/**
	 * @param by - ex: findElement(By.xxxxxxxx)
	 */
	public static boolean isElementTextPresent(By by, String expectedText) {
		try {
			Demo1.driver.findElement(by).getText().contains(expectedText);
			return true;
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			return false;
		}
	}

	/**
	 * Returns true if the expected element present else false
	 *
	 * @param by - ex: findElement(By.xxxxxxxx)
	 */
	public static boolean isElementPresent(By by) {
		try {
			Synchronize.defaultAjaxSync();

			Demo1.driver.findElement(by);
			return true;
		} catch (Exception e) {
			Reuse.log(e);

			Demo1.logger.error(e);
			return false;
		}
	}

	public static boolean IsElementVisible(By by) {
		try {
			return Demo1.driver.findElement(by).isDisplayed();
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			return false;
		}
	}

	public static void ElementVisible(By by, String elementType, String elementName) {
		try {
			if (Demo1.driver.findElement(by).isDisplayed()) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Check <b>" + elementName + "</b> " + elementType + " visible",
						"<b>" + elementName + "</b> " + elementType + " should be visible",
						"<b>" + elementName + "</b> " + elementType + " visible");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check <b>" + elementName + "</b> " + elementType + " visible",
						"<b>" + elementName + "</b> " + elementType + " should be visible",
						"<b>" + elementName + "</b> " + elementType + " not visible");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check <b>" + elementName + "</b> " + elementType + " visible",
					"<b>" + elementName + "</b> " + elementType + " should be visible",
					"Unable to locate <b>" + elementName + "</b>");
		}
	}

	public static void ElementNotVisible(By by, String elementType, String elementName) {
		try {
			if (Demo1.driver.findElement(by).isDisplayed()) {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check <b>" + elementName + "</b> " + elementType + " visible",
						"<b>" + elementName + "</b> " + elementType + " should not be visible",
						"<b>" + elementName + "</b> " + elementType + " visible");
			} else {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Check <b>" + elementName + "</b> " + elementType + " visible",
						"<b>" + elementName + "</b> " + elementType + " should not be visible",
						"<b>" + elementName + "</b> " + elementType + " not visible");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check <b>" + elementName + "</b> " + elementType + " visible",
					"<b>" + elementName + "</b> " + elementType + " should not be visible",
					"Unable to locate <b>" + elementName + "</b>");
		}
	}

	/**
	 * Returns true if expected link present else false
	 */
	public static boolean isLinkPresent(String linkText) {
		try {
			Demo1.driver.findElement(By.linkText(linkText));
			return true;
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			return false;
		}
	}

	/**
	 * Verifies the expected link present
	 */
	public static void LinkPresent(String linkText) {
		By by = By.linkText(linkText);
		if (isElementPresent(by)) {
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Verify Link " + linkText + " present",
					"Expected link " + linkText + " should be presented",
					"Expected link " + linkText + " presented as expected");
		} else {
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify Link " + linkText + " present",
					"Expected link " + linkText + " should be presented",
					"Expected link " + linkText + " not presented");
		}
	}

	public static void LinkPresent(By by) {
		if (isElementPresent(by)) {
			String linkText = Demo1.driver.findElement(by).getText();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Verify Link  present", "Link " + linkText + " should be presented",
					"Link " + linkText + " presented as expected");
		} else {
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify Link  present", "Expected link  should be presented", "Link  not presented");
		}
	}

	/**
	 * Verifies the Element presence
	 *
	 * @param by - ex: findElement(By.xxxxxxxx)
	 */
	public static void ElementExist(By by, String elementType, String elementName) {
		try {

			waitForElement(by, Config.TIME_OUT, 5000);

			Demo1.driver.findElement(by);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Verify <b>" + elementType + " " + elementName + "</b> is Exist",
					"" + elementName + " should be Exist", "<b>" + elementName + "</b> Exist");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify <b>" + elementType + " " + elementName + "</b> is Exist",
					"" + elementName + " should be Exist", "<b>" + elementName + "</b> not Exist");
		}
	}

	public static void shadow_ElementExist(String by, String elementType, String elementName) {
		try {
			WebElement element;
			try {

				// Reuse.waitForTextToAppear(by);

				Shadow shadow = new Shadow(Demo1.driver);

				element = shadow.findElement(by);

			} catch (Exception e) {

				oWait(Config.TIME_OUT);

				Shadow shadow = new Shadow(Demo1.driver);

				element = shadow.findElement(by);

				// TODO Auto-generated catch block
				// Uncomment and replace with appropriate logger
				// LOGGER.error(e, e);
			}

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Verify <b>" + elementType + " " + elementName + "</b> is Exist",
					"" + elementName + " should be Exist", "<b>" + elementName + "</b> Exist");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify <b>" + elementType + " " + elementName + "</b> is Exist",
					"" + elementName + " should be Exist", "<b>" + elementName + "</b> not Exist");
		}
	}

	public static void ElementNotExist(By by, String elementType, String elementName) throws NoSuchElementException {

		Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Config.ElementNotPresentWait));
		try {
			try {

				WebElement ele = Demo1.driver.findElement(by);

				if (ele.isDisplayed()) {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Verify <b>" + elementType + " " + elementName + "</b> is not Exist",
							"" + elementName + " should not be Exist", "<b>" + elementName + "</b> Exist");
				} else {
					throw new Exception("Element is available in the DOM, But not visible in the page");
				}

			} catch (Exception e) {
				Reuse.log(e);
				Demo1.logger.error(e);
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify <b>" + elementType + " " + elementName + "</b> is not Exist",
						"" + elementName + " should not be Exist", "<b>" + elementName + "</b> not Exist");
			}
		} catch (Exception e1) {
			Reuse.log(e1);
		}
		Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Config.TIME_OUT));

	}

	public static void shadow_ElementNotExist(String by, String elementType, String elementName)
			throws NoSuchElementException {

		try {
			try {

				WebElement element;
				Shadow shadow = new Shadow(Demo1.driver);

				element = shadow.findElement(by);

				if (element.isDisplayed()) {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Verify <b>" + elementType + " " + elementName + "</b> is not Exist",
							"" + elementName + " should not be Exist", "<b>" + elementName + "</b> Exist");
				} else {
					throw new Exception("Element is available in the DOM, But not visible in the page");
				}

			} catch (Exception e) {
				Reuse.log(e);
				Demo1.logger.error(e);
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify <b>" + elementType + " " + elementName + "</b> is not Exist",
						"" + elementName + " should not be Exist", "<b>" + elementName + "</b> not Exist");
			}
		} catch (Exception e1) {
			Reuse.log(e1);
		}

	}

	/**
	 * To wait - in seconds
	 */
	public static void oWait(int timeOutInsec) throws Exception {
		int secToWait = 1000 * timeOutInsec;
		Thread.sleep(secToWait);
	}

	public static void ClickImage(By by, String imageName) {
		try {
			WebElement element = Demo1.driver.findElement(by);
			if (isElementPresent(by)) {
				element.click();
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Click Iamge <b>" + imageName + "</b>",
						"Should be able to click image <b>" + imageName + "</b>",
						"Clicked image <b>" + imageName + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Click Iamge <b>" + imageName + "</b>",
						"Should be able to click image <b>" + imageName + "</b>",
						" Not clicked image <b>" + imageName + "</b>");
			}

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Action: Click", "Click the element",
					"Unbale to locate image <b>" + imageName + "</b>");
		}
	}

	/**
	 * to click link
	 */
	public static void Link_Click(String linkText) {
		try {
			WebElement element = Demo1.driver.findElement(By.linkText(linkText));
			if (element.isDisplayed()) {
				element.click();
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Action: Click Link", "Click the Link",
						"Link " + linkText + " clicked successfully");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Action: Click Link", "Click the Link", "Link " + linkText + " not clicked");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Action: Click Link", "Click the Link", "Unable to identify element");
		}
	}

	public static void Link_Click(By by, String linkname) {
		try {
			if (isElementPresent(by)) {
				Demo1.driver.findElement(by).click();
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Click Link <b>" + linkname + "</b>",
						"Should be able to click <b>" + linkname + "</b>", "Clicked on <b>" + linkname + "</b> link");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Click Link <b>" + linkname + "</b>",
						"Should be able to click <b>" + linkname + "</b>",
						"Not clicked on <b>" + linkname + "</b> link");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Click Link <b>" + linkname + "</b>", "Should be able to click <b>" + linkname + "</b>",
					"Unbale to locate link <b>" + linkname + "</b>");
		}
	}

	/**
	 * To click element
	 *
	 * @param by - ex: findElement(By.xxxxxxxx)
	 */
	public static void Click_Element(By by, String elementType, String elementName) {
		boolean isvalcom = false;

		// String eveClick = "var event = new MouseEvent('click', {'bubbles':
		// true});arguments[0].dispatchEvent(event);";

		try {

			if (isElementPresent(by)) {
				Focus(Demo1.driver.findElement(by));
				if (elementType.equalsIgnoreCase("Checkbox")) {
					if (Demo1.driver.findElement(by).isSelected()) {
						Demo1.gbTestCaseStatus = "Pass";
						Demo1.ReportStep(2, "Click <b>" + elementName + " " + elementType + "</b>",
								"<b>" + elementName + " " + elementType + "</b> should be selected",
								"Check box is already selected");
					} else {
						Demo1.driver.findElement(by).click();
						Demo1.gbTestCaseStatus = "Pass";
						Demo1.ReportStep(2, "Click <b>" + elementName + " " + elementType + "</b>",
								"<b>" + elementName + " " + elementType + "</b> should be selected",
								"Checked box is selected");
					}
				} else {
					try {
						if ((Config.smartClick.toLowerCase().contains("true"))
								&& (by.toString().toUpperCase().contains("EXECUTE")
										|| by.toString().toUpperCase().contains("VALIDATE")
										|| by.toString().toUpperCase().contains("COMMIT"))) {
							/*
							 * WebElement jsElement = getElementForJS(by); if (jsElement == null) {
							 * Demo1.driver.findElement(by).click(); } else {
							 *
							 * JavascriptExecutor executor = (JavascriptExecutor) Demo1.driver;
							 * executor.executeScript("arguments[0].click();", jsElement);
							 *
							 *
							 * }
							 */
							Thread.sleep(3000);
							// WebElement element =
							// Demo1.driver.findElement(by);
							JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
							// ((JavascriptExecutor)
							// Demo1.driver).executeScript("arguments[0].scrollIntoView(true);");
							((JavascriptExecutor) Demo1.driver).executeScript("scroll(0,0)");
							Thread.sleep(2000);
							isvalcom = true;
						}

						Synchronize.defaultAjaxSync();
						WebDriverWait wait = new WebDriverWait(Demo1.driver, Duration.ofSeconds(15));
						wait.until(ExpectedConditions.elementToBeClickable(by));
						// Thread.sleep(2000);

						if (Demo1.driver.findElement(by).isDisplayed() && !isvalcom) {
							Demo1.driver.findElement(by).click();
							if (Config.wealthRun) {
								// newly added to test the loader element
								try {
									Thread.sleep(100);
								} catch (InterruptedException e) {
									e.printStackTrace();
									System.out.println("Error while adding sleep time");
								}
								checkWealthSpinnerElement();
							}
							Thread.sleep(100);
							Demo1.gbTestCaseStatus = "Pass";
							Demo1.ReportStep(2, "Click <b>" + elementName + " " + elementType + "</b>",
									"<b>" + elementName + " " + elementType + "</b> should be Clicked",
									"Clicked on <b>" + elementName + "</b>");
							

						} else {

							Reuse.log("Click Type 2");
							String eveClick = "var event = new MouseEvent('click', {'bubbles': true});arguments[0].dispatchEvent(event);";
							JavascriptExecutor executor = (JavascriptExecutor) Demo1.driver;
							executor.executeScript(eveClick, Demo1.driver.findElement(by));
							Demo1.gbTestCaseStatus = "Pass";
							Demo1.ReportStep(2, "Click <b>" + elementName + " " + elementType + "</b>",
									"<b>" + elementName + " " + elementType + "</b> should be Clicked",
									"Clicked on <b>" + elementName + "</b>");

						}
					} catch (WebDriverException e1) {
						Reuse.log("Click Type 2, handled exception");
						Reuse.log(e1);
						String eveClick = "var event = new MouseEvent('click', {'bubbles': true});arguments[0].dispatchEvent(event);";
						JavascriptExecutor executor = (JavascriptExecutor) Demo1.driver;
						executor.executeScript(eveClick, Demo1.driver.findElement(by));
						Thread.sleep(100);
						Demo1.gbTestCaseStatus = "Pass";
						Demo1.ReportStep(2, "Click <b>" + elementName + " " + elementType + "</b>",
								"<b>" + elementName + " " + elementType + "</b> should be Clicked",
								"Clicked on <b>" + elementName + "</b>");

					} finally {
						isvalcom = false;
					}

				}

			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Click element <b>" + elementName + "</b>",
						"Should be able to click on <b>" + elementName + "</b>",
						"Element <b>" + elementName + "</b> not present/unable to locate element");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Click " + elementType + " <b>" + elementName + "</b>",
					"<b>" + elementName + "</b> " + elementType + " should be clicked", e.getMessage());
		}
	}
	
	public static void click_ElementWithoutJS(By by, String elementType, String elementName) {
        boolean isvalcom = false;
        try {

            if (isElementPresent(by)) {
                Focus(Demo1.driver.findElement(by));
                if (elementType.equalsIgnoreCase("Checkbox")) {
                    if (Demo1.driver.findElement(by).isSelected()) {
                        Demo1.gbTestCaseStatus = "Pass";
                        Demo1.ReportStep(2, "Click <b>" + elementName + " " + elementType + "</b>",
                                "<b>" + elementName + " " + elementType + "</b> should be selected",
                                "Check box is already selected");
                    } else {
                        Demo1.driver.findElement(by).click();
                        Demo1.gbTestCaseStatus = "Pass";
                        Demo1.ReportStep(2, "Click <b>" + elementName + " " + elementType + "</b>",
                                "<b>" + elementName + " " + elementType + "</b> should be selected",
                                "Checked box is selected");
                    }
                } else {
                    try {
                        if ((Config.smartClick.toLowerCase().contains("true"))
                                && (by.toString().toUpperCase().contains("EXECUTE")
                                        || by.toString().toUpperCase().contains("VALIDATE")
                                        || by.toString().toUpperCase().contains("COMMIT"))) {
                            Thread.sleep(3000);
                            JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
                            ((JavascriptExecutor) Demo1.driver).executeScript("scroll(0,0)");
                            Thread.sleep(2000);
                            isvalcom = true;
                        }

                        Synchronize.defaultAjaxSync();
                        WebDriverWait wait = new WebDriverWait(Demo1.driver, Duration.ofSeconds(15));
                        wait.until(ExpectedConditions.elementToBeClickable(by));
                       

                        if (Demo1.driver.findElement(by).isDisplayed() && isvalcom == false) {
                            Demo1.driver.findElement(by).click();
                            if (Config.wealthRun) {
                                // newly added to test the loader element
                                try {
                                    Thread.sleep(100);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                    System.out.println("Error while adding sleep time");
                                }
                                checkWealthSpinnerElement();
                            }
                            Demo1.gbTestCaseStatus = "Pass";
                            Demo1.ReportStep(2, "Click <b>" + elementName + " " + elementType + "</b>",
                                    "<b>" + elementName + " " + elementType + "</b> should be Clicked",
                                    "Clicked on <b>" + elementName + "</b>");

                        }
                    } catch (WebDriverException e1) {
                        Reuse.log("Click action failed");
                        Reuse.log(e1);
                       e1.printStackTrace();
                        Demo1.gbTestCaseStatus = "Fail";
                        Demo1.ReportStep(2, "Click element <b>" + elementName + "</b>",
                                "Should be able to click on <b>" + elementName + "</b>",
                                "Element <b>" + elementName + "</b> not present/unable to locate element");

                    } finally {
                        isvalcom = false;
                    }

                }
               
                
            } else {
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Click element <b>" + elementName + "</b>",
                        "Should be able to click on <b>" + elementName + "</b>",
                        "Element <b>" + elementName + "</b> not present/unable to locate element");
            }
        } catch (Exception e) {
            Reuse.log(e);
            Demo1.logger.error(e);
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Click " + elementType + " <b>" + elementName + "</b>",
                    "<b>" + elementName + "</b> " + elementType + " should be clicked", e.getMessage());
        }
    }

	public static WebElement getElementForJS(By by) {
		WebElement childElement = Demo1.driver.findElement(by);

		boolean childHas = false;
		boolean parentHas = false;

		if (childElement.getTagName().trim().toLowerCase().equals("a")) {
			childHas = true;
		} /*
			 * else { String attr = childElement.getAttribute("onclick"); if (attr != null)
			 * { if (attr.trim().length() > 1) { childHas = true; }
			 *
			 * } }
			 */

		if (!childHas) {
			JavascriptExecutor executor = (JavascriptExecutor) Demo1.driver;
			WebElement parentElement = (WebElement) executor.executeScript("return arguments[0].parentNode;",
					childElement);
			if (parentElement.getTagName().trim().toLowerCase().equals("a")) {
				parentHas = true;
			} /*
				 * else { { String attr = parentElement.getAttribute("onclick"); if (attr !=
				 * null) { if (attr.trim().length() > 1) { parentHas = true; }
				 *
				 * } } }
				 */
		}
		if (childHas) {
			return Demo1.driver.findElement(by);
		} else if (parentHas) {
			JavascriptExecutor executor = (JavascriptExecutor) Demo1.driver;

			return (WebElement) executor.executeScript("return arguments[0].parentNode;", childElement);

		}

		return null;
	}

	public static void ClickIf(By by, String elementType, String elementName, String condition) {
		try {
			if (condition.equalsIgnoreCase("IsExist")) {
				if (isElementPresent(by)) {
					Demo1.driver.findElement(by).click();
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Click if <b>" + elementName + " " + elementType + "</b> Exist",
							"<b>" + elementName + " " + elementType + "</b> should be Clicked",
							"Clicked on <b>" + elementName + "</b>");
				} else {
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Click if <b>" + elementName + " " + elementType + "</b> Exist",
							"<b>" + elementName + " " + elementType + "</b> should be Clicked",
							"Element <b>" + elementName + "</b> not exist");
				}
			} else if (condition.equalsIgnoreCase("IsEnabled")) {
				if (isElementPresent(by) && Demo1.driver.findElement(by).isEnabled()) {
					Demo1.driver.findElement(by).click();
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Click if <b>" + elementName + " " + elementType + "</b> Enabled",
							"<b>" + elementName + " " + elementType + "</b> should be Clicked",
							"Clicked on <b>" + elementName + "</b>");
				} else {
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Click if <b>" + elementName + " " + elementType + "</b> Enabled",
							"<b>" + elementName + " " + elementType + "</b> should be Clicked",
							"Element <b>" + elementName + "</b> not enabled");
				}
			} else if (condition.equalsIgnoreCase("IsNotSelected")) {
				if (isElementPresent(by) && Demo1.driver.findElement(by).isSelected()) {
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Select if <b>" + elementName + " " + elementType + "</b> not selected",
							"<b>" + elementName + " " + elementType + "</b> should be selected",
							"<b>" + elementName + "</b> already selected");
				} else {
					Demo1.driver.findElement(by).click();
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Select if <b>" + elementName + " " + elementType + "</b> not selected",
							"<b>" + elementName + " " + elementType + "</b> should be selected",
							"<b>" + elementName + "</b> selected");
				}
			} else if (condition.equalsIgnoreCase("IsDisplayed")) {
				if (isElementPresent(by) && Demo1.driver.findElement(by).isDisplayed()) {
					Demo1.driver.findElement(by).click();
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Click if <b>" + elementName + " " + elementType + "</b> displayed",
							"<b>" + elementName + " " + elementType + "</b> should be Clicked",
							"Clicked on <b>" + elementName + "</b>");
				} else {
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Click if <b>" + elementName + " " + elementType + "</b> displayed",
							"<b>" + elementName + " " + elementType + "</b> should be Clicked",
							"Element <b>" + elementName + "</b> not displayed");
				}
			}
			else if (condition.equalsIgnoreCase("IsSelected")) {
				JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
				boolean isSelected = (Boolean) js.executeScript("return arguments[0].checked;", Demo1.driver.findElement(by));
				if (isElementPresent(by) && !isSelected) {
					Demo1.driver.findElement(by).click();
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Select if <b>" + elementName + " " + elementType + "</b> not selected",
							"<b>" + elementName + " " + elementType + "</b> should be selected",
							"<b>" + elementName + "</b> already selected");
				} else {
					//Demo1.driver.findElement(by).click();
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Select if <b>" + elementName + " " + elementType + "</b> not selected",
							"<b>" + elementName + " " + elementType + "</b> should be selected",
							"<b>" + elementName + "</b> selected");
				}
				}
			else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Click <b>" + elementName + " " + elementType + "</b>",
						"<b>" + elementName + " " + elementType + "</b> should be Clicked",
						"Condition <b>" + condition + "</b> not matched");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("ClickIf " + e);
			// Demo1.gbTestCaseStatus = "Fail";
			// Demo1.ReportStep(2, "Click " + elementType + " <b>" + elementName
			// + "</b>", "<b>" + elementName + "</b> " + elementType + " should
			// be clicked", e.getMessage());
		}
	}

	public static void log(Throwable e) {

		try {
			Date d = new Date();
			String formatted = new SimpleDateFormat("HH:mm:ss:dd-MM-yyyy>>").format(d);
			System.out.println(formatted + Throwables.getStackTraceAsString(e));

		} catch (Exception e1) {
			System.out.println(Throwables.getStackTraceAsString(e1));
		}

	}

	public static void log(String e) {

		try {
			Date d = new Date();
			String formatted = new SimpleDateFormat("HH:mm:ss:dd-MM-yyyy>>").format(d);
			System.out.println(formatted + e);

		} catch (Exception e1) {
			System.out.println(Throwables.getStackTraceAsString(e1));
		}

	}

	public static void ClickIfElse(By by1, By by2, By by3, String condition) {
		String by2Text = "";
		boolean isby1Exist = false;
		try {
			switch (condition) {
			case "IsExist":
				if (isElementPresent(by1)) {
					Demo1.driver.findElement(by2).click();
					by2Text = Demo1.driver.findElement(by2).getText();
					isby1Exist = true;
					break;
				}
			case "IsEnabled":
				if (isElementPresent(by1) && Demo1.driver.findElement(by1).isEnabled()) {
					Demo1.driver.findElement(by2).click();
					by2Text = Demo1.driver.findElement(by2).getText();
					isby1Exist = true;
					break;
				}
			case "IsNotEnabled":
				if (isElementPresent(by1) && !Demo1.driver.findElement(by1).isEnabled()) {
					Demo1.driver.findElement(by2).click();
					by2Text = Demo1.driver.findElement(by2).getText();
					isby1Exist = true;
					break;
				}
			case "IsNotSelected":
				if (isElementPresent(by1) && !Demo1.driver.findElement(by1).isSelected()) {
					Demo1.driver.findElement(by2).click();
					by2Text = Demo1.driver.findElement(by2).getText();
					isby1Exist = true;
					break;
				}
			case "IsSelected":
				if (isElementPresent(by1) && Demo1.driver.findElement(by1).isSelected()) {
					Demo1.driver.findElement(by2).click();
					by2Text = Demo1.driver.findElement(by2).getText();
					isby1Exist = true;
					break;
				}
			case "IsDisplayed":
				if (isElementPresent(by1) && Demo1.driver.findElement(by1).isDisplayed()) {
					Demo1.driver.findElement(by2).click();
					by2Text = Demo1.driver.findElement(by2).getText();
					isby1Exist = true;
					break;
				}
			case "IsNotDisplayed":
				if (isElementPresent(by1) && !Demo1.driver.findElement(by1).isDisplayed()) {
					Demo1.driver.findElement(by2).click();
					by2Text = Demo1.driver.findElement(by2).getText();
					isby1Exist = true;
					break;
				}
			default:
				Demo1.logger.error("Error in ClickIfElse. " + condition + " not matched");
			}
			if (isby1Exist) {
				isby1Exist = false;
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Click <b>" + by2Text + "</b> if Element-1 " + condition,
						"Should be Clicked on " + by2Text, "Clicked <b>" + by2Text + "</b>");
			} else {
				if (isElementPresent(by3)) {
					Demo1.driver.findElement(by3).click();
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2,
							"Click <b>" + Demo1.driver.findElement(by3).getText() + "</b> if Element-2 not found",
							"Should be Clicked on " + Demo1.driver.findElement(by3).getText(), "Clicked");
				} else {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Click Element-3 if Element-2 not found", "Should be Clicked on Element-3",
							"Element-3 not found");
				}
			}

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("ClickIf " + e);
		}
	}
	
	public static void clickIfElseByCondition(String elementName,String propertyKey, By by1, By by2) {
         try {
        	 String value=Reuse.GetPropertyValue(propertyKey);
        	 if(Boolean.parseBoolean(value)==true) {
        		 Demo1.driver.findElement(by1).click();
        		 Demo1.gbTestCaseStatus = "Pass";
     			Demo1.ReportStep(2, "Click element <b>" + elementName + "</b>",
     					"Should be able to click on <b>" + elementName + "</b>",
     					"Clicked on <b>" + elementName + "</b>");
        	 }else {
        		 Demo1.driver.findElement(by2).click();
        		 Demo1.gbTestCaseStatus = "Pass";
      			Demo1.ReportStep(2, "Click element <b>" + elementName + "</b>",
      					"Should be able to click on <b>" + elementName + "</b>",
      					"Clicked on <b>" + elementName + "</b>");
        	 }
		} catch (Exception e) {
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Click element <b>" + elementName + "</b>",
					"Should be able to click on <b>" + elementName + "</b>",
					"Element <b>" + elementName + "</b> not present/unable to locate element");
		}
	}

	public static void waitForElementToAppear(final By locator, int withTimeoutInSec, int pollingEveryInSec) {
		try {
			if (waitForElement(locator, withTimeoutInSec, pollingEveryInSec) != null) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Wait for Element to appear", "Should wait until the time out", "Element appeared");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Wait for Element to appear", "Should wait until the time out",
						"Element not found");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("waitForElementToAppear. " + e);
		}
	}

	public static void Shadow_waitForElementToAppear(final String locator, int withTimeoutInSec, int pollingEveryInSec,
			String action) {
		try {
			if (action.equalsIgnoreCase("SHADOWCSS")) {
				if (Shadow_waitForElement(locator, withTimeoutInSec, pollingEveryInSec) != null) {
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Wait for Element to appear", "Should wait until the time out",
							"Element appeared");
				} else {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Wait for Element to appear", "Should wait until the time out",
							"Element not found");
				}
			} else if (action.equalsIgnoreCase("JS")) {
				if (JS_waitForElement(locator, withTimeoutInSec, pollingEveryInSec) != null) {
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Wait for Element to appear", "Should wait until the time out",
							"Element appeared");
				} else {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Wait for Element to appear", "Should wait until the time out",
							"Element not found");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reuse.log(e);
			Demo1.logger.error("waitForElementToAppear. " + e);
		}
	}

	public static void waitForElementComparision(final By expectedLocator, final By actualLocator,
			String withTimeoutInSec, By refreshElementBy) {
		long overallTimeOut = Long.parseLong(withTimeoutInSec) / 60;
		WebElement expElement = null;
		WebElement actualElement = null;
		WebElement pageRefreshElement = null;

		boolean textEqual = false;
		try {

			String startTimeOfCob = getCurrentDatenTime("HH:mm:ss");
			System.out.println("STARTING TIME:::" + startTimeOfCob);
			long durationSoFar = 0;

			do {
				expElement = Demo1.driver.findElement(expectedLocator);
				String exceptedtext = expElement.getText();

				System.out.println("Excepted Text::" + exceptedtext);

				actualElement = Demo1.driver.findElement(actualLocator);
				String Actualtext = actualElement.getText();

				System.out.println("Actual Text::" + Actualtext);

				if (exceptedtext.equalsIgnoreCase(Actualtext)) {
					textEqual = true;
				}

				// getting page refresh webelement
				if (null != refreshElementBy) {
					pageRefreshElement = Demo1.driver.findElement(refreshElementBy);
				}
				if (!textEqual) {
					try {
						String currentTimeOfCob = getCurrentDatenTime("HH:mm:ss");
						durationSoFar = timeDifference(startTimeOfCob, currentTimeOfCob, "HH:mm:ss");
						System.out.println("TIME SO FAR BATCH/DATE/SERVICECONTROL::" + durationSoFar + " Minutes");

						if (durationSoFar >= overallTimeOut) {
							System.out.println("BREAKING INTERMITTENTLY!");
							break;
						} else {
							Thread.sleep(59000);
							/* Demo1.driver.navigate().refresh(); */

							if (pageRefreshElement.isDisplayed()) {
								pageRefreshElement.click();
								Thread.sleep(1000);
							}
							continue;
						}

					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

			} while (!textEqual);

			if (textEqual) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Wait for Element to appear", "Should wait until the time out", "Element appeared");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Wait for Element to appear", "Should wait until the time out",
						"Element not found");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("waitForElementToAppear. " + e);
		}
	}

	public static void waitForSameElementComparision(final By expectedLocator, String expectedTextInSameElement,
			String withTimeoutInSec, By refreshElementBy) {
		long overallTimeOut = Long.parseLong(withTimeoutInSec) / 60;
		WebElement expElement = null;
		WebElement actualElement = null;
		WebElement pageRefreshElement = null;

		boolean textEqual = false;
		try {

			String startTimeOfCob = getCurrentDatenTime("HH:mm:ss");
			System.out.println("STARTING TIME:::" + startTimeOfCob);
			long durationSoFar = 0;

			do {
				expElement = Demo1.driver.findElement(expectedLocator);
				String currentText = expElement.getText();

				System.out.println("Current Text::" + currentText);

				if (currentText.equalsIgnoreCase(expectedTextInSameElement)) {
					textEqual = true;
				}

				// getting page refresh webelement
				if (null != refreshElementBy) {
					pageRefreshElement = Demo1.driver.findElement(refreshElementBy);
				}
				if (!textEqual) {
					try {
						String currentTimeOfCob = getCurrentDatenTime("HH:mm:ss");
						durationSoFar = timeDifference(startTimeOfCob, currentTimeOfCob, "HH:mm:ss");
						System.out.println("TIME SO FAR BATCH/DATE/SERVICECONTROL::" + durationSoFar + " Minutes");

						if (durationSoFar >= overallTimeOut) {
							System.out.println("BREAKING INTERMITTENTLY!");
							break;
						} else {
							Thread.sleep(59000);
							/* Demo1.driver.navigate().refresh(); */

							if (pageRefreshElement.isDisplayed()) {
								pageRefreshElement.click();
								Thread.sleep(1000);
							}
							continue;
						}

					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

			} while (!textEqual);

			if (textEqual) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Wait for Element to appear", "Should wait until the time out", "Element appeared");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Wait for Element to appear", "Should wait until the time out",
						"Element not found");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("waitForElementToAppear. " + e);
		}
	}

	private static String getCurrentDatenTime(String format) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.format(cal.getTime());
	}

	private static long timeDifference(String StartTime, String endTime, String dateFormat) {
		SimpleDateFormat format = null;
		long diffMinutes = 0;
		try {
			// "dd-MM-yy HH:mm:ss"
			format = new SimpleDateFormat(dateFormat);
			Date FStartTime = format.parse(StartTime);
			Date FEndTime = format.parse(endTime);
			long diff = FEndTime.getTime() - FStartTime.getTime();

			long newTime = Math.abs(diff);
//            diffMinutes = (newTime / (60 * 1000)) % 60;
			diffMinutes = (newTime / (60 * 1000));

			/*
			 * long diffSeconds = (newTime/1000)%60; long diffMinutes = (newTime / (60 *
			 * 1000))%60; long diffHours = newTime / (60 * 60 * 1000)%24;
			 *
			 * String hrs,mins,secs; if(diffHours<=0){ hrs=""; }else{
			 * hrs=diffHours+" hrs, "; } if(diffMinutes<=0){ mins=""; }else{
			 * mins=diffMinutes+" mins, "; } if(diffSeconds<=0){ secs=""; }else{
			 * secs=diffSeconds+" sec"; } return hrs+mins+secs;
			 */
		} catch (Exception e) {
			System.out.println("UtilDate.timeDifference " + e);
			/* return null; */
		}

		return diffMinutes;
	}

	public static WebElement waitForElement(final By locator, int withTimeoutInSec, int pollingEveryInSec) {

		List<Class<? extends Throwable>> allExceptions = new ArrayList<>();
        allExceptions.add(NoSuchElementException.class);
        allExceptions.add(ElementNotInteractableException.class);
        allExceptions.add(StaleElementReferenceException.class);
        allExceptions.add(ElementClickInterceptedException.class);
        allExceptions.add(JavaScriptException.class);

		Wait<WebDriver> wait = new FluentWait<WebDriver>(Demo1.driver).withTimeout(Duration.ofSeconds(withTimeoutInSec))
				.pollingEvery(Duration.ofMillis(pollingEveryInSec)).ignoreAll(allExceptions);

		WebElement element = null;
		try {
			element = wait.until(new Function<WebDriver, WebElement>() {

				@Override
				public WebElement apply(WebDriver driver) {

					return driver.findElement(locator);
				}
			});
		} catch (Exception e) {
			Reuse.log(e);

		}
		return element;
	}

	public static WebElement JS_waitForElement(final String locator, int withTimeoutInSec, int pollingEveryInSec) {
		
		List<Class<? extends Throwable>> allExceptions = new ArrayList<>();
        allExceptions.add(NoSuchElementException.class);
        allExceptions.add(ElementNotInteractableException.class);
        allExceptions.add(StaleElementReferenceException.class);
        allExceptions.add(ElementClickInterceptedException.class);
        allExceptions.add(JavaScriptException.class);

		Wait<WebDriver> wait = new FluentWait<WebDriver>(Demo1.driver).withTimeout(Duration.ofSeconds(withTimeoutInSec))
				.pollingEvery(Duration.ofMillis(pollingEveryInSec)).ignoreAll(allExceptions);

		WebElement element = null;
		try {
			element = wait.until(new Function<WebDriver, WebElement>() {

				@Override
				public WebElement apply(WebDriver driver) {

					return (WebElement) ((JavascriptExecutor) Demo1.driver).executeScript("return " + locator);
				}
			});
		} catch (Exception e) {
			Reuse.log(e);

		}
		return element;
	}

	public static WebElement Shadow_waitForElement(final String locator, int withTimeoutInSec, int pollingEveryInSec) {
		
		List<Class<? extends Throwable>> allExceptions = new ArrayList<>();
        allExceptions.add(NoSuchElementException.class);
        allExceptions.add(ElementNotInteractableException.class);
        allExceptions.add(StaleElementReferenceException.class);
        allExceptions.add(ElementClickInterceptedException.class);
        allExceptions.add(JavaScriptException.class);

		Wait<WebDriver> wait = new FluentWait<WebDriver>(Demo1.driver).withTimeout(Duration.ofSeconds(withTimeoutInSec))
				.pollingEvery(Duration.ofMillis(pollingEveryInSec)).ignoreAll(allExceptions);

		WebElement element = null;
		Shadow shadow = new Shadow(Demo1.driver);
		try {
			element = wait.until(new Function<WebDriver, WebElement>() {

				@Override
				public WebElement apply(WebDriver driver) {

					return shadow.findElement(locator);
				}
			});
		} catch (Exception e) {
			Reuse.log(e);

		}
		return element;
	}

	public static void JSClick(By by, String eleType, String eleName) {
		try {
			WebElement element = Demo1.driver.findElement(by);
			JavascriptExecutor executor = (JavascriptExecutor) Demo1.driver;
			executor.executeScript("arguments[0].click();", element);
			Reuse.log("Clicked");
			// Demo1.driver.navigate().to("javascript:document.getElementById('"+id+"').click()");
		} catch (Exception e) {
			Reuse.log(e);
			Reuse.log(e);
		}
	}

	public static void JSClick(String locType, String loc) {
		JavascriptExecutor js;
		try {
			Reuse.log("Locator type: " + locType + " Locator: " + loc);
			// Demo1.driver.navigate().to("javascript:document.getElementById('"+loc+"').click()");
			WebElement performance = Demo1.driver.findElement(By.xpath("//button[text()='Execute']"));
			js = (JavascriptExecutor) Demo1.driver;
			js.executeScript("arguments[0].click();", performance);
		} catch (Exception e) {
			Reuse.log(e);
			// Reuse.log(e);
		} finally {
			js = null;
		}
	}

	public static void TextBox_Clear(By by, String textBoxName) {

		if (isElementPresent(by)) {
			try {
				Focus(Demo1.driver.findElement(by));

				Demo1.driver.findElement(by).clear();

				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Clear text in to the field <b>" + textBoxName + "</b>", "Clear text <b>",
						"Text cleared Successfully");

			} catch (Exception e) {
				Reuse.log(e);

				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Clear text in to the field <b>" + textBoxName + "</b>", "Clear text <b>",
						"Unbale to locate textbox <b>" + textBoxName + "</b>");
				Demo1.logger.error(e);
			}
		} else {
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Clear text in to the field <b>" + textBoxName + "</b>", "Clear text <b>",
					"Element <b>" + textBoxName + " </b> not present/unable to locate element");
		}

	}

	public static void Shadow_TextBox_Clear(String Locator, String textBoxName) {

		try {
			Shadow shadow = new Shadow(Demo1.driver);
			shadow.findElement(Locator).clear();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Shadow Clear text in to the field <b>" + textBoxName + "</b>", "Clear text <b>",
					"Text cleared Successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Shadow Clear text in to the field <b>" + textBoxName + "</b>", "Clear text <b>",
					"Unbale to locate textbox <b>" + textBoxName + "</b>");
		}

	}

	/**
	 * to input text in text box
	 */

	public static void TextBox_InputText(By by, String text, String textBoxName) {
		try {

			if (Config.Mode.toUpperCase().contains("TFO")) {
				WebDriverWait wait = new WebDriverWait(Demo1.driver, Duration.ofSeconds(15));
				wait.until(ExpectedConditions.visibilityOfElementLocated(by));

			}

			if (!(text == null) && text.contains("CURR_DIR@"))
				text = System.getProperty("user.dir") + File.separator + "TestData\\" + text.split("CURR_DIR@")[1];

			if (isElementPresent(by)) {
				try {
					Focus(Demo1.driver.findElement(by));

					Demo1.driver.findElement(by).clear();
					Demo1.driver.findElement(by).sendKeys(text);

					if (Config.wealthRun) {
						// newly added to test the loader element
						try {
							Thread.sleep(100);
						} catch (InterruptedException e) {
							e.printStackTrace();
							System.out.println("Error while adding sleep time");
						}
						checkWealthSpinnerElement();
					}

				} catch (Exception e) {
					JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
					js.executeScript("arguments[0].value='" + text + "';", Demo1.driver.findElement(by));
					js.executeScript("var event = new Event('change');arguments[0].dispatchEvent(event);",
							Demo1.driver.findElement(by));
					js.executeScript("var event = new Event('blur');arguments[0].dispatchEvent(event);",
							Demo1.driver.findElement(by));

					Reuse.log(e);
				}

				try {
					String event = Config.textBoxEvent;

					if (Config.Mode.toUpperCase().contains("TFO")) {

						JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
						String str = (String) js.executeScript("return arguments[0].value;",
								Demo1.driver.findElement(by));
						if (str != null & !str.trim().contains(text)
								& (text.trim().length() == 6 || str.trim().length() < text.trim().length())) {
							System.out.println("#HANDLER:Re-entering text again");
							Thread.sleep(2000);
							Demo1.driver.findElement(by).clear();
							Thread.sleep(2000);
							Demo1.driver.findElement(by).sendKeys(text);
							Thread.sleep(2000);
						}
					}

					if (event.trim().equalsIgnoreCase("true")) {

						JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
						js.executeScript("var event = new Event('change');arguments[0].dispatchEvent(event);",
								Demo1.driver.findElement(by));
						js.executeScript("var event = new Event('blur');arguments[0].dispatchEvent(event);",
								Demo1.driver.findElement(by));
						String str = (String) js.executeScript("return arguments[0].value;",
								Demo1.driver.findElement(by));

						if (str != null & str.trim().isEmpty()) {
							System.out.println("Reentering value again as the textbox is empty");
							js.executeScript("arguments[0].value='" + text + "';", Demo1.driver.findElement(by));
							js.executeScript("var event = new Event('change');arguments[0].dispatchEvent(event);",
									Demo1.driver.findElement(by));
							js.executeScript("var event = new Event('blur');arguments[0].dispatchEvent(event);",
									Demo1.driver.findElement(by));
						}
					}
				} catch (Exception e) {
					Reuse.log(e);
					Reuse.log("Error while dispatching change event");
				}

				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Input text in to the field <b>" + textBoxName + "</b>",
						"Input text <b>" + text + "</b>", "Text <b>" + text + "</b> entered Successfully");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Input text in to the field <b>" + textBoxName + "</b>",
						"Input text <b>" + text + "</b>",
						"Element <b>" + textBoxName + " </b> not present/unable to locate element");
			}
		} catch (Exception e) {
			Reuse.log(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Input text in to the field <b>" + textBoxName + "</b>",
					"Input text <b>" + text + "</b>", "Unbale to locate textbox <b>" + textBoxName + "</b>");
			Demo1.logger.error(e);
		}
	}

	public static String getProcessedString(String action, String s) {
		try {
			if (action.trim().isEmpty()) {
				return s;
			}

			if (action.trim().toUpperCase().contains("SUBSTRING")) {
				int startSub = action.indexOf("[") + 1;
				int endSub = action.indexOf("]");

				String[] arrSubindex = action.substring(startSub, endSub).split(",");

				return s.substring(Integer.parseInt(arrSubindex[0]) - 1, Integer.parseInt(arrSubindex[1]));
			}

		} catch (Exception e) {
			Reuse.log(e);
		}
		return s;
	}

	public static String getProcessedString(String action, String s, String keyword) {
		try {
			if (action.trim().isEmpty()) {
				return s;
			}

			if (action.trim().toUpperCase().contains("SPLIT")) {
				int startSub = action.indexOf("[") + 1;
				int endSub = action.indexOf("]");

				int arrSubindex = Integer.parseInt(action.substring(startSub, endSub));

				return s.split(keyword)[arrSubindex - 1].trim();
			}

		} catch (Exception e) {
			Reuse.log(e);
		}
		return s;
	}

	public static void TextBox_InputText(String mode, By by, String text, String textBoxName) {
		try {
			if (isElementPresent(by)) {

				if (mode.equalsIgnoreCase("JS")) {
					JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
					js.executeScript("arguments[0].value='" + text + "'", Demo1.driver.findElement(by));
					// js.executeScript("$(arguments[0]).change()",
					// Demo1.driver.findElement(by));
					js.executeScript("var event = new Event('change');arguments[0].dispatchEvent(event);",
							Demo1.driver.findElement(by));
					js.executeScript("var event = new Event('blur');arguments[0].dispatchEvent(event);",
							Demo1.driver.findElement(by));
				} /*
					 * else if (mode.equalsIgnoreCase("ACTION")) {
					 *
					 * Actions actions = new Actions(Demo1.driver);
					 * actions.moveToElement(Demo1.driver.findElement(by)).click()
					 * .sendKeys(Demo1.driver.findElement(by), text) .build().perform();
					 * Reuse.log("TEXTBOX SEND KEYS VALUE=>" + text); //
					 * Demo1.driver.findElement(by).clear();
					 *
					 * // actions.sendKeys(text);
					 *
					 * }
					 */else if (mode.equalsIgnoreCase("OPTIONAL")) {

					Focus(Demo1.driver.findElement(by));
					Demo1.driver.findElement(by).clear();
					Demo1.driver.findElement(by).sendKeys(text);

				}

				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Input text in to the field <b>" + textBoxName + "</b>",
						"Input text <b>" + text + "</b>", "Text <b>" + text + "</b> entered Successfully");
			} else {
				if (mode.equalsIgnoreCase("OPTIONAL"))
					return;
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Input text in to the field <b>" + textBoxName + "</b>",
						"Input text <b>" + text + "</b>",
						"Element <b>" + textBoxName + " </b> not present/unable to locate element");
			}
		} catch (Exception e) {
			Reuse.log(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Input text in to the field <b>" + textBoxName + "</b>",
					"Input text <b>" + text + "</b>", "Unable to locate textbox <b>" + textBoxName + "</b>");
			Demo1.logger.error(e);
		}
	}

	public static void TextBox_AppendText(By by, String text, String textBoxName) {
		try {
			if (isElementPresent(by)) {
				// Demo1.driver.findElement(by).clear();
				// oWait(5);
				Demo1.driver.findElement(by).sendKeys(text);
				if (Config.wealthRun) {
					// newly added to test the loader element
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
						System.out.println("Error while adding sleep time");
					}
					checkWealthSpinnerElement();
				}
				try {
					String event = Config.textBoxEvent;

					if (event.trim().equalsIgnoreCase("true")) {
						JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
						// js.executeScript("$(arguments[0]).change()",
						// Demo1.driver.findElement(by));
						js.executeScript("var event = new Event('change');arguments[0].dispatchEvent(event);",
								Demo1.driver.findElement(by));
					}
				} catch (Exception e) {
					Reuse.log(e);
					Reuse.log("Error while dispatching change event");
				}

				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Input text in to the field <b>" + textBoxName + "</b>",
						"Input text <b>" + text + "</b>", "Text <b>" + text + "</b> entered Successfully");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Input text in to the field <b>" + textBoxName + "</b>",
						"Input text <b>" + text + "</b>", "Element not fund");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Input text in to the field <b>" + textBoxName + "</b>",
					"Input text <b>" + text + "</b>", "Unbale to locate textbox <b>" + textBoxName + "</b>");
		}
	}

	public static void oSetCommandLine(String command) {
		Demo1.driver.switchTo().frame(0);
		Demo1.driver.findElement(By.id("commandValue")).clear();
		Demo1.driver.findElement(By.id("commandValue")).sendKeys(command);
		Demo1.driver.findElement(By.id("cmdline_img")).click();
	}

	public static void LaunchResults() {
		// RunNo
		try {
			/*
			 * Runtime rTime=Runtime.getRuntime(); String
			 * browser="C:\\Program Files\\Mozilla Firefox\\firefox.exe "; String url =
			 * Demo1.curDir + "\\HTMLResults\\"+Demo1.RunNo+"\\index_"+Demo1.RunNo+".htm";
			 * Process pc; pc=rTime.exec(browser + url); pc.waitFor();
			 */
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
		}
	}

	public static void SwitchToDefaultControl() {
		try {
			Demo1.driver.switchTo().defaultContent();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Switch to Default control", "Should be switched to default control",
					"Switched to default control");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Switch to Default control", "Should be switched to default control", e.getMessage());
		}
	}

	public static void SelectFrame(String name) {
		try {
			WebElement element;
			element = Demo1.driver.findElement(By.xpath("//frame[contains(@id,'" + name + "')]"));
			Demo1.driver.switchTo().frame(element);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Switch to frame by name of <b>" + name + "</b>",
					"Should be switched to Frame <b>" + name + "</b>", "Switched to frame <b>" + name + "</b>");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Switch to frame by name of <b>" + name + "</b>",
					"Should be switched to Frame <b>" + name + "</b>", e.getMessage());
		}
	}

	public static void SelectFrame(By by) {
		try {
			WebElement element;
			element = Demo1.driver.findElement(by);
			Demo1.driver.switchTo().frame(element);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Switch to frame by element", "Should be switched to Frame by element",
					"Switched to frame");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Switch to frame by element", "Should be switched to Frame by element", e.getMessage());
		}

	}

	public static void SelectFrame(int index) {
		try {
			Demo1.driver.switchTo().frame(index);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Switch to frame by Index of <b>" + index + "</b>",
					"Should be switched to Frame <b>" + index + "</b>", "Switched to frame <b>" + index + "</b>");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Switch to frame by Index of <b>" + index + "</b>",
					"Should be switched to Frame <b>" + index + "</b>", e.getMessage());
		}
	}

	public static void Shadow_SelectFrame(String element) {
		try {
			Shadow shadow = new Shadow(Demo1.driver);
			WebElement frame = shadow.findElement(element);
			Demo1.driver.switchTo().frame(frame);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Switch to Shadow frame by element", "Should be switched to ShadowFrame by element",
					"Switched to Shadow frame");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Switch to Shadow frame by element", "Should be switched to Shadow Frame by element",
					e.getMessage());
		}

	}

	public static void Refresh() {
		try {
			Demo1.driver.navigate().refresh();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Refresh page", "Refresh current page", "Reresh done");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Refresh page", "Refresh page", e.getMessage());
		}
	}

	public static void BrowserNavigation(String navigation, String windowName) {
		try {
			if (navigation.equals("Refresh")) {
				Demo1.driver.navigate().refresh();
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Refresh window <b>" + windowName + "</b>",
						"Refresh window <b>" + windowName + "</b>", "Reresh done");
			} else if (navigation.equals("Back")) {
				Demo1.driver.navigate().back();
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Click window <b>" + windowName + "</b> back button",
						"Should be clicked window <b>" + windowName + "</b> back button", "Done");
			} else if (navigation.equals("Forward")) {
				Demo1.driver.navigate().forward();
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Click window <b>" + windowName + "</b> forward button",
						"Should be clicked window <b>" + windowName + "</b> forward button", "Done");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "<b>" + navigation + "</b> window <b>" + windowName + "</b>",
					"Should be <b>" + navigation + "</b> window <b>" + windowName + "</b>", e.getMessage());
		}
	}

	public static void RefreshWindow(String windowName) {
		try {
			SwitchToWindow(windowName);
			Demo1.driver.navigate().refresh();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Refresh window <b>" + windowName + "</b>", "Refresh window <b>" + windowName + "</b>",
					"Reresh done");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Refresh window <b>" + windowName + "</b>", "Refresh window <b>" + windowName + "</b>",
					e.getMessage());
		}
	}

	public static void Alert_Accept() {
		try {
			if (Demo1.driver.switchTo().alert() != null) {
				Demo1.driver.switchTo().alert().accept();
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Accept Alert", "Alert should be accepted", "Alert accepted");
			} else {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Accept Alert", "Alert should be accepted", "Alert not present");
			}
		} catch (NoSuchFieldError e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Accept Alert", "Alert should be accepted", e.getMessage());
		} catch (NoSuchMethodError e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Accept Alert", "Alert should be accepted", e.getMessage());
		} catch (NoSuchElementException e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Accept Alert", "Alert should be accepted", e.getMessage());
		} catch (NoAlertPresentException e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Accept Alert", "Alert should be accepted", "Alert not present");
		}
		/*
		 * Alert alert=null; try { alert = Demo1.driver.switchTo().alert(); if
		 * (IsAlertPresent()) { String alertTxt = alert.getText(); alert.accept();
		 * Demo1.gbTestCaseStatus = "Pass"; Demo1.ReportStep(2, "Accept Alert <b>" +
		 * alertTxt + "</b>", "Able to accept Alert <b>" + alertTxt + "</b>",
		 * "Accepted alert <b>" + alertTxt + "</b> successfully"); } else {
		 * Demo1.gbTestCaseStatus = "Pass"; Demo1.ReportStep(2, "Accept Alert",
		 * "Able to accept Alert", "Alert not present"); } } catch (Exception e) {
		 * Reuse.log(e); Demo1.logger.error(e); Demo1.gbTestCaseStatus = "Fail";
		 * Demo1.ReportStep(2, "Accept Alert", "Able to accept Alert", e.getMessage());
		 * }finally{ alert=null; }
		 */
	}

	public static void Alert_Dismiss() {
		Alert alert = null;
		try {
			alert = Demo1.driver.switchTo().alert();
			if (IsAlertPresent()) {
				String alertTxt = alert.getText();
				alert.dismiss();
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Dismiss Alert <b>" + alertTxt + "</b>",
						"Alert <b>" + alertTxt + "</b> should be dismissed",
						"Alert <b>" + alertTxt + "</b> dismissed successfully");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Dismiss Alert", "Able to Dismiss Alert", "Alert not present");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Dismiss Alert", "Able to Dismiss Alert", e.getMessage());
		} finally {
			alert = null;
		}
	}

	public static void Alert_Present() {
		String alertTxt = "";
		if (IsAlertPresent()) {
			alertTxt = AlertGetText();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Alert <b>" + alertTxt + "</b> Present",
					"Alert <b>" + alertTxt + "</b> should be present", "Alert present");
		} else {
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Alert <b>" + alertTxt + "</b> Present",
					"Alert <b>" + alertTxt + "</b> should be present", "Alert not present");
		}
	}

	public static void Alert_Text(String text, String option) {
		String alertTxt = "";
		try {
			if (IsAlertPresent()) {
				alertTxt = AlertGetText();
				if (option.equals("CONTAINS")) {
					if (alertTxt.contains(text)) {
						Demo1.gbTestCaseStatus = "Pass";
						Demo1.ReportStep(2, "Alert <b>" + text + "</b> exist",
								"Alert <b>" + text + "</b> should be exist", "<b>" + text + "</b> Exist");
					} else {
						Demo1.gbTestCaseStatus = "Fail";
						Demo1.ReportStep(2, "Alert <b>" + text + "</b> exist",
								"Alert <b>" + text + "</b> should be exist", "<b>" + text + "</b> not Exist");
					}
				} else if (option.equals("EQUALS")) {
					if (alertTxt.equals(text)) {
						Demo1.gbTestCaseStatus = "Pass";
						Demo1.ReportStep(2, "Alert <b>" + text + "</b> Exist",
								"Alert <b>" + text + "</b> should be exist", "<b>" + text + "</b> exist");
					} else {
						Demo1.gbTestCaseStatus = "Fail";
						Demo1.ReportStep(2, "Alert <b>" + text + "</b> exist",
								"Alert <b>" + text + "</b> should be exist", "<b>" + text + "</b> not Exist");
					}
				}
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Vefify Alert <b>" + text + "</b> Present",
						"Alert <b>" + text + "</b> should be present", "Alert Not present");
			}
		} catch (NoAlertPresentException e) {
			Demo1.logger.error(e);
			Reuse.log(e);
			// Demo1.gbTestCaseStatus = "Fail";
			// Demo1.ReportStep(2, "Vefify Alert <b>"+text+"</b> Present","Alert
			// <b>"+text+"</b> should be present",e.getMessage());
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			// Demo1.gbTestCaseStatus = "Fail";
			// Demo1.ReportStep(2, "Vefify Alert <b>"+text+"</b> Present","Alert
			// <b>"+text+"</b> should be present",e.getMessage());
		}
	}

	public static String AlertGetText() {
		Alert alert = null;
		try {
			alert = Demo1.driver.switchTo().alert();
			return alert.getText();
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			return null;
		} finally {
			alert = null;
		}
	}

	public static boolean IsAlertPresent() {
		try {
			Demo1.driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {

			Demo1.logger.error(e);
			return false;
		}
	}

	public static void RadioButton_Select(By by, String radioButtonName) {
		try {
			if (isElementPresent(by)) {
				if (!IsRadioButtonSelected(by)) {
					Demo1.driver.findElement(by).click();
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Select RadioButton <b>" + radioButtonName + "</b>",
							"Should be able to select RadioButton <b>" + radioButtonName + "</b>",
							"RadioButton <b>" + radioButtonName + "</b> selected");
				}
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Select RadioButton <b>" + radioButtonName + "</b>",
						"Should be able to select RadioButton <b>" + radioButtonName + "</b>",
						"RadioButton <b>" + radioButtonName + "</b> not selected");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Select RadioButton <b>" + radioButtonName + "</b>",
					"Should be able to select RadioButton <b>" + radioButtonName + "</b>",
					"Unable to locate radiobutton <b>" + radioButtonName + "</b>");
		}
	}

	public static boolean IsRadioButtonSelected(By by) {
		try {
			return Demo1.driver.findElement(by).isSelected();
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			return false;
		}
	}

	public static boolean IsElementSelected(By by) {
		try {
			return Demo1.driver.findElement(by).isSelected();
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			return false;
		}
	}

	public static void ElementEnabled(By by, String elementType, String elementName) {
		try {
			if (Demo1.driver.findElement(by).isEnabled()) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Check " + elementType + " <b>" + elementName + "</b> enabled",
						"" + elementType + " <b>" + elementName + "</b> should be enabled",
						"" + elementType + " <b>" + elementName + "</b> enabled");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check " + elementType + " <b>" + elementName + "</b> enabled",
						"" + elementType + " <b>" + elementName + "</b> should be enabled",
						"" + elementType + " <b>" + elementName + "</b> not enabled");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check " + elementType + " <b>" + elementName + "</b> enabled",
					"" + elementType + " <b>" + elementName + "</b> should be enabled",
					"Unable to locate " + elementType + " <b>" + elementName + "</b>");
		}
	}

	public static void ElementNotEnabled(By by, String elementType, String elementName) {
		try {
			if (Demo1.driver.findElement(by).isEnabled()) {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check " + elementType + " <b>" + elementName + "</b> not enabled",
						"" + elementType + " <b>" + elementName + "</b> should not be enabled",
						"" + elementType + " <b>" + elementName + "</b> enabled");
			} else {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Check " + elementType + " <b>" + elementName + "</b> not enabled",
						"" + elementType + " <b>" + elementName + "</b> should not be enabled",
						"" + elementType + " <b>" + elementName + "</b> not enabled");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check " + elementType + " <b>" + elementName + "</b> not enabled",
					"" + elementType + " <b>" + elementName + "</b> should not be enabled",
					"Unable to locate " + elementType + " <b>" + elementName + "</b>");
		}
	}

	public static void ElementSelected(By by, String elementType, String elementName) {
		try {
			if (Demo1.driver.findElement(by).isSelected()) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Check " + elementType + " <b>" + elementName + "</b> selected",
						"" + elementType + " <b>" + elementName + "</b> should be selected",
						"" + elementType + " <b>" + elementName + "</b> selected");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check " + elementType + " <b>" + elementName + "</b> selected",
						"" + elementType + " <b>" + elementName + "</b> should be selected",
						"" + elementType + " <b>" + elementName + "</b> not selected");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check " + elementType + " <b>" + elementName + "</b> selected",
					"" + elementType + " <b>" + elementName + "</b> should be selected",
					"Unable to locate " + elementType + " <b>" + elementName + "</b>");
		}
	}

	public static void ElementNotSelected(By by, String elementType, String elementName) {
		try {
			if (Demo1.driver.findElement(by).isSelected()) {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check " + elementType + " <b>" + elementName + "</b> not selected",
						"" + elementType + " <b>" + elementName + "</b> should not be selected",
						"" + elementType + " <b>" + elementName + "</b> selected");
			} else {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Check " + elementType + " <b>" + elementName + "</b> not selected",
						"" + elementType + " <b>" + elementName + "</b> should not be selected",
						"" + elementType + " <b>" + elementName + "</b> not selected");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check " + elementType + " <b>" + elementName + "</b> not selected",
					"" + elementType + " <b>" + elementName + "</b> should not be selected",
					"Unable to locate " + elementType + " <b>" + elementName + "</b>");
		}
	}

	public static void shadow_ElementSelected(String by, String elementType, String elementName) {
		try {

			Shadow shadow = new Shadow(Demo1.driver);

			shadow.findElement(by);

			if (shadow.findElement(by).isSelected()) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Check " + elementType + " <b>" + elementName + "</b> selected",
						"" + elementType + " <b>" + elementName + "</b> should be selected",
						"" + elementType + " <b>" + elementName + "</b> selected");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check " + elementType + " <b>" + elementName + "</b> selected",
						"" + elementType + " <b>" + elementName + "</b> should be selected",
						"" + elementType + " <b>" + elementName + "</b> not selected");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check " + elementType + " <b>" + elementName + "</b> selected",
					"" + elementType + " <b>" + elementName + "</b> should be selected",
					"Unable to locate " + elementType + " <b>" + elementName + "</b>");
		}
	}

	public static void shadow_ElementNotSelected(String by, String elementType, String elementName) {
		try {

			Shadow shadow = new Shadow(Demo1.driver);
			if (shadow.findElement(by).isSelected()) {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check " + elementType + " <b>" + elementName + "</b> not selected",
						"" + elementType + " <b>" + elementName + "</b> should not be selected",
						"" + elementType + " <b>" + elementName + "</b> selected");
			} else {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Check " + elementType + " <b>" + elementName + "</b> not selected",
						"" + elementType + " <b>" + elementName + "</b> should not be selected",
						"" + elementType + " <b>" + elementName + "</b> not selected");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check " + elementType + " <b>" + elementName + "</b> not selected",
					"" + elementType + " <b>" + elementName + "</b> should not be selected",
					"Unable to locate " + elementType + " <b>" + elementName + "</b>");
		}
	}

	public static void CheckBoxSet(By by, String setOnOff, String checkBoxName) {
		try {
			if (isElementPresent(by)) {
				if (setOnOff.contentEquals("ON")) {
					if (!IsCheckBoxChecked(by)) {
						Demo1.driver.findElement(by).click();

						Demo1.gbTestCaseStatus = "Pass";
						Demo1.ReportStep(2, "Select checkBox <b>" + checkBoxName + "</b>",
								"Should be able to select checkBox <b>" + checkBoxName + "</b>",
								"CheckBox <b>" + checkBoxName + "</b> selected successfully");
					}
				} else if (setOnOff.contentEquals("OFF")) {
					if (IsCheckBoxChecked(by)) {
						Demo1.driver.findElement(by).click();

						Demo1.gbTestCaseStatus = "Pass";
						Demo1.ReportStep(2, "Uncheck checkBox <b>" + checkBoxName + "</b>",
								"Should be uncheck checkBox <b>" + checkBoxName + "</b>",
								"CheckBox <b>" + checkBoxName + "</b> unchecked successfully");
					}
				}

			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Set checkBox <b>" + checkBoxName + "</b>",
						"Should be able to set checkBox <b>" + checkBoxName + "</b>",
						"CheckBox <b>" + checkBoxName + "</b> not set");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Set checkBox <b>" + checkBoxName + "</b>",
					"Should be able to set checkBox <b>" + checkBoxName + "</b>",
					"Unable to locate checkbox <b>" + checkBoxName + "</b>");
		}
	}

	public static boolean IsCheckBoxChecked(By by) {
		try {
			return Demo1.driver.findElement(by).isSelected();
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			return false;
		}
	}

	public static void DeleteAllCookies() {
		try {
			Demo1.driver.manage().deleteAllCookies();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Delete All Cookies", "Should be Deleted all Cookies", "Deleted");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Delete All Cookies", "Should be Deleted all Cookies", e.getMessage());
		}
	}

	public static void Verify_MultiMessages(By by, String expMessages) {

		List<WebElement> errElements = Demo1.driver.findElements(by);
		String[] arrMessages = expMessages.split("~");
		boolean isErrMsg = false;
		for (String message : arrMessages) {
			for (int i = 0; i < errElements.size(); i++) {
				String actualErrMsg = errElements.get(i).getText();
				if (actualErrMsg.trim().contentEquals(message.trim())) {
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Error Message <b>" + message + "</b> validation",
							"Should be displayed error message <b>" + message + "</b>",
							"Error message <b>" + actualErrMsg + "</b>");
					errElements.remove(i);
					isErrMsg = true;
					break;
				}
				if (!isErrMsg) {
					isErrMsg = false;
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Error Message <b>" + message + "</b> validation",
							"Should be displayed error message <b>" + message + "</b>",
							"Error message <b>" + message + "</b> not displayed");
				}
			}
		}

	}

	public static void ValidateDeal() {
		try {
			By by = By.xpath("//img[contains(@src,'../plaf/images/default/tools/txncommit.gif')]");
			// By by = By.xpath("//img[@title='Validate a deal']");

			if (isElementPresent(by)) {
				Demo1.driver.findElement(by).click();
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Validate a deal", "should be click on Validate a deal button",
						"Clicked on Validate a deal button successfully");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Validate a deal", "should be click on Validate a deal button",
						"Failed to click on Validate a deal button");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Validate a deal", "should be click on Validate a deal button",
					"Unable to identify the element");
		}
	}

	public static void CommitDeal() {
		try {
			By by = By.xpath("//img[@title='Commit the deal']");
			if (isElementPresent(by)) {
				Demo1.driver.findElement(by).click();
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Commit the deal", "should be click on Commit a deal button",
						"Clicked on Commit a deal button successfully");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Commit a deal", "should be click on Commit a deal button",
						"Failed to click on Commit a deal button");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Commit a deal", "should be click on Commit a deal button",
					"Unable to identify the element");
		}
	}

	public static void AcceptOverrides() {
		try {
			By by = By.xpath("//select[contains(@id,'warningChooser:Have you received Introductory Document')]");
			if (isElementPresent(by)) {
				Dropdown_SelectItem(by, "RECEIVED", "Override");
				ValidateDeal();
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
		}
	}

	public static void VerifyButtonText(By by, String text) {
		try {
			if (isElementPresent(by)) {
				if (!Demo1.driver.findElement(by).getAttribute("value").isEmpty()) {
					if (Demo1.driver.findElement(by).getAttribute("value").contentEquals(text)) {
						Demo1.gbTestCaseStatus = "Pass";
						Demo1.ReportStep(2, "Verify button text", "Button text should be " + text,
								"Button text " + text);
					} else {
						Demo1.gbTestCaseStatus = "Fail";
						Demo1.ReportStep(2, "Verify button text", "Button text should be " + text,
								"Expected Button text " + text + " not displayed");
					}
				} else {
					if (!Demo1.driver.findElement(by).getAttribute("title").isEmpty()) {
						if (Demo1.driver.findElement(by).getAttribute("title").contains(text)) {
							Demo1.gbTestCaseStatus = "Pass";
							Demo1.ReportStep(2, "Verify button text", "Button text should be " + text,
									"Button text " + text);
						} else {
							Demo1.gbTestCaseStatus = "Fail";
							Demo1.ReportStep(2, "Verify button text", "Button text should be " + text,
									"Expected Button text " + text + " not displayed");
						}
					}
				}

			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify button text", "Button text should be " + text, "Element not present");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify button text", "Button text should be " + text, "Element not present");
		}
	}

	public static void VerifyAttributeValueExist(String attribute, String expValue, By by, String elementName) {
		try {
			String actAttbValue = Demo1.driver.findElement(by).getAttribute(attribute).trim();
			if (actAttbValue.equals(expValue.trim())) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Vefify attribute value <b>" + expValue + "</b>",
						"Attribute value <b>" + expValue + " </b> should be exist",
						"Attribute value <b>" + expValue + "</b> exist");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Vefify attribute value <b>" + expValue + "</b>",
						"Attribute value <b>" + expValue + " </b> should be exist",
						"Actual Attribute value <b>" + actAttbValue + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Vefify attribute value <b>" + expValue + "</b>",
					"Attribute value <b>" + expValue + " </b> should be exist",
					"Unable to locate <b> " + elementName + " </b>element");
		}
	}

	public static void VerifyAttributeValueNotExist(String attribute, String expValue, By by, String elementName) {
		try {
			String actAttbValue = Demo1.driver.findElement(by).getAttribute(attribute).trim();
			if (!actAttbValue.equals(expValue.trim())) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Vefify attribute value <b>" + expValue + "</b> exist",
						"Attribute value <b>" + expValue + " </b> should not be exist",
						"Actual Attribute value <b>" + actAttbValue + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Vefify attribute value <b>" + expValue + "</b> exist",
						"Attribute value <b>" + expValue + " </b> should not be exist",
						"Actual Attribute value <b>" + actAttbValue + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Vefify attribute value <b>" + expValue + "</b> exist",
					"Attribute value <b>" + expValue + " </b> should not be exist",
					"Unable to locate <b> " + elementName + " </b>element");
		}
	}

	public static void VerifyAttributeValueContains(String attribute, String expValue, By by, String elementName) {
		try {
			String actAttbValue = Demo1.driver.findElement(by).getAttribute(attribute).trim();

			System.out.println("AttributeValue" + actAttbValue);

			if (actAttbValue.contains(expValue.trim())) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2,
						"Vefify attribute value <b> " + actAttbValue + " </b>contains <b>" + expValue + "</b>",
						"Attribute value <b> " + actAttbValue + " </b>should contains <b>" + expValue + " </b>",
						"Attribute value <b>" + actAttbValue + " </b> contains <b>" + expValue + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2,
						"Vefify attribute value <b> " + actAttbValue + " </b>contains <b>" + expValue + "</b>",
						"Attribute value <b> " + actAttbValue + " </b>should contains <b>" + expValue + " </b>",
						"Actual Attribute value <b>" + actAttbValue + " </b>");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Vefify attribute value contains <b>" + expValue + "</b>",
					"Attribute value should contains the text <b>" + expValue + " </b>",
					"Unable to locate element <b> " + elementName + "</b>");
		}
	}

	public static void VerifyAttributeValueNotContains(String attribute, String expValue, By by, String elementName) {
		try {
			String actAttbValue = Demo1.driver.findElement(by).getAttribute(attribute).trim();
			if (!actAttbValue.contains(expValue.trim())) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2,
						"Vefify attribute value <b> " + actAttbValue + " </b> not contains <b>" + expValue + "</b>",
						"Attribute value <b> " + actAttbValue + " </b> should not contains <b>" + expValue + " </b>",
						"Attribute value <b>" + actAttbValue + " </b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2,
						"Vefify attribute value <b> " + actAttbValue + " </b> not contains <b>" + expValue + "</b>",
						"Attribute value <b> " + actAttbValue + " </b> should not contains <b>" + expValue + " </b>",
						"Attribute value <b>" + actAttbValue + " </b>");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Vefify attribute value not contains<b>" + expValue + "</b>",
					"Attribute value should not contains <b>" + expValue + " </b>",
					"Unable to locate <b>" + elementName + " </b>element");

		}
	}

	public static void MouseOver(By by, String elementName) {
		Actions actions = null;
		try {

			WebDriverWait wait = new WebDriverWait(Demo1.driver, Duration.ofSeconds(Config.TIME_OUT));
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));

			actions = new Actions(Demo1.driver);
			WebElement elementAction = Demo1.driver.findElement(by);
			actions.moveToElement(elementAction).build().perform();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Mouseover Event on <b>" + elementName + "</b>", "Mouseover Event should be done",
					"Mouseover Event on <b>" + elementName + "</b> done");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Mouseover Event on <b>" + elementName + "</b>", "Mouseover Event should be done",
					"Mouseover Event on <b>" + elementName + "</b> not done");
		} finally {
			actions = null;
		}
	}

	public static void ShadowMouseOver(String locator, String elementName) {
		Actions actions = null;
		try {

			Shadow shadow = new Shadow(Demo1.driver);
			WebElement elementAction = shadow.findElement(locator);
			actions = new Actions(Demo1.driver);
			actions.moveToElement(elementAction).build().perform();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Shadow Mouseover Event on <b>" + elementName + "</b>",
					"Shadow Mouseover Event should be done",
					"Shadow Mouseover Event on <b>" + elementName + "</b> done");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Shadow Mouseover Event on <b>" + elementName + "</b>",
					"Shadow Mouseover Event should be done",
					"Shadow Mouseover Event on <b>" + elementName + "</b> not done");
		} finally {
			actions = null;
		}
	}
	
	public static void ShadowRightClick(String locator, String elementName) {
		Actions actions = null;
		try {

			Shadow shadow = new Shadow(Demo1.driver);
			WebElement elementAction = shadow.findElement(locator);
			actions = new Actions(Demo1.driver);
			actions.contextClick(elementAction).build().perform();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Shadow RightClick Event on <b>" + elementName + "</b>",
					"Shadow RightClick Event should be done",
					"Shadow RightClick Event on <b>" + elementName + "</b> done");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Shadow RightClick Event on <b>" + elementName + "</b>",
					"Shadow RightClick Event should be done",
					"Shadow RightClick Event on <b>" + elementName + "</b> not done");
		} finally {
			actions = null;
		}
	}

	public static void JS_MouseOver(By by, String elementName) {
		Actions actions = null;
		try {

			WebDriverWait wait = new WebDriverWait(Demo1.driver, Duration.ofSeconds(Config.TIME_OUT));
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));

			WebElement element = Demo1.driver.findElement(by);

			// The below JavaScript code creates, initializes and dispatches
			// mouse event to an object on fly.
			String strJavaScript = "var element = arguments[0];"
					+ "var mouseEventObj = document.createEvent('MouseEvents');"
					+ "mouseEventObj.initEvent( 'mouseover', true, true );" + "element.dispatchEvent(mouseEventObj);";

			// Then JavascriptExecutor class is used to execute the script to
			// trigger the dispatched event.
			((JavascriptExecutor) Demo1.driver).executeScript(strJavaScript, element);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "JS Mouseover Event on <b>" + elementName + "</b>", "Mouseover Event should be done",
					"Mouseover Event on <b>" + elementName + "</b> done");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "JS Mouseover Event on <b>" + elementName + "</b>", "Mouseover Event should be done",
					"Mouseover Event on <b>" + elementName + "</b> not done");
		} finally {
			actions = null;
		}
	}

	public static void DragAndDropByPosition(By by, int xOffset, int yOffset, String elementName) {
		try {
			Actions builder = new Actions(Demo1.driver);
			WebElement elementAction = Demo1.driver.findElement(by);
			Action dragAndDrop = builder.clickAndHold(elementAction).moveByOffset(xOffset, yOffset).release().build();
			dragAndDrop.perform();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2,
					"Drag the element <b>" + elementName + " and Drop in <b>Xoffset:" + xOffset + " and Yoffset: "
							+ yOffset + " </b>",
					"Drag the element <b>" + elementName + " and should be drop in <b>Xoffset:" + xOffset
							+ " and Yoffset: " + yOffset + " </b> ",
					"Drag and Drop Event done");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2,
					"Drag the element <b>" + elementName + " and Drop in <b>Xoffset:" + xOffset + " and Yoffset: "
							+ yOffset + " </b>",
					"Drag the element <b>" + elementName + " and should be drop in <b>Xoffset:" + xOffset
							+ " and Yoffset: " + yOffset + " </b> ",
					"Unbale to locate element <b>" + elementName + "</b>");
		}
	}

	public static void ContextClick(By by, String elementType, String elementName) {
		try {
			JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
			js.executeScript(
					"var event = new Event('HTMLEvents');event.initEvent('contextmenu', true, false);arguments[0].dispatchEvent(event);",
					Demo1.driver.findElement(by));

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Right click on <b>" + elementName + "</b> " + elementType + "",
					"Should be able to right click on <b>" + elementName + "</b> " + elementType + "",
					"Right click action done");

		} catch (Exception e) {
			System.out.println("Checking context click via actions");
			Actions actions = null;
			try {
				actions = new Actions(Demo1.driver);
				WebElement element = Demo1.driver.findElement(by);
				// element.sendKeys(Keys.chord(Keys.SHIFT, Keys.F10));
				actions.moveToElement(element).contextClick(element).build().perform();
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Right click on <b>" + elementName + "</b> " + elementType + "",
						"Should be able to right click on <b>" + elementName + "</b> " + elementType + "",
						"Right click action done");
				actions = null;

			} catch (Exception e1) {
				Reuse.log(e1);
				Demo1.logger.error(e1);
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Right click on <b>" + elementName + "</b> " + elementType + "",
						"Should be able to right click on <b>" + elementName + "</b> " + elementType + "",
						"Right click action not done");

			}

		}
	}

	public static void JS_DragAndDrop(By by, By by1, String elementName) {
		try {

			WebDriverWait wait = new WebDriverWait(Demo1.driver, Duration.ofSeconds(Config.TIME_OUT));
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
			WebElement From = Demo1.driver.findElement(by);
			wait.until(ExpectedConditions.visibilityOfElementLocated(by1));
			WebElement To = Demo1.driver.findElement(by1);

			Actions builder = new Actions(Demo1.driver);

			// builder.moveToElement(Demo1.driver.findElement(by)).perform();

			((JavascriptExecutor) Demo1.driver).executeScript("arguments[0].scrollIntoView(true);", From);

			builder.clickAndHold(Demo1.driver.findElement(by)).perform();

			((JavascriptExecutor) Demo1.driver).executeScript("arguments[0].scrollIntoView(true);", To);

			builder.moveToElement(Demo1.driver.findElement(by1)).build().perform();
			// builder.release(Demo1.driver.findElement(by1));
			builder.release(Demo1.driver.findElement(by1)).build().perform();
			oWait(2);

			builder.perform();
			Thread.sleep(4000);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Drag the element <b>" + elementName + " and Dropped ",
					"Drag the element <b>" + elementName + " and should be dropped", "Drag and Drop Event done");

			Synchronize.defaultAjaxSync();
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Drag the element <b>" + elementName + " and Dropped ",
					"Drag the element <b>" + elementName + " and should be dropped",
					"Unable to locate element <b>" + elementName + "</b>");
		}
	}

	public static void DragAndDrop(By by, By by1, String elementName) {
		try {
			WebDriverWait wait = new WebDriverWait(Demo1.driver, Duration.ofSeconds(Config.TIME_OUT));
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
			WebElement From = Demo1.driver.findElement(by);
			wait.until(ExpectedConditions.visibilityOfElementLocated(by1));
			WebElement To = Demo1.driver.findElement(by1);
			Actions builder = new Actions(Demo1.driver);
			// working for wealth horizontal
			builder.clickAndHold(From).moveToElement(To).perform();
			builder.dragAndDrop(From, To).perform();
			Thread.sleep(4000);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Drag the element <b>" + elementName + " and Dropped ",
					"Drag the element <b>" + elementName + " and should be dropped", "Drag and Drop Event done");

			Synchronize.defaultAjaxSync();
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Drag the element <b>" + elementName + " and Dropped ",
					"Drag the element <b>" + elementName + " and should be dropped",
					"Unable to locate element <b>" + elementName + "</b>");
		}
	}

	public static void DragAndDrop1(By by, By by1, String elementName) {
		try {

			WebDriverWait wait = new WebDriverWait(Demo1.driver, Duration.ofSeconds(Config.TIME_OUT));
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
			WebElement From = Demo1.driver.findElement(by);
			wait.until(ExpectedConditions.visibilityOfElementLocated(by1));
			WebElement To = Demo1.driver.findElement(by1);

			Actions builder = new Actions(Demo1.driver);
//			  builder.clickAndHold(From);
//			  builder.moveToElement(To); 
//			  builder.release(To);
//			  builder.perform();
			if (Config.wealthRun && Demo1.BrowName.contentEquals("firefox")) {
				builder.dragAndDrop(To, From).perform();// headless
			} else {
				builder.dragAndDrop(From, To).perform();// normal mode
			}
			Thread.sleep(4000);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Drag the element <b>" + elementName + " and Dropped ",
					"Drag the element <b>" + elementName + " and should be dropped", "Drag and Drop Event done");

		} catch (Exception e) {
			e.printStackTrace();
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Drag the element <b>" + elementName + " and Dropped ",
					"Drag the element <b>" + elementName + " and should be dropped",
					"Unable to locate element <b>" + elementName + "</b>");
		}
	}

	public static void Shadow_DragAndDrop(String by, String by1, String elementName) {
		try {

			Shadow shadow = new Shadow(Demo1.driver);
			WebElement From = shadow.findElement(by);
			WebElement To = shadow.findElement(by1);
			Actions builder = new Actions(Demo1.driver);
			builder.dragAndDrop(From, To).perform();

			oWait(4);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Shadow Drag the element <b>" + elementName + " and Dropped ",
					"Drag the element <b>" + elementName + " and should be dropped", "Drag and Drop Event done");

			Synchronize.defaultAjaxSync();
		} catch (Exception e) {
			e.printStackTrace();
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Shadow Drag the element <b>" + elementName + " and Dropped ",
					"Drag the element <b>" + elementName + " and should be dropped",
					"Unable to locate element <b>" + elementName + "</b>");
		}
	}

	public static void Shadow_DropdownMultipleValue(String by, String itemToSelect, String dropdownName) {
		try {
			Shadow shadow = new Shadow(Demo1.driver);
			List<WebElement> select = shadow.findElements(by);
			boolean isOptExist = false;
			for (WebElement option : select) {
				if (option.getText().equals(itemToSelect)) {
					JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
					js.executeScript("arguments[0].click();", option);
					// option.click();
					if (Config.wealthRun) {
						checkWealthSpinnerElement();
					}
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
							"Item <b>" + itemToSelect + "</b> should be selected",
							"<b>" + itemToSelect + "</b> Selected");
					isOptExist = true;
					break;
				}
			}
			if (!isOptExist) {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
						"Item <b>" + itemToSelect + "</b> should be selected", "<b>" + itemToSelect + "</b> not exist");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Select <b>" + itemToSelect + "</b> from <b>" + dropdownName + "</b> dropdown",
					"Should be select <b>" + itemToSelect + "</b>",
					"Unable to locate dropdown <b>" + dropdownName + "</b>");
		}
	}

	public static void SendKeysByLocator(By by, String key, String elementName) {
		try {
			if (key.equals("TAB")) {
				Demo1.driver.findElement(by).sendKeys(Keys.TAB);
			} else if (key.equals("ENTER")) {
				Demo1.driver.findElement(by).sendKeys(Keys.ENTER);
			} else if (key.equals("SPACE")) {
				Demo1.driver.findElement(by).sendKeys(Keys.SPACE);
			} else if (key.equals("CNTL")) {
				Demo1.driver.findElement(by).sendKeys(Keys.CONTROL);
			} else if (key.equals("ARROW_DOWN")) {
				Demo1.driver.findElement(by).sendKeys(Keys.ARROW_DOWN);
			} else if (key.equals("ARROW_UP")) {
				Demo1.driver.findElement(by).sendKeys(Keys.ARROW_UP);
			} else if (key.equals("ARROW_RIGHT")) {
				Demo1.driver.findElement(by).sendKeys(Keys.ARROW_RIGHT);
			} else if (key.equals("ARROW_LEFT")) {
				Demo1.driver.findElement(by).sendKeys(Keys.ARROW_LEFT);
			} else if (key.equals("ESCAPE")) {
				Demo1.driver.findElement(by).sendKeys(Keys.ESCAPE);
			} else if (key.equals("ALT")) {
				Demo1.driver.findElement(by).sendKeys(Keys.ALT);
			} /*
				 * else if (key.contains("+")) { Actions keyAction = new Actions(Demo1.driver);
				 *
				 * switch(key){ case "CNTL+A":
				 *
				 * Demo1.driver.findElement(by).sendKeys(Keys.chord(Keys.CONTROL, "a")); break;
				 * case "CNTL+SPACE": System.out.println("we are inside CNTL+SPACE"); keyAction
				 * .keyDown(Demo1.driver.findElement(by), Keys.CONTROL)
				 * .sendKeys(Demo1.driver.findElement(by), " ")
				 * .keyUp(Demo1.driver.findElement(by), Keys.CONTROL) .build() .perform();
				 *
				 * break; case "ALT":
				 *
				 * break; case "ENTER":
				 *
				 * break; default:
				 *
				 * }
				 *
				 * }
				 */ else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "keystroke events on <b>" + elementName + "</b> element",
						"Keystroke of <b>" + key + "</b> on <b>" + elementName + "</b>",
						"Wrong option <b>" + key + "</b> Sent by user");
			}
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "keystroke events on <b>" + elementName + "</b> element",
					"Keystroke of <b>" + key + "</b> on <b>" + elementName + "</b>",
					"Keystroke of <b>" + key + "</b> done");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "keystroke events on <b>" + elementName + "</b> element",
					"Keystroke of <b>" + key + "</b> on <b>" + elementName + "</b>",
					"Unable to locate <b>" + elementName + "</b>");
		}
	}

	public static void SendKeys(String key) {
		Actions actions = null;
		try {
			actions = new Actions(Demo1.driver);
			if (key.equalsIgnoreCase("TAB")) {
				actions.sendKeys(Keys.TAB).build().perform();
			} else if (key.equalsIgnoreCase("ENTER")) {
				actions.sendKeys(Keys.ENTER).build().perform();
			} else if (key.equalsIgnoreCase("SPACE")) {
				actions.sendKeys(Keys.SPACE).build().perform();
			} else if (key.equalsIgnoreCase("BACKSPACE")) {
				actions.sendKeys(Keys.BACK_SPACE).build().perform();
			} else if (key.equalsIgnoreCase("ARROW_DOWN")) {
				actions.sendKeys(Keys.ARROW_DOWN).build().perform();
			} else if (key.equalsIgnoreCase("ARROW_UP")) {
				actions.sendKeys(Keys.ARROW_UP).build().perform();
			} else if (key.equalsIgnoreCase("ARROW_LEFT")) {
				actions.sendKeys(Keys.ARROW_LEFT).build().perform();
			} else if (key.equalsIgnoreCase("ARROW_RIGHT")) {
				actions.sendKeys(Keys.ARROW_RIGHT).build().perform();
			} else if (key.equalsIgnoreCase("ESCAPE")) {
				actions.sendKeys(Keys.ESCAPE).build().perform();
			} else if (key.equalsIgnoreCase("ALT")) {
				actions.sendKeys(Keys.ALT).build().perform();
			} else if (key.equalsIgnoreCase("RETURN")) {
				actions.sendKeys(Keys.RETURN).build().perform();
			} else if (key.equalsIgnoreCase("DELETE")) {
				actions.sendKeys(Keys.DELETE).build().perform();
			} else if (key.equalsIgnoreCase("CTRL+SHIFT+ENTER")) {
				actions.keyDown(Keys.CONTROL).keyDown(Keys.SHIFT).sendKeys(Keys.RETURN).keyUp(Keys.CONTROL)
						.keyUp(Keys.SHIFT).build().perform();
			} else if (key.equalsIgnoreCase("CTRL+SHIFT+SPACE")) {
				actions.keyDown(Keys.CONTROL).keyDown(Keys.SHIFT).sendKeys(Keys.SPACE).keyUp(Keys.CONTROL)
						.keyUp(Keys.SHIFT).build().perform();
			} else if (key.equalsIgnoreCase("SHIFT+TAB")) {
				actions.keyDown(Keys.SHIFT).sendKeys(Keys.TAB).keyUp(Keys.SHIFT).build().perform();
			} else if (key.equalsIgnoreCase("CTRL+SHIFT+CLICK")) {
				actions.keyDown(Keys.CONTROL).keyDown(Keys.SHIFT).click().keyUp(Keys.CONTROL).keyUp(Keys.SHIFT).build()
						.perform();
			}

			else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "keystroke events on the specified element", "Keystroke of <b>" + key + "</b>",
						"Wrong option <b>" + key + "</b> Sent by user");
			}
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "keystroke events", "Keystroke of <b>" + key + "</b>",
					"Keystroke of <b>" + key + "</b> done");
			actions = null;
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "keystroke events on the specified element", "Keystroke of <b>" + key + "</b>",
					e.getMessage());
		} finally {
			actions = null;
		}
	}

	public static void DoubleClick(By by, String elementType, String elementName) {
		Actions actions = null;
		try {
			actions = new Actions(Demo1.driver);
			WebElement element = Demo1.driver.findElement(by);
			actions.moveToElement(element).build().perform();
			actions.doubleClick(element).build().perform();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Double click <b>" + elementName + "</b> " + elementType + "",
					"Should be double click <b>" + elementName + "</b> " + elementType + " ", "Double clicked");
			// actions = null;
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Double click on <b>" + elementName + "</b>",
					"Should be able to double click on <b>" + elementName + " element",
					"Ubale to locate <b>" + elementName + "</b> " + elementType);
		} finally {
			actions = null;
		}
	}

	public static void ClickAction(By by, String elementType, String elementName) {
		Actions actions = null;
		try {
			actions = new Actions(Demo1.driver);
			WebElement element = Demo1.driver.findElement(by);
			// element.sendKeys(Keys.chord(Keys.SHIFT, Keys.F10));
			actions.moveToElement(element).click(element).build().perform();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, " click on <b>" + elementName + "</b> " + elementType + "",
					"Should be able to  click on <b>" + elementName + "</b> " + elementType + "", " click action done");
			actions = null;
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, " click on <b>" + elementName + "</b> " + elementType + "",
					"Should be able to  click on <b>" + elementName + "</b> " + elementType + "",
					" click action not done");
		} finally {
			actions = null;
		}
	}

	public static void RightClick(By by, String elementType, String elementName) {
		Actions actions = null;
		try {
			actions = new Actions(Demo1.driver);
			WebElement element = Demo1.driver.findElement(by);
			// element.sendKeys(Keys.chord(Keys.SHIFT, Keys.F10));
			actions.moveToElement(element).contextClick(element).build().perform();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Right click on <b>" + elementName + "</b> " + elementType + "",
					"Should be able to right click on <b>" + elementName + "</b> " + elementType + "",
					"Right click action done");
			actions = null;
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Right click on <b>" + elementName + "</b> " + elementType + "",
					"Should be able to right click on <b>" + elementName + "</b> " + elementType + "",
					"Right click action not done");
		} finally {
			actions = null;
		}
	}

	public static void RightClick() {
		Actions actions = null;
		try {
			actions = new Actions(Demo1.driver);
			actions.contextClick().build().perform();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Right click", "Right click action should be done", "Right click action done");
			actions = null;
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Right click", "Right click action should be done", "Right click action not done");
		} finally {
			actions = null;
		}
	}

	public static void CtrlSelectionTwoElements(By by1, String by1Name, By by2, String by2Name) {
		Actions actions = null;
		try {
			actions = new Actions(Demo1.driver);
			WebElement element1 = Demo1.driver.findElement(by1);
			WebElement element2 = Demo1.driver.findElement(by2);
			actions.keyDown(Keys.CONTROL).click(element1).click(element2).keyUp(Keys.CONTROL).build().perform();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Press Ctrl and Select <b>" + by1Name + "</b> and <b>" + by2Name + "</b>",
					"Ctrl Selection action should be done", "Ctrl Selection action done");
			actions = null;
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Press Ctrl and Select <b>" + by1Name + "</b> and <b>" + by2Name + "</b>",
					"Ctrl Selection action should be done", "Ctrl Selection action not done");
		} finally {
			actions = null;
		}
	}

	public static void CtrlSelectionMultipleElements(String[] locatorStrings, String elementsName) {
		Actions actions = null;
		WebElement newElement = null;
		try {
			actions = new Actions(Demo1.driver);
			actions.keyDown(Keys.CONTROL);
			for (String locatorString : locatorStrings) {
				newElement = Demo1.driver.findElement(Reuse.GetLocator(locatorString));
				actions.click(newElement);
			}
			actions.keyUp(Keys.CONTROL).build().perform();

			// actions.keyDown(Keys.CONTROL).click(element1).click(element2).keyUp(Keys.CONTROL).build().perform();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Press Ctrl and Select all the elements <b>" + elementsName + "</b>",
					"Ctrl Selection action should be done", "Ctrl Selection action done");
			actions = null;
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Press Ctrl and Select all the elements <b>" + elementsName + "</b>",
					"Ctrl Selection action should be done", "Ctrl Selection action not done");
		} finally {
			actions = null;
		}
	}

	public static void SelectAllElements(By by1, String by1Name, By by2, String by2Name) {
		Actions actions = null;
		try {
			actions = new Actions(Demo1.driver);
			WebElement firstRow = Demo1.driver.findElement(by1);
			String chord = Keys.chord(Keys.SHIFT, Keys.END);
			String chord1 = Keys.chord(Keys.SHIFT, Keys.HOME);
			actions.click(firstRow).sendKeys(chord).sendKeys(chord).build().perform();
			WebElement lastRow = Demo1.driver.findElement(by2);
			actions.keyDown(Keys.SHIFT).click(lastRow).sendKeys(chord1).build().perform();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Select all the <b>" + by1Name + "</b> and <b>" + by2Name + "</b>",
					"Select all rows should be done", "Select all rows action done");
			actions = null;
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Press Ctrl and Select <b>" + by1Name + "</b> and <b>" + by2Name + "</b>",
					"Select all rows should be done", "Select all rows action not done");
		} finally {
			actions = null;
		}
	}

	public static void oComparePosition(By elementToCompare, String nameElementToCompare, By compareWith,
			String nameElementToCompareWith, String rowWiseOrColumnWise, String relationalPosition) {
		try {
			Point pointTOCompare, pointCompareWith;

			int baseVal, compareVal;

			pointTOCompare = Demo1.driver.findElement(elementToCompare).getLocation(); // Element
			// to
			// compare
			// -
			// Base
			// element
			pointCompareWith = Demo1.driver.findElement(compareWith).getLocation();// Element
			// to
			// compare
			// with

			if (rowWiseOrColumnWise == "ROW") {
				baseVal = pointTOCompare.x;
				compareVal = pointCompareWith.x;
			} else {
				baseVal = pointTOCompare.y;
				compareVal = pointCompareWith.y;
			}
			if (baseVal != compareVal) {
				if (relationalPosition.contentEquals("BELOW")) {
					if (compareVal > baseVal) {
						Demo1.gbTestCaseStatus = "Pass";
						Demo1.ReportStep(2,
								"Compare <b>" + nameElementToCompare + "</b> position with <b>"
										+ nameElementToCompareWith + "</b>",
								"<b>" + nameElementToCompareWith + "</b> position should be below the <b>"
										+ nameElementToCompare + " position",
								"<b>" + nameElementToCompareWith + "</b> position <b>below</b> the <b>"
										+ nameElementToCompare + "</b> position");
					} else {
						Demo1.gbTestCaseStatus = "Fail";
						Demo1.ReportStep(2,
								"Compare <b>" + nameElementToCompare + "</b> position with <b>"
										+ nameElementToCompareWith + "</b>",
								"<b>" + nameElementToCompareWith + "</b> position should be below the <b>"
										+ nameElementToCompare + " position",
								"<b>" + nameElementToCompareWith + "</b> position <b>above</b> the <b>"
										+ nameElementToCompare + "</b> position");
					}
				} else if (relationalPosition.contentEquals("ABOVE")) {
					if (compareVal < baseVal) {
						Demo1.gbTestCaseStatus = "Pass";
						Demo1.ReportStep(2,
								"Compare <b>" + nameElementToCompare + "</b> position with <b>"
										+ nameElementToCompareWith + "</b>",
								"<b>" + nameElementToCompareWith + "</b> position should be above the <b>"
										+ nameElementToCompare + " position",
								"<b>" + nameElementToCompareWith + "</b> position <b>above</b> the <b>"
										+ nameElementToCompare + "</b> position");
					} else {
						Demo1.gbTestCaseStatus = "Fail";
						Demo1.ReportStep(2,
								"Compare <b>" + nameElementToCompare + "</b> position with <b>"
										+ nameElementToCompareWith + "</b>",
								"<b>" + nameElementToCompareWith + "</b> position should be above the <b>"
										+ nameElementToCompare + " position",
								"<b>" + nameElementToCompareWith + "</b> position <b>below</b> the <b>"
										+ nameElementToCompare + "</b> position");
					}
				}
				if (relationalPosition.contentEquals("AFTER")) {
					if (compareVal > baseVal) {
						Demo1.gbTestCaseStatus = "Pass";
						Demo1.ReportStep(2,
								"Compare <b>" + nameElementToCompare + "</b> position with <b>"
										+ nameElementToCompareWith + "</b>",
								"<b>" + nameElementToCompareWith + "</b> position should be after the <b>"
										+ nameElementToCompare + "</b>",
								"<b>" + nameElementToCompareWith + "</b> position <b>after</b> the <b>"
										+ nameElementToCompare + "</b>");
					} else {
						Demo1.gbTestCaseStatus = "Fail";
						Demo1.ReportStep(2,
								"Compare <b>" + nameElementToCompare + "</b> position with <b>"
										+ nameElementToCompareWith + "</b>",
								"<b>" + nameElementToCompareWith + "</b> position should be after the <b>"
										+ nameElementToCompare + "</b>",
								"<b>" + nameElementToCompareWith + "</b> position <b>before</b> the <b>"
										+ nameElementToCompare + "</b>");
					}
				} else if (relationalPosition.contentEquals("BEFORE")) {
					if (compareVal < baseVal) {
						Demo1.gbTestCaseStatus = "Pass";
						Demo1.ReportStep(2,
								"Compare <b>" + nameElementToCompare + "</b> position with <b>"
										+ nameElementToCompareWith + "</b>",
								"<b>" + nameElementToCompareWith + "</b> position should be above the <b>"
										+ nameElementToCompare + "</b>",
								"<b>" + nameElementToCompareWith + "</b> position <b>before</b> the <b>"
										+ nameElementToCompare + "</b>");
					} else {
						Demo1.gbTestCaseStatus = "Fail";
						Demo1.ReportStep(2,
								"Compare <b>" + nameElementToCompare + "</b> position with <b>"
										+ nameElementToCompareWith + "</b>",
								"<b>" + nameElementToCompareWith + "</b> position should be above the <b>"
										+ nameElementToCompare + "</b>",
								"<b>" + nameElementToCompareWith + "</b> position <b>after</b> the <b>"
										+ nameElementToCompare + "</b>");
					}
				}
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2,
						"Compare <b>" + nameElementToCompare + "</b> position with <b>" + nameElementToCompareWith
								+ "</b>",
						"<b>" + nameElementToCompareWith + "</b> position should be above the <b>"
								+ nameElementToCompare + "</b>",
						"<b>" + nameElementToCompareWith + "</b> and <b>" + nameElementToCompare + "</b> are in same "
								+ rowWiseOrColumnWise);
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2,
					"Compare <b>" + nameElementToCompare + "</b> position with <b>" + nameElementToCompareWith + "</b>",
					"<b>" + nameElementToCompareWith + "</b> position should be above the <b>" + nameElementToCompare
							+ "</b>",
					e.getMessage());
		}
	}

	public static void VerifyTextContainsInPage(String text, String verificationType) {
		Boolean isTxtValidated = false;
		try {
			if (verificationType.equalsIgnoreCase("CONTAINS")) {
				if (Demo1.driver.getPageSource().contains(text)) {
					isTxtValidated = true;
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Verify text <b>" + text + "</b> contains in page",
							"<b>" + text + "</b> should be exist", "<b>" + text + "</b> exist");
				} else {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Verify text <b>" + text + "</b> contains in page",
							"<b>" + text + "</b> should be exist", "<b>" + text + "</b> not exist");
				}
			} else if (verificationType.equalsIgnoreCase("NOTCONTAINS")) {
				if (!Demo1.driver.getPageSource().contains(text)) {
					isTxtValidated = true;
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Verify text <b>" + text + "</b> not contains in page",
							"<b>" + text + "</b> should not exist", "<b>" + text + "</b> not exist");
				} else {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Verify text <b>" + text + "</b> not contains in page",
							"<b>" + text + "</b> should not exist", "<b>" + text + "</b> exist");
				}
			} else if (verificationType.equalsIgnoreCase("PRESENT")) {
				if (Demo1.driver.getPageSource().equals(text)) {
					isTxtValidated = true;
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Verify text <b>" + text + "</b> present in page",
							"<b>" + text + "</b> should be exist", "<b>" + text + "</b> exist");
				} else {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Verify text <b>" + text + "</b> present in page",
							"<b>" + text + "</b> should be exist", "<b>" + text + "</b> not exist");
				}
			} else if (verificationType.equalsIgnoreCase("NOTPRESENT")) {
				if (!Demo1.driver.getPageSource().equals(text)) {
					isTxtValidated = true;
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Verify text <b>" + text + "</b> not present in page",
							"<b>" + text + "</b> should not exist", "<b>" + text + "</b> not exist");
				} else {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Verify text <b>" + text + "</b> not present in page",
							"<b>" + text + "</b> should not exist", "<b>" + text + "</b> exist");
				}
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>" + text + "</b> contains", "<b>" + text + "</b> should be exist",
					e.getMessage());
		}
	}

	public static By GetLocator(String elementLoc) {
		By by = null;
		String locatorType = elementLoc.substring(0, elementLoc.indexOf("=")).trim();
		String locator = elementLoc.substring(elementLoc.indexOf("=") + 1);
		boolean isLType = false;
		try {
			if (locatorType.equalsIgnoreCase("id")) {
				by = By.id(locator);
				isLType = true;

			} else if (locatorType.equalsIgnoreCase("name")) {
				by = By.name(locator);
				isLType = true;

			} else if (locatorType.equalsIgnoreCase("css")) {
				by = By.cssSelector(locator);
				isLType = true;

			} else if (locatorType.equalsIgnoreCase("link")) {
				by = By.linkText(locator);
				isLType = true;

			} else if (locatorType.equalsIgnoreCase("xpath")) {
				by = By.xpath(locator);
				isLType = true;
			}
			if (isLType) {
				return by;
			} else {
				Demo1.logger.error("Not Matched with any Locator Type.Locator syntax may be worng. Check " + elementLoc
						+ " in Testware.xlsx");
				return null;
			}

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("Not Matched with any Locator Type.Locator syntax may be worng. Check " + elementLoc
					+ " in Testware.xlsx");
			return null;
		}
	}

	public static By GetLocatorBack(String[] param) {
		StringBuffer strBuf = new StringBuffer();
		String locatorType, locator;
		By by = null;

		for (int prmIndx = 1; prmIndx < param.length; prmIndx++) {
			strBuf.append(param[prmIndx]);
		}
		// locatorType=param[0].replaceFirst("\"", "");
		locatorType = param[0];
		locator = strBuf.toString();
		try {
			if (locatorType.equals("id")) {
				by = By.id(locator);

			} else if (locatorType.equals("name")) {
				by = By.name(locator);

			} else if (locatorType.equals("css")) {
				by = By.cssSelector(locator);

			} else if (locatorType.equals("link")) {
				by = By.linkText(locator);

			} else if (locatorType.equals("className")) {
				by = By.className(locator);

			} else if (locatorType.equals("xpath")) {
				StringBuffer sb = new StringBuffer();
				boolean isParamLen = false;
				for (int i = 1; i < param.length; i++) {
					if (!isParamLen) {
						if (param.length > 2) {
							sb = sb.append(param[i]).append("=");
							isParamLen = true;
						} else {
							sb = sb.append(param[i]);
						}
					} else {
						sb = sb.append(param[i]);
					}
				}
				if (sb.toString().contains("[contains("))
					by = By.xpath(locator);
				else
					by = By.xpath(sb.toString());
			}

		} catch (Exception e) {
			Reuse.log(e);
			// Reuse.log(e.getMessage().toString());
		}
		return by;
	}

	public static String[] ProcessParameters(String strParam) {
		String[] finalParamList = null;
		try {

			if (strParam != null && !Demo1.component.trim().equalsIgnoreCase("API_SetRequestBodyByContent")) {
				// String[] finalParamList=null;
				// String subStrOfParamList =
				// strParam.substring(1,strParam.length() - 1);

				String delimiter = "\",";

				String[] arrParamList = strParam.split(delimiter);

				finalParamList = new String[arrParamList.length];
				int arrParLen = arrParamList.length;
				for (int prmIndx = 0; prmIndx < arrParLen; prmIndx++) {
					if (arrParLen == 1) {
						finalParamList[prmIndx] = arrParamList[prmIndx].substring(1,
								arrParamList[prmIndx].length() - 1);
					} else {
						if (prmIndx == 0) {
							finalParamList[prmIndx] = arrParamList[prmIndx].replaceFirst("\"", "");
						} else if (prmIndx == arrParLen - 1) {
							String tempStr = arrParamList[prmIndx].substring(arrParamList[prmIndx].indexOf("\"") + 1);
							finalParamList[prmIndx] = tempStr.substring(0, tempStr.length() - 1);
							tempStr = "";
						} else {
							// String
							// tempStr=arrParamList[prmIndx].substring(arrParamList[prmIndx].indexOf("\"")+1);
							finalParamList[prmIndx] = arrParamList[prmIndx]
									.substring(arrParamList[prmIndx].indexOf("\"") + 1);
							// tempStr="";
						}
					}
				}
				for (int pl = 0; pl < finalParamList.length; pl++) {
					if (finalParamList[pl].contains("ObjRepo.")) {
						String getLoc = ReadOR(finalParamList[pl]);
						finalParamList[pl] = getLoc;
						break;
					}
				}
				return finalParamList;
			} else if (Demo1.component.equalsIgnoreCase("API_SetRequestBodyByContent")) {

				String[] arrParamList = { strParam };

				finalParamList = new String[arrParamList.length];
				int arrParLen = arrParamList.length;
				for (int prmIndx = 0; prmIndx < arrParLen; prmIndx++) {
					if (arrParLen == 1) {
						finalParamList[prmIndx] = arrParamList[prmIndx].substring(1,
								arrParamList[prmIndx].length() - 1);
					}
				}

				return finalParamList;
			} else {

				return finalParamList;
			}

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("Error in ProcessParameters method. Test Case id: " + Demo1.gbCurrTestCaseName
					+ ". Parameters: " + strParam + ". Error: " + e);
			return finalParamList;
		}
	}

	public static String[] BackupProcessParameters(String strParam) {
		try {
			if (strParam != null) {
				String[] finalParamList;
				String subStrOfParamList = strParam.substring(1, strParam.length() - 1);
				String delimiter = "\",";
				String[] arrParamList = subStrOfParamList.split(delimiter);
				finalParamList = new String[arrParamList.length];
				for (int prmIndx = 0; prmIndx < arrParamList.length; prmIndx++) {
					if (prmIndx == 0) {
						finalParamList[prmIndx] = arrParamList[prmIndx];
					} else {
						finalParamList[prmIndx] = arrParamList[prmIndx].replaceFirst(" \"", "");
						// System.out.println(finalParamList[prmIndx]);
					}
				}
				for (int pl = 0; pl < finalParamList.length; pl++) {
					if (finalParamList[pl].contains("ObjRepo.")) {
						String getLoc = ReadOR(finalParamList[pl]);
						finalParamList[pl] = getLoc;
						break;
					}
				}
				return finalParamList;
			} else {
				return null;
			}

		} catch (Exception e) {
			Reuse.log(e);
			return null;
		}
	}

	public static void CheckPoint_IsElementTextPresent(By by, String elementName, String expText, String compareStr,
			String action) {
		boolean isCompareStr = false;
		try {
			if (isElementPresent(by)) {
				if (compareStr.equalsIgnoreCase("EQUALS")) {
					if (Demo1.driver.findElement(by).getText().equals(expText)) {
						Demo1.gbTestCaseStatus = "Pass";
						Demo1.ReportStep(2,
								"Check Check point Text <b>" + expText + "</b> for the element <b>" + elementName
										+ "</b>",
								"Text <b>" + expText + "</b> should be displayed",
								"Text <b>" + compareStr + "</b> displayed");
					} else {
						isCompareStr = true;
					}
				} else if (compareStr.equalsIgnoreCase("CONTAINS")) {
					if (Demo1.driver.findElement(by).getText().contains(expText)) {
						Demo1.gbTestCaseStatus = "Pass";
						Demo1.ReportStep(2,
								"Check Check point Text <b>" + expText + "</b> for the element <b>" + elementName
										+ "</b>",
								"Text <b>" + expText + "</b> should be displayed",
								"Text <b>" + compareStr + "</b> displayed");
					} else {
						isCompareStr = true;
					}
				} else if (compareStr.equalsIgnoreCase("STARTSWITH")) {
					if (Demo1.driver.findElement(by).getText().startsWith(expText)) {
						Demo1.gbTestCaseStatus = "Pass";
						Demo1.ReportStep(2,
								"Check Check point Text <b>" + expText + "</b> for the element <b>" + elementName
										+ "</b>",
								"Text <b>" + expText + "</b> should be displayed",
								"Text <b>" + compareStr + "</b> displayed");
					} else {
						isCompareStr = true;
					}
				} else if (compareStr.equalsIgnoreCase("ENDSWITH")) {
					if (Demo1.driver.findElement(by).getText().endsWith(expText)) {
						Demo1.gbTestCaseStatus = "Pass";
						Demo1.ReportStep(2,
								"Check Check point Text <b>" + expText + "</b> for the element <b>" + elementName
										+ "</b>",
								"Text <b>" + expText + "</b> should be displayed",
								"Text <b>" + compareStr + "</b> displayed");
					} else {
						isCompareStr = true;
					}
				} else {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2,
							"Check Check point Text <b>" + expText + "</b> for the element <b>" + elementName + "</b>",
							"Text <b>" + expText + "</b> should be displayed",
							"Compare action <b>" + compareStr + "</b> not matched");
				}
				if (isCompareStr) {
					isCompareStr = false;
					if (action.equalsIgnoreCase("SKIP_TESTCASE")) {
						isSkipTestCase = true;
						CloseAllChildWindows();
						Demo1.gbTestCaseStatus = "Fail";
						Demo1.ReportStep(2,
								"Check Check point Text <b>" + expText + "</b> in the element <b>" + elementName
										+ "</b>",
								"Text <b>" + expText + "</b> should be displayed",
								"Text <b>" + compareStr + "</b> not displayed. Hence skipped the Testcase");
					} else if (action.equalsIgnoreCase("SKIP_TEST")) {
						isSkipTest = true;
						Demo1.gbTestCaseStatus = "Fail";
						Demo1.ReportStep(2,
								"Check Check point Text <b>" + expText + "</b> in the element <b>" + elementName
										+ "</b>",
								"Text <b>" + expText + "</b> should be displayed",
								"Text <b>" + compareStr + "</b> not displayed. Hence skipped the Test");
					}
				}
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2,
						"Check Check point Text <b>" + expText + "</b> for the element <b>" + elementName + "</b>",
						"Text <b>" + expText + "</b> should be displayed",
						"Unable to locate element <b>" + elementName + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2,
					"Check Check point Text <b>" + expText + "</b> for the element <b>" + elementName + "</b>",
					"Text <b>" + expText + "</b> should be displayed",
					"Unable to locate element <b>" + elementName + "</b> or " + e.getMessage());
		}
	}

	public static void CheckPoint_IsElementPresent(By by, String elementName, String action) {
		try {
			if (!isElementPresent(by)) {
				if (action.equalsIgnoreCase("SKIP_TESTCASE")) {
					isSkipTestCase = true;
					CloseAllChildWindows();
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Check Check point for element <b>" + elementName + "</b>",
							"Element <b>" + elementName + "</b> should be displayed",
							"Unable to locate element. Hence Skipped the Testcase");
				} else if (action.equalsIgnoreCase("SKIP_TEST")) {
					isSkipTest = true;
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Check Check point for element <b>" + elementName + "</b>",
							"Element <b>" + elementName + "</b> should be displayed",
							"Unable to locate element. Hence Skips the Test");
				} else {
					Demo1.logger.error("CheckPoint_Element - Action " + action + " not found");
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Check Check point for element <b>" + elementName + "</b>",
							"Element <b>" + elementName + "</b> should be displayed",
							"Unable to locate element. Hence Skipped the Test");
				}
			} else {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Check Check point for element <b>" + elementName + "</b>",
						"Element <b>" + elementName + "</b> should be displayed", "Displayed");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check Check point for element <b>" + elementName + "</b>",
					"Element <b>" + elementName + "</b> should be displayed", e.getMessage());
		}
	}

	public static String ReadOR(String objectKey) {
		try {
			if (workbookForOR == null) {
				fileForOR = new FileInputStream(new File(Demo1.curDir + "\\OR\\OR.xlsx"));
				workbookForOR = new XSSFWorkbook(fileForOR);
			}
			String expORKey = objectKey;
			String[] orKeySplit = expORKey.split("\\.");

			XSSFSheet SHEET_OR = workbookForOR.getSheet("OR");
			String locator = "";
			int rowNum = SHEET_OR.getLastRowNum() + 1;
			for (int r = 1; r < rowNum; r++) {
				XSSFRow row = SHEET_OR.getRow(r);
				String pageName = row.getCell(0).toString().trim();
				if (pageName.equals(orKeySplit[1].trim())) {
					String objectName = row.getCell(1).toString();
					if (objectName.equals(orKeySplit[2].trim())) {
						locator = row.getCell(2).toString();
						break;
					}
				}
			}
			return locator;
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("ReadOR " + e);
			return "";
		}
	}

	public static void WriteProperties(String key, String value) {
		FileOutputStream fileOut = null;
		FileInputStream fileIn = null;
		File file;
		try {
			Properties configProperty = new Properties();
			if(Config.Mode.equals("LMS")) {
           	 file = new File(Config.TestDataFileLocation + "\\testVariables.prperties");
           }
           else {
           	file = new File(Demo1.curDir + "\\TestData\\testVariables.prperties");
           }
			fileIn = new FileInputStream(file);
			configProperty.load(fileIn);
			configProperty.setProperty(key, value);
			fileOut = new FileOutputStream(file);
			configProperty.store(fileOut, null);
		} catch (Exception ex) {
			Reuse.log(ex);
			// Reuse.log(ex);
		} finally {
			try {
				fileOut.close();
			} catch (Exception e) {
				Reuse.log(e);
				// Reuse.log(e);
			}
		}
	}

	public static void WriteProperties(String key, String value, String filePath) {
		FileOutputStream fileOut = null;
		FileInputStream fileIn = null;
		try {

			Properties configProperty = new Properties();
			File file = new File(filePath);

			if (!file.exists()) {
				file.mkdir();
			} else {

			}

			fileIn = new FileInputStream(file);
			configProperty.load(fileIn);
			configProperty.setProperty(key, value);
			fileOut = new FileOutputStream(file);
			configProperty.store(fileOut, null);
		} catch (Exception ex) {
			Reuse.log(ex);
			// Reuse.log(ex);
		} finally {
			try {
				fileOut.close();
			} catch (Exception e) {
				Reuse.log(e);
				// Reuse.log(e);
			}
		}
	}

	public static String GetPropertyValue(String key) {
		String propval = "";
		FileInputStream propfile = null;
		File cfgfile;
		try {
			if(Config.Mode.equals("LMS")) {
       		 cfgfile = new File(Config.TestDataFileLocation + "\\testVariables.prperties");
           }
           else {
           	cfgfile = new File(Demo1.curDir + "\\TestData\\testVariables.prperties");
           }
			if (cfgfile.exists()) {
				java.util.Properties prop = new java.util.Properties();
				propfile = new FileInputStream(cfgfile);
				prop.load(propfile);
				propval = prop.getProperty(key);
				propfile.close();

				System.out.println("key :: " + key + " Value ::" + propval);

				if (propval == null) {
					Reuse.log("Could not find  a variable in the props with the provided key" + key);

					return "";
				} else {
					return propval;
				}
			} else {
				propval = "";
			}
		} catch (Exception e) {
			Reuse.log(e);
			// Report exception here
		}
		return propval;
	}

	public static String GetTafjPropertyValue(String tafjPath, String key) {
		String propval = "";
		String curDir = System.getProperty("user.dir");
		// System.out.println("curretn directory"+curDir);
		FileInputStream propfile = null;
		try {
			File cfgfile = new File(tafjPath + "/conf/tafj.properties");
			// System.out.println(cfgfile);
			if (cfgfile.exists()) {
				java.util.Properties prop = new java.util.Properties();
				propfile = new FileInputStream(cfgfile);
				prop.load(propfile);
				propval = prop.getProperty(key);
				propfile.close();

				if (propval == null) {
					// Reuse.log("Could not find a variable in the props with
					// the provided key"+key);
					System.out.println(key + "is not present in tafj property");
					return "";
				} else {
					return propval;
				}
			} else {
				propval = "";
			}
		} catch (Exception e) {
			// Reuse.log(e);
			// Report exception here
		}
		System.out.println(key + ":::" + propval);
		return propval;
	}

	public static void AttributeExist(By by, String elementName, String elementType, String attribute) {
		try {
			if (Demo1.driver.findElement(by).getAttribute(attribute) != null) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2,
						"Verify <b>" + elementName + "</b> " + elementType + " attribute <b>" + attribute
								+ "</b> exist",
						"Attribute <b>" + attribute + "</b> should be exist",
						"Attribute <b>" + attribute + "</b> exist");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2,
						"Verify <b>" + elementName + "</b> " + elementType + " attribute <b>" + attribute
								+ "</b> exist",
						"Attribute <b>" + attribute + "</b> should be exist",
						"Attribute <b>" + attribute + "</b> not exist");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2,
					"Verify <b>" + elementName + "</b> " + elementType + " attribute <b>" + attribute + "</b> exist",
					"Attribute <b>" + attribute + "</b> should be exist", e.getMessage());
		}
	}

	public static void AttributeNotExist(By by, String elementName, String elementType, String attribute) {
		try {
			if (Demo1.driver.findElement(by).getAttribute(attribute) != null) {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2,
						"Verify <b>" + elementName + "</b> " + elementType + " attribute <b>" + attribute
								+ "</b> not exist",
						"Attribute <b>" + attribute + "</b> should not be exist",
						"Attribute <b>" + attribute + "</b> exist");
			} else {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2,
						"Verify <b>" + elementName + "</b> " + elementType + " attribute <b>" + attribute
								+ "</b> not exist",
						"Attribute <b>" + attribute + "</b> should not be exist",
						"Attribute <b>" + attribute + "</b> not exist");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2,
					"Verify <b>" + elementName + "</b> " + elementType + " attribute <b>" + attribute
							+ "</b> not exist",
					"Attribute <b>" + attribute + "</b> should not be exist", e.getMessage());
		}
	}

	public static void ElementFocused(By by, String elementName, String elementType) {
		try {
			WebElement element = Demo1.driver.findElement(by);
			if (element.equals(Demo1.driver.switchTo().activeElement())) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Check <b>" + elementName + "</b> " + elementType + " focused",
						"<b>" + elementName + "</b> should be focused", "Focused");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check <b>" + elementName + "</b> " + elementType + " focused",
						"<b>" + elementName + "</b> should be focused", "Not focused");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check <b>" + elementName + "</b> " + elementType + " focused",
					"<b>" + elementName + "</b> should be focused", e.getMessage());
		}
	}

	public static void ElementNotFocused(By by, String elementName, String elementType) {
		try {
			WebElement element = Demo1.driver.findElement(by);

			if (element.equals(Demo1.driver.switchTo().activeElement())) {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check <b>" + elementName + "</b> " + elementType + " not focused",
						"<b>" + elementName + "</b> should not be focused", "Focused");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check <b>" + elementName + "</b> " + elementType + " not focused",
						"<b>" + elementName + "</b> should not be focused", "Not focused");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check <b>" + elementName + "</b> " + elementType + " not focused",
					"<b>" + elementName + "</b> should not be focused", e.getMessage());
		}
	}

	public static void StoreTextByPosition(By by, String position, String elementName, String variableName) {
		try {
			if (Reuse.isElementPresent(by)) {
				String strElementTxt = Demo1.driver.findElement(by).getText();
				String[] splitelement = strElementTxt.split(" ");
				String textToStore;
				if (position.equals("END")) {
					textToStore = splitelement[splitelement.length - 1].replaceAll("-", "").trim();
				} else {
					textToStore = splitelement[0].replaceAll("-", "").trim();
				}
				oStoreText(textToStore, variableName, elementName);
				// Demo1.gbTestCaseStatus = "Pass";
				// Demo1.ReportStep(2,
				// "Strore data for <b>"+elementName+"</b>","Data should be
				// stored","Stored data: <b>"+Demo1.storeTextData+"</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Strore data for <b>" + elementName + "</b>", "Data should be stored",
						"Unable to locate Element <b>" + elementName + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Strore data for <b>" + elementName + "</b>", "Data should be stored", e.getMessage());
		}
	}

	public static void CompareColor(By by, String elementName, String expColorCode) {
		try {
			String color = Demo1.driver.findElement(by).getCssValue("color");
			String[] numbers = color.replace("rgba(", "").replace(")", "").split(",");
			int r = Integer.parseInt(numbers[0].trim());
			int g = Integer.parseInt(numbers[1].trim());
			int b = Integer.parseInt(numbers[2].trim());

			String hex = "#" + Integer.toHexString(r) + Integer.toHexString(g) + Integer.toHexString(b);
			if (hex.equals(expColorCode)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Compare  <b>" + elementName + "</b> color",
						"<b>" + elementName + "</b> color should be matched with <b>" + expColorCode + "</b> code",
						"Actual color code is <b>" + hex + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Compare  <b>" + elementName + "</b> color",
						"<b>" + elementName + "</b> color should be matched with <b>" + expColorCode + "</b> code",
						"Actual color code is <b>" + hex + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Compare  <b>" + elementName + "</b> color",
					"<b>" + elementName + "</b> color should be matched with <b>" + expColorCode + "</b> code",
					"Error due to Element/format/color code");
		}
	}

	public static void CompareBGColor(By by, String elementName, String expColorCode) {
		try {
			String color = Demo1.driver.findElement(by).getCssValue("background-color");
			String[] numbers = color.replace("rgba(", "").replace(")", "").split(",");
			int r = Integer.parseInt(numbers[0].trim());
			int g = Integer.parseInt(numbers[1].trim());
			int b = Integer.parseInt(numbers[2].trim());

			String hex = "#" + Integer.toHexString(r) + Integer.toHexString(g) + Integer.toHexString(b);
			if (hex.equals(expColorCode)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Compare  <b>" + elementName + "</b> BG color",
						"<b>" + elementName + "</b> BG color should be matched with <b>" + expColorCode + "</b> code",
						"Actual color code is <b>" + hex + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Compare  <b>" + elementName + "</b> BG color",
						"<b>" + elementName + "</b> BG color should be matched with <b>" + expColorCode + "</b> code",
						"Actual color code is <b>" + hex + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Compare  <b>" + elementName + "</b> BG color",
					"<b>" + elementName + "</b> BG color should be matched with <b>" + expColorCode + "</b> code",
					"Error due to Element/format/color code");
		}
	}

	public static void TextStyle_Bold(By by) {
		try {
			String strSize = Demo1.driver.findElement(by).getCssValue("font-weight");
			if (strSize.equals("bold")) {
				Reuse.log("Bold");
			} else if (Integer.parseInt(strSize) >= 700) {
				Reuse.log("Bold");
			} else {
				Reuse.log("Not Bold");
			}
		} catch (Exception e) {
			Reuse.log(e);
		}
	}

	public static void TextStyle(By by, String style) {
		try {
			String strSize = Demo1.driver.findElement(by).getCssValue(style);
			if (strSize.equals("bold")) {
				Reuse.log("Bold");
			} else if (Integer.parseInt(strSize) >= 700) {
				Reuse.log("Bold");
			} else {
				Reuse.log("Not Bold");
			}
		} catch (Exception e) {
			Reuse.log(e);
		}
	}

	public static void oStoreElementText(By by, String variableName, String elementName) {
		boolean isMapInitialized = false;
		try {
			if (!isMapInitialized) {
				txtAndVal = new HashMap<>();
				isMapInitialized = true;
			}
			String eleText = Demo1.driver.findElement(by).getText();
			if (eleText != null) {
				if (!txtAndVal.containsKey(variableName)) {
					txtAndVal.put(variableName, eleText.trim());
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Store text <b>" + eleText + "</b> in <b>" + variableName + "</b> variable",
							"Text <b>" + eleText + "</b> should be stored in <b>" + variableName + "</b> variable",
							"Stored");
				} else {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Store text <b>" + eleText + "</b> in <b>" + variableName + "</b> variable",
							"Text <b>" + eleText + "</b> should be stored in <b>" + variableName + "</b> variable",
							"Provided variable <b>" + variableName
									+ " already exist. Kindly provide some other variable name.");
				}
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Store text <b>" + eleText + "</b> in <b>" + variableName + "</b> variable",
						"Text <b>" + eleText + "</b> should be stored in <b>" + variableName + "</b> variable",
						"Unable to get text from <b>" + elementName + "</b>");
			}

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Store text in <b>" + variableName + "</b> variable",
					"Text should be stored in <b>" + variableName + "</b> variable", e.getMessage());
		}
	}

	public static void oStoreText(String textToStore, String variableName, String elementName) {
		boolean isMapInitialized = false;
		try {
			if (!isMapInitialized) {
				STORE_TEXT = new HashMap<>();
				isMapInitialized = true;
			}
			String eleText = textToStore;
			if (eleText != null) {
				if (!STORE_TEXT.containsKey(variableName)) {
					STORE_TEXT.put(variableName, eleText.trim());
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Store text <b>" + eleText + "</b> in <b>" + variableName + "</b> variable",
							"Text <b>" + eleText + "</b> should be stored in <b>" + variableName + "</b> variable",
							"Stored");
				} else {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Store text <b>" + eleText + "</b> in <b>" + variableName + "</b> variable",
							"Text <b>" + eleText + "</b> should be stored in <b>" + variableName + "</b> variable",
							"Provided variable <b>" + variableName
									+ " already exist. Kindly provide some other variable name.");
				}
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Store text <b>" + eleText + "</b> in <b>" + variableName + "</b> variable",
						"Text <b>" + eleText + "</b> should be stored in <b>" + variableName + "</b> variable",
						"Unable to get text from <b>" + elementName + "</b>");
			}

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Store text in <b>" + variableName + "</b> variable",
					"Text should be stored in <b>" + variableName + "</b> variable", e.getMessage());
		}
	}

	public static void Table_Click(String expElementTxt, String elementName, int ColumnToPerAction, String expAction,
			By by) {
		Actions action = null;
		try {
			action = new Actions(Demo1.driver);
			boolean isActionDone = false;
			// To locate table
			WebElement table = Demo1.driver.findElement(by);
			// To locate Rows
			List<WebElement> table_Rows = table.findElements(By.tagName("tr"));
			// No of rows
			int table_rows_count = table_Rows.size();
			breakForLoop: for (int i = 0; i < table_rows_count; i++) {
				List<WebElement> table_Columns = table_Rows.get(i).findElements(By.tagName("td"));
				int column_count = table_Columns.size();
				for (int j = 0; j < column_count; j++) {
					WebElement element = table_Columns.get(j);
					if (expElementTxt.equals(element.getText())) {
						if (expAction.equalsIgnoreCase("CLICK")) {
							// System.out.println(table_Columns.get(ColumnToPerAction).getText());
							WebElement ele = table_Columns.get(ColumnToPerAction);
							Reuse.log(ele.getText());
							ele.click();
							isActionDone = true;
							break breakForLoop;
						} else if (expAction.equalsIgnoreCase("DOUBLE_CLICK")) {
							action.doubleClick(table_Columns.get(ColumnToPerAction)).build().perform();
							isActionDone = true;
							break breakForLoop;
						} else {
							Demo1.gbTestCaseStatus = "Fail";
							Demo1.ReportStep(2, "Perform " + expAction + " on <b>" + elementName + "</b>",
									expAction + " should be performed", "Action " + expAction + " not found");
						}
					}
				}
			}
			if (isActionDone) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Perform " + expAction + " on <b>" + elementName + "</b>",
						expAction + " should be performed", expAction + " done successfully");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Perform " + expAction + " on <b>" + elementName + "</b>",
						expAction + " should be performed", "Unable to locate element " + elementName);

			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("Error in Table_PerfomActionsOnTable - " + e.getMessage().toString());
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Perform " + expAction + " on <b>" + elementName + "</b>",
					expAction + " should be performed", "Unable to locate element " + elementName);
		} finally {
			action = null;
		}
	}

	public static void Table_SetText(String expElementTxt, String elementName, int ColumnToPerAction, String expAction,
			String textToSet, By by) {
		try {
			boolean isActionDone = false;
			// To locate table
			WebElement table = Demo1.driver.findElement(by);
			// To locate Rows
			List<WebElement> table_Rows = table.findElements(By.tagName("tr"));
			// No of rows
			int table_rows_count = table_Rows.size();
			breakForLoop: for (int i = 0; i < table_rows_count; i++) {
				List<WebElement> table_Columns = table_Rows.get(i).findElements(By.tagName("td"));
				int column_count = table_Columns.size();
				for (int j = 0; j < column_count; j++) {
					WebElement element = table_Columns.get(j);
					if (expElementTxt.equals(element.getText())) {
						if (expAction.equalsIgnoreCase("SET_TEXT")) {
							table_Columns.get(ColumnToPerAction).clear();
							table_Columns.get(ColumnToPerAction).sendKeys(textToSet);
							isActionDone = true;
							break breakForLoop;
						} else if (expAction.equalsIgnoreCase("APPEND_TEXT")) {
							table_Columns.get(ColumnToPerAction).sendKeys(textToSet);
							isActionDone = true;
							break breakForLoop;
						} else {
							Demo1.gbTestCaseStatus = "Fail";
							Demo1.ReportStep(2, "Perform " + expAction + " on <b>" + elementName + "</b>",
									expAction + " should be performed", "Action " + expAction + " not found");
						}
					}
				}
			}
			if (isActionDone) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Perform " + expAction + " on <b>" + elementName + "</b>",
						expAction + " should be performed", expAction + " done successfully");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Perform " + expAction + " on <b>" + elementName + "</b>",
						expAction + " should be performed", "Unable to locate element " + elementName);
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("Error in Table_PerfomActionsOnTable - " + e.getMessage().toString());
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Perform " + expAction + " on <b>" + elementName + "</b>",
					expAction + " should be performed", "Unable to locate element " + elementName);
		}
	}

	// *********************************************************************
	// ****************** Windows based reusable functions ******************
	// *********************************************************************
	public static boolean isWinWindowExist(String winName) {
		try {
			return Demo1.autoItX.winExists(winName);
		} catch (Exception e) {
			Reuse.log(e);
			return false;
		}
	}

	public static boolean WinExist(String winName) {
		try {
			return Demo1.autoItX.winExists(winName);
		} catch (Exception e) {
			Reuse.log(e);
			return false;
		}
	}

	public static void WinWindowSetText(String winName, String editName, String control, String setText) {
		try {
			Demo1.autoItX.winActivate(winName);
			Demo1.autoItX.ControlSetText(winName, "", control, setText);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Set text in <b>" + editName + "</b>",
					"Text <b>" + editName + "</b> should be inputted ", "<b>" + editName + "</b> Inserted");

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Set text in <b>" + editName + "</b>",
					"Text <b>" + editName + "</b> should be inputted ", "<b>" + editName + "</b> not inserted");
		}
	}

	public static void WinWindowExist(String winName) {
		try {
			if (isWinWindowExist(winName)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Check <b>" + winName + "</b> Window exist",
						"<b>" + winName + "</b> should be exist", "Exist");

			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check <b>" + winName + "</b> Window exist",
						"<b>" + winName + "</b> should be exist", "Not Exist");

			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check <b>" + winName + "</b> Window exist", "<b>" + winName + "</b> should be exist",
					e.getMessage());
		}
	}

	public static void WinWindowNotExist(String winName) {
		try {
			if (isWinWindowExist(winName)) {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check <b>" + winName + "</b> Window not exist",
						"<b>" + winName + "</b> should not be exist", "Exist");
			} else {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Check <b>" + winName + "</b> Window not exist",
						"<b>" + winName + "</b> should not be exist", "Not Exist");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check <b>" + winName + "</b> Window not exist",
					"<b>" + winName + "</b> should not be exist", e.getMessage());
		}
	}

	public static void WinWindow_Close(String winName) {
		try {
			if (isWinWindowExist(winName)) {
				Demo1.autoItX.winActivate(winName);
				Demo1.autoItX.winClose(winName);
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Close Window <b>" + winName + "</b>",
						"<b>" + winName + "</b> window should be closed", "Closed");

			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Close Window <b>" + winName + "</b>",
						"<b>" + winName + "</b> window should be closed", "Window <b>" + winName + "</b> not exist");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Close Window <b>" + winName + "</b>", "<b>" + winName + "</b> window should be closed",
					e.getMessage());
		}
	}

	public static void WinWindowClick(String title, String text, String controlText, String controlID) {
		try {
			if (Demo1.autoItX.winExists(title)) {
				Demo1.autoItX.winActivate(title);
				Demo1.autoItX.controlClick(title, controlText, controlID);
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Click  <b>" + text + "</b> on Window <b>" + title + "</b> ",
						"Should be clicked on <b>" + text + "</b>", "Clicked");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Click  <b>" + text + "</b> on Window <b>" + title + "</b> ",
						"Should be clicked on <b>" + text + "</b>", "Window <b>" + title + "<b> not exist");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("Problem in WinWindowClick. " + e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Click  <b>" + text + "</b> on Window <b>" + title + "</b> ",
					"Should be clicked on <b>" + text + "</b>", e.getMessage());
		}
	}

	public static void WinRun(String applicationName, String filename, String inputParams) {
		try {
			/* Demo1.autoItX.runWait(filename); */
			// Runtime.getRuntime().exec(filename + " " + inputParams);

			String filePath = "";
			if (filename.startsWith("dlls")) {
				filePath = curDir + File.separator + filename;
			} else {
				filePath = filename;
			}

			String inputParameters = "";
			if (inputParams.startsWith("TestData")) {
				inputParameters = curDir + File.separator + inputParams;
			} else {
				inputParameters = inputParams;
			}

			Demo1.logger.info("APPLN::" + filePath + "\tPARAM::" + inputParameters);
			Runtime.getRuntime().exec(new String[] { filePath, inputParameters });

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Run Application <b>" + applicationName + "</b>",
					"Application <b>" + applicationName + "</b>Should be Launched",
					"Application <b>" + applicationName + "</b> launched");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("Problem in WinRun. " + e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Run Application <b>" + applicationName + "</b>",
					"Application <b>" + applicationName + "</b>Should be Launched",
					"Application <b>" + applicationName + "</b> not launched");
		}
	}

	public static void WinWindow_Wait(String winTitle) {
		Demo1.autoItX.winWaitActive(winTitle);
	}

	public static void WinWindow_setText(String winTitle, String fieldName, String textToSet) {
		try {
			Demo1.autoItX.winActivate(winTitle);
			Demo1.autoItX.send(textToSet);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Input text <b>" + textToSet + "</b> in <b>" + fieldName + "</b> field",
					"Text <b>" + textToSet + "</b> should be entered in <b>" + fieldName + "</b> field",
					"Text <b>" + textToSet + "</b> entered in <b>" + fieldName + "</b> field successfully");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("WinWindow_sendKeys. " + e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Input text <b>" + textToSet + "</b> in <b>" + fieldName + "</b> field",
					"Text <b>" + textToSet + "</b> should be entered in <b>" + fieldName + "</b> field",
					e.getMessage());
		}
	}

	public static void WinWindow_LoginAuthentication(String winTitle, String user, String password) {
		try {
			Demo1.autoItX.winWaitActive(winTitle);
			Demo1.autoItX.send(user);
			Demo1.autoItX.send("{TAB}", false);
			Demo1.autoItX.send(password);
			Demo1.autoItX.send("{ENTER}", false);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Authentication",
					"Should be authenticate using the user <b>" + user + "</b> and password <b>" + password + "</b>",
					"Authenticated successfully");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("WinWindow_sendKeys. " + e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Authentication",
					"Should be authenticate using the user <b>" + user + "</b> and password <b>" + password + "</b>",
					"Failded to Authenticated " + e.getMessage());
		}
	}

	public static void TomcatStop(String path) {
		Process p = null;
		try {
			p = Runtime.getRuntime().exec("cmd /c start /MIN " + path + "\\bin//shutdown.bat run ", null,
					new File(path));
			Thread.sleep(2000);
			// Runtime.getRuntime().exec("taskkill /IM cmd.exe");
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Stop Tomcat server", "Server should be stopped", "Server stopped successfully");

		} catch (Exception e) {
			Reuse.log(e);
			Reuse.log("Server stop failed");
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Stop Tomcat server", "Server should be stopped", "Failed to stop server");
		} finally {
			p = null;
		}
	}

	// Functions to start and stop tomcat

	public static void TomcatStart(String path) {

		/*
		 * File file = new File(path + "\\webapps\\TrainingCourse.war");
		 *
		 * while (!file.exists()) { Thread.sleep(5000); }
		 */

		deleteLog(path);
		Process p = null;
		try {
			p = Runtime.getRuntime().exec("cmd /c start /MIN " + path + "\\bin//catalina.bat run ", null,
					new File(path));
			Thread.sleep(2000);
			String h = readFileBack(path);
			while (!h.contains("Server startup")) {
				h = readFileBack(path);
			}
			if (h.contains("Server startup")) {
				// Reuse.log("Server started");
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Start Tomcat server", "Server should be started", "Server started successfully");
			} else {
				// Reuse.log("Server already in use");
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Start Tomcat server", "Server should be started", "Server already in use");
			}

		} catch (Exception e) {
			Reuse.log(e);
			// Reuse.log("Server not started");
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Start Tomcat server", "Server should be started", "Server not started");
		} finally {
			p = null;
		}
	}

	public static void deleteLog(String path) {
		String ld = dateFormat("yyyy-MM-dd");
		File logfile = new File(path + "\\logs\\catalina." + ld + ".log");
		if (logfile.exists()) {
			if (logfile.delete()) {
				// Reuse.log("log file deleted");
			} else {
				// Reuse.log("log file not deleted");
			}
		}
	}

	public static String readFileBack(String path) throws IOException {
		String ld = dateFormat("yyyy-MM-dd");
		File logfile = new File(path + "\\logs\\catalina." + ld + ".log");
		StringBuilder sb = null;
		BufferedReader br = new BufferedReader(new FileReader(logfile));
		try {
			sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append(System.lineSeparator());
				line = br.readLine();
			}
			String everything = sb.toString();
			// Reuse.log(everything);
			return everything;
		} finally {
			br.close();
			logfile = null;
			sb = null;
		}
	}

	public static String ReadFile(String path) {
		BufferedReader br = null;
		FileReader fr = null;
		StringBuilder sb = null;

		try {
			fr = new FileReader(path);
			br = new BufferedReader(fr);
			String sCurrentLine;
			sb = new StringBuilder();
			while ((sCurrentLine = br.readLine()) != null) {
				sb.append(sCurrentLine);
				sb.append(System.lineSeparator());
			}
			return sb.toString();
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} finally {
			try {

				if (br != null)
					br.close();

				if (fr != null)
					fr.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}

		}

	}

	public static StringBuilder readFile(String path) {
		// Assumes that a file article.rss is available on the SD card
		File file = new File(path);
		StringBuilder builder = new StringBuilder();
		if (!file.exists()) {
			System.out.println(file.toString());
			throw new RuntimeException("File not found");
		}
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(file));
			String line;
			while ((line = reader.readLine()) != null) {
				builder.append(line);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return builder;
	}

	public static void verifyTextContainInFile(String path, String expectedText) {

		try {
			if (readFile(path).toString().contains(expectedText)) {

				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "To verify text in file", expectedText + "Text should contain in : " + path,
						"Contains in File");

			} else {

				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "To verify text in file", expectedText + "Text doesn't should contain in : " + path,
						"Doesn't Contains in File");

			}
		} catch (Exception e) {

			Reuse.log(e);
			e.printStackTrace();

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To verify text in file", "Text doesn't should contain in : " + path,
					"Doesn't Contains in File");

			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
		}

	}

	public static void verifyTextContainInPDF(String path, String expectedText) {

		try {

			File file = new File(path);
			PDDocument document = PDDocument.load(file);
			// Instantiate PDFTextStripper class
			PDFTextStripper pdfStripper = new PDFTextStripper();
			// Retrieving text from PDF document
			String text = pdfStripper.getText(document);
			System.out.println(text);
			// Closing the document
			document.close();

			if (text.contains(expectedText)) {

				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "To verify text in file", expectedText + "Text should contain in : " + path,
						"Contains in File");

			} else {

				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "To verify text in file", expectedText + "Text doesn't should contain in : " + path,
						"Doesn't Contains in File");

			}

		} catch (Exception e) {

			Reuse.log(e);
			e.printStackTrace();

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To verify text in file", "Text doesn't should contain in : " + path,
					"Doesn't Contains in File");

			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
		}

	}

	public static void editTextFile(String path, int lineNo, int startPos, int endPos, String replaceString,
			String SaveAsPath) {

		try {
			FileReader Moduleconf = new FileReader(path);
			BufferedReader Modulebr = new BufferedReader(Moduleconf);
			String s;
			StringBuffer newStrModule = new StringBuffer();

			int i = 0;
			while ((s = Modulebr.readLine()) != null) {

				i++;
				String s1 = s.trim();

				if (lineNo == i) {

					String r = s1.substring(startPos, endPos);

					newStrModule.append(s1.replace(r, replaceString) + "\n");

				} else {
					newStrModule.append(s + "\n");
				}
			}
			Modulebr.close();
			Moduleconf.close();
			FileWriter fw = new FileWriter(SaveAsPath);
			fw.write(newStrModule.toString());
			fw.close();
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public static String dateFormat(String dtFormat) {
		Date date = null;
		try {
			date = new Date();
			SimpleDateFormat ft = new SimpleDateFormat(dtFormat);
			String logdate = ft.format(date);
			return logdate;
		} catch (Exception e) {
			Reuse.log(e);
			return null;
		} finally {
			date = null;
		}
	}
	
	 public static String dateFormat(String dtFormat, int daysToModify) {
	        String result = null;
	        try {
	        	SimpleDateFormat ft = new SimpleDateFormat(dtFormat);
	    		Date dt = new Date();
	            System.out.println("Current Date::" + ft.format(dt));
	            Calendar c = Calendar.getInstance();
	            
	            	c.setTime(dt);
	                c.add(Calendar.DATE, daysToModify);
	                dt = c.getTime();
	                result = ft.format(dt);
	                System.out.println("Updated Date::" + result);
	            
	            return result;
	        } catch (Exception e) {
	            Reuse.log(e);
	            return null;
	        }
	    }

	public static String dateFormat(String dtFormat, int daysToModify, String action) {
		String result = null;
		try {
			SimpleDateFormat ft = new SimpleDateFormat(dtFormat);
			Date dt = new Date();
			System.out.println("Current Date::" + ft.format(dt));
			Calendar c = Calendar.getInstance();

			if (action.equalsIgnoreCase("ADD")) {
				c.setTime(dt);
				c.add(Calendar.DATE, daysToModify);
				dt = c.getTime();
				result = ft.format(dt);
				System.out.println("Updated Date::" + result);
			}

			return result;
		} catch (Exception e) {
			Reuse.log(e);
			return null;
		}
	}

	public static String customDateFormat(String dtFormat, int daysToModify, String propkey) {
		String result = null;
		try {
			String propvalue = Reuse.GetPropertyValue(propkey);
			SimpleDateFormat ft = new SimpleDateFormat(dtFormat);
			@SuppressWarnings("deprecation")
			Date dt = new Date(propvalue);
			System.out.println("Property file Date::" + ft.format(dt));
			Calendar c = Calendar.getInstance();
			c.setTime(dt);
			c.add(Calendar.DATE, daysToModify);
			dt = c.getTime();
			result = ft.format(dt);
			System.out.println("Updated Date::" + result);

			return result;
		} catch (Exception e) {
			Reuse.log(e);
			return null;
		}
	}

	public static String customTimeFormat(String TimeFormat, int TimeToModify, String Timezone) {
		String result = null;
		try {
			SimpleDateFormat ft = new SimpleDateFormat(TimeFormat.trim());
			Date dt = new Date();
			ft.setTimeZone(TimeZone.getTimeZone(Timezone.toUpperCase().trim()));
			String time = ft.format(dt);
			System.out.println("Current " + Timezone + "Time::" + time);
			Reuse.log("Current " + Timezone + "Time::" + time);
			Date parse = ft.parse(time);
			Calendar cal = Calendar.getInstance();
			cal.setTime(parse);
			cal.add(Calendar.MINUTE, TimeToModify);
			dt = cal.getTime();
			result = ft.format(dt);
			System.out.println("Updated " + Timezone + "time::" + result);
			Reuse.log("Updated " + Timezone + "time::" + result);

			return result;
		} catch (Exception e) {
			Reuse.log(e);
			return null;
		}
	}

	public static String dateFormat(String dtFormat, String Zone) {
		Date date = null;
		try {
			date = new Date();
			SimpleDateFormat ft = new SimpleDateFormat(dtFormat);
			ft.setTimeZone(TimeZone.getTimeZone(Zone));
			String logdate = ft.format(date);
			System.out.println(logdate);
			return logdate;
		} catch (Exception e) {
			Reuse.log(e);
			return null;
		} finally {
			date = null;
		}
	}

	public static Boolean WaitUntilFileCreated(String path, int timeIntervelInSec) {
		File file = new File(path);
		while (!file.exists()) {
			try {
				int timeInSec = timeIntervelInSec * 1000;
				Thread.sleep(timeInSec);
			} catch (Exception ie) {
				Reuse.log(ie);
				return null;
			}
		}
		return true;
	}

	public static void StartLDTest(String qtppath, String selpath) {
		File file = null;
		File file1 = null;

		try {
			file = new File(qtppath);
			while (!file.exists()) {
				Thread.sleep(1000);
			}
			file1 = new File(selpath);
			file1.createNewFile();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Flag to confirm LD Test", "Flag should be created",
					"LD Test has been competed... Now QTP can resume...");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Flag to confirm LD Test", "Flag should be created",
					"LD Test not completed successfully... more Inof: " + e);
		} finally {
			file = null;
			file1 = null;
		}
	}

	public static void createFile(String path) {
		File file = null;
		try {

			String fsoPath = Config.framewrkPathForFSO.trim();
			if (fsoPath.length() > 1) {
				String workingdir = Common.getWorkingDir();

				path = workingdir + "\\" + fsoPath + "\\" + path;

			}

			System.out.println(path);
			file = new File(path);
			file.createNewFile();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Create new file", "Create new file under the path: " + path, "Created");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Create new file", "Create new file under the path: " + path,
					"Not created. More info: " + e.getMessage());
		} finally {
			file = null;
		}
	}

	public static void createDirectory(String path) {
		File file = null;
		try {

			String fsoPath = Config.framewrkPathForFSO.trim();
			if (fsoPath.length() > 1) {
				String workingdir = Common.getWorkingDir();

				path = workingdir + "\\" + fsoPath + "\\" + path;

			}

			System.out.println(path);
			file = new File(path);
			file.mkdir();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Create new dir", "Create new dir under the path: " + path, "Created");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Create new dir", "Create new dir under the path: " + path,
					"Not created. More info: " + e.getMessage());
		} finally {
			file = null;
		}
	}

	public static void CopyFile(String source, String destination) {
		File fileSource = null;
		File fileDest = null;
		try {
			fileSource = new File(source);
			fileDest = new File(destination);
			FileUtils.copyFile(fileSource, fileDest);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Copy file", "Copy file from " + source + " to " + " destination",
					"File Copied successfully");
		} catch (Exception io) {
			Reuse.log(io);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Copy file", "Copy file from " + source + " to " + " destination", io.getMessage());
			Demo1.logger.error("Unable to copy file " + io);
		}
	}

	public static void CopyDirectoryToDirectory(String source, String destination) {
		File fileSource = null;
		File fileDest = null;
		try {
			fileSource = new File(source);
			fileDest = new File(destination);
			FileUtils.copyDirectoryToDirectory(fileSource, fileDest);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Copy directory", "Copy directory from " + source + " to " + " destination",
					"directory Copied successfully");
		} catch (Exception io) {
			Reuse.log(io);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Copy directory", "Copy directory from " + source + " to " + " destination",
					io.getMessage());
			Demo1.logger.error("Unable to copy directory " + io);
		} finally {
			fileSource = null;
			fileDest = null;
		}
	}

	public static void CopyFilesToDirectory(String source, String destination) {
		File fileSource = null;
		File fileDest = null;
		try {
			fileSource = new File(source);
			fileDest = new File(destination);
			FileUtils.copyDirectory(fileSource, fileDest);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Copy Files to directory", "Copy Files from " + source + " to " + " destination",
					"Files Copied successfully");
		} catch (Exception io) {
			Reuse.log(io);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Copy Files", "Copy Files from " + source + " to " + " destination", io.getMessage());
			Demo1.logger.error("Unable to copy Files " + io);
		} finally {
			fileSource = null;
			fileDest = null;
		}
	}

	public static void CopyFileToDirectory(String source, String destination) {
		File fileSource = null;
		File fileDest = null;
		try {
			fileSource = new File(source);
			fileDest = new File(destination);
			FileUtils.copyFileToDirectory(fileSource, fileDest);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Copy File to directory", "Copy Files from " + source + " to " + " destination",
					"File Copied successfully");
		} catch (Exception io) {
			Reuse.log(io);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Copy File", "Copy File from " + source + " to " + " destination", io.getMessage());
			Demo1.logger.error("Unable to copy File " + io);
		} finally {
			fileSource = null;
			fileDest = null;
		}
	}

	public static void DeleteDirectory(String dirPath) {
		File fileSource = null;
		try {
			fileSource = new File(dirPath);
			FileUtils.deleteDirectory(fileSource);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Delete directory", "Delete directory " + dirPath, "Directory deleted");
		} catch (Exception io) {
			Reuse.log(io);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Delete directory", "Delete directory " + dirPath, io.getMessage());
			Demo1.logger.error("DeleteDirectory " + io);
		} finally {
			fileSource = null;
		}
	}

	public static void DeleteDirectoryContent(String dirPath) {
		File fileSource = null;
		try {
			fileSource = new File(dirPath);
			FileUtils.cleanDirectory(fileSource);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Delete directory content", "Clean directory " + dirPath, "Directory content deleted");
		} catch (Exception io) {
			Reuse.log(io);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Delete directory contents", "Delete directory " + dirPath, io.getMessage());
			Demo1.logger.error("DeleteDirectory " + io);
		} finally {
			fileSource = null;
		}
	}

	public static void waitForFileExist(String path) {
		File file = null;
		int counter = 0;
		try {
			String fsoPath = Config.framewrkPathForFSO.trim();
			if (fsoPath.length() > 1) {
				String workingdir = Common.getWorkingDir();

				file = new File(workingdir + "\\" + fsoPath + "\\" + path);

			} else {
				file = new File(path);

			}

			while (!file.exists()) {
				Thread.sleep(5000);
				counter = counter + 1;
				if (counter >= 12) {
					int winLen = Demo1.driver.getWindowHandle().length();
					counter = 0;
				}
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Wait for file exist", "Should wait until the file exist", e.getMessage());
		} finally {
			file = null;
		}
	}

	public static void fileExist(String path) {
		File file = null;
		try {

			String fsoPath = Config.framewrkPathForFSO.trim();
			if (fsoPath.length() > 1) {
				String workingdir = Common.getWorkingDir();

				file = new File(workingdir + "\\" + fsoPath + "\\" + path);

				path = file.getAbsolutePath();
			} else {
				file = new File(path);

			}

			if (file.exists()) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Check file exist", "File should be exist under the path: " + path, "Exist");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check file exist", "File should be exist under the path: " + path, "Not Exist");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check file exist", "File should be exist under the path: " + path, e.getMessage());
		} finally {
			file = null;
		}
	}

	public static void deleteFile(String path) {
		File file = null;
		try {

			String fsoPath = Config.framewrkPathForFSO.trim();
			if (fsoPath.length() > 1) {
				String workingdir = Common.getWorkingDir();
				path = workingdir + "\\" + fsoPath + "\\" + path;
			}
			file = new File(path);
			if (file.exists()) {
				file.delete();
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Delete file", "Delete the file under the path: " + path, "Deleted successfully");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Delete file", "Delete the file under the path: " + path, "File not exist");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
		} finally {
			file = null;
		}
	}

	public static void JbossStart(String path) {
		try {
			// waitForFileExist(pathToWar);
			// JbossStop(path);
			// deleteLog(path);
			ClearFileContents(path + "\\standalone\\log\\server.log");
			Thread.sleep(1000);
			Runtime.getRuntime().exec("cmd /k start /MIN " + path + "\\bin\\standalone.bat", null, new File(path));
			Thread.sleep(60000);
			String h = ReadFile(path + "\\standalone\\log\\server.log");
			int cnt = 0;
			while (!h.contains("Admin console listening")) {
				Thread.sleep(10000);
				cnt = cnt + 1;
				if (cnt > 10) {
					break;
				} else {
					h = ReadFile(path);
				}
			}
			if (h.contains("Admin console listening")) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Start Jboss server", "Server should be started", "Server started successfully");
			} else {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Start Jboss server", "Server should be started",
						"There is an issue in the server start up");
			}

		} catch (Exception e) {
			Reuse.log("JbossStart " + e);
		}
	}

	public static void ClearFileContents(String path) {
		FileOutputStream write = null;
		try {
			write = new FileOutputStream(path);
			write.close();
		} catch (Exception e) {
			System.out.println(e.getStackTrace());
		} finally {
			write = null;
		}
	}

	public static void JbossStop(String path) {
		Process p = null;
		try {
			// p = Runtime.getRuntime().exec("cmd /k start /MIN " + path +
			// "//bin//jboss-cli.bat --connect command=:shutdown", null, new
			// File(path));
			p = Runtime.getRuntime().exec(path + "\\bin\\jboss-cli.bat --connect command=:shutdown", null,
					new File(path));
			Thread.sleep(30000);
			String h = ReadFile(path + "\\standalone\\log\\server.log");
			int cnt = 0;
			while (!h.contains("Stopped deployment")) {
				Thread.sleep(10000);
				cnt = cnt + 1;
				if (cnt > 10) {
					break;
				} else {
					h = ReadFile(path);
				}
			}
			if (h.contains("Stopped deployment")) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Stop Jboss server", "Server should be Stopped", "Stopped");
			} else {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Stop Jboss server", "Server should be Stopped",
						"There is some issue while stopping the server");
			}
			// Runtime.getRuntime().exec("taskkill /IM cmd.exe");

		} catch (Exception e) {
			Demo1.logger.error("JbossStop " + e);
		}
	}

	public static void StartRemoteWebDriverServer(String service) {
		Process p = null;
		try {
			Runtime.getRuntime().exec("cmd /c " + service, null, new File(Demo1.curDir + "\\Server"));
			Demo1.logger.info("Remote Server started");
			Thread.sleep(5000);
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("Problem wiht start " + service + " server");
			Demo1.logger.error(e.getMessage());
		} finally {
			p = null;
		}
	}

	public static void StopRemoteWebDriverServer(String service) {
		Process p = null;
		try {
			Runtime.getRuntime().exec("cmd /c " + service, null, new File(Demo1.curDir + "\\Server"));
			Demo1.logger.info("Remote server Shutdowned");
			Thread.sleep(1000);
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("Problem wiht Shutdowned " + service + " server");
			Demo1.logger.error(e.getMessage());
		} finally {
			p = null;
		}
	}

	public static void ReadTestData(String testDtFileName, String testDataCaseID) throws Exception {
		String filePath = "";
		File file = null;
		XSSFWorkbook workbook = null;
		boolean isTestDataIDExit = false;
		try {
			filePath = Demo1.curDir + "\\TestData\\" + testDtFileName + ".xlsx";
			file = new File(filePath);
			workbook = new XSSFWorkbook(file);

			XSSFSheet sheetTestData = workbook.getSheet("TestData");
			XSSFSheet sheetOR = workbook.getSheet("OR");
			int rowCnt_TD = sheetTestData.getPhysicalNumberOfRows();
			int colmCnt_TD = sheetTestData.getRow(0).getLastCellNum();
			// String currentTestCaseID=Demo1.gbCurrTestCaseName;
			int getTDRow = 0;
			for (int oRow = 1; oRow < rowCnt_TD; oRow++) {
				String testDtTestCaseID = sheetTestData.getRow(oRow).getCell(0).toString();
				if (testDtTestCaseID.length() > 0) {
					if (testDtTestCaseID.equalsIgnoreCase(testDataCaseID)) {
						getTDRow = oRow;
						isTestDataIDExit = true;
						break;
					}
				}
			}
			if (isTestDataIDExit) {
				for (int col = 1; col <= colmCnt_TD; col++) {
					String testData = "";
					XSSFCell cell = sheetTestData.getRow(getTDRow).getCell(col);
					if (cell != null) {
						cell.setCellType(CellType.STRING);
						testData = cell.toString();
						if (testData.length() > 0) {
							String fieldName = sheetTestData.getRow(0).getCell(col).toString();
							String locator = sheetOR.getRow(col).getCell(1).toString();
							String elementType = sheetOR.getRow(col).getCell(2).toString();
							GetData(testData, fieldName, locator, elementType);
						}
					}
				}
			} else {
				Demo1.logger.error("Current test case id" + testDataCaseID
						+ " not matched with the test case id in Test data in " + testDtFileName + " data file");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("Error while executing ReadTestData. " + e);
		} finally {
			workbook.close();
		}
	}

	public static void GetData(String businessData, String field, String locator_ID, String locatorType) {
		try {
			By by = By.id(locator_ID);

			if (locatorType.equalsIgnoreCase("WebEdit")) {

				TextBox_InputText(by, businessData, field);

			} else if (locatorType.equalsIgnoreCase("RadioButton")) {

				By xpath = By.xpath(locator_ID);
				Click_Element(xpath, locatorType, field);

			} else if (locatorType.equalsIgnoreCase("Dropdown")) {

				By xpath = By.xpath("//select[@id='" + locator_ID + "']");
				Dropdown_SelectItem(xpath, businessData, field);

			} else if (locatorType.equalsIgnoreCase("TextArea")) {

				TextBox_InputText(by, businessData, field);

			} else if (locatorType.equalsIgnoreCase("Button")) {
				By xpath = By.xpath(locator_ID);
				Click_Element(xpath, businessData, field);

			} else {
				Demo1.logger.error("Undefined element type " + locatorType);
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error("Error in GetData method. " + e);
		}
	}
	// Test Functions for Test Data management
	// ***************************************

	public static FirefoxProfile getFFProfile() {
		String localDir = System.getProperty("user.dir");

		FirefoxProfile profile = new FirefoxProfile();
		// Set Location to store files after downloading.
		profile.setPreference("browser.download.dir", localDir + "\\Downloads");

		profile.setPreference("browser.download.folderList", 2);
		// Set Preference to not show file download confirmation dialogue using
		// MIME types Of different file extension types.
		profile.setPreference("browser.helperApps.neverAsk.saveToDisk", Config.downloadType);
		profile.setPreference("browser.helperApps.neverAsk.openFile", Config.downloadType);
		profile.setPreference("browser.download.manager.showWhenStarting", false);
		profile.setPreference("pdfjs.disabled", true);

		return profile;

	}

	public static FirefoxOptions getFFOptions(FirefoxProfile profile) {

		FirefoxOptions options = new FirefoxOptions();

		options.setProfile(profile);

		try {
			if (Config.firefoxVersion.equalsIgnoreCase("68.0")) {
				String path = System.getProperty("user.dir")
						+ "/Server/Firefox_Browser_Setup/Firefox Setup 68.0/core/firefox.exe";
				System.out.println(path);
				if (new File(path).exists())
					options.setBinary(path);
			} else if (Config.firefoxVersion.equalsIgnoreCase("73.0.1")) {
				String path = System.getProperty("user.dir")
						+ "/Server/Firefox_Browser_Setup/Firefox Setup 73.0.1/core/firefox.exe";
				System.out.println(path);
				if (new File(path).exists())
					options.setBinary(path);
			} else if (Config.firefoxVersion.equalsIgnoreCase("83.0")) {
				String path = System.getProperty("user.dir")
						+ "/Server/Firefox_Browser_Setup/Firefox Setup 83.0/core/firefox.exe";
				System.out.println(path);
				if (new File(path).exists())
					options.setBinary(path);
			} else if (Config.firefoxVersion.equalsIgnoreCase("84.0.2")) {
				String path = System.getProperty("user.dir")
						+ "/Server/Firefox_Browser_Setup/Firefox Setup 84.0.2/core/firefox.exe";
				System.out.println(path);
				if (new File(path).exists())
					options.setBinary(path);
			} else if (Config.firefoxVersion.equalsIgnoreCase("86.0")) {
				String path = System.getProperty("user.dir")
						+ "/Server/Firefox_Browser_Setup/Firefox Setup 86.0/core/firefox.exe";
				System.out.println(path);
				if (new File(path).exists())
					options.setBinary(path);
			} else if (Config.firefoxVersion.equalsIgnoreCase("95.0")) {
				String path = System.getProperty("user.dir")
						+ "/Server/Firefox_Browser_Setup/Firefox Setup 95.0/core/firefox.exe";
				System.out.println(path);
				if (new File(path).exists())
					options.setBinary(path);
			} else {
				System.out.println("Going with system firefox");
			}
		} catch (Exception e) {

			System.out.println("issue in binary, going to system configuration");
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
		}

		// FOR WEALTH
		// to set default screen resolution before starting execution
		if (Config.wealthRun) {
			Reuse.log("RESOLUTION::" + Config.defaultScreenResolutionNeeded);
			if (Config.defaultScreenResolutionNeeded.equals("NONE")) {
				// do nothing
			} else {
				// options.setCapability("resolution", "1280x720"); //added to
				// set DEFAULT RESOLUTION: 16-SEP-2020
				System.out.println("Resolution being set to " + Config.defaultScreenResolutionNeeded);
				Reuse.log("Resolution being set to " + Config.defaultScreenResolutionNeeded);
				options.addArguments("--headless");
				//options.setHeadless(true);
				//options.
				// options.addArguments("--window-size=1920,1200");
			}
		}

		// options.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR,
		// UnexpectedAlertBehaviour.ACCEPT);

		return options;

	}

	public static void checkIfFileExist() {
		try {
			String localDir = System.getProperty("user.dir");

			File f = new File(localDir + "\\Downloads");
			File[] files = f.listFiles(new FileFilter() {
				@Override
				public boolean accept(File file) {
					return file.isFile();
				}
			});
			List<File> lstFiles = Arrays.asList(files);

			if (lstFiles.size() > 0) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify file download", "Downloaded file should be available in disk",
						"File exist:" + lstFiles.get(0).getName());
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify file download", "Downloaded file should be available in  disk",
						"File does not exist");
			}

			File archive = new File(localDir + "\\Downloads\\Archive");

			for (File f1 : lstFiles) {
				File isExist = new File(localDir + "\\Downloads\\Archive\\" + f1.getName());
				if (isExist.exists()) {
					isExist.renameTo(
							new File(localDir + "\\Downloads\\Archive\\" + getDateTimeStamp() + "_" + f1.getName()));
					// Files.m
					Files.move(f1.toPath(), isExist.toPath());

				}
			}

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify file download", "Downloaded file should be available in local disk",
					"File does not exist");
		}
	}

	public static void closeAllWindowAndLaunch() {
		try {

			if (Demo1.driver != null || (Demo1.driver instanceof WebDriver)) {
				// for (String handle : Demo1.driver.getWindowHandles()) {
				// Thread.sleep(500);
				// Demo1.driver.switchTo().window(handle);
				// Demo1.driver.close();
				// }
				Demo1.driver.quit();
			}

		} catch (Exception e) {
			Reuse.log(e);
			Reuse.log("closeAllWindowAndLaunch No valid instance found");
		}
		if (Config.BrowName.contentEquals("firefox")) {

			if (!Demo1.envName.equalsIgnoreCase("MOBILEAPP") && !Demo1.envName.equalsIgnoreCase("API")) {
				try {
					Demo1.driver = null;
					System.gc();
					// System.setProperty("webdriver.gecko.driver", Demo1.curDir +
					// "\\Server\\geckodriver.exe");
					// Demo1.driver = new FirefoxDriver();
					Demo1.driver = Reuse.getFF(Reuse.getFFOptions(Reuse.getFFProfile()));
					Demo1.driver.manage().window().maximize();
					Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Demo1.TIME_OUT));
				} catch (Exception e) {
					Reuse.log(e);
					try {
						Demo1.driver = null;
						System.gc();
						// Demo1.driver = new FirefoxDriver();
						Demo1.driver = Reuse.getFF(Reuse.getFFOptions(Reuse.getFFProfile()));
						Demo1.driver.manage().window().maximize();
						Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Demo1.TIME_OUT));
					} catch (Exception e2) {
						Reuse.log(e2);

						// TODO Auto-generated catch block
						// Uncomment and replace with appropriate logger
						// LOGGER.error(exception_var, exception_var);
					}
				}
			}
		} else if (Config.BrowName.contains("chrome") || Config.BrowName.contains("AndriodChrome")) {

			if (!Demo1.envName.equalsIgnoreCase("MOBILEAPP") && !Demo1.envName.equalsIgnoreCase("API")) {
				Demo1.driver = null;
				System.gc();
				ChromeOptions options = new ChromeOptions();
				options.setAcceptInsecureCerts(true);
				if (Config.headLessMode.equalsIgnoreCase("Yes")) {
					options.addArguments("--headless=old");
					if (Config.wealthRun) {
						options.addArguments("--window-size=1360,600");
					} else {
						options.addArguments("--window-size=1920,1080");

					}
					// options.addArguments("window-size=1920,1080");
					/*
					 * options.addArguments("window-size=1280,800");
					 * options.addArguments("--disable-gpu");
					 * options.addArguments("--disable-extensions");
					 * options.addArguments("--proxy-server='direct://'");
					 * options.addArguments("--proxy-bypass-list=*");
					 * options.addArguments("--start-maximized");
					 */
					System.out.println("background");

//                  options.addArguments("no-sandbox");
				}

				options.addArguments("disable-popup-blocking");
				// options.addArguments("--start-maximized");
				options.addArguments("--disable-extensions");
				options.addArguments("--remote-allow-origins=*");
				try {
					Demo1.driver = new ChromeDriver(options);
					Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Demo1.TIME_OUT));
					Demo1.driver.manage().window().maximize();
				} catch (Exception e) {
					Reuse.log(e);
					try {
						Demo1.driver = new ChromeDriver(options);
						Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Demo1.TIME_OUT));
						Demo1.driver.manage().window().maximize();
					} catch (Exception e2) {
						Reuse.log(e2);

						// TODO Auto-generated catch block
						// Uncomment and replace with appropriate logger
						// LOGGER.error(exception_var, exception_var);
					}
				}

			}
		} else if (Config.BrowName.equalsIgnoreCase("edge")) {
			Demo1.driver = null;
			System.gc();
			EdgeOptions options = new EdgeOptions();
			options.setAcceptInsecureCerts(true);
			if (Config.headLessMode.equalsIgnoreCase("Yes")) {

				options.addArguments("--headless");
				if (Config.wealthRun) {
					options.addArguments("--window-size=1360,600");
				} else {
					options.addArguments("--window-size=1920,1080");
				}
				System.out.println("background");

//               options.addArguments("no-sandbox");
			}

			options.addArguments("disable-popup-blocking");
			// options.addArguments("--start-maximized");
			options.addArguments("--disable-extensions");
			options.addArguments("--remote-allow-origins=*");
			try {
				Demo1.driver = new EdgeDriver(options);
				Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Demo1.TIME_OUT));
				Demo1.driver.manage().window().maximize();
			} catch (Exception e) {
				Reuse.log(e);
				try {
					Demo1.driver = new EdgeDriver(options);
					Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Demo1.TIME_OUT));
					Demo1.driver.manage().window().maximize();
				} catch (Exception e2) {
					Reuse.log(e2);
				}
			}

		}
	}
	
	public static void Switch_BackFrom_Frame() {
        try {
            Demo1.driver.switchTo().defaultContent();
            Demo1.gbTestCaseStatus = "Pass";
            Demo1.ReportStep(2, "Switch back from iframe", "Should be switched back from iframe",
                    "Switched back from iframe");
        } catch (Exception e) {
            Reuse.log(e);
            Demo1.logger.error(e);
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Switch back from iframe", "unable to switch back from iframe", e.getMessage());
        }
    }

	// Added on 28Apr2017
	public static void DateSelector(By by, String date, String textBoxName) {
		try {
			WebElement element;
			String[] arrDate = date.trim().split("-");
			String iDate = arrDate[0].trim();
			String iMonth = arrDate[1];
			String iYear = arrDate[2];
			if (isElementPresent(by)) {
				element = Demo1.driver.findElement(by);

				JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
				((JavascriptExecutor) Demo1.driver).executeScript("arguments[0].scrollIntoView(true);", element);

				Thread.sleep(500);
				js.executeScript("arguments[0].click();", element);
				Thread.sleep(500);

				Select month = new Select(
						Demo1.driver.findElement(By.xpath("//select[normalize-space(@class)='ui-datepicker-month']")));
				month.selectByVisibleText(iMonth);
				Thread.sleep(500);

				Select year = new Select(
						Demo1.driver.findElement(By.xpath("//select[normalize-space(@class)='ui-datepicker-year']")));
				year.selectByVisibleText(iYear);
				Thread.sleep(500);

				Demo1.driver.findElement(By.xpath("//a[@class='ui-state-default' and text()='" + iDate + "']")).click();
				Demo1.ReportStep(2, "Selecting date in  <b>date picker</b>", "<b>Date</b> should be selected",
						"Check box is already selected");
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "dateSelect in to the field <b>" + textBoxName + "</b>",
						"Input text <b>" + date + "</b>", "date( <b>" + date + ")</b> entered Successfully");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "dateSelect in to the field <b>" + textBoxName + "</b>",
						"Input text (<b>" + date + "</b>)",
						"Element <b>" + textBoxName + " </b> not present/unable to locate element");
			}
		} catch (Exception e) {

			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "datepicker in to the field <b>" + textBoxName + "</b>",
					"datepicker <b>" + date + "</b>", "Unbale to locate textbox <b>" + textBoxName + "</b>");
			Demo1.logger.error(e);
		}

	}

	// Added on 28Apr2017
	public static void VerifyOnClickPaginationElement(String elementName, By element, String action,
			String runTimeValue) {
		try {
			boolean isthere = false;
			boolean found = false;
			String text, Elements;
			breakDo: do {

				Thread.sleep(5000);
				// table[@class='resultTable primpableEnqResultsTable
				// mainResultTable']

				Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

				if (Reuse.isElementPresent(element) & action.equals("CLICK")) {
					Demo1.driver.findElement(element).click();
					found = true;
					break breakDo;
				}

				if (Reuse.isElementPresent(element) & action.equals("PRESENT")) {
					Demo1.driver.findElement(element);
					found = true;
					break breakDo;
				}

				if (action.equals("NOT_PRESENT")) {
					if (!Reuse.isElementPresent(element)
							& !Reuse.isElementPresent(By.xpath("//a[contains(text(),'>')]"))) {
						found = true;
						break breakDo;
					}
				}

				if (Reuse.isElementPresent(element) & action.equals("RIGHT_CLICK")) {
					RightClick(element, elementName, elementName);
					found = true;
					break breakDo;
				}

				if (Reuse.isElementPresent(element) & action.equals("CONTEXT_CLICK")) {
					ContextClick(element, elementName, elementName);
					found = true;
					break breakDo;
				}

				if (!found && !action.equals("CONTEXT_CLICK") && !action.equals("RIGHT_CLICK")) {
					try {

						Demo1.driver.findElement(By.xpath("//a[contains(text(),'>')]")).click();
						// driver.findElement(By.xpath("//a[contains(@class,'pagination-item')
						// and text()='>']")).click();

						isthere = true;

					} catch (Exception e) {
						Reuse.log(e);
						isthere = false;
						break breakDo;
					}
				}

			} while (isthere);

			if (found) {
				Demo1.gbTestCaseStatus = "Pass";
				if (action.equals("PRESENT"))
					Demo1.ReportStep(2, "Verifying <b>" + elementName + "</b> in table",
							"The Text => <b>" + runTimeValue + "</b>",
							" The Text <b> " + runTimeValue + "</b> was present in table");
				if (action.equals("CLICK"))
					Demo1.ReportStep(2, "Element <b>" + elementName + "</b>is clickable",
							"The Element to be Clicked =><b>" + runTimeValue + "</b>",
							"The Element <b>" + runTimeValue + "</b> has been clicked");
				if (action.equals("NOT_PRESENT"))
					Demo1.ReportStep(2, "Verifying <b>" + elementName + "</b> in table",
							"The Text => <b>" + runTimeValue + "</b>",
							" The Text <b> " + runTimeValue + "</b> was not present in table");
				if (action.equals("RIGHT_CLICK"))
					Demo1.ReportStep(2, "Element <b>" + elementName + "</b>is RIGHT_CLICKable",
							"The Element to be Clicked =><b>" + runTimeValue + "</b>",
							"The Element <b>" + runTimeValue + "</b> has been clicked");
				if (action.equals("CONTEXT_CLICK"))
					Demo1.ReportStep(2, "Element <b>" + elementName + "</b>is CONTEXT_CLICKable",
							"The Element to be Clicked =><b>" + runTimeValue + "</b>",
							"The Element <b>" + runTimeValue + "</b> has been clicked");

				Reuse.log("Match Found ");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				if (action.equals("PRESENT"))
					Demo1.ReportStep(2, "Unable to identify the " + elementName + "</b>",
							"The Text => <b>" + runTimeValue + "</b>",
							"The Text <b> " + runTimeValue + "</b> was not present in table");
				if (action.equals("CLICK"))
					Demo1.ReportStep(2, "<b>" + elementName + "</b> has not been clickable",
							"The Element => <b>" + runTimeValue + "</b>",
							"Unable to Click an element <b>" + runTimeValue + "</b>");
				if (action.equals("NOT_PRESENT"))
					Demo1.ReportStep(2, "Verifying <b>" + elementName + "</b> in table",
							"The Text => <b>" + runTimeValue + "</b>",
							" The Text <b> " + runTimeValue + "</b> is present in table");
				if (action.equals("RIGHT_CLICK"))
					Demo1.ReportStep(2, "<b>" + elementName + "</b> has not been RIGHT_CLICKable",
							"The Element => <b>" + runTimeValue + "</b>",
							"Unable to Click an element <b>" + runTimeValue + "</b>");
				if (action.equals("CONTEXT_CLICK"))
					Demo1.ReportStep(2, "<b>" + elementName + "</b> has not been CONTEXT_CLICKable",
							"The Element => <b>" + runTimeValue + "</b>",
							"Unable to Click an element <b>" + runTimeValue + "</b>");

				Reuse.log("Match Not Found ");
			}

		} catch (Exception e1) {
			Reuse.log(e1);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "<b>" + elementName + "</b> has not been clickable or Text not present",
					"Expected Text or Element => <b>" + runTimeValue + "</b>",
					"Unable to Click/Verify an element <b>" + runTimeValue + "</b>");
		} finally {
			Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Demo1.TIME_OUT));

		}
		// System.exit(0);
	}

	// Added on 28Apr2017
	public static void VerifyOnClickPaginationElement(String elementName, By element, By next, String action,
			String runTimeValue) {
		try {
			boolean isthere = false;
			boolean found = false;
			String text, Elements;
			breakDo: do {

				Thread.sleep(5000);
				// table[@class='resultTable primpableEnqResultsTable
				// mainResultTable']

				Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

				if (Reuse.isElementPresent(element) & action.equals("CLICK")) {
					Demo1.driver.findElement(element).click();
					found = true;
					break breakDo;
				}

				if (Reuse.isElementPresent(element) & action.equals("PRESENT")) {
					Demo1.driver.findElement(element);
					found = true;
					break breakDo;
				}

				if (action.equals("NOT_PRESENT")) {
					if (!Reuse.isElementPresent(element) & !Reuse.isElementPresent(next)) {
						found = true;
						break breakDo;
					}
				}

				if (!found) {
					try {

						Demo1.driver.findElement(next).click();
						// driver.findElement(By.xpath("//a[contains(@class,'pagination-item')
						// and text()='>']")).click();

						isthere = true;

					} catch (Exception e) {
						Reuse.log(e);
						isthere = false;
						break breakDo;
					}
				}
			} while (isthere);

			if (found) {
				Demo1.gbTestCaseStatus = "Pass";
				if (action.equals("PRESENT"))
					Demo1.ReportStep(2, "Verifying <b>" + elementName + "</b> in table",
							"The Text => <b>" + runTimeValue + "</b>",
							" The Text <b> " + runTimeValue + "</b> was present in table");
				if (action.equals("CLICK"))
					Demo1.ReportStep(2, "Element <b>" + elementName + "</b>is clickable",
							"The Element to be Clicked =><b>" + runTimeValue + "</b>",
							"The Element <b>" + runTimeValue + "</b> has been clicked");
				if (action.equals("NOT_PRESENT"))
					Demo1.ReportStep(2, "Verifying <b>" + elementName + "</b> in table",
							"The Text => <b>" + runTimeValue + "</b>",
							" The Text <b> " + runTimeValue + "</b> was not present in table");

				Reuse.log("Match Found ");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				if (action.equals("PRESENT"))
					Demo1.ReportStep(2, "Unable to identify the " + elementName + "</b>",
							"The Text => <b>" + runTimeValue + "</b>",
							"The Text <b> " + runTimeValue + "</b> was not present in table");
				if (action.equals("CLICK"))
					Demo1.ReportStep(2, "<b>" + elementName + "</b> has not been clickable",
							"The Element => <b>" + runTimeValue + "</b>",
							"Unable to Click an element <b>" + runTimeValue + "</b>");
				if (action.equals("NOT_PRESENT"))
					Demo1.ReportStep(2, "Verifying <b>" + elementName + "</b> in table",
							"The Text => <b>" + runTimeValue + "</b>",
							" The Text <b> " + runTimeValue + "</b> is present in table");
				Reuse.log("Match Not Found ");
			}

		} catch (Exception e1) {
			Reuse.log(e1);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "<b>" + elementName + "</b> has not been clickable or Text not present",
					"Expected Text or Element => <b>" + runTimeValue + "</b>",
					"Unable to Click/Verify an element <b>" + runTimeValue + "</b>");
		} finally {
			Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Demo1.TIME_OUT));

		}
		// System.exit(0);
	}

	// Added on 28Apr2017
	public static void VerifyPagination(String str, By by) {
		try {
			boolean isthere = false;
			boolean found = false;
			breakDo: do {

				Thread.sleep(5000);
				// table[@class='resultTable primpableEnqResultsTable
				// mainResultTable']
				List<WebElement> pagesize = Demo1.driver.findElement(by).findElements(By.xpath("//tr/td[1]"));
				Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(0));

				for (WebElement e : pagesize) {
					try {
						String txt = e.getText();
						if (txt.toLowerCase().contains(str.toLowerCase())) {
							found = true;
							break breakDo;
						}
					} catch (Exception x1) {
						Reuse.log(x1);

					}
				}
				try {
					new Actions(Demo1.driver)
							.moveToElement(Demo1.driver.findElement(By.xpath("//a[contains(text(),'Page')]"))).build()
							.perform();

					Demo1.driver.findElement(By.xpath("//a[contains(text(),'>')]")).click();
					// driver.findElement(By.xpath("//a[contains(@class,'pagination-item')
					// and text()='>']")).click();
					isthere = true;

				} catch (Exception e) {
					Reuse.log(e);
					isthere = false;
					break breakDo;
				}

			} while (isthere);

			if (found) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verifying text in table", "Expected text:" + str,
						"Expected text was present in table");

				Reuse.log("Match Found ");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verifying text in table", "Expected text:" + str,
						"Expected text was not present in table");

			}

		} catch (Exception e1) {
			Reuse.log(e1);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verifying text in table", "Expected text:" + str,
					"Expected text was not present in table");
		} finally {
			Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Demo1.TIME_OUT));

		}
	}

	public static void VerifyTextBoxContainsSomeText(By by, String elementName) {
		String sText = null;
		try {
			WebElement e = Demo1.driver.findElement(by);
			JavascriptExecutor executor = (JavascriptExecutor) Demo1.driver;
			sText = executor.executeScript("return arguments[0].value;", e).toString();

		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
		}

		try {

			if (!sText.trim().isEmpty()) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verifying ID present inside text box",
						"ID should be present inside:" + elementName, "ID was present inside:" + elementName);

				Reuse.log("Match Found ");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verifying ID present inside text box",
						"ID should be present inside:" + elementName, "ID was not present inside:" + elementName);

			}

		} catch (Exception e1) {
			Reuse.log(e1);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verifying ID present inside text box", "ID should be present inside:" + elementName,
					"ID was not present inside:" + elementName);

		}

	}

	public static void JavaScriptClick(String elementName, By by) {
		try {
			String eveClick = "var event = new MouseEvent('click', {'bubbles': true});arguments[0].dispatchEvent(event);";

			JavascriptExecutor executor = (JavascriptExecutor) Demo1.driver;

			WebElement ele = Demo1.driver.findElement(by);
			executor.executeScript(eveClick, ele);

			if (Config.wealthRun) {
				// newly added to test the loader element
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
					System.out.println("Error while adding sleep time");
				}
				checkWealthSpinnerElement();
			}

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Clicking on element", "Element name:" + elementName,
					elementName + " has been clicked successfully");

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Clicking on element", "Element name:" + elementName,
					elementName + " has not been clicked");
		}

	}

	public static void Dropdown_OptionNotExist(By by, String expectedOption, String dropdownName) {
		Select dropDown = null;
		try {
			WebElement select = Demo1.driver.findElement(by);
			// Select class initialization
			dropDown = new Select(select);
			List<WebElement> Options = dropDown.getOptions();
			boolean isOptExist = false;
			for (WebElement option : Options) {
				if (option.getText().trim().equals(expectedOption.trim())) {

					isOptExist = true;
					break;
				}
			}
			if (!isOptExist) {

				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2,
						"Verify item <b>" + expectedOption + "</b> not exist in <b>" + dropdownName + "</> dropdown",
						"<b>" + expectedOption + "</b> should not exist",
						"<b>" + expectedOption + "</b> is not available");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify item <b>" + expectedOption + "</b> in <b>" + dropdownName + "</> dropdown",
						"<b>" + expectedOption + "</b> should be exist", "<b>" + expectedOption + "</b>  exist");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify item <b>" + expectedOption + "</b> in <b>" + dropdownName + "</> dropdown",
					"<b>" + expectedOption + "</b> should be exist",
					"Unable to locate <b>" + dropdownName + "</b> dropdown");
		} finally {
			dropDown = null;
		}
	}

	public static void Scroll_Element(By by, String eleName) {
		try {
			WebElement element;
			if (isElementPresent(by)) {
				element = Demo1.driver.findElement(by);
				// JavascriptExecutor js = (JavascriptEx ecutor)Demo1.driver;
				((JavascriptExecutor) Demo1.driver).executeScript("arguments[0].scrollIntoView(true);", element);
				// js.executeScript("arguments[0].scrollIntoView(true);",
				// element);
				Thread.sleep(500);
				// js.executeScript("arguments[0].style.border='3px solid red'",
				// element);
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Scroll to <b>" + eleName + "</b>",
						"Element should be scrolled and focus on  <b>" + eleName + "</b>",
						"Element scrolled and focused on <b>" + eleName + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Scroll to <b>" + eleName + "</b>",
						"Element should be scrolled and focus on <b>" + eleName + "</b>",
						"Element not scrolled and focused on <b>" + eleName + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Scroll to Element <b>" + eleName + "</b>",
					"Element should be scrolled and focus on <b>" + eleName + "</b>",
					"Element not scrolled and focused on <b>" + eleName + "</b>");
			Demo1.logger.error(e);
		}

	}

	public static void Scroll_Horizontal() {
		try {

			((JavascriptExecutor) Demo1.driver).executeScript("window.scrollBy(2000,0)");
			// js.executeScript("arguments[0].scrollIntoView(true);",
			// element);
			Thread.sleep(500);
			// js.executeScript("arguments[0].style.border='3px solid red'",
			// element);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Scroll <b>" + "horizontal" + "</b>",
					"Element should be scrolled   <b>" + "horizontal" + "</b>",
					"Element scrolled " + "horizontal" + "</b>");

		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Scroll  <b>" + "horizontal" + "</b>",
					"Element should be scrolled <b>" + "horizontal" + "</b>",
					"Element not scrolled <b>" + "horizontal" + "</b>");
			Demo1.logger.error(e);
		}

	}

	public static void Scroll_Horizontal_left() {
		try {

			((JavascriptExecutor) Demo1.driver).executeScript("window.scrollBy(-2000,0)");
			// js.executeScript("arguments[0].scrollIntoView(true);",
			// element);
			Thread.sleep(500);
			// js.executeScript("arguments[0].style.border='3px solid red'",
			// element);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Scroll <b>" + "horizontal" + "</b>",
					"Element should be scrolled   <b>" + "horizontal" + "</b>",
					"Element scrolled " + "horizontal" + "</b>");

		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Scroll  <b>" + "horizontal" + "</b>",
					"Element should be scrolled <b>" + "horizontal" + "</b>",
					"Element not scrolled <b>" + "horizontal" + "</b>");
			Demo1.logger.error(e);
		}

	}

	public static void Scroll_Horizontal_click(int pageNo, By by, String elementType, String elementName) {
		try {

			Boolean flag = false;

			for (int i = 0; i < pageNo; i++) {

				if (flag) {
					break;
				}

				((JavascriptExecutor) Demo1.driver).executeScript("window.scrollBy(2000,0)");

				if (!flag) {

					try {
						if (isElementPresent(by)) {
							Focus(Demo1.driver.findElement(by));

							Demo1.driver.findElement(by).click();

							flag = true;
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						// Uncomment and replace with appropriate logger
						// LOGGER.error(e, e);
					}

				}

			}

			// js.executeScript("arguments[0].scrollIntoView(true);",
			// element);
			Thread.sleep(500);
			// js.executeScript("arguments[0].style.border='3px solid red'",
			// element);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Click <b>" + elementName + " " + elementType + "</b>",
					"<b>" + elementName + " " + elementType + "</b> should be Clicked",
					"Clicked on <b>" + elementName + "</b>");

		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Click <b>" + elementName + " " + elementType + "</b>",
					"<b>" + elementName + " " + elementType + "</b> should be Clicked",
					"Not Clicked on <b>" + elementName + "</b>");
			Demo1.logger.error(e);
		}

	}

	public static void Scroll_Horizontal_VerifyText(int pageNo, By by, String expectedText, String elementName) {
		try {

			Boolean flag = false;
			String actualText = "";

			for (int i = 0; i < pageNo; i++) {

				if (flag) {
					break;
				}

				((JavascriptExecutor) Demo1.driver).executeScript("window.scrollBy(2000,0)");

				if (!flag) {

					try {
						if (isElementPresent(by)) {
							actualText = Demo1.driver.findElement(by).getText();
							if (actualText != null & actualText.trim().isEmpty()) {
								actualText = Demo1.driver.findElement(by).getAttribute("value");
								if (actualText == null) {
									actualText = "";
								}
							}

							flag = true;
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						// Uncomment and replace with appropriate logger
						// LOGGER.error(e, e);
					}

				}

			}

			if (actualText.toUpperCase().contentEquals(expectedText.toUpperCase())) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2,
						"Verify text <b>" + expectedText + "</b> present for the element <b>" + elementName + "</b>",
						"<b>" + expectedText + "</b> text should be present", "<b>" + actualText + "</b> present");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> present",
						"<b>" + expectedText + "</b> text should be present", "Actual text <b>" + actualText + "</b>");
			}

			Thread.sleep(500);

		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> present",
					"<b>" + expectedText + "</b> text should be present",
					"Unable to locate <b>" + elementName + "</b>");
			Demo1.logger.error(e);
		}

	}

	// *[@id="grid_C12__TBL_B3673DDF3890486B493620_records"]

	public static void Scroll_Vertical_click(int pageNo, By by, By by1, String elementType, String elementName) {
		try {

			Boolean flag = false;

			for (int i = 0; i < pageNo; i++) {

				if (flag) {
					break;
				}

				/*
				 * Actions actions = new Actions(Demo1.driver); WebElement elementAction =
				 * Demo1.driver.findElement(by);
				 * actions.moveToElement(elementAction).build().perform();
				 */

				WebElement m = Demo1.driver.findElement(by);

				String strJavaScript = "var element = arguments[0];"
						+ "var mouseEventObj = document.createEvent('MouseEvents');"
						+ "mouseEventObj.initEvent( 'mouseover', true, true );"
						+ "element.dispatchEvent(mouseEventObj);";

				// Then JavascriptExecutor class is used to execute the script to
				// trigger the dispatched event.
				((JavascriptExecutor) Demo1.driver).executeScript(strJavaScript, m);

				// Javascript executor
				((JavascriptExecutor) Demo1.driver).executeScript("arguments[0].scrollIntoView(true);", m);

				((JavascriptExecutor) Demo1.driver).executeScript("scroll(0,0)", m);

//                ((JavascriptExecutor)Demo1.driver).executeScript("window.scrollBy(2000,0)");

				if (!flag) {

					try {
						if (isElementPresent(by1)) {
							Focus(Demo1.driver.findElement(by1));

							Demo1.driver.findElement(by1).click();

							flag = true;
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						// Uncomment and replace with appropriate logger
						// LOGGER.error(e, e);
					}

				}

			}

			if (flag) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Click <b>" + elementName + " " + elementType + "</b>",
						"<b>" + elementName + " " + elementType + "</b> should be Clicked",
						"Clicked on <b>" + elementName + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Click <b>" + elementName + " " + elementType + "</b>",
						"<b>" + elementName + " " + elementType + "</b> should be Clicked",
						"Not Clicked on <b>" + elementName + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Click <b>" + elementName + " " + elementType + "</b>",
					"<b>" + elementName + " " + elementType + "</b> should be Clicked",
					"Not Clicked on <b>" + elementName + "</b>");
			Demo1.logger.error(e);
		}

	}

	public static void RandomAlphabet(String count, String eleName, By by) {

		final String CHAR_LIST = "abcdefghijklmnopqrstuvwxyz";
		String str = null;
		try {
			WebElement element;
			if (isElementPresent(by)) {
				element = Demo1.driver.findElement(by);
				final int RANDOM_STRING_LENGTH = Integer.parseInt(count);
				StringBuffer randStr = new StringBuffer();
				for (int i = 0; i < RANDOM_STRING_LENGTH; i++) {
					int number = getRandomAlpha();
					char ch = CHAR_LIST.charAt(number);
					randStr.append(ch);
				}
				str = randStr.toString().toUpperCase();
				Reuse.TextBox_InputText(by, str, eleName);
				// Demo1.driver.findElement(by).sendKeys(str);
				// Demo1.gbTestCaseStatus = "Pass";
				// Demo1.ReportStep(2, "Verify the Text entered on <b>" +
				// eleName + "<b>", "Text Should be entered", " Text entered
				// <b>" + str + "</b>");
			} else {
				// Demo1.gbTestCaseStatus = "Fail";
				// Demo1.ReportStep(2, "Verify the Text entered on <b>" +
				// eleName + "<b>", "Text Should be entered", "Unable to enter
				// Text on <b>" + str + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);
			// Demo1.logger.error(e);
			// Demo1.gbTestCaseStatus = "Fail";
			// Demo1.ReportStep(2, "Verify the Text entered on <b>" + eleName +
			// "<b>", "Text Should be entered", "Unable to enter Text on <b>" +
			// str + "</b>");
			// Demo1.logger.error(e);
		}
	}

	public static int getRandomAlpha() {
		int randomInt = 0;
		Random randomGenerator = new Random();
		// randomInt = 10000 + randomGenerator.nextInt(RANDOM_STRING_LENGTH)+26;
		randomInt = randomGenerator.nextInt(CHAR_LIST.length());
		if (randomInt - 1 == -1) {
			return randomInt;
		} else {
			return randomInt - 1;
		}

	}

	private static int getRandomNum() {
		int randomInt = 0;
		Random randomGenerator = new Random();
		// randomInt = 10000 + randomGenerator.nextInt(RANDOM_STRING_LENGTH)+26;
		randomInt = randomGenerator.nextInt(NUM_LIST.length());
		if (randomInt - 1 == -1) {
			return randomInt;
		} else {
			return randomInt - 1;
		}

	}

	public static void RandomNumber(String count, String eleName, By by) {

		int num = 0;
		String str = null;
		try {
			WebElement element;
			if (isElementPresent(by)) {
				element = Demo1.driver.findElement(by);
				// String test1= JOptionPane.showInputDialog("Enter the Max
				// Random number to Generate ");
				int input = Integer.parseInt(count);
				StringBuffer randStr = new StringBuffer();
				for (int i = 0; i < input; i++) {
					int number = getRandomNum();
					randStr.append(number);
				}
				str = randStr.toString();
				Reuse.log(str);
				// public static void TextBox_InputText(By by, String text,
				// String textBoxName)
				Reuse.TextBox_InputText(by, str, eleName);
				// Demo1.driver.findElement(by).sendKeys(str);
				// Demo1.gbTestCaseStatus = "Pass";
				// Demo1.ReportStep(2, "Verify the Text entered on <b>" +
				// eleName + "<b>", "Text Should be entered", " Text entered
				// <b>" + str + "</b>");
			} else {

				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Enter value in <b>" + eleName + "<b>", "Text Should be entered",
						"Unable to enter Text on <b>" + str + "</b>");

			}
		} catch (Exception e) {
			Reuse.log(e);
			// Demo1.logger.error(e);
			// Demo1.gbTestCaseStatus = "Fail";
			// Demo1.ReportStep(2, "Verify the Text entered on <b>" + eleName +
			// "<b>", "Text Should be entered", "Unable to enter Text on <b>" +
			// str + "</b>");
			// Demo1.logger.error(e);
		}
	}

	public static void appendRandomNumber(String count, String eleName, By by) {

		int num = 0;
		String str = null;
		try {
			WebElement element;
			if (isElementPresent(by)) {
				element = Demo1.driver.findElement(by);
				// String test1= JOptionPane.showInputDialog("Enter the Max
				// Random number to Generate ");
				int input = Integer.parseInt(count);
				StringBuffer randStr = new StringBuffer();
				for (int i = 0; i < input; i++) {
					int number = getRandomNum();
					randStr.append(number);
				}
				str = randStr.toString();
				Reuse.log(str);
				// public static void TextBox_InputText(By by, String text,
				// String textBoxName)
				Reuse.TextBox_AppendText(by, str, eleName);
				// Demo1.driver.findElement(by).sendKeys(str);
				// Demo1.gbTestCaseStatus = "Pass";
				// Demo1.ReportStep(2, "Verify the Text entered on <b>" +
				// eleName + "<b>", "Text Should be entered", " Text entered
				// <b>" + str + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Enter value in <b>" + eleName + "<b>", "Text Should be entered",
						"Unable to enter Text on <b>" + str + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);
			// Demo1.logger.error(e);
			// Demo1.gbTestCaseStatus = "Fail";
			// Demo1.ReportStep(2, "Verify the Text entered on <b>" + eleName +
			// "<b>", "Text Should be entered", "Unable to enter Text on <b>" +
			// str + "</b>");
			// Demo1.logger.error(e);
		}
	}

	public static WebDriver getFF(FirefoxOptions options) {
		WebDriver d;
		d = new FirefoxDriver(options);
		d.manage().timeouts().implicitlyWait(Duration.ofSeconds(Demo1.TIME_OUT));
		d.manage().window().maximize();
		return d;
	}

	public static WebDriver getChrome(ChromeOptions Options) {
		WebDriver d;
		d = new ChromeDriver(Options);
		d.manage().timeouts().implicitlyWait(Duration.ofSeconds(Demo1.TIME_OUT));
		d.manage().window().maximize();
		return d;
	}

	@SuppressWarnings("deprecation")
	public static WebDriver getEdgeChromium() {
		WebDriver d;
		d = new EdgeDriver();
		d.manage().timeouts().implicitlyWait(Duration.ofSeconds(Demo1.TIME_OUT));
		d.manage().window().maximize();
		return d;
	}

	// Fluent wait
	protected WebElement fluentWait(final By locator, int WaitFor) {

		WebElement foo = null;
		try {

			Wait<WebDriver> wait = new FluentWait<>(Demo1.driver).withTimeout(Duration.ofSeconds(WaitFor))
					.pollingEvery(Duration.ofMillis(600)).ignoring(NoSuchElementException.class);

			foo = wait.until(new Function<WebDriver, WebElement>() {
				@Override
				public WebElement apply(WebDriver driver) {
					return driver.findElement(locator);
				}
			});
		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
		}
		return foo;
	}

	public void WriteStoredDataIntoFile() {
		File file = null;
		BufferedWriter bw = null;
		FileWriter fw = null;
		try {
			file = new File(
					"D:\\Working\\Auto\\Seleni\\project\\baseProject\\WebDriver_28_10_15\\MBTest\\TestLogs\\Completed.csv");
			if (!file.exists()) {
				file.createNewFile();
			}
			if (file.exists()) {
				fw = new FileWriter(file.getAbsoluteFile());
				bw = new BufferedWriter(fw);
				bw.write("1,Hello,world");
				bw.newLine();
				bw.write("2,Good,Bye");
				bw.close();
				Reuse.log("Done");
			} else {
				Reuse.log("File not exist");
			}
		} catch (Exception e) {
			Reuse.log(e);

			Reuse.log("Problem with FlogForRunComplition method. for more info: " + e.getMessage());
		} finally {
			file = null;
		}
	}

	public static void performanceTiming_NavigationStart() {
		try {
			perfTimingJs = (JavascriptExecutor) Demo1.driver;
			perfTimingNavStart = (Long) perfTimingJs.executeScript("return window.performance.timing.navigationStart;");
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public static void performanceTiming_LoadEventEnd() {
		try {
			perfTimingLoadEventEnd = (Long) perfTimingJs
					.executeScript("return window.performance.timing.loadEventEnd;");
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public static void performanceTiming_NavigationEnd(double expResponseTimeInSec) {
		try {
			double frameworkExeTime = 4;
			performanceTiming_LoadEventEnd();

			double diff = Math.round(
					Math.abs((((perfTimingLoadEventEnd - perfTimingNavStart) / 1000) - frameworkExeTime)) * 100.00)
					/ 100.00;
			System.out.println("Total TIme with no fwExe: " + (perfTimingLoadEventEnd - perfTimingNavStart) / 1000);
			if (diff <= expResponseTimeInSec) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Page response time",
						"Expected time to load the page is " + expResponseTimeInSec + " sec",
						"Time taken " + diff + " sec");
			} else {
				if (Config.responseTimeReportLevel.toLowerCase().contains("error")) {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Page response time",
							"Expected time to load the page is " + expResponseTimeInSec + " sec.",
							"Time taken " + diff + " sec");
				} else if (Config.responseTimeReportLevel.toLowerCase().contains("warning")) {
					Demo1.gbTestCaseStatus = "Warning";
					Demo1.ReportStep(2, "Page response time",
							"Expected time to load the page is " + expResponseTimeInSec + " sec.",
							"Time taken " + diff + " sec");
				} else {
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Page response time",
							"Expected time to load the page is " + expResponseTimeInSec + " sec.",
							"Time taken " + diff + " sec");
				}

			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public static void ExecuteOfsMessage(String applicationName, String servicePointURL, String userAgent,
			String passWord, String ofsMsgData, String outputParams) {
		System.out.println("OUTPUT PARAMS::" + outputParams);
		try {

			if (ofsMsgData.contains("auto@")) {
				ofsMsgData = updateRuntimeValuesInOfs(ofsMsgData);
			}

			String servicePointUrlUpdated = servicePointURL
					+ "/axis2/services/OFSConnectorServiceWS.OFSConnectorServiceWSHttpSoap11Endpoint";

			System.out.println("UPDATED URL:::" + servicePointUrlUpdated);

			URL obj = new URL(servicePointUrlUpdated);
			HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();

			postConnection.setRequestMethod("POST");
			postConnection.setRequestProperty("User-Agent", userAgent);
			postConnection.setRequestProperty("password", passWord);
			postConnection.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
			postConnection.setRequestProperty("SOAPAction", "ofs:processOFS");

			postConnection.setDoOutput(true);

			StringBuffer ofsXmlMessage = new StringBuffer();

			ofsXmlMessage.append("<?xml version='1.0' encoding='utf-8'?>\n");
			ofsXmlMessage.append(
					"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ofs=\"http://OFSConnectorServiceWS\" xmlns:xsd=\"http://data.services.soa.temenos.com/xsd\">\n");
			ofsXmlMessage.append("        <soapenv:Header/>\n");
			ofsXmlMessage.append("        <soapenv:Body>\n");
			ofsXmlMessage.append("                <ofs:processOFS>\n");
			ofsXmlMessage.append("                        <ofs:userDetails>\n");
			ofsXmlMessage.append("                                <xsd:user>" + userAgent + "</xsd:user>\n");
			ofsXmlMessage.append("                                <xsd:password>" + passWord + "</xsd:password>\n");
			ofsXmlMessage.append("                        </ofs:userDetails>\n");
			ofsXmlMessage.append("                        <ofs:ofsRequest>" + ofsMsgData + "</ofs:ofsRequest>\n");
			ofsXmlMessage.append("                </ofs:processOFS>\n");
			ofsXmlMessage.append("        </soapenv:Body>\n");
			ofsXmlMessage.append("</soapenv:Envelope>");

			/* System.out.print(ofsXmlMessage + "\n"); */

			DataOutputStream os = new DataOutputStream(postConnection.getOutputStream());
			os.writeBytes(ofsXmlMessage.toString());
			os.flush();
			os.close();

			int responseCode = postConnection.getResponseCode();
			System.out.println("POST Response Code :  " + responseCode);
			System.out.println("POST Response Message : " + postConnection.getResponseMessage());

			if (responseCode == HttpURLConnection.HTTP_CREATED || responseCode == HttpURLConnection.HTTP_OK) { // success
				BufferedReader in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
				String inputLine;
				StringBuffer data = new StringBuffer();
				while ((inputLine = in.readLine()) != null) {
					data.append(inputLine);
				}
				in.close();
				// print result
				System.out.println(data.toString());

				/*
				 * String responseContent =
				 * response.substring(response.indexOf("<ax219:ofsResponse>")+
				 * "<ax219:ofsResponse>".length(), response.indexOf("</ax219:ofsResponse>"));
				 */

				/*
				 * String responseContent = response.substring(response.indexOf("ofsResponse>")+
				 * "ofsResponse>".length(), response.indexOf("ofsResponse>"));
				 */

				String responseContent = data.substring(data.indexOf("ofsResponse>") + "ofsResponse>".length());
				responseContent = responseContent.substring(0, responseContent.indexOf("ofsResponse>"));

				responseContent = responseContent.substring(0, responseContent.lastIndexOf("</"));

				if (responseContent.contains("&lt;")) {
					responseContent = responseContent.replaceAll("&lt;", "<");
				}

				if (responseContent.contains("<requests>") && responseContent.contains("</requests>")) {
					responseContent = responseContent.substring(
							responseContent.indexOf("<requests>") + "<requests>".length(),
							responseContent.lastIndexOf("</requests>"));
					/* System.out.println(responseContent + "\n"); */

					String res = responseContent.substring(responseContent.indexOf("<request>") + "<request>".length(),
							responseContent.lastIndexOf("</request>"));

					String[] parsed = null;
					if (res.contains("<request>")) {
						parsed = res.split("</request><request>");
					} else {
						parsed = new String[1];
						parsed[0] = res;
					}

					boolean okay = true;

					for (String str : parsed) {
						String[] responseArray = str.split(",");

						if (!outputParams.isEmpty()) {
							storeRunTimeParameters(responseArray, outputParams);
						}

						String responseStatus = responseArray[0];
						responseStatus = responseStatus.substring(responseStatus.indexOf("//") + 2);

						if (responseStatus.startsWith("-1")) {
							okay = false;
						}
					}

					if (okay) {
						Demo1.gbTestCaseStatus = "Pass";
						Demo1.ReportStep(2, "Execute OFS msg",
								"Expected to inject " + applicationName + " ofs message ",
								applicationName + " OFS message was successfully injected");
					} else {
						Demo1.gbTestCaseStatus = "Fail";
						Demo1.ReportStep(2, "Execute OFS msg",
								"Expected to inject " + applicationName + " ofs message ", responseContent);
					}

				} else {
					String[] responseArray = responseContent.split(",");

					if (!outputParams.isEmpty()) {
						storeRunTimeParameters(responseArray, outputParams);
					}

					String responseStatus = responseArray[0];
					responseStatus = responseStatus.substring(responseStatus.indexOf("//") + 2);

					if (responseStatus.startsWith("1")) {
						Demo1.gbTestCaseStatus = "Pass";
						Demo1.ReportStep(2, "Execute OFS msg",
								"Expected to inject " + applicationName + " ofs message ",
								applicationName + " OFS message was successfully injected");
					} else if (responseStatus.startsWith("-1")) {
						Demo1.gbTestCaseStatus = "Fail";
						Demo1.ReportStep(2, "Execute OFS msg",
								"Expected to inject " + applicationName + " ofs message ", responseContent);
					}
				}

			} else {
				System.out.println("POST NOT WORKED");

				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Execute OFS msg", "Expected to inject " + applicationName + " ofs message ",
						applicationName + " OFS message was not injected");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Execute OFS msg", "Expected to inject " + applicationName + " ofs message ",
					e.getMessage());
		}
	}

	/**
	 * @param responseArray
	 * @param outputParams
	 */
	public static void storeRunTimeParameters(String[] responseArray, String outputParams) {

		/*
		 * if (! isDataMapInitialized) { generalDataMap = new HashMap<String, String>();
		 * isDataMapInitialized = true; }
		 */

		/*
		 * if(! StoreText.isMapInitialized){ StoreText.txtAndVal = new HashMap<String,
		 * String>(); StoreText.isMapInitialized = true; }
		 */

		String[] outputParamList = outputParams.split(";");

		for (String param : outputParamList) {
			String[] paramSplitted = param.split("=");

			String dataReq = null;

			if (paramSplitted[0].contains(":")) {

				for (int resIndex = 1; resIndex < responseArray.length; resIndex++) {
					String[] responseSplitted = responseArray[resIndex].split("=");

					if (responseSplitted[0].trim().equals(paramSplitted[0])) {

						System.out.println("RUNTIME VARIABLE::" + paramSplitted[1]);
						String runtimeVariableUpdated = paramSplitted[1];
						runtimeVariableUpdated = runtimeVariableUpdated.substring(
								runtimeVariableUpdated.indexOf("auto@") + "auto@".length(),
								runtimeVariableUpdated.length() - 1);

						System.out.println("RUNTIME VARIABLE PARSED::" + runtimeVariableUpdated);

						Reuse.WriteProperties(runtimeVariableUpdated, responseSplitted[1]);
						System.out.println("Stored data in TestData");
						System.out.println("KEY::" + runtimeVariableUpdated + "\tVALUE::" + responseSplitted[1]);

						/*
						 * if(null == StoreText.txtAndVal.get(runtimeVariableUpdated)){
						 * StoreText.txtAndVal.put(runtimeVariableUpdated, responseSplitted[1]);
						 * System.out.println("KEY::" + runtimeVariableUpdated + "\tVALUE::" +
						 * responseSplitted[1]); }
						 */
					}
				}

			} else {
				dataReq = responseArray[0];

				if (dataReq.contains("Response"))
					dataReq = dataReq.substring(8, dataReq.indexOf("//")).trim();
				else
					dataReq = dataReq.substring(0, dataReq.indexOf("//"));

				System.out.println("RUNTIME VARIABLE::" + paramSplitted[1]);
				String runtimeVariableUpdated = paramSplitted[1];
				runtimeVariableUpdated = runtimeVariableUpdated.substring(
						runtimeVariableUpdated.indexOf("auto@") + "auto@".length(),
						runtimeVariableUpdated.length() - 1);

				System.out.println("RUNTIME VARIABLE PARSED::" + runtimeVariableUpdated);

				Reuse.WriteProperties(runtimeVariableUpdated, dataReq);
				System.out.println("Stored data in TestData");
				System.out.println("KEY::" + runtimeVariableUpdated + "\tVALUE::" + dataReq);

				/*
				 * if(null == StoreText.txtAndVal.get(runtimeVariableUpdated)){
				 * StoreText.txtAndVal.put(runtimeVariableUpdated, dataReq);
				 * System.out.println("KEY::" + runtimeVariableUpdated + "\tVALUE::" + dataReq);
				 * }
				 */
			}
		}

	}

	/**
	 * @param ofsMsgData
	 */
	public static String updateRuntimeValuesInOfs(String ofsMsgData) {

		int index = 0;
		do {
			String runTimeVariableName = ofsMsgData.substring(ofsMsgData.indexOf("auto@"));
			runTimeVariableName = runTimeVariableName.substring(0, runTimeVariableName.indexOf("@", 5) + 1);

			System.out.println("VARIABLE NAME::" + runTimeVariableName);

			String updatedRunTimeVariableName = runTimeVariableName.substring(
					runTimeVariableName.indexOf("auto@") + "auto@".length(), runTimeVariableName.length() - 1);
			// change this
			String runTimeValue = Reuse.GetPropertyValue(updatedRunTimeVariableName);
			System.out.println("Stored data in TestData");
			// String runTimeValue =
			// StoreText.txtAndVal.get(updatedRunTimeVariableName);

			System.out.println("KEY::" + updatedRunTimeVariableName + "\tVALUE::" + runTimeValue);

			/*
			 * ofsMsgData = ofsMsgData.replaceFirst(runTimeVariableName, runTimeValue);
			 */

			ofsMsgData = ofsMsgData.replaceFirst(runTimeVariableName, runTimeValue);

			System.out.println(ofsMsgData + ":: Actual Text");

		} while (ofsMsgData.contains("auto@"));

		return ofsMsgData;
	}

//    public static void analyzeViolations() {
//
//        JSONArray violationsArray;
//
//        JSONObject violationsObject;
//
//        int totalCriticalPagesCounter = 0;
//
//        int totalSeriousPagesCounter = 0;
//
//        int totalModeratePagesCounter = 0;
//
//        int totalMinorPagesCounter = 0;
//
//        try {
//            JSONObject responseJSON = new AXE.Builder(Demo1.driver, scriptUrl).analyze();
//            
//            violationsArray = responseJSON.getJSONArray("violations");
//
//            System.out.println("All Violations" + violationsArray);
//
//            for (int i = 0; i < violationsArray.length(); i++) {
//
//                violationsObject = (JSONObject) violationsArray.get(i);
//
//                String help = null;
//                try {
//                    help = violationsObject.get("help").toString();
//                } catch (Exception e) {
//
//                    System.out.println("Issue is help");
//                    e.printStackTrace();
//                    // TODO Auto-generated catch block
//                    // Uncomment and replace with appropriate logger
//                    // LOGGER.error(e, e);
//
//                }
//                String impact = null;
//                try {
//                    impact = violationsObject.get("impact").toString();
//                } catch (Exception e) {
//                    System.out.println("Issue is impact");
//                    e.printStackTrace();
//                    // TODO Auto-generated catch block
//                    // Uncomment and replace with appropriate logger
//                    // LOGGER.error(e, e);
//                }
//                String description = null;
//                try {
//                    description = violationsObject.get("description").toString();
//                } catch (Exception e) {
//                    System.out.println("Issue is description");
//                    e.printStackTrace();
//                    // TODO Auto-generated catch block
//                    // Uncomment and replace with appropriate logger
//                    // LOGGER.error(e, e);
//                }
//                String tags = null;
//                try {
//                    tags = violationsObject.get("tags").toString();
//                } catch (Exception e) {
//                    System.out.println("Issue is tags");
//                    e.printStackTrace();
//                    // TODO Auto-generated catch block
//                    // Uncomment and replace with appropriate logger
//                    // LOGGER.error(e, e);
//                }
//
//                JSONArray violationsArray1 = (JSONArray) violationsObject.get("nodes");
//
//                for (int j = 0; j < violationsArray1.length(); j++) {
//
//                    JSONObject violationsObject1 = (JSONObject) violationsArray1.get(j);
//
//                    String html = violationsObject1.get("html").toString();
//                    String target = violationsObject1.get("target").toString();
//
//                    JSONArray violationsArray2 = (JSONArray) violationsObject1.get("any");
//
//                    List<HashMap<String, String>> anyList = new ArrayList<>();
//
//                    for (int k = 0; k < violationsArray2.length(); k++) {
//
//                        HashMap<String, String> anyMap = new HashMap<>();
//
//                        JSONObject violationsObject2 = (JSONObject) violationsArray2.get(k);
//
//                        String nodeImpact = violationsObject2.get("impact").toString().replace("<", "&lt").replace(">",
//                                "&gt");
//
//                        anyMap.put("NodeImpact", nodeImpact);
//
//                        String id = violationsObject2.get("id").toString().replace("<", "&lt").replace(">", "&gt");
//
//                        anyMap.put("id", id);
//
//                        String message = violationsObject2.get("message").toString().replace("<", "&lt").replace(">",
//                                "&gt");
//
//                        anyMap.put("message", message);
//
//                        anyList.add(k, anyMap);
//
//                        System.out.println(anyList);
//
//                    }
//
//                    try {
//                        if (impact.contains("critical") || impact.contains("serious")) {
//
//                            if (impact.contains("critical"))
//                                critical = critical + 1;
//                            if (impact.contains("serious"))
//                                serious = serious + 1;
//
//                            Demo1.gbTestCaseStatus = "Fail";
//                            Demo1.ReportStep(2,
//                                    "help :" + help.replace("<", "&lt").replace(">", "&gt") + "<br>" + "impact :"
//                                            + impact.replace("<", "&lt").replace(">", "&gt") + "<br>" + "description :"
//                                            + description.replace("<", "&lt").replace(">", "&gt") + "<br>" + "tags:"
//                                            + tags.replace("<", "&lt").replace(">", "&gt") + "<br> ",
//                                            "nodeImpact: id: message:" + anyList + "</b>",
//                                            "html : Element Source :" + html.replace("<", "&lt").replace(">", "&gt") + "<br>"
//                                                    + "target : Element Location :"
//                                                    + target.replace("<", "&lt").replace(">", "&gt") + "<br>");
//                        }
//
//                        else {
//
//                            if (impact.contains("moderate"))
//                                moderate = moderate + 1;
//                            if (impact.contains("minor"))
//                                minor = minor + 1;
//
//                            Demo1.gbTestCaseStatus = "Warning";
//                            Demo1.ReportStep(2,
//                                    "help :" + help.replace("<", "&lt").replace(">", "&gt") + "<br>" + "impact :"
//                                            + impact.replace("<", "&lt").replace(">", "&gt") + "<br>" + "description :"
//                                            + description.replace("<", "&lt").replace(">", "&gt") + "<br>" + "tags:"
//                                            + tags.replace("<", "&lt").replace(">", "&gt") + "<br> ",
//                                            "nodeImpact: id: message:" + anyList + "</b>",
//                                            "html : Element Source :" + html.replace("<", "&lt").replace(">", "&gt") + "<br>"
//                                                    + "target : Element Location :"
//                                                    + target.replace("<", "&lt").replace(">", "&gt") + "<br>");
//                        }
//                    } catch (Exception e) {
//
//                        e.printStackTrace();
//                        System.out.println(
//                                "One of the following element is not present[help,impact,description,tags,anyList,html,target]");
//                        Demo1.gbTestCaseStatus = "Fail";
//                        Demo1.ReportStep(2, "Element not found",
//                                "One of the following element is not present[help,impact,description,tags,anyList,html,target]",
//                                "Error " + e.getMessage());
//                        // TODO Auto-generated catch block
//                        // Uncomment and replace with appropriate logger
//                        // LOGGER.error(e, e);
//                    }
//
//                }
//
//                if (impact.contains("critical") && totalCriticalPagesCounter == 0) {
//                    totalCriticalPages = totalCriticalPages + 1;
//                    totalCriticalPagesCounter++;
//                }
//
//                if (impact.contains("serious") && totalSeriousPagesCounter == 0) {
//                    totalSeriousPages = totalSeriousPages + 1;
//                    totalSeriousPagesCounter++;
//                }
//
//                if (impact.contains("moderate") && totalModeratePagesCounter == 0) {
//                    totalModeratePages = totalModeratePages + 1;
//                    totalModeratePagesCounter++;
//                }
//
//                if (impact.contains("minor") && totalMinorPagesCounter == 0) {
//                    totalMinorPages = totalMinorPages + 1;
//                    totalMinorPagesCounter++;
//                }
//
//            }
//
//            totalPages = totalPages + 1;
//
//            if (violationsArray.length() == 0)
//                passed = passed + 1;
//
//            WriteViolationIndexHeader(totalPages, passed, serious, critical, moderate, minor, totalSeriousPages,
//                    totalCriticalPages, totalModeratePages, totalMinorPages);
//
//        } catch (Exception e) {
//
//            Reuse.log(e);
//            e.printStackTrace();
//            Demo1.gbTestCaseStatus = "Fail";
//            Demo1.ReportStep(2, "Failed to analyze issues", "Failed to analyze issues",
//                    "Failed to analyze issues" + "</b>" + e.getMessage());
//            Demo1.logger.error(e);
//
//            // TODO Auto-generated catch block
//            // Uncomment and replace with appropriate logger
//            // LOGGER.error(e, e);
//        }
//
//    }

	public static void WriteViolationIndexHeader(int totalPages, int passed, int serious, int critical, int moderate,
			int minor, int totalSeriousPages, int totalCriticalPages, int totalModeratePages, int totalMinorPages)
			throws IOException {

		HTMLViolationReportFile = new BufferedWriter(
				new FileWriter(Demo1.gbResultFolderName + "\\Index_Voilation.htm"));

		HTMLViolationReportFile.write("<html> \n");
		// HTMLIndexFile.write("");
		HTMLViolationReportFile.write(
				"\n<head><link rel=\"stylesheet\" type=\"text/css\" href=\"../ReportInfo/report_theme.css\"/></head><body>\n");
		// 'Pageheaderincludingprojecttitle&companyname
		// WriteGenericPageHeader ();

		HTMLViolationReportFile.write("\n");
		HTMLViolationReportFile.write("\n");
		HTMLViolationReportFile.write("\n<hr class=\"divline\">");
		// HTMLReportFile.write("<BR>");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile.write("\n<table class=\"rephead\" width=1200px><tr>\n");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile.write("\n<td height=63px>" + Config.gbApplicationName + "</td>\n");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile
				.write("\n<td height=63px align=right><img src = ..\\ReportInfo\\images\\New-Temenos-logo.png></td>\n");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile.write(" \n</tr></table><hr class=\"divline\"> <BR>\n");
		HTMLViolationReportFile.write("");
		// 'Testcasenameandexecutiondate&time

		HTMLViolationReportFile.write("\r \n<table  class=\"subhead\"  width=1200px><tr>\n");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile.write("\r \n\r \n<td width=400px  class=\"subhead\"align=left>TestRun</td>\n");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile.write("\r \n\r \n<td width=200px  class=\"subhead\">ExecutionDate</td>\n");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile.write("\r \n\r \n<td width=200px class=\"subhead\">Tested on</td>\n");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile.write("\r \n\r \n<td width=100px class=\"subhead\"align=right>Build/Release</td>\n");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile.write("\r \n</tr><tr>\n");
		HTMLViolationReportFile.write("");
		String testRun = Config.testRun;
		HTMLViolationReportFile.write("\r \n\r \n<td width=400px class=\"subcont\"align=left>" + testRun + "</td>\n");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile
				.write("\r \n\r \n<td width=300px class=\"subcont\">" + dateFormat("yyyy-MM-dd") + "</td>\n");
		HTMLViolationReportFile.write("");
		String testedOn = Config.BrowName;
		HTMLViolationReportFile.write("\r \n\r \n<td width=200px class=\"subcont\">" + testedOn + "</td>\n");
		HTMLViolationReportFile.write("");
		String buildNo = Config.buildNo;
		HTMLViolationReportFile.write("\r \n\r \n<td width=100px class=\"subcont\"align=right>" + buildNo + "</td>\n");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile.write("\r \n</tr></table><hr class=\"divline\"><BR>\n");

		// 'Teststepstableheader

		HTMLViolationReportFile.write("\r \n<table width=1200 class=\"tsteps\">\n");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile.write("\r \n<tr>");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile.write("\r \n\r \n<td class=\"tshead\" width=50px>S.No</td>\n");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile.write("\r \n\r \n<td class=\"tshead\" width=200px>Product</td>\n");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile.write("\r \n\r \n<td class=\"tshead\" width=200px>Total Pages</td>\n");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile.write("\r \n\r \n<td class=\"tshead\" width=300px>Passed Pages</td>\n");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile.write("\r \n\r \n<td class=\"tshead\" width=200px>Serious</td>\n");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile.write("\r \n\r \n<td class=\"tshead\" width=200px>Critical</td>\n");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile.write("\r \n\r \n<td class=\"tshead\" width=50px>Moderate</td>\n");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile.write("\r \n\r \n<td class=\"tshead\" width=50px>Minor</td>\n");
		HTMLViolationReportFile.write("");
		HTMLViolationReportFile.write("\r \n</tr>");

		HTMLViolationReportFile.write("<tr >");
		HTMLViolationReportFile.write("<td class=\"tsind\" width=50px>" + "1" + "</td>");
		HTMLViolationReportFile.write("<td class=\"tsnorm\" width=200px><a class=\tcindex\" href=\"" + "index_"
				+ Config.RunNo + ".htm\">" + "Temenos UXP" + "</a></td>");
		// HTMLIndexFile.write("<td class=\"tsnorm\" width=200px><a
		// class=\"tcindex\" href=\"" + gbCurrTestCaseName + ".htm\">" +
		// gbCurrTestCaseName + "</a></td>");
		HTMLViolationReportFile.write("<td class=\"tsnorm\" width=300px>" + totalPages + "</td>");
		HTMLViolationReportFile.write("<td class=\"tsnorm\" width=1500px>" + passed + "</td>");
		HTMLViolationReportFile
				.write("<td class=\"tsnorm\" width=300px>" + totalSeriousPages + "(" + serious + ")" + "</td>"); // Complexity
		HTMLViolationReportFile
				.write("<td class=\"tsnorm\" width=300px>" + totalCriticalPages + "(" + critical + ")" + "</td>");
		HTMLViolationReportFile
				.write("<td class=\"tsnorm\" width=300px>" + totalModeratePages + "(" + moderate + ")" + "</td>");
		HTMLViolationReportFile
				.write("<td class=\"tsnorm\" width=300px>" + totalMinorPages + "(" + minor + ")" + "</td>");
		HTMLViolationReportFile.write("</tr >");

		HTMLViolationReportFile.write("</table>");

		HTMLViolationReportFile.write("<br >");
		HTMLViolationReportFile.write("<br >");
		HTMLViolationReportFile.write("<div>");
		HTMLViolationReportFile.write(
				"Note : The number outside the brackets is the number of pages where at least such an issue occurred and the number in brackets is the sum of items across all the pages where they occurred. ");
		HTMLViolationReportFile.write("</div>");
		HTMLViolationReportFile.write("</body></html>");
		HTMLViolationReportFile.close();
	}

	public static void analyzeViolations() {

		int totalCriticalPagesCounter = 0;

		int totalSeriousPagesCounter = 0;

		int totalModeratePagesCounter = 0;

		int totalMinorPagesCounter = 0;
		String help = null;
		String impact = null;
		String description = null;
		String html = null;
		String target = null;
		String Nodeimpact = null;
		List<String> tags;
		HashMap<String, String> anyMap = null;
		List<HashMap<String, String>> anyList = null;

		try {
			AxeBuilder builder = new AxeBuilder();
			Results results = builder.analyze(Demo1.driver);
			System.out.println(results.getViolations());

			List<Rule> violations = results.getViolations();
			for (Rule rule : violations) {
				help = rule.getHelp();
				impact = rule.getImpact();
				description = rule.getDescription();
				tags = rule.getTags();
				System.out.println("tags" + tags);

				List<CheckedNode> nodes = rule.getNodes();
				for (CheckedNode rule2 : nodes) {
					html = rule2.getHtml();
					target = rule2.getTarget().toString();
					List<Check> any = rule2.getAny();
					anyList = new ArrayList<HashMap<String, String>>();
					for (Check rule3 : any) {
						anyMap = new HashMap<String, String>();
						Nodeimpact = rule3.getImpact();
						anyMap.put("html", Nodeimpact);
						String id = rule3.getId();
						anyMap.put("id", id);
						String message = rule3.getMessage();
						anyMap.put("message", message);
						anyList.add(anyMap);
						System.out.println(anyList);

					}

					try {
						if (impact.contains("critical") || impact.contains("serious")) {

							if (impact.contains("critical"))
								critical = critical + 1;
							if (impact.contains("serious"))
								serious = serious + 1;

							Demo1.gbTestCaseStatus = "Fail";
							Demo1.ReportStep(2,
									"help :" + help.replace("<", "&lt").replace(">", "&gt") + "<br>" + "impact :"
											+ impact.replace("<", "&lt").replace(">", "&gt") + "<br>" + "description :"
											+ description.replace("<", "&lt").replace(">", "&gt") + "<br>" + "tags:"
											+ tags + "<br> ",
									"nodeImpact: id: message:"
											+ anyList.toString().replace("<", "&lt").replace(">", "&gt") + "</b>",
									"html : Element Source :" + html.replace("<", "&lt").replace(">", "&gt") + "<br>"
											+ "target : Element Location :"
											+ target.replace("<", "&lt").replace(">", "&gt") + "<br>");
						}

						else {

							if (impact.contains("moderate"))
								moderate = moderate + 1;
							if (impact.contains("minor"))
								minor = minor + 1;

							Demo1.gbTestCaseStatus = "Warning";
							Demo1.ReportStep(2,
									"help :" + help.replace("<", "&lt").replace(">", "&gt") + "<br>" + "impact :"
											+ impact.replace("<", "&lt").replace(">", "&gt") + "<br>" + "description :"
											+ description.replace("<", "&lt").replace(">", "&gt") + "<br>" + "tags:"
											+ tags + "<br> ",
									"nodeImpact: id: message:"
											+ anyList.toString().replace("<", "&lt").replace(">", "&gt") + "</b>",
									"html : Element Source :" + html.replace("<", "&lt").replace(">", "&gt") + "<br>"
											+ "target : Element Location :"
											+ target.replace("<", "&lt").replace(">", "&gt") + "<br>");
						}
					} catch (Exception e) {
						e.printStackTrace();
						System.out.println(
								"One of the following element is not present[help,impact,description,tags,anyList,html,target]");
						Demo1.gbTestCaseStatus = "Fail";
						Demo1.ReportStep(2, "Element not found",
								"One of the following element is not present[help,impact,description,tags,anyList,html,target]",
								"Error " + e.getMessage());
						// TODO Auto-generated catch block
						// Uncomment and replace with appropriate logger
						// LOGGER.error(e, e);
					}

				}

				if (impact.contains("critical") && totalCriticalPagesCounter == 0) {
					totalCriticalPages = totalCriticalPages + 1;
					totalCriticalPagesCounter++;
				}

				if (impact.contains("serious") && totalSeriousPagesCounter == 0) {
					totalSeriousPages = totalSeriousPages + 1;
					totalSeriousPagesCounter++;
				}

				if (impact.contains("moderate") && totalModeratePagesCounter == 0) {
					totalModeratePages = totalModeratePages + 1;
					totalModeratePagesCounter++;
				}

				if (impact.contains("minor") && totalMinorPagesCounter == 0) {
					totalMinorPages = totalMinorPages + 1;
					totalMinorPagesCounter++;
				}

			}

			totalPages = totalPages + 1;

			if (violations.size() == 0)
				passed = passed + 1;

			WriteViolationIndexHeader(totalPages, passed, serious, critical, moderate, minor, totalSeriousPages,
					totalCriticalPages, totalModeratePages, totalMinorPages);

		} catch (Exception e) {

			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Failed to analyze issues", "Failed to analyze issues",
					"Failed to analyze issues" + "</b>" + e.getMessage());
			Demo1.logger.error(e);

			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
		}

	}

//    public static void analyzePasses() {
//
//        JSONArray violationsArray;
//
//        JSONObject violationsObject;
//
//        try {
//
//            JSONObject responseJSON = new AXE.Builder(Demo1.driver, scriptUrl).analyze();
//
//            violationsArray = responseJSON.getJSONArray("passes");
//
//            System.out.println("All Violations" + violationsArray);
//
//            for (int i = 0; i < violationsArray.length(); i++) {
//
//                violationsObject = (JSONObject) violationsArray.get(i);
//
//                String help = null;
//                try {
//                    help = violationsObject.get("help").toString();
//                } catch (Exception e) {
//
//                    System.out.println("Issue is help");
//                    e.printStackTrace();
//                    // TODO Auto-generated catch block
//                    // Uncomment and replace with appropriate logger
//                    // LOGGER.error(e, e);
//                }
//                String impact = null;
//                try {
//                    impact = violationsObject.get("impact").toString();
//                } catch (Exception e) {
//                    System.out.println("Issue is impact");
//                    e.printStackTrace();
//                    // TODO Auto-generated catch block
//                    // Uncomment and replace with appropriate logger
//                    // LOGGER.error(e, e);
//                }
//                String description = null;
//                try {
//                    description = violationsObject.get("description").toString();
//                } catch (Exception e) {
//                    System.out.println("Issue is description");
//                    e.printStackTrace();
//                    // TODO Auto-generated catch block
//                    // Uncomment and replace with appropriate logger
//                    // LOGGER.error(e, e);
//                }
//                String tags = null;
//                try {
//                    tags = violationsObject.get("tags").toString();
//                } catch (Exception e) {
//                    System.out.println("Issue is tags");
//                    e.printStackTrace();
//                    // TODO Auto-generated catch block
//                    // Uncomment and replace with appropriate logger
//                    // LOGGER.error(e, e);
//                }
//
//                JSONArray violationsArray1 = (JSONArray) violationsObject.get("nodes");
//
//                for (int j = 0; j < violationsArray1.length(); j++) {
//
//                    JSONObject violationsObject1 = (JSONObject) violationsArray1.get(j);
//
//                    String html = violationsObject1.get("html").toString();
//                    String target = violationsObject1.get("target").toString();
//
//                    JSONArray violationsArray2 = (JSONArray) violationsObject1.get("any");
//
//                    List<HashMap<String, String>> anyList = new ArrayList<>();
//
//                    for (int k = 0; k < violationsArray2.length(); k++) {
//
//                        HashMap<String, String> anyMap = new HashMap<>();
//
//                        JSONObject violationsObject2 = (JSONObject) violationsArray2.get(k);
//
//                        String nodeImpact = violationsObject2.get("impact").toString().replace("<", "&lt").replace(">",
//                                "&gt");
//
//                        anyMap.put("NodeImpact", nodeImpact);
//
//                        String id = violationsObject2.get("id").toString().replace("<", "&lt").replace(">", "&gt");
//
//                        anyMap.put("id", id);
//
//                        String message = violationsObject2.get("message").toString().replace("<", "&lt").replace(">",
//                                "&gt");
//
//                        anyMap.put("message", message);
//
//                        anyList.add(k, anyMap);
//
//                        System.out.println(anyList);
//
//                    }
//
//                    if (impact.contains("critical") || impact.contains("serious")) {
//                        Demo1.gbTestCaseStatus = "Fail";
//                        Demo1.ReportStep(2,
//                                "help :" + help.replace("<", "&lt").replace(">", "&gt") + "<br>" + "impact :"
//                                        + impact.replace("<", "&lt").replace(">", "&gt") + "<br>" + "description :"
//                                        + description.replace("<", "&lt").replace(">", "&gt") + "<br>" + "tags:"
//                                        + tags.replace("<", "&lt").replace(">", "&gt") + "<br> ",
//                                        "nodeImpact: id: message:" + anyList + "</b>",
//                                        "html : Element Source :" + html.replace("<", "&lt").replace(">", "&gt") + "<br>"
//                                                + "target : Element Location :" + target.replace("<", "&lt").replace(">", "&gt")
//                                                + "<br>");
//                    }
//
//                    else {
//                        Demo1.gbTestCaseStatus = "Warning";
//                        Demo1.ReportStep(2,
//                                "help :" + help.replace("<", "&lt").replace(">", "&gt") + "<br>" + "impact :"
//                                        + impact.replace("<", "&lt").replace(">", "&gt") + "<br>" + "description :"
//                                        + description.replace("<", "&lt").replace(">", "&gt") + "<br>" + "tags:"
//                                        + tags.replace("<", "&lt").replace(">", "&gt") + "<br> ",
//                                        "nodeImpact: id: message:" + anyList + "</b>",
//                                        "html : Element Source :" + html.replace("<", "&lt").replace(">", "&gt") + "<br>"
//                                                + "target : Element Location :" + target.replace("<", "&lt").replace(">", "&gt")
//                                                + "<br>");
//                    }
//
//                }
//
//            }
//
//        } catch (Exception e) {
//
//            Reuse.log(e);
//            e.printStackTrace();
//            Demo1.gbTestCaseStatus = "Fail";
//            Demo1.ReportStep(2, "Failed to analyze issues", "Failed to analyze issues",
//                    "Failed to analyze issues" + "</b>" + e.getMessage());
//            Demo1.logger.error(e);
//
//            // TODO Auto-generated catch block
//            // Uncomment and replace with appropriate logger
//            // LOGGER.error(e, e);
//        }
//    }

	public static void analyzePasses() {
		String help = null;
		String impact = null;
		String description = null;
		String html = null;
		String target = null;
		List<String> tags;
		HashMap<String, String> anyMap = null;
		List<HashMap<String, String>> anyList = null;

		try {
			AxeBuilder builder = new AxeBuilder();
			Results results = builder.analyze(Demo1.driver);
			System.out.println(results.getPasses());

			List<Rule> pass = results.getPasses();
			for (Rule rule : pass) {
				help = rule.getHelp();
				impact = rule.getImpact();
				description = rule.getDescription();
				tags = rule.getTags();
				System.out.println("tags" + tags);

				List<CheckedNode> nodes = rule.getNodes();
				for (CheckedNode rule2 : nodes) {
					html = rule2.getHtml();
					target = rule2.getTarget().toString();
					List<Check> any = rule2.getAny();
					anyList = new ArrayList<HashMap<String, String>>();
					for (Check rule3 : any) {
						anyMap = new HashMap<String, String>();
						String Nodeimpact = rule3.getImpact();
						anyMap.put("html", Nodeimpact);
						String id = rule3.getId();
						anyMap.put("id", id);
						String message = rule3.getMessage();
						anyMap.put("message", message);
						anyList.add(anyMap);
						System.out.println(anyList);

					}

					try {
						if (impact.contains("critical") || impact.contains("serious")) {

							Demo1.gbTestCaseStatus = "Fail";
							Demo1.ReportStep(2,
									"help :" + help.replace("<", "&lt").replace(">", "&gt") + "<br>" + "impact :"
											+ impact.replace("<", "&lt").replace(">", "&gt") + "<br>" + "description :"
											+ description.replace("<", "&lt").replace(">", "&gt") + "<br>" + "tags:"
											+ tags + "<br> ",
									"nodeImpact: id: message:"
											+ anyList.toString().replace("<", "&lt").replace(">", "&gt") + "</b>",
									"html : Element Source :" + html.replace("<", "&lt").replace(">", "&gt") + "<br>"
											+ "target : Element Location :"
											+ target.replace("<", "&lt").replace(">", "&gt") + "<br>");
						}

						else {

							Demo1.gbTestCaseStatus = "Warning";
							Demo1.ReportStep(2,
									"help :" + help.replace("<", "&lt").replace(">", "&gt") + "<br>" + "impact :"
											+ impact.replace("<", "&lt").replace(">", "&gt") + "<br>" + "description :"
											+ description.replace("<", "&lt").replace(">", "&gt") + "<br>" + "tags:"
											+ tags + "<br> ",
									"nodeImpact: id: message:"
											+ anyList.toString().replace("<", "&lt").replace(">", "&gt") + "</b>",
									"html : Element Source :" + html.replace("<", "&lt").replace(">", "&gt") + "<br>"
											+ "target : Element Location :"
											+ target.replace("<", "&lt").replace(">", "&gt") + "<br>");
						}
					} catch (Exception e) {
						e.printStackTrace();
						System.out.println(
								"One of the following element is not present[help,impact,description,tags,anyList,html,target]");
						Demo1.gbTestCaseStatus = "Fail";
						Demo1.ReportStep(2, "Element not found",
								"One of the following element is not present[help,impact,description,tags,anyList,html,target]",
								"Error " + e.getMessage());
						// TODO Auto-generated catch block
						// Uncomment and replace with appropriate logger
						// LOGGER.error(e, e);
					}
				}
			}

		} catch (Exception e) {

			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Failed to analyze issues", "Failed to analyze issues",
					"Failed to analyze issues" + "</b>" + e.getMessage());
			Demo1.logger.error(e);

			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
		}

	}

	public static void getDataFromUnix(String command) {

		try {
			String host = Config.unixHost;
			String user = Config.unixUsername;
			String password = Config.unixPassword;

			SSHExec.setOption(IOptionName.HALT_ON_FAILURE, true);
			ConnBean cb = new ConnBean(host, user, password);

			SysConfigOption.INTEVAL_TIME_BETWEEN_TASKS = 1000;

			SSHExec ssh = SSHExec.getInstance(cb);

			CustomTask ct2 = new ExecCommand(command);

			ssh.connect();

			Result r1 = null;

			String cmdResult = null;
			try {
				r1 = ssh.exec(ct2);

				cmdResult = r1.sysout;

				System.out.println("Query Result" + r1.sysout);

			} catch (TaskExecFailException e) {
				Reuse.log(e);
				e.printStackTrace();
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Failed to get data from unix", "Failed to get data from unix",
						"Failed to get data from unix" + "</b>" + e.getMessage());
				Demo1.logger.error(e);
			}
			System.out.println("Return code: " + r1.rc);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "getDataFromUnix", "Expected to getDataFromUnix ", "Got DB result:" + cmdResult);

			ssh.disconnect();
		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Failed to get data from unix", "Failed to get data from unix",
					"Failed to get data from unix" + "</b>" + e.getMessage());
			Demo1.logger.error(e);
		}

	}

	public static void getDBConnect(String query) {
		try {

			String host = Config.unixHost;
			String sid = Config.tdsSID;
			String user = Config.tdsDBUsername;
			String password = Config.tdsDBPassword;
			String portNo = Config.tdsDBPortNo;

			List<String> queryResult = new ArrayList<>();

			// step1 load the driver class
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// step2 create the connection object
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@" + host + ":" + portNo + ":" + sid, user,
					password);

			// "jdbc:oracle:thin:@maa2wmlx1:1521:prodb1","tdsuser","tdsuser")

			// step3 create the statement object
			Statement stmt = con.createStatement();

			// step4 execute query
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				System.out.println(rs.getString(1));
				queryResult.add(rs.getString(1));
			}
			// System.out.println( "first row"+ rs.absolute(1) );

			// step5 close the connection object
			con.close();

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "getDataFromDB", "Expected to getDataFromDB ", "Got DB result:" + queryResult);

		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Failed to get data from DB", "Failed to get data from DB",
					"Failed to get data from DB" + "</b>" + e.getMessage());
			Demo1.logger.error(e);
		}

	}

	public static void verifyDataFromDB(String query, String expectedValue) {
		try {

			String host = Config.unixHost;
			String sid = Config.tdsSID;
			String user = Config.tdsDBUsername;
			String password = Config.tdsDBPassword;
			String portNo = Config.tdsDBPortNo;

			List<String> queryResult = new ArrayList<>();

			// step1 load the driver class
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// step2 create the connection object
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@" + host + ":" + portNo + ":" + sid, user,
					password);

			// "jdbc:oracle:thin:@maa2wmlx1:1521:prodb1","tdsuser","tdsuser")

			// step3 create the statement object
			Statement stmt = con.createStatement();

			query = getProcessedQuery(query);

			// step4 execute query
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				System.out.println(rs.getString(1));
				queryResult.add(rs.getString(1));
			}

			String actualValue = queryResult.get(0);

			if (expectedValue.contentEquals(actualValue)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify text <b>" + actualValue + "</b> contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> should contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> text contains <b>" + expectedValue + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + actualValue + "</b> contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> should contains <b>" + expectedValue + "</b>",
						"Actual text <b>" + actualValue + "</b>");
			}

			// step5 close the connection object
			con.close();

		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Failed to get data from DB", "Failed to get data from DB",
					"Failed to get data from DB" + "</b>" + e.getMessage());
			Demo1.logger.error(e);
		}

	}

	public static void verifyDataFromUnix(String command, String expectedValue) {

		try {
			String host = Config.unixHost;
			String user = Config.unixUsername;
			String password = Config.unixPassword;

			SSHExec.setOption(IOptionName.HALT_ON_FAILURE, true);
			ConnBean cb = new ConnBean(host, user, password);

			SysConfigOption.INTEVAL_TIME_BETWEEN_TASKS = 1000;

			SSHExec ssh = SSHExec.getInstance(cb);

			CustomTask ct2 = new ExecCommand(command);

			ssh.connect();

			Result r1 = null;

			String actualValue = null;
			try {
				r1 = ssh.exec(ct2);

				actualValue = r1.sysout;

				System.out.println("Query Result" + r1.sysout);

			} catch (TaskExecFailException e) {
				Reuse.log(e);
				e.printStackTrace();
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Failed to get data from unix", "Failed to get data from unix",
						"Failed to get data from unix" + "</b>" + e.getMessage());
				Demo1.logger.error(e);
			}

			if (expectedValue.contentEquals(actualValue.trim())) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify text <b>" + actualValue + "</b> contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> should contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> text contains <b>" + expectedValue + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + actualValue + "</b> contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> should contains <b>" + expectedValue + "</b>",
						"Actual text <b>" + actualValue + "</b>");
			}

			System.out.println("Return code: " + r1.rc);

			ssh.disconnect();
		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Failed to get data from unix", "Failed to get data from unix",
					"Failed to get data from unix" + "</b>" + e.getMessage());
			Demo1.logger.error(e);
		}

	}

	public static void verifyDataContainsFromUnix(String command, String expectedValue) {

		try {
			String host = Config.unixHost;
			String user = Config.unixUsername;
			String password = Config.unixPassword;

			SSHExec.setOption(IOptionName.HALT_ON_FAILURE, true);
			ConnBean cb = new ConnBean(host, user, password);

			SysConfigOption.INTEVAL_TIME_BETWEEN_TASKS = 1000;

			SSHExec ssh = SSHExec.getInstance(cb);

			command = Reuse.getProcessedCommand(command);

			String cmd[] = { Config.export_jboss_home, Config.export_pdb_home, Config.set_path, command };

			CustomTask ct2 = new ExecCommand(cmd);

			ssh.connect();

			Result r1 = null;

			String actualValue = null;
			try {
				r1 = ssh.exec(ct2);

				actualValue = r1.sysout;

				System.out.println("Query Result" + r1.sysout);

			} catch (TaskExecFailException e) {
				Reuse.log(e);
				e.printStackTrace();
				Demo1.gbTestCaseStatus = "Fail";

				Demo1.ReportStep(2, "Get data from unix", "Run Unix command :" + command + "successfuly",
						"Failed to get data from unix" + "</b>" + e.getMessage());
				Demo1.logger.error(e);
			}

			if (actualValue.contains(expectedValue)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2,
						"Verify actual text: <b>" + actualValue + "</b> contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> should contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> text contains <b>" + expectedValue + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2,
						"Verify actual text:<b>" + actualValue + "</b> contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> should contains <b>" + expectedValue + "</b>",
						"Actual text <b>" + actualValue + "</b> text doesn't contains <b>" + expectedValue + "</b>");
			}

			System.out.println("Return code: " + r1.rc);

			ssh.disconnect();
		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";

			Demo1.ReportStep(2, "Failed to get data from unix", "Get data from unix",
					"Failed to get data from unix from command:" + command + e.getMessage());
			Demo1.logger.error(e);
		}

	}

	public static void verifyDataContainsFromUnixWithVar(String commandWithVar, String expectedValue) {

		try {
			String host = Config.unixHost;
			String user = Config.unixUsername;
			String password = Config.unixPassword;

			SSHExec.setOption(IOptionName.HALT_ON_FAILURE, true);
			ConnBean cb = new ConnBean(host, user, password);

			SysConfigOption.INTEVAL_TIME_BETWEEN_TASKS = 1000;

			SSHExec ssh = SSHExec.getInstance(cb);

			commandWithVar = Reuse.getProcessedCommand(commandWithVar);

			String cmd[] = { Config.export_jboss_home, Config.export_pdb_home, Config.set_path, commandWithVar };

			CustomTask ct2 = new ExecCommand(cmd);

			ssh.connect();

			Result r1 = null;

			String actualValue = null;
			try {
				r1 = ssh.exec(ct2);

				actualValue = r1.sysout;

				System.out.println("Query Result" + r1.sysout);

			} catch (TaskExecFailException e) {
				Reuse.log(e);
				e.printStackTrace();
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Failed to get data from unix", "Failed to get data from unix",
						"Failed to get data from unix" + "</b>" + e.getMessage());
				Demo1.logger.error(e);
			}

			if (actualValue.contains(expectedValue)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify text <b>" + actualValue + "</b> contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> should contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> text contains <b>" + expectedValue + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + actualValue + "</b> contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> should contains <b>" + expectedValue + "</b>",
						"Actual text <b>" + actualValue + "</b>");
			}

			System.out.println("Return code: " + r1.rc);

			ssh.disconnect();
		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Failed to get data from unix", "Failed to get data from unix",
					"Failed to get data from unix" + "</b>" + e.getMessage());
			Demo1.logger.error(e);
		}

	}

	public static void storeDataFromDBToFile(String query, String variableName) {
		try {

			String host = Config.unixHost;
			String sid = Config.tdsSID;
			String user = Config.tdsDBUsername;
			String password = Config.tdsDBPassword;
			String portNo = Config.tdsDBPortNo;

			List<String> queryResult = new ArrayList<>();

			// step1 load the driver class
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// step2 create the connection object
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@" + host + ":" + portNo + ":" + sid, user,
					password);

			// "jdbc:oracle:thin:@maa2wmlx1:1521:prodb1","tdsuser","tdsuser")

			// step3 create the statement object
			Statement stmt = con.createStatement();

			query = getProcessedQuery(query);
			// step4 execute query
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				// System.out.println(rs.getString(1));
				queryResult.add(rs.getString(1));
			}

			String actualValue = queryResult.get(0);

			if (actualValue != null && actualValue.length() > 0 && !actualValue.equals("")) {

				Reuse.WriteProperties(variableName, actualValue);
				Demo1.gbTestCaseStatus = "Pass";
				actualValue = escapeHtml3(actualValue);

				Demo1.ReportStep(2,
						"Store actual value: <b>" + actualValue + "</b> in variable name:<b>" + variableName + "</b> ",
						"<b>Actual value:" + actualValue + "</b> should be stored in variable name:<b>" + variableName
								+ "</b> ",
						"Actual value:" + actualValue + "</b> is stored in variable name: <b>" + variableName);

			}

			else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2,
						"Store actual value:<b>" + actualValue + "</b> in variable name: <b>" + variableName + "</b> ",
						"<b> Actual value:" + actualValue + "</b> should be stored in variable name: <b>"
								+ variableName,
						"Actual value:" + actualValue + "</b> is not stored in variable name: <b>" + variableName);

			}

			// step5 close the connection object
			con.close();

		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Failed to get data from DB", "Get data from DB",
					"Failed to get data from unix from command:" + query + e.getMessage());

			Demo1.logger.error(e);
		}

	}

	public static void storeDateFromDBToFile(String query, String variableName) {
		try {

			String host = Config.unixHost;
			String sid = Config.tdsSID;
			String user = Config.tdsDBUsername;
			String password = Config.tdsDBPassword;
			String portNo = Config.tdsDBPortNo;

			List<String> queryResult = new ArrayList<>();

			// step1 load the driver class
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// step2 create the connection object
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@" + host + ":" + portNo + ":" + sid, user,
					password);

			// "jdbc:oracle:thin:@maa2wmlx1:1521:prodb1","tdsuser","tdsuser")

			// step3 create the statement object
			Statement stmt = con.createStatement();

			query = getProcessedQuery(query);
			// step4 execute query
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				// System.out.println(rs.getDate(1));
				queryResult.add(rs.getDate(1).toString());
			}

			String actualValue = queryResult.get(0);

			if (actualValue != null && actualValue.length() > 0 && !actualValue.equals("")) {

				Reuse.WriteProperties(variableName, actualValue);
				Demo1.gbTestCaseStatus = "Pass";
				actualValue = escapeHtml3(actualValue);
				Demo1.ReportStep(2,
						"Store actual value:<b>" + actualValue + "</b> in variable name: <b>" + variableName + "</b> ",
						"<b>  Actual value:" + actualValue + "</b> should be stored in variable name: <b>"
								+ variableName + "</b> ",
						"Actual value:" + actualValue + "</b> is stored in variable name: <b>" + variableName);
			}

			else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2,
						"Store actual value:<b>" + actualValue + "</b> in variable name: <b>" + variableName + "</b> ",
						"<b> Actual value:" + actualValue + "</b> should be stored in variable name: <b>"
								+ variableName,
						"Actual value:" + actualValue + "</b> is not stored in variable name: <b>" + variableName);
			}

			// step5 close the connection object
			con.close();

		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";

			Demo1.ReportStep(2, "Failed to get data from DB", "Get data from DB",
					"Failed to get data from DB for command:" + query + e.getMessage());

			Demo1.logger.error(e);
		}

	}

	public static void storeDataFromUnixToFile(String command, String variableName) {

		try {
			String host = Config.unixHost;
			String user = Config.unixUsername;
			String password = Config.unixPassword;

			SSHExec.setOption(IOptionName.HALT_ON_FAILURE, true);
			ConnBean cb = new ConnBean(host, user, password);

			SysConfigOption.INTEVAL_TIME_BETWEEN_TASKS = 1000;

			SSHExec ssh = SSHExec.getInstance(cb);

			CustomTask ct2 = new ExecCommand(command);

			ssh.connect();

			Result r1 = null;

			String actualValue = null;
			try {
				r1 = ssh.exec(ct2);

				actualValue = r1.sysout;

				System.out.println("Query Result" + r1.sysout);

			} catch (TaskExecFailException e) {
				Reuse.log(e);
				e.printStackTrace();
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Failed to get data from unix", "Failed to get data from unix",
						"Failed to get data from unix" + "</b>" + e.getMessage());
				Demo1.logger.error(e);
			}

			if (actualValue != null && actualValue.length() > 0 && !actualValue.equals("")) {

				Reuse.WriteProperties(variableName, actualValue);
				Demo1.gbTestCaseStatus = "Pass";
				actualValue = escapeHtml3(actualValue);
				Demo1.ReportStep(2, "Store <b>" + actualValue + "</b> in <b>" + variableName + "</b> ",
						"<b>" + actualValue + "</b> should be stored in <b>" + variableName + "</b> ", "Stored");
			}

			else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Store <b>" + actualValue + "</b> in <b>" + variableName + "</b> ",
						"<b>" + actualValue + "</b> should be stored in <b>" + variableName + "</b> ",
						"Value may not present in the element provided");
			}

			System.out.println("Return code: " + r1.rc);

			ssh.disconnect();
		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Failed to get data from unix", "Failed to get data from unix",
					"Failed to get data from unix" + "</b>" + e.getMessage());
			Demo1.logger.error(e);
		}

	}

	public static void storeStatIdByImport(String command, String variableName) {

		try {
			String host = Config.unixHost;
			String user = Config.unixUsername;
			String password = Config.unixPassword;

			SSHExec.setOption(IOptionName.HALT_ON_FAILURE, true);
			ConnBean cb = new ConnBean(host, user, password);

			SysConfigOption.INTEVAL_TIME_BETWEEN_TASKS = 1000;

			SSHExec ssh = SSHExec.getInstance(cb);

			String cmd[] = { Config.export_jboss_home, Config.export_pdb_home, Config.set_path, command };

			CustomTask ct2 = new ExecCommand(cmd);

			ssh.connect();

			Result r1 = null;

			String actualValue = null;
			try {
				r1 = ssh.exec(ct2);

				actualValue = r1.sysout;

				System.out.println("Query Result" + r1.sysout);

			} catch (TaskExecFailException e) {
				Reuse.log(e);
				e.printStackTrace();
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Get data from unix", "Run Unix command :" + command + "successfuly",
						"Failed to get data from unix" + "</b>" + e.getMessage());
				Demo1.logger.error(e);
			}

			String statId = null;
			try {
				statId = actualValue.substring(actualValue.indexOf("statId"));
				statId = statId.substring(0, statId.indexOf("\n"));
				statId = statId.split("=")[1];
				System.out.println("Stat_id is :" + statId);

				if (statId != null && statId.length() > 0 && !statId.equals("")) {

					Reuse.WriteProperties(variableName, statId);
					Demo1.gbTestCaseStatus = "Pass";
					actualValue = escapeHtml3(statId);
					Demo1.ReportStep(2, "Store stat_id in variable Name:" + variableName,
							"<b>" + statId + "</b> should be stored in <b>" + variableName + "</b> ",
							"Stored" + statId + "</b> in " + variableName);
				}

				else {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Store stat_id in variable Name:" + variableName,
							" Stat_Id should be stored in <b>" + variableName + "</b> ",
							" Stat_Id is not stored in variable name:<b>" + variableName);
				}

			} catch (Exception e) {
				e.printStackTrace();
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Store stat_id in variable Name:" + variableName,
						" Stat_Id should be stored in <b>" + variableName + "</b> ",
						" Stat_Id is not stored in variable name:<b>" + variableName + e.getMessage());

			}

			System.out.println("Return code: " + r1.rc);

			ssh.disconnect();

		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Failed to get data from unix", "Get data from unix",
					"Failed to get data from unix from command:" + command + e.getMessage());
			Demo1.logger.error(e);
		}

	}

	public static void storeExportedFileNameAndPath(String command, String variableName, String pathVarName) {

		try {
			String host = Config.unixHost;
			String user = Config.unixUsername;
			String password = Config.unixPassword;

			SSHExec.setOption(IOptionName.HALT_ON_FAILURE, true);
			ConnBean cb = new ConnBean(host, user, password);

			SysConfigOption.INTEVAL_TIME_BETWEEN_TASKS = 1000;

			SSHExec ssh = SSHExec.getInstance(cb);

			String cmd[] = { Config.export_jboss_home, Config.export_pdb_home, Config.set_path, command };

			CustomTask ct2 = new ExecCommand(cmd);

			ssh.connect();

			Result r1 = null;

			String actualValue = null;
			try {
				r1 = ssh.exec(ct2);

				actualValue = r1.sysout;

				System.out.println("Query Result" + r1.sysout);

			} catch (TaskExecFailException e) {
				Reuse.log(e);
				e.printStackTrace();
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Get data from unix", "Run Unix command :" + command + "successfuly",
						"Failed to get data from unix" + "</b>" + e.getMessage());
				Demo1.logger.error(e);
			}

			String fileName = null;
			String pathName = null;
			try {

				fileName = actualValue.substring(actualValue.indexOf("Export file"));
				fileName = fileName.split("=")[1].trim();

				pathName = fileName.substring(0, fileName.lastIndexOf('/') + 1).trim();

				fileName = fileName.substring(fileName.lastIndexOf('/') + 1).trim();

				System.out.println(fileName);

				if (fileName != null && fileName.length() > 0 && !fileName.equals("")) {

					Reuse.WriteProperties(variableName, fileName);
					Demo1.gbTestCaseStatus = "Pass";
					actualValue = escapeHtml3(fileName);
					Demo1.ReportStep(2, "Store File Name in variable Name:" + variableName,
							"<b>" + fileName + "</b> should be stored in <b>" + variableName + "</b> ",
							"Stored" + fileName + "</b> in " + variableName);
				}

				else {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Store stat_id in variable Name:" + variableName,
							" File name should be stored in <b>" + variableName + "</b> ",
							" File Name is not stored in variable name:<b>" + variableName);
				}

				if (pathName != null && pathName.length() > 0 && !pathName.equals("")) {

					Reuse.WriteProperties(pathVarName, pathName);
					Demo1.gbTestCaseStatus = "Pass";
					actualValue = escapeHtml3(pathVarName);
					Demo1.ReportStep(2, "Store path in variable Name:" + pathVarName,
							"<b>" + pathName + "</b> should be stored in <b>" + pathVarName + "</b> ",
							"Stored" + pathName + "</b> in " + pathVarName);
				}

				else {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Store path in variable Name:" + pathVarName,
							" Path should be stored in <b>" + pathVarName + "</b> ",
							" Path is not stored in variable name:<b>" + pathVarName);
				}

			} catch (Exception e) {
				e.printStackTrace();
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Store file name in variable Name:" + variableName,
						" File Name should be stored in <b>" + variableName + "</b> ",
						" File Name is not stored in variable name:<b>" + variableName + e.getMessage());

			}

			System.out.println("Return code: " + r1.rc);

			ssh.disconnect();

		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Failed to get data from unix", "Get data from unix",
					"Failed to get data from unix from command:" + command + e.getMessage());
			Demo1.logger.error(e);
		}

	}

	public static void verifyFilePresentInUnixPath(String path, String expectedValue) {

		try {
			String host = Config.unixHost;
			String user = Config.unixUsername;
			String password = Config.unixPassword;

			SSHExec.setOption(IOptionName.HALT_ON_FAILURE, true);
			ConnBean cb = new ConnBean(host, user, password);

			SysConfigOption.INTEVAL_TIME_BETWEEN_TASKS = 1000;

			SSHExec ssh = SSHExec.getInstance(cb);

			path = Reuse.getProcessedCommand(path);

			expectedValue = Reuse.getProcessedCommand(expectedValue);

			String cmd[] = { Config.export_jboss_home, Config.export_pdb_home, Config.set_path, "cd " + path, "ls" };

			CustomTask ct2 = new ExecCommand(cmd);

			ssh.connect();

			Result r1 = null;

			String actualValue = null;
			try {
				r1 = ssh.exec(ct2);

				actualValue = r1.sysout;

				// System.out.println("Query Result" + r1.sysout);

			} catch (TaskExecFailException e) {
				Reuse.log(e);
				e.printStackTrace();
				Demo1.gbTestCaseStatus = "Fail";

				Demo1.ReportStep(2, "Get data from unix", "Run Unix command :" + path + "successfuly",
						"Failed to get data from unix" + "</b>" + e.getMessage());
				Demo1.logger.error(e);
			}

			if (actualValue.contains(expectedValue)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify actual text: <b>" + "</b> contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> should contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> text contains <b>" + expectedValue + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify actual text:<b>" + "</b> contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> should contains <b>" + expectedValue + "</b>",
						"Actual text <b>" + actualValue + "</b> text doesn't contains <b>" + expectedValue + "</b>");
			}

			System.out.println("Return code: " + r1.rc);

			ssh.disconnect();
		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";

			Demo1.ReportStep(2, "Failed to get data from unix", "Get data from unix",
					"Failed to get data from unix from command:" + path + e.getMessage());
			Demo1.logger.error(e);
		}

	}

	public static String getProcessedQuery(String queryWithVariable) {
		try {

			if (queryWithVariable.contains("var@")) {
				String temp = null;
				do {
					temp = queryWithVariable.substring(queryWithVariable.indexOf("var@") + 4);
					temp = temp.substring(0, temp.indexOf(64));

					String text = Reuse.GetPropertyValue(temp);

					queryWithVariable = queryWithVariable.replace("var@" + temp + "@", text);
				} while (queryWithVariable.contains("@var"));
				System.out.println(queryWithVariable);
			}

		} catch (Exception e) {
			Reuse.log(e);
		}
		return queryWithVariable;
	}

	public static String getProcessedCommand(String commandWithVariable) {
		try {

			if (commandWithVariable.contains("var@")) {
				String temp = null;
				do {
					temp = commandWithVariable.substring(commandWithVariable.indexOf("var@") + "var@".length());
					temp = temp.substring(0, temp.indexOf(64));

					String text = Reuse.GetPropertyValue(temp);
					System.out.println(text);

					commandWithVariable = commandWithVariable.replace("var@" + temp + "@", text);
				} while (commandWithVariable.contains("var@"));

				System.out.println(commandWithVariable);
			}

		} catch (Exception e) {
			Reuse.log(e);
		}
		return commandWithVariable;
	}

	public static void verifyDataFromDBWithStoredVar(String query, String expectedValue) {
		try {

			String host = Config.unixHost;
			String sid = Config.tdsSID;
			String user = Config.tdsDBUsername;
			String password = Config.tdsDBPassword;
			String portNo = Config.tdsDBPortNo;

			List<String> queryResult = new ArrayList<>();

			// step1 load the driver class
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// step2 create the connection object
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@" + host + ":" + portNo + ":" + sid, user,
					password);

			// "jdbc:oracle:thin:@maa2wmlx1:1521:prodb1","tdsuser","tdsuser")

			// step3 create the statement object
			Statement stmt = con.createStatement();

			query = getProcessedQuery(query);

			System.out.println("query:" + query);
			// step4 execute query
			ResultSet rs = stmt.executeQuery(query);
			String actualValue = null;
			while (rs.next()) {
				System.out.println(rs.getString(1));
				actualValue = rs.getString(1);
				queryResult.add(rs.getString(1));
			}

			actualValue = queryResult.get(0);

			System.out.println(":" + actualValue);

			if (expectedValue.contentEquals(actualValue)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify text <b>" + actualValue + "</b> contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> should contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> text contains <b>" + expectedValue + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + actualValue + "</b> contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> should contains <b>" + expectedValue + "</b>",
						"Actual text <b>" + actualValue + "</b>");
			}

			// step5 close the connection object
			con.close();

		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Failed to get data from DB", "Failed to get data from DB",
					"Failed to get data from DB" + "</b>" + e.getMessage());
			Demo1.logger.error(e);
		}

	}

	public static void verifyDataPresentInDB(String query) {
		try {

			String host = Config.unixHost;
			String sid = Config.tdsSID;
			String user = Config.tdsDBUsername;
			String password = Config.tdsDBPassword;
			String portNo = Config.tdsDBPortNo;

			List<String> queryResult = new ArrayList<>();

			// step1 load the driver class
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// step2 create the connection object
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@" + host + ":" + portNo + ":" + sid, user,
					password);

			// "jdbc:oracle:thin:@maa2wmlx1:1521:prodb1","tdsuser","tdsuser")

			// step3 create the statement object
			Statement stmt = con.createStatement();

			query = getProcessedQuery(query);

			System.out.println("query:" + query);
			// step4 execute query
			ResultSet rs = stmt.executeQuery(query);
			String actualValue = null;
			while (rs.next()) {
				// System.out.println(rs.getString(1));
				actualValue = rs.getString(1);
				queryResult.add(rs.getString(1));
			}

			actualValue = queryResult.get(0);

			System.out.println(":" + actualValue);

			if (!actualValue.isEmpty()) {
				Demo1.gbTestCaseStatus = "Pass";

				Demo1.ReportStep(2, "Verify data present in the DB", "<b>" + actualValue + " : should be present in DB",
						"<b>" + actualValue + "</b> is present in DB");

			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify data present in the DB",
						"<b>" + actualValue + " : Data should be present in DB",
						"<b>" + actualValue + "</b> Data is not present in DB");
			}

			// step5 close the connection object
			con.close();

		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Failed to get data from DB", "Get data from DB",
					"Failed to get data from DB for command:" + query + e.getMessage());

			Demo1.logger.error(e);
		}

	}

	public static void storeAndVerifyDataFromDB(String query, String variableName, String expectedValue) {
		try {

			String host = Config.unixHost;
			String sid = Config.tdsSID;
			String user = Config.tdsDBUsername;
			String password = Config.tdsDBPassword;
			String portNo = Config.tdsDBPortNo;

			List<String> queryResult = new ArrayList<>();

			// step1 load the driver class
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// step2 create the connection object
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@" + host + ":" + portNo + ":" + sid, user,
					password);

			// "jdbc:oracle:thin:@maa2wmlx1:1521:prodb1","tdsuser","tdsuser")

			// step3 create the statement object
			Statement stmt = con.createStatement();

			query = getProcessedQuery(query);

			System.out.println("query:" + query);
			// step4 execute query
			ResultSet rs = stmt.executeQuery(query);
			String actualValue = null;
			while (rs.next()) {
				System.out.println(rs.getString(1));
				actualValue = rs.getString(1);
				queryResult.add(rs.getString(1));
			}

			actualValue = queryResult.get(0);

			System.out.println(":" + actualValue);

			if (expectedValue.contentEquals(actualValue)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify text <b>" + actualValue + "</b> contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> should contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> text contains <b>" + expectedValue + "</b>");

			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + actualValue + "</b> contains <b>" + expectedValue + "</b>",
						"<b>" + actualValue + "</b> should contains <b>" + expectedValue + "</b>",
						"Actual text <b>" + actualValue + "</b>");
			}

			// step5 close the connection object
			con.close();

		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Failed to get data from DB", "Failed to get data from DB",
					"Failed to get data from DB" + "</b>" + e.getMessage());
			Demo1.logger.error(e);
		}

	}

	public static void storeEffectiveScheduledDate(String dateAlreadyStoredVariable, String finalDateFormat,
			String monthDaysStringLocator, String scheduledDaysCount) {
		String updatedDate = "";
		int receivedDaysCount = Integer.parseInt(scheduledDaysCount);
		int pendingDaysInFirstMonth = 0;
		String updatedMonthDaysStringLocator = "";

		try {

			String storedDate = "";
			if (dateAlreadyStoredVariable.contains("auto@")) {
				String runTimeVariableName = dateAlreadyStoredVariable.replace("auto@", "");
				runTimeVariableName = runTimeVariableName.substring(0, runTimeVariableName.length() - 1);

				storedDate = StoreText.txtAndVal.get(runTimeVariableName);
				System.out.println("STORED DATE RECEIVED:::" + storedDate);
			} else {
				// runtime variable is not propery given
				System.out.println("Runtime variable name was not given properly.");
			}

			SimpleDateFormat ft = new SimpleDateFormat("yyyyMMdd");
			Date formattedDate = ft.parse(storedDate);

			Calendar c = Calendar.getInstance();
			c.setTime(formattedDate);
			System.out.println("DATE SET:::" + c.getTime());

			int dayOfMonth = c.get(Calendar.DAY_OF_MONTH);
			System.out.println("DAY:::" + dayOfMonth);

			int month = c.get(Calendar.MONTH) + 1;
			System.out.println("MONTH:::" + String.format("%02d", month));

			int daysToBeAddedToGetScheduleDate = 0;

			boolean found = false;
			boolean sameMonth = true;

			int neededDays = -1;
			int daysPending = -1;

			do {
				// identifying no of days in the month
				daysPending++;

				updatedMonthDaysStringLocator = monthDaysStringLocator.replace("MONTH-INDEX",
						String.format("%02d", month));

				System.out.println("LOCATOR UPDATED:::" + updatedMonthDaysStringLocator);

				By monthDaysStringElement = Reuse.GetLocator(updatedMonthDaysStringLocator);

				Reuse.waitForTextToAppear(monthDaysStringElement);
				String monthDaysString = Demo1.driver.findElement(monthDaysStringElement).getText();
				if (monthDaysString != null & monthDaysString.trim().isEmpty()) {
					monthDaysString = Demo1.driver.findElement(monthDaysStringElement).getAttribute("value");
					if (monthDaysString == null) {
						monthDaysString = "";
					}
				}
				monthDaysString = escapeHtml3(monthDaysString);

				// identifying no of X days in the month
				int totalNoOfDaysOfMonth = 31;
				int xCount = 0;
				if (monthDaysString.contains("X")) {
					for (int ind = monthDaysString.length() - 1; ind >= 0; ind--) {
						if (monthDaysString.toCharArray()[ind] == 'X') {
							xCount++;
						} else {
							break;
						}
					}
				}
				totalNoOfDaysOfMonth = totalNoOfDaysOfMonth - xCount;

				// verifying if working date is available in current month
				int addedDays = dayOfMonth + Integer.parseInt(scheduledDaysCount);
				System.out.println("ADDED DAYS:::" + addedDays);

				if (addedDays > totalNoOfDaysOfMonth) {
					if (daysPending == 0) {
						pendingDaysInFirstMonth = pendingDaysInFirstMonth + Math.abs(totalNoOfDaysOfMonth - dayOfMonth);
					} else {
						pendingDaysInFirstMonth = pendingDaysInFirstMonth + totalNoOfDaysOfMonth;
					}

					sameMonth = false;
					dayOfMonth = addedDays - totalNoOfDaysOfMonth;
					month++;
					System.out.println("MONTH INCREASED:::" + month);
					scheduledDaysCount = "0";

				} else {

					neededDays = -1;
					for (int ind = addedDays; ind <= 31; ind++) {
						neededDays++;
						if (monthDaysString.toCharArray()[(ind - 1)] == 'W') {
							found = true;
							break;
						}
					}

					if (found) {

						daysToBeAddedToGetScheduleDate = addedDays + neededDays;
						break;
					} else { // if working day is not found from the current
						// month

						month++;
						System.out.println("MONTH INCREASED:::" + month);
						daysToBeAddedToGetScheduleDate = 0;
						scheduledDaysCount = "1";
						dayOfMonth = 0;
						sameMonth = false;
					}
				}

			} while (!found);

			if (month > (c.get(Calendar.MONTH) + 1)) {

				c.add(Calendar.MONTH, month - (c.get(Calendar.MONTH) + 1));
				c.set(Calendar.DAY_OF_MONTH, daysToBeAddedToGetScheduleDate);
			} else {
				c.set(Calendar.DAY_OF_MONTH, daysToBeAddedToGetScheduleDate);
			}

			// Date after adding/subtracting the days to the given date
			/* ft = new SimpleDateFormat("yyyyMMdd"); */
			ft = new SimpleDateFormat(finalDateFormat);
			updatedDate = ft.format(c.getTime());

			if (!sameMonth) {
				daysToBeAddedToGetScheduleDate = daysToBeAddedToGetScheduleDate + pendingDaysInFirstMonth;
			} else {
				daysToBeAddedToGetScheduleDate = receivedDaysCount + neededDays;
			}

			System.out.println("DATE AFTER ADDING SCHEDULED DAYS COUNT:::" + updatedDate);
			System.out.println("NO OF DAYS ADDED TO GET SCHEDULED DATE:::" + daysToBeAddedToGetScheduleDate);

			boolean available = true;
			int ind = 1;
			do {
				if (null == StoreText.txtAndVal.get("SCHEDULED_DATE" + ind)) {

					available = false;
					StoreText.txtAndVal.put("SCHEDULED_DATE" + ind, updatedDate);
					StoreText.txtAndVal.put("SCHEDULED_DAYS_COUNT" + ind,
							Integer.toString(daysToBeAddedToGetScheduleDate));

					System.out.println("SCHEDULED DATE VARIABLE:::" + "SCHEDULED_DATE" + ind);
					System.out.println("SCHEDULED DAYS COUNT VARIABLE:::" + "SCHEDULED_DAYS_COUNT" + ind);

				} else {

					ind++;
					/* System.out.println("DAYS VARIABLE:::" + ind); */
				}

			} while (available);

		} catch (Exception e) {
			Reuse.log(e);

			Demo1.logger.error("error method storeManipulatedApplicationDate in " + e.getMessage());
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Store Date value <b>" + updatedDate + "</b> contains",
					"Should be contains <b>" + updatedDate + "</b>",
					"Unable to locate <b>" + updatedMonthDaysStringLocator + "</b> element");
		}
	}

	/**
	 * Compares the expected text with actual
	 */
	public static void storeManipulatedApplicationDate(final By by, String dateFormat, String elementName,
			String daysCount, String runTimeVariableName) {

		String formattedDate = null;

		try {
			Reuse.waitForTextToAppear(by);
			String actualText = Demo1.driver.findElement(by).getText();
			if (actualText != null & actualText.trim().isEmpty()) {
				actualText = Demo1.driver.findElement(by).getAttribute("value");
				if (actualText == null) {
					actualText = "";
				}
			}
			actualText = escapeHtml3(actualText);

			System.out.println("ACTUAL DATE:::" + actualText);

			formattedDate = manipulateDateValue(dateFormat, actualText, daysCount);

			if (!StoreText.isMapInitialized) {
				StoreText.txtAndVal = new HashMap<>();
				StoreText.isMapInitialized = true;
			}

			if (runTimeVariableName.startsWith("auto@")) {
				runTimeVariableName = runTimeVariableName.replace("auto@", "");
				runTimeVariableName = runTimeVariableName.substring(0, runTimeVariableName.length() - 1);
				System.out.println("RUNTIME VARIABLE PARSED:::" + runTimeVariableName);
			}

			if (!StoreText.txtAndVal.containsKey(runTimeVariableName)) {

				StoreText.txtAndVal.put(runTimeVariableName, formattedDate);
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2,
						"Store text <b>" + formattedDate + "</b> in <b>" + runTimeVariableName + "</b> variable",
						"Text <b>" + formattedDate + "</b> should be stored in <b>" + runTimeVariableName
								+ "</b> variable",
						"Stored");

			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2,
						"Store text <b>" + formattedDate + "</b> in <b>" + runTimeVariableName + "</b> variable",
						"Text <b>" + formattedDate + "</b> should be stored in <b>" + runTimeVariableName
								+ "</b> variable",
						"Provided variable <b>" + runTimeVariableName
								+ " already exist. Kindly provide some other variable name.");
			}
		} catch (Exception e) {
			Reuse.log(e);

			Demo1.logger.error("error method storeManipulatedApplicationDate in " + e.getMessage());
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Store Date value <b>" + formattedDate + "</b> contains",
					"Should be contains <b>" + formattedDate + "</b>",
					"Unable to locate <b>" + elementName + "</b> element");
		}
	}

	public static String manipulateDateValue(String dtFormat, String dateValue, String daysCount) {
		try {
			// first parsing the date value in the defined format dd MMM yyyy
			// (17 APR 2018)
			SimpleDateFormat ft = new SimpleDateFormat("dd MMM yyyy");
			String formattedDate = ft.format(new Date(dateValue)); // changes
			// made on
			// 24-MAY-2018

			System.out.println("ACTUAL DATE AFTER PARSING:::" + formattedDate);

			// setting the date format to the user request format
			ft = new SimpleDateFormat(dtFormat);

			Calendar c = Calendar.getInstance();
			c.setTime(new Date(formattedDate));

			/*
			 * try{ //Setting the date to the given date c.setTime(ft.parse(dateValue));
			 * }catch(ParseException e){ e.printStackTrace(); }
			 */

			if (Integer.parseInt(daysCount) != 0) { // this is to avoid adding
				// backdate if value is 0
				c.add(Calendar.DAY_OF_MONTH, Integer.parseInt(daysCount));
			}

			// Date after adding/subtracting the days to the given date
			String updatedDate = ft.format(c.getTime());

			// Displaying the new Date after addition of Days
			System.out.println("Date after Manipulation:::" + updatedDate);

			return updatedDate;
		} catch (Exception e) {
			Reuse.log(e);
			return null;
		}
	}

	public static void JavaScriptZoom(String value) {
		try {

			JavascriptExecutor executor = (JavascriptExecutor) Demo1.driver;

			executor.executeScript("document.body.style.zoom='" + value + "%'");

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "zoom on page", "zoom should successful", "zoom is successfully");

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "zoom on page", "zoom should successful", "zoom is not successfully");
		}

	}

	public static void MOB_ClickIf_Element(By by, String elementType, String elementName) {

		try {

			MOB_waitUntil(by);

			if (Demo1.driver1.findElement(by).isEnabled() && Demo1.driver1.findElement(by).isEnabled()) {
				Demo1.driver1.findElement(by).click();

				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Click <b>" + elementName + " " + elementType + "</b>",
						"<b>" + elementName + " " + elementType + "</b> should be Clicked",
						"Clicked on <b>" + elementName + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
		}
	}

	public static void MOB_Click_Element(By by, String elementType, String elementName) {

		try {
			// Synchronize.defaultAjaxSync();
			WebDriverWait wait = new WebDriverWait(Demo1.driver1, Duration.ofSeconds(Config.mobTimeout));
			wait.until(ExpectedConditions.elementToBeClickable(by));
			// Thread.sleep(2000);

			Demo1.driver1.findElement(by).click();

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Click <b>" + elementName + " " + elementType + "</b>",
					"<b>" + elementName + " " + elementType + "</b> should be Clicked",
					"Clicked on <b>" + elementName + "</b>");

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Click " + elementType + " <b>" + elementName + "</b>",
					"<b>" + elementName + "</b> " + elementType + " should be clicked", e.getMessage());
		}
	}

	public static void MOB_ScrollDown(String elementType, String elementName) {

		try {

			// MOB_waitUntil(by);

			Dimension size = Demo1.driver1.manage().window().getSize();
			int x = size.width / 2;
			int starty = (int) (size.height * 0.60);
			int endy = (int) (size.height * 0.10);
			TouchAction ta = new TouchAction(Demo1.driver1);
			ta.press(PointOption.point(x, starty)).waitAction().moveTo(PointOption.point(x, endy)).release().perform();

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Scroll  <b>" + elementName + " " + elementType + "</b>",
					"<b>" + elementName + " " + elementType + "</b> should be Scrolled",
					"Scrolled on <b>" + elementName + "</b>");

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Scroll  <b>" + elementName + " " + elementType + "</b>",
					"<b>" + elementName + " " + elementType + "</b> should be Scrolled",
					"Not Scrolled on <b>" + elementName + "</b>");
		}
	}

	public static void MOB_waitUntil(By by) {

		try {

			Wait<AndroidDriver> wait = new FluentWait<AndroidDriver>(Demo1.driver1)
					.withTimeout(Duration.ofSeconds(Config.TIME_OUT)).pollingEvery(Duration.ofMillis(600))
					.ignoring(NoSuchElementException.class);

			wait.until(ExpectedConditions.presenceOfElementLocated(by));

		} catch (Exception e) {
			// Log.error("Unable to Find widget :: " + objectIdentifierKey);
			e.printStackTrace();
		}

	}

	public static void MOB_DriverQuit() {

		try {

			if (Demo1.driver1 != null) {

				System.out.println("****Resetting App for Android******");
				Demo1.driver1.quit();
			}

		} catch (Exception exception) {
			exception.printStackTrace();
		}

	}

	public static void MOB_IsElementPresent(By by, String elementType, String elementName) {

		boolean flag = false;
		try {

			MOB_waitUntil(by);

			WebElement Element = Demo1.driver1.findElement(by);
			if (Element.isDisplayed()) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, " Verify Element ", "Element should be successful", "Element  is successful");

			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, " Verify Element ", "Element should be successful", "Element  is not successful");
			}

		} catch (Exception exception) {
			// Log.error("Unable to Find widget :: " + objectIdentifierKey);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, " Verify Element ", "Element should be successful", "Element  is not successful");
		}

	}

	public static void MOB_IsElementEnabled(By by, String elementType, String elementName) {

		boolean flag = false;
		try {

			MOB_waitUntil(by);

			WebElement Element = Demo1.driver1.findElement(by);
			if (Element.isEnabled()) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, " Verify Element ", "Element should be enabled", "Element  is enabled");

			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, " Verify Element ", "Element should be enabled", "Element  is not enabled");
			}

		} catch (Exception exception) {
			// Log.error("Unable to Find widget :: " + objectIdentifierKey);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, " Verify Element ", "Element should be enabled", "Element  is not enabled");
		}

	}

	public static void MOB_IsElementSelected(By by, String elementType, String elementName) {

		boolean flag = false;
		try {

			MOB_waitUntil(by);

			WebElement Element = Demo1.driver1.findElement(by);
			if (Element.isSelected()) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, " Verify Element ", "Element should be selected", "Element  is selected");

			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, " Verify Element ", "Element should be selected", "Element  is not selected");
			}

		} catch (Exception exception) {
			// Log.error("Unable to Find widget :: " + objectIdentifierKey);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, " Verify Element ", "Element should be selected", "Element  is not selected");
		}

	}

	public static void MOB_IsElementNotPresent(By by, String elementType, String elementName) {

		try {

			WebElement Element = Demo1.driver1.findElement(by);
			if (Element.isDisplayed()) {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, " Verify Element ", "Element should be successful", "Element  is not successful");

			} else {

				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, " Verify Element ", "Element should be successful", "Element  is successful");

			}

		} catch (Exception exception) {
			// Log.error("Unable to Find widget :: " + objectIdentifierKey);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, " Verify Element ", "Element should be successful", "Element  is successful");
		}

	}

	public static void MOB_IsElementNotEnabled(By by, String elementType, String elementName) {

		try {

			WebElement Element = Demo1.driver1.findElement(by);
			if (Element.isEnabled()) {

				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, " Verify Element ", "Element should be enabled", "Element  is not enabled");

			} else {

				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, " Verify Element ", "Element should be enabled", "Element  is enabled");
			}

		} catch (Exception exception) {
			// Log.error("Unable to Find widget :: " + objectIdentifierKey);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, " Verify Element ", "Element should be enabled", "Element  is enabled");
		}

	}

	public static void MOB_IsElementNotSelected(By by, String elementType, String elementName) {

		try {

			WebElement Element = Demo1.driver1.findElement(by);
			if (Element.isSelected()) {

				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, " Verify Element ", "Element should be not selected", "Element  is  selected");

			} else {

				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, " Verify Element ", "Element should be not selected", "Element  is not selected");

			}

		} catch (Exception exception) {
			// Log.error("Unable to Find widget :: " + objectIdentifierKey);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, " Verify Element ", "Element should be not selected", "Element  is  selected");
		}

	}

	public static void MOB_LaunchApp() {
		try {
			URL url = new URL("http", Config.mobileServer, Config.mobilePort, "/wd/hub");

			DesiredCapabilities capabilities = new DesiredCapabilities();

			capabilities.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
			capabilities.setCapability("device", "Android");
			capabilities.setCapability("platformName", "Android");
			capabilities.setCapability("deviceName", Config.deviceName);
			capabilities.setCapability("automationName", "UiAutomator2");
			capabilities.setCapability(CapabilityType.BROWSER_NAME, "");

			// capabilities.setCapability("device ID", "emulator-5554");
			capabilities.setCapability(CapabilityType.BROWSER_VERSION, Config.deviceVersion);
			capabilities.setCapability(CapabilityType.PLATFORM_NAME, Config.platform);
			// capabilities.setCapability("app", app.getAbsolutePath());
			// //app.getAbsolutePath()
			// Here we mention the app's package name, to find the package name
			// we have to convert .apk file into java class files
			capabilities.setCapability("appPackage", Config.android_appPackageName);
			// Here we mention the activity name, which is invoked initially as
			// app's first page.
			capabilities.setCapability("appActivity", Config.android_appActivityName);

			Demo1.driver1 = new AndroidDriver(url, capabilities);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "LaunchApp", "LaunchApp should be successful", "Application  is successful");

		} catch (Exception e) {
			Reuse.log(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "LaunchApp", "LaunchApp should be successful", "Application  is not successful");
			Demo1.logger.error(e);
		}
	}

	public static void MOB_TextBox_InputText(By by, String text, String textBoxName) {
		try {

			WebDriverWait wait = new WebDriverWait(Demo1.driver1, Duration.ofSeconds(Config.mobTimeout));
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));

			// Focus(Demo1.driver1.findElement(by));
			Demo1.driver1.findElement(by).clear();
			// Demo1.driver1.findElement(By.xpath("//android.widget.EditText[@resource-id='C2__C1__USER_NAME']")).sendKeys("Bilal");
			Demo1.driver1.findElement(by).sendKeys(text);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Input text in to the field <b>" + textBoxName + "</b>",
					"Input text <b>" + text + "</b>", "Text <b>" + text + "</b> entered Successfully");

		} catch (Exception e) {
			Reuse.log(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Input text in to the field <b>" + textBoxName + "</b>",
					"Input text <b>" + text + "</b>", "Unbale to locate textbox <b>" + textBoxName + "</b>");
			Demo1.logger.error(e);
		}
	}

	public static void MOB_Screen_Orientation_Lan() {
		try {

			Thread.sleep(2000);

			Demo1.driver1.rotate(ScreenOrientation.LANDSCAPE);

			ScreenOrientation orientation = Demo1.driver1.getOrientation();

			String orien = orientation.toString();
			System.out.println(orien);

			if (orien.equalsIgnoreCase("LANDSCAPE")) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Screen orientation to be LANDSCAPE", "Screen orientation should be LANDSCAPE",
						"Screen orientation LANDSCAPE Successfully");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Screen orientation to be LANDSCAPE", "Screen orientation should be LANDSCAPE ",
						"Screen orientation has not placed to be LANDSCAPE ");
			}
		} catch (Exception e) {
			Reuse.log(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Screen orientation to be LANDSCAPE", "Screen orientation should be LANDSCAPE ",
					"Screen orientation has not placed to be LANDSCAPE ");
			Demo1.logger.error(e);
		}
	}

	public static void MOB_Screen_Orientation_Pot() {
		try {

			Thread.sleep(2000);

			Demo1.driver1.rotate(ScreenOrientation.PORTRAIT);

			ScreenOrientation orientation = Demo1.driver1.getOrientation();

			String orien = orientation.toString();
			System.out.println(orien);

			if (orien.equalsIgnoreCase("PORTRAIT")) {

				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Screen orientation to be PORTRAIT", "Screen orientation should be PORTRAIT",
						"Screen orientation PORTRAIT Successfully");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Screen orientation to be PORTRAIT", "Screen orientation should be PORTRAIT ",
						"Screen orientation has not placed to be PORTRAIT ");

			}

		} catch (Exception e) {
			Reuse.log(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Screen orientation to be PORTRAIT", "Screen orientation should be PORTRAIT ",
					"Screen orientation has not placed to be PORTRAIT ");
			Demo1.logger.error(e);
		}
	}

	public static void MOB_AppInstallation(String path) {
		try {

			Thread.sleep(2000);

			Demo1.driver1.installApp(path);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Application installation", "Application installation should be from" + path + "",
					"Application installation is successful");

		} catch (Exception e) {
			Reuse.log(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Application installation", "Application installation should be from" + path + "",
					"Application installation is unsuccessful");
			Demo1.logger.error(e);
		}
	}

	public static void MOB_ToggleWifi() {
		try {

			Thread.sleep(2000);

			Demo1.driver1.toggleWifi();

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Application toggleWifi", "Application toggleWifi should be happen",
					"Application installation is toggleWifi successful");

		} catch (Exception e) {
			Reuse.log(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Application toggleWifi", "Application toggleWifi should be happen",
					"Application installation is toggleWifi unsuccessful");
			Demo1.logger.error(e);
		}
	}

	public static Boolean MOB_waitForTextToAppear(final By locator) {

		Wait<AndroidDriver> wait = new FluentWait<AndroidDriver>(Demo1.driver1)
				.withTimeout(Duration.ofSeconds(Config.TIME_OUT)).pollingEvery(Duration.ofMillis(600))
				.ignoring(NoSuchElementException.class);

		Boolean element = false;
		try {
			element = wait.until(new Function<AndroidDriver, Boolean>() {

				@Override
				public Boolean apply(AndroidDriver driver1) {
					String s = Demo1.driver1.findElement(locator).getText();
					if (s == null || (s != null & s.trim().isEmpty())) {
						s = "";
					}
					return (!s.trim().isEmpty());
				}
			});
		} catch (Exception e) {
			Reuse.log(e);

		}
		return element;
	}

	/**
	 * Compares the expected text with actual
	 */
	public static void MOB_Verify_TextPresent(final By by, String expectedText, String elementName) {
		try {
			waitForTextToAppear(by);
			String actualText = Demo1.driver1.findElement(by).getText();
			if (actualText != null & actualText.trim().isEmpty()) {
				actualText = Demo1.driver1.findElement(by).getAttribute("value");
				if (actualText == null) {
					actualText = "";
				}
			}
			actualText = escapeHtml3(actualText);
			Reuse.log("actualText :" + actualText);

			System.out.println("EXPECTED TEXT:::" + expectedText);

			if (expectedText.contains("auto@")) {
				expectedText = expectedText.substring(expectedText.indexOf("auto@") + "auto@".length(),
						expectedText.length() - 1);

				System.out.println("RUNTIME VARIABLE:::" + expectedText);

				expectedText = StoreText.txtAndVal.get(expectedText);
				System.out.println("EXPECTED TEXT UPDATED:::" + expectedText);
			}

			Reuse.log("expectedText :" + expectedText);

			if (expectedText.toUpperCase().contentEquals("EMPTY") || expectedText.isEmpty()) {

				if (actualText.isEmpty()) {
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Verifying element <b>" + elementName + "</b> to be empty",
							"Element should be empty", "Element is empty");
				} else {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Verifying element <b>" + elementName + "</b> to be empty",
							"Element should be empty", "Element is not empty");
				}

			} else if (actualText.toUpperCase().contentEquals(expectedText.toUpperCase())) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2,
						"Verify text <b>" + expectedText + "</b> present for the element <b>" + elementName + "</b>",
						"<b>" + expectedText + "</b> text should be present", "<b>" + actualText + "</b> present");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> present",
						"<b>" + expectedText + "</b> text should be present", "Actual text <b>" + actualText + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);

			Demo1.logger.error("error method Verify_TextPresent in " + e.getClass().getName());
			Demo1.logger.error(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> present",
					"<b>" + expectedText + "</b> text should be present",
					"Unable to locate <b>" + elementName + "</b>");
		}
	}

	public static void MOB_Verify_TextPresent_IgnoreCase(final By by, String expectedText, String elementName) {
		try {
			String actualText = Demo1.driver1.findElement(by).getText();
			if (actualText != null & actualText.trim().isEmpty()) {
				actualText = Demo1.driver1.findElement(by).getAttribute("value");
				if (actualText == null) {
					actualText = "";
				}
			}
			actualText = escapeHtml3(actualText);
			Reuse.log("actualText :" + actualText);
			Reuse.log("expectedText :" + expectedText);
			if (actualText.equalsIgnoreCase(expectedText)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2,
						"Verify text <b>" + expectedText + "</b> present for the element <b>" + elementName + "</b>",
						"<b>" + expectedText + "</b> text should be present", "<b>" + actualText + "</b> present");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> present",
						"<b>" + expectedText + "</b> text should be present", "Actual text <b>" + actualText + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);

			Demo1.logger.error("error method Verify_TextPresent in " + e.getClass().getName());
			Demo1.logger.error(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> present",
					"<b>" + expectedText + "</b> text should be present",
					"Unable to locate <b>" + elementName + "</b>");
		}
	}

	/**
	 * Compares the expected text with actual
	 */

	public static void MOB_Verify_TextContains(final By by, String expectedText, String elementName) {
		try {
			Reuse.waitForTextToAppear(by);
			String actualText = Demo1.driver1.findElement(by).getText();
			if (actualText != null & actualText.trim().isEmpty()) {
				actualText = Demo1.driver1.findElement(by).getAttribute("value");
				if (actualText == null) {
					actualText = "";
				}
			}
			actualText = escapeHtml3(actualText);

			if (expectedText.contains("auto@")) {
				String runTimeVariableName = expectedText.replace("auto@", "");
				runTimeVariableName = runTimeVariableName.substring(0, runTimeVariableName.length() - 1);

				expectedText = StoreText.txtAndVal.get(runTimeVariableName);
			}

			if (actualText.toUpperCase().contains(expectedText.toUpperCase())) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify text <b>" + actualText + "</b> contains <b>" + expectedText + "</b>",
						"<b>" + actualText + "</b> should contains <b>" + expectedText + "</b>",
						"<b>" + actualText + "</b> text contains <b>" + expectedText + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + actualText + "</b> contains <b>" + expectedText + "</b>",
						"<b>" + actualText + "</b> should contains <b>" + expectedText + "</b>",
						"Actual text <b>" + actualText + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);

			Demo1.logger.error("error method Verify_TextContains in " + e.getMessage());
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> contains",
					"Should be contains <b>" + expectedText + "</b>",
					"Unable to locate <b>" + elementName + "</b> element");
		}
	}

	public static void MOB_Verify_TextNotContains(final By by, String expectedText, String elementName) {
		try {
			String actualText = Demo1.driver1.findElement(by).getText();
			if (actualText != null & actualText.trim().isEmpty()) {
				actualText = Demo1.driver1.findElement(by).getAttribute("value");
				if (actualText == null) {
					actualText = "";
				}
			}
			actualText = escapeHtml3(actualText);
			if (!actualText.contains(expectedText)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify text <b>" + actualText + "</b> not contains <b>" + expectedText + "</b>",
						"<b>" + actualText + "</b> should not contains <b>" + expectedText + "</b>",
						"Actual text <b>" + actualText + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + actualText + "</b> not contains <b>" + expectedText + "</b>",
						"<b>" + actualText + "</b> should not contains <b>" + expectedText + "</b>",
						"Actual text <b>" + actualText + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);

			Demo1.logger.error("error method Verify_TextNotContains in " + e.getClass().getName());
			Demo1.logger.error(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify text <b>" + expectedText + "</b> not contains",
					"Should not be contains <b>" + expectedText + "</b>",
					"Unable to locate <b>" + elementName + "</b> element");
		}
	}

	/**
	 * Compares the expected text with actual
	 */
	public static void MOB_Verify_TextNotPresent(final By by, String text, String elementName) {
		try {
			String actualText = Demo1.driver1.findElement(by).getText();
			if (actualText != null & actualText.trim().isEmpty()) {
				actualText = Demo1.driver1.findElement(by).getAttribute("value");
				if (actualText == null) {
					actualText = "";
				}
			}
			actualText = escapeHtml3(actualText);
			if (!actualText.contains(text)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify text <b>" + text + "</b> not present",
						"<b>" + text + "</b> should not be present", "Actual text <b>" + actualText + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify text <b>" + text + "</b> not present",
						"<b>" + text + "</b> should not be present", "Actual text <b>" + actualText + "</b>");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "False";
			Demo1.ReportStep(2, "Verify text <b>" + text + "</b> not present",
					"<b>" + text + "</b> should not be present", "Unable to locate <b>" + elementName + "</b>");
		}
	}

	public static void MOB_ElementFocused(By by, String elementName, String elementType) {
		try {
			WebElement element = Demo1.driver1.findElement(by);
			if (element.equals(Demo1.driver1.switchTo().activeElement())) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Check <b>" + elementName + "</b> " + elementType + " focused",
						"<b>" + elementName + "</b> should be focused", "Focused");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check <b>" + elementName + "</b> " + elementType + " focused",
						"<b>" + elementName + "</b> should be focused", "Not focused");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check <b>" + elementName + "</b> " + elementType + " focused",
					"<b>" + elementName + "</b> should be focused", e.getMessage());
		}
	}

	public static void MOB_ElementNotFocused(By by, String elementName, String elementType) {
		try {
			WebElement element = Demo1.driver1.findElement(by);

			if (element.equals(Demo1.driver1.switchTo().activeElement())) {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check <b>" + elementName + "</b> " + elementType + " not focused",
						"<b>" + elementName + "</b> should not be focused", "Focused");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check <b>" + elementName + "</b> " + elementType + " not focused",
						"<b>" + elementName + "</b> should not be focused", "Not focused");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check <b>" + elementName + "</b> " + elementType + " not focused",
					"<b>" + elementName + "</b> should not be focused", e.getMessage());
		}
	}

	public static void MOB_swipingRightLeft() {
		try {
			Dimension size = Demo1.driver1.manage().window().getSize();
			int startx = (int) (size.width * 0.70);
			int endx = (int) (size.width * 0.30);
			int y = size.height / 2;

			System.out.println("startx = " + startx + " ,endx = " + endx + " , starty = " + y);

			TouchAction ta = new TouchAction(Demo1.driver1);
			ta.press(PointOption.point(startx, y)).waitAction().moveTo(PointOption.point(endx, y)).release().perform();

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To swipe mobile screen from right to left", "The screen should be swiped sucuessfully",
					"The screen is swiped succesfuly");

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To swipe mobile screen from right to left", "The screen should be swiped sucessfully",
					e.getMessage());
		}
	}

	public static void MOB_swipingLeftRight() {
		try {

			Dimension size = Demo1.driver1.manage().window().getSize();
			int startx = (int) (size.width * 0.70);
			int endx = (int) (size.width * 0.30);
			int y = size.height / 2;

			System.out.println("startx = " + startx + " ,endx = " + endx + " , starty = " + y);

			TouchAction ta = new TouchAction(Demo1.driver1);
			ta.press(PointOption.point(endx, y)).waitAction().moveTo(PointOption.point(startx, y)).release().perform();

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To swipe mobile screen from right to left", "The screen should be swiped sucuessfully",
					"The screen is swiped succesfuly");

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To swipe mobile screen from right to left", "The screen should be swiped sucessfully",
					e.getMessage());
		}
	}

	public static void MOB_swipingEleLeftRight(String resourceId, String text) {
		try {

			WebElement el = Demo1.driver
					.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().resourceId(\""
							+ resourceId + "\")).setAsVerticalList().scrollIntoView(" + "new UiSelector().text(\""
							+ text + "\"));"));

			/*
			 * Dimension size = Demo1.driver1.manage().window().getSize(); int startx =
			 * (int) (size.width * 0.70); int endx = (int) (size.width * 0.30); int y =
			 * (int) (size.height / 2);
			 *
			 * System.out.println("startx = " + startx + " ,endx = " + endx + " , starty = "
			 * + y);
			 *
			 * TouchAction ta = new TouchAction(Demo1.driver1);
			 * ta.press(PointOption.point(endx,
			 * y)).waitAction().moveTo(PointOption.point(startx, y)).release().perform();
			 */

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To swipe mobile screen from right to left", "The screen should be swiped sucuessfully",
					"The screen is swiped succesfuly");

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To swipe mobile screen from right to left", "The screen should be swiped sucessfully",
					e.getMessage());
		}
	}

	public static void SearchTextInFile(String pathFolder, String fileStartWith, String expectedString)
			throws IOException {

		StringBuilder sb = new StringBuilder();
		boolean flag = false;
		boolean totalFlag = false;
		int count = 0;
		int lineNo = 0;

		// File folder = new
		// File("D:\\Temenos9\\UTP-DEV-RET-2020.09.18-01-699-saf-retailsuite-developer-s08\\Temenos\\logs");
		File folder = new File(pathFolder);
		File[] listOfFiles = folder.listFiles();

		for (File file : listOfFiles) {
			if (file.isFile()) {

				if (file.getName().startsWith(fileStartWith)) {
					System.out.println(file.getName());

					sb.append("------------" + file.getName() + "------------ \n");

					// searchText(file.getAbsolutePath(),expectedString);

					Scanner sc2 = new Scanner(new FileInputStream(file.getAbsolutePath()));
					while (sc2.hasNextLine()) {

						String line = sc2.nextLine();
						// System.out.println(line);
						// if(line.indexOf(expectedText)!=-1) {
						if (line.contains(expectedString)) {
							flag = true;
							count = count + 1;
							System.out.println("In line no ::::" + lineNo);
							sb.append("In line no ::::" + lineNo + "\n");
							// System.out.println("The actual line ::::"+line);
							sb.append("The actual line ::::" + line + "\n");
						}
						lineNo++;
					}

					if (flag) {
						totalFlag = true;
						System.out.println("File contains the specified word");
						System.out.println("Number of occurrences is: " + count);

						sb.append("File contains the specified word \n");
						sb.append("Number of occurrences is: " + count + "\n");
						sb.append("======================================================================\n");

					} else {
						System.out.println("File does not contain the specified word in " + file.getAbsolutePath());
						sb.append("File does not contain the specified word in" + file.getAbsolutePath() + "\n");
						sb.append("======================================================================\n");
					}
				}
			}
		}

		if (totalFlag) {

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Verify the text is occurred in the file", "The text should be occurred in the file",
					"The text is occurred in the file, For more details refer :" + Demo1.gbResultFolderName
							+ "//SearchResult.txt");

		} else {

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify the text is occurred in the file", "The text should be occurred in the file",
					"The text is not occurred in the file, For more details refer :" + Demo1.gbResultFolderName
							+ "//SearchResult.txt");

		}

		try (FileOutputStream oS = new FileOutputStream(new File(Demo1.gbResultFolderName + "//SearchResult.txt"))) {
			oS.write(sb.toString().getBytes());
			oS.flush();
			oS.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void SearchErrorInFile(String pathFolder, String fileStartWith, String expectedString)
			throws IOException {

		StringBuilder sb = new StringBuilder();
		boolean flag = false;
		boolean totalFlag = false;
		int count = 0;
		int lineNo = 0;

		// File folder = new
		// File("D:\\Temenos9\\UTP-DEV-RET-2020.09.18-01-699-saf-retailsuite-developer-s08\\Temenos\\logs");
		File folder = new File(pathFolder);
		File[] listOfFiles = folder.listFiles();

		for (File file : listOfFiles) {
			if (file.isFile()) {

				if (file.getName().startsWith(fileStartWith)) {
					System.out.println(file.getName());

					sb.append("------------" + file.getName() + "------------ \n");

					// searchText(file.getAbsolutePath(),expectedString);

					Scanner sc2 = new Scanner(new FileInputStream(file.getAbsolutePath()));
					while (sc2.hasNextLine()) {

						String line = sc2.nextLine();
						// System.out.println(line);
						// if(line.indexOf(expectedText)!=-1) {
						if (line.contains(expectedString)) {
							flag = true;
							count = count + 1;
							System.out.println("In line no ::::" + lineNo);
							sb.append("In line no ::::" + lineNo + "\n");
							// System.out.println("The actual line ::::"+line);
							sb.append("The actual line ::::" + line + "\n");
						}
						lineNo++;
					}

					if (totalFlag) {

						Demo1.gbTestCaseStatus = "Pass";
						Demo1.ReportStep(2, "Verify the text is occurred in the file",
								"The text should be occurred in the file",
								"The text is occured in the file, For more details refer :" + Demo1.gbResultFolderName
										+ "//SearchResult.txt");

					} else {

						Demo1.gbTestCaseStatus = "Fail";
						Demo1.ReportStep(2, "Verify the text is occurred in the file",
								"The text should be occurred in the file",
								"The text is not occured in the file, For more details refer :"
										+ Demo1.gbResultFolderName + "//SearchResult.txt");

					}
				}
			}
		}

		if (totalFlag) {

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify the text is occured in the file", "The text should not occured in the file",
					"The text is occured in the file, For more details refer :" + Demo1.gbResultFolderName
							+ "//SearchResult.txt");

		} else {

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Verify the text is occured in the file", "The text should not occured in the file",
					"The text is not occured in the file, For more details refer :" + Demo1.gbResultFolderName
							+ "//SearchResult.txt");

		}

		try (FileOutputStream oS = new FileOutputStream(new File(Demo1.gbResultFolderName + "//SearchResult.txt"))) {
			oS.write(sb.toString().getBytes());
			oS.flush();
			oS.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void runPaymentsRoutine(String routineName, String arg1, String arg2, String arg3, String arg4,
			String applicationName, String ofsMessage, String outputParams, String routineValue) {
		try {

			String[] responseArray = batfileCall.main(new String[] { routineName, arg1, arg2, arg3, arg4 });
			System.out.println("EXECUTION RESPONSE:::" + responseArray);

			for (int i = 0; i <= responseArray.length - 1; i++) {
				System.out.println("response array list on " + i + ":::" + responseArray[i]);

			}

			String response[] = responseArray[responseArray.length - 1].split(",");

			for (int i = 0; i <= response.length - 1; i++) {
				System.out.println("response  list on " + i + ":::" + response[i]);

				try {
					ofsMessage = ofsMessage.replace(response[i].split(":")[0],
							response[i].split(":")[1].replace("$", "").replace("\\", ""));
				} catch (Exception e) {
//                    System.out.println(response[i].split(":")[0] + response[i].split(":")[1].replace("$", ""));
					// TODO Auto-generated catch block
					// Uncomment and replace with appropriate logger
					// LOGGER.error(e, e);
				}

				System.out.println(ofsMessage);

			}

			ExecuteComponent_ExecuteOFS(applicationName, ofsMessage, outputParams, routineValue);

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check execute ofs message<b>" + "</b> " + " ", "<b>" + "</b> should executed ",
					" not executed");
		}
	}

	public static void runPaymentsRoutine1(String routineName, String arg1, String arg2, String arg3, String arg4,
			String variableName) {
		try {

			String[] responseArray = batfileCall.main(new String[] { routineName, arg1, arg2, arg3, arg4 });
			System.out.println("EXECUTION RESPONSE:::" + responseArray);

			for (int i = 0; i <= responseArray.length - 1; i++) {
				System.out.println("response array list on " + i + ":::" + responseArray[i]);

			}

			String response[] = responseArray[responseArray.length - 1].split(",");

			for (int i = 0; i <= response.length - 1; i++) {
				System.out.println("response  list on " + i + ":::" + response[i]);

				try {
					int y = i + 1;

					String value = response[i].split(":")[1].replace("$", "").replace("\\", "");

					System.out.print(value + ",");

					Reuse.WriteProperties(variableName + "_" + y, value);

				} catch (Exception e) {
//                    System.out.println(response[i].split(":")[0] + response[i].split(":")[1].replace("$", ""));
					// TODO Auto-generated catch block
					// Uncomment and replace with appropriate logger
					// LOGGER.error(e, e);
				}

			}
//
//
//         ExecuteComponent_ExecuteOFS(applicationName, ofsMessage, outputParams, routineValue);
//

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check execute ofs message<b>" + "</b> " + " ", "<b>" + "</b> should executed ",
					" not executed");
		}
	}

	public static void testrunPaymentsRoutine(String routineName, String arg1, String arg2, String arg3,
			String applicationName, String ofsMessage, String outputParams, String routineValue) {
		try {

			String[] responseArray = batfileCall.main(new String[] { routineName, arg1, arg2, arg3 });
			System.out.println("EXECUTION RESPONSE:::" + responseArray);

			for (int i = 0; i <= responseArray.length - 1; i++) {
				System.out.println("response array list on " + i + ":::" + responseArray[i]);

			}

			String response[] = responseArray[responseArray.length - 1].split(",");

			for (int i = 0; i <= response.length - 1; i++) {
				System.out.println("response  list on " + i + ":::" + response[i]);

				ofsMessage = ofsMessage.replace(response[i].split(":")[0], response[i].split(":")[1]);

				System.out.println(ofsMessage);

			}

			ExecuteComponent_ExecuteOFS(applicationName, ofsMessage, outputParams, routineValue);

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check execute ofs message<b>" + "</b> " + " ", "<b>" + "</b> should executed ",
					" not executed");
		}
	}

	public static void TextIsAlphanum(By by, String elementType, String elementName) {
		try {
			String actualText = Demo1.driver.findElement(by).getText();

			if (StringUtils.isAlphanumeric(actualText)) {

				System.out.println("ActualText" + actualText);

				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify <b>" + elementType + " " + elementName + "</b> is AlphaNum",
						"" + elementName + " should be AlphaNum", "<b>" + actualText + "</b> AlphaNum");

			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify <b>" + elementType + " " + elementName + "</b> is AlphaNum",
						"" + elementName + " should be AlphaNum", "<b>" + actualText + "</b> AlphaNum");

			}

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify <b>" + elementType + " " + elementName + "</b> is AlphaNum",
					"" + elementName + " should be AlphaNum", "<b>" + elementName + "</b> AlphaNum");
		}
	}

	public static void TextIsGreater(By by, String expectedDigit, String elementName) {
		try {
			String actualText = Demo1.driver.findElement(by).getText();

			System.out.println("ActualText" + actualText);

			int actualDigit = Integer.parseInt(actualText);

			int expDigit = Integer.parseInt(expectedDigit);

			if (actualDigit > expDigit) {

				System.out.println("ActualDigit" + actualDigit);
				System.out.println("expDigit" + expDigit);

				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify <b>" + actualDigit + " greater than " + expDigit,
						"" + elementName + " should be greater ", "<b>" + actualText + "</b> is greater");

			} else {

				System.out.println("ActualDigit" + actualDigit);
				System.out.println("expDigit" + expDigit);

				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify <b>" + actualDigit + " greater than " + expDigit,
						"" + elementName + " should be greater ", "<b>" + actualText + "</b> is lesser");

			}

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify <b>" + " " + elementName + "</b> is greater",
					"" + elementName + " should be greater", "<b>" + elementName + "</b> has some issue");
		}
	}

	public static void TextIsNum(By by, String elementType, String elementName) {
		try {
			String actualText = Demo1.driver.findElement(by).getText();

			if (StringUtils.isNumeric(actualText)) {

				System.out.println("ActualText" + actualText);

				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify <b>" + elementType + " " + elementName + "</b> is Num",
						"" + elementName + " should be Num", "<b>" + actualText + "</b> Num");

			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify <b>" + elementType + " " + elementName + "</b> is Num",
						"" + elementName + " should be Num", "<b>" + actualText + "</b> Num");

			}

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify <b>" + elementType + " " + elementName + "</b> is Num",
					"" + elementName + " should be Num", "<b>" + elementName + "</b> Num");
		}
	}

	public static void getSystemDetailsHost(String VariableName) {
		InetAddress ip;
		String hostname;

		try {

			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();
			System.out.println("Your current IP address : " + ip);
			System.out.println("Your current Hostname : " + hostname);

			Reuse.WriteProperties(VariableName, hostname);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Check <b>" + "</b> " + " not focused", "<b>" + "</b> should not be focused",
					"Focused");

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check <b>" + "</b> " + " not focused", "<b>" + "</b> should not be focused",
					"Focused");
		}
	}

	// function to get runtime value for runtime dynamic variables
	public static String getValueOfRunTimeVariables(String variableName) {
		/*
		 * if(variableName.startsWith("@auto")){ //older approach variableName =
		 * variableName.replace("@auto", "");
		 *
		 * if(null == StoreText.txtAndVal.get(variableName)){ variableName =
		 * Reuse.GetPropertyValue(variableName); }else{ variableName =
		 * StoreText.txtAndVal.get(variableName); } }
		 */

		if (variableName.contains("auto@")) { // if one or more runtime variable
												// is used
			int count = variableName.split("\\@", -1).length;

			if (count == 2) {
				variableName = variableName.replace("auto@", "");

				// added to fetch value from properties file if value is not
				// present
				if (null != Reuse.GetPropertyValue(variableName)) {
					variableName = Reuse.GetPropertyValue(variableName);
				} else if (null != StoreText.txtAndVal.get(variableName)) {
					variableName = StoreText.txtAndVal.get(variableName);
				} else {
					variableName = "";
				}

			} else if (count > 2) {
				do {
					int start = variableName.indexOf("auto@");
					int end = variableName.indexOf("@", start + 5);
					String variable = variableName.substring(start, end + 1);
					String actualVariable = variable.substring(5, variable.length() - 1);

					String value;

					if (null != Reuse.GetPropertyValue(actualVariable)) {
						value = Reuse.GetPropertyValue(actualVariable);
					} else if (null != StoreText.txtAndVal.get(actualVariable)) {
						value = StoreText.txtAndVal.get(actualVariable);
					} else {
						value = "";
					}

					variableName = variableName.replaceFirst(variable, value);
				} while (variableName.contains("auto@"));
			}
		}

		return variableName;
	}

	private static void checkWealthSpinnerElement() {
		try {
			if (Config.wealthWsc) {
				processWealthSpinnerElement();
			} else if (null != Reuse.GetPropertyValue("wseLoader")) {
				if (Reuse.GetPropertyValue("wseLoader").trim().equalsIgnoreCase("true")) {
					processWealthSpinnerElement();
				}
			}
		} catch (Exception e1) {
			System.out.println("Error::" + e1.getStackTrace());
		}
	}

	private static void processWealthSpinnerElement() {
		try {
			String xpath = Config.wseLoaderXpath.trim();
			// newly added to test the loader element
			if (!xpath.isEmpty()) {
				Synchronize.dataLoaderLoading(xpath);
			}
		} catch (Exception e1) {
			System.out.println("Error::" + e1.getMessage());
			System.out.println("Error while getting Loader xpath value.");
		}
	}

	public static void bngMod1Create(String path, String jarName, String fileName) {

		try {
			FileWriter fr;
			String UserDirectory = Demo1.curDir;
			String[] Userloc = UserDirectory.split(":");
			fr = new FileWriter(UserDirectory + "\\TestData\\BNGmod1.bat");
			fr.write(Userloc[0] + ":\n");
			fr.write("cd " + path + "\n");
//             fr.write("jar -xvf TAFJJEE_EAR.ear TAFJJEE_MDB.jar\n");
			fr.write("jar -xvf " + jarName + " " + fileName);
			fr.close();
			// earMod1CreateStat = true;
		} catch (Exception e) {

			e.printStackTrace();

		}
	}

	public static void bngMod2Create(String path, String jarName, String fileName) {
		try {
			FileWriter fr1;
			String UserDirectory = Demo1.curDir;
			String[] Userloc = UserDirectory.split(":");
			fr1 = new FileWriter(UserDirectory + "\\TestData\\BNGmod2.bat");

//            fr1.write("@SET file="+path+ File.separator + fileName + "\n");

			fr1.write(Userloc[0] + ":\n");
			fr1.write("cd " + path + "\n");

			fr1.write("jar -uvf " + jarName + " " + fileName);

//             fr1.write("IF EXIST \"%file%\" (\n");
//             fr1.write("del /S /Q \"%file%\"\n");
//             fr1.write(")");

			fr1.close();
			// earMod2CreateStat = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void BNGMod(String fileName, String actualText, String replaceText, String jarPath)
			throws IOException {

		String UserDirectory = Demo1.curDir;

		String path1 = "cmd /c " + UserDirectory + "\\TestData\\BNGmod1.bat";
		String path2 = "cmd /c " + UserDirectory + "\\TestData\\BNGmod2.bat";
		try {
			Runtime rn2 = Runtime.getRuntime();
			Runtime rn3 = Runtime.getRuntime();
			rn2.exec(path1);
			Thread.sleep(3000);
			replaceTextInFile(jarPath, fileName, actualText, replaceText);
			Thread.sleep(3000);
			rn3.exec(path2);
			// TAFJJEEModStat = true;
			Thread.sleep(3000);

			File f1 = new File(jarPath + File.separator + fileName);
			if (f1.exists()) {
				f1.delete();
			}

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Check <b>" + "</b> " + " text replaced in jar", "<b>" + "</b> should  be replaced",
					"replaced");

		} catch (Exception e) {
			e.printStackTrace();

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check <b>" + "</b> " + " text replaced in jar", "<b>" + "</b> should  be replaced",
					"replaced");
		}
	}

	public static void replaceTextInFile(String jarPath, String fileName, String actualText, String replaceText) {

		Path path = Paths.get(jarPath + File.separator + fileName);
		Charset charset = StandardCharsets.UTF_8;

		System.out.println(path + "::::");

		String content = null;
		try {
			content = new String(Files.readAllBytes(path), charset);

			System.out.println(content + "::::::");

			content = content.replaceAll(actualText, replaceText);

//        content = content.replace(actualText, replaceText);

			Files.write(path, content.getBytes(charset));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
		}

	}

	public static void ExecuteComponent_ExecuteOFS(String applicationName, String ofsMessage, String outputParams,
			String routineValue) throws Exception {

		try {

			Properties prop = new Properties();

			InputStream input;
			try {
				input = new FileInputStream(curDir + "\\Config\\config.properties");
				prop.load(input);

				tafjHome = prop.getProperty("TAFJHOME").trim();
				javaHome = prop.getProperty("JAVAHOME").trim();

			} catch (IOException e) {
				System.out.println("Unable to read the config file");
			}

			if (!routineValue.isEmpty()) {

				try {
					FileWriter fw = new FileWriter(curDir + "\\TestData\\ExecuteOfs.bat");
					fw.write("set JAVA_HOME=" + javaHome + "\n");
					fw.write("set TAFJ_HOME=" + tafjHome + "\n");

					fw.write("set OFSMSG=%1\n");
					fw.write("CRT \"MESSAGE:::\" %OFSMSG%\n");
					fw.write("cd %TAFJ_HOME%/bin\n");
					fw.write("./tRun REG.PROCESS.OFS.MSG " + routineValue + " %OFSMSG%\n");

					fw.close();
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e);
				}

			} else {
				try {
					FileWriter fw = new FileWriter(curDir + "\\TestData\\ExecuteOfs.bat");
					fw.write("set JAVA_HOME=" + javaHome + "\n");
					fw.write("set TAFJ_HOME=" + tafjHome + "\n");

					fw.write("set OFSMSG=%1\n");
					fw.write("CRT \"MESSAGE:::\" %OFSMSG%\n");
					fw.write("cd %TAFJ_HOME%/bin\n");
					fw.write("./tRun REG.PROCESS.OFS.MSG GCS %OFSMSG%\n");

					fw.close();
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e);
				}
			}

			String response = executeOfsMessage(ofsMessage);

			System.out.println("Raw response before parsing :" + response);
			if (ofsMessage.contains("DECARRIER")) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Execute Swift msg", "Expected to inject " + applicationName + " swift message ",
						applicationName + " swift message was successfully injected");

			}

			else {

				if (response.contains("<requests>") && response.contains("</requests>")) {
					response = response.substring(response.indexOf("<requests>") + "<requests>".length(),
							response.lastIndexOf("</requests>"));
					/* System.out.println(response + "\n"); */

					String res = response.substring(response.indexOf("<request>") + "<request>".length(),
							response.lastIndexOf("</request>"));

					System.out.println("res:" + res);

					String[] parsed = null;
					if (res.contains("<request>")) {
						parsed = res.split("</request><request>");
					} else {
						parsed = new String[1];
						parsed[0] = res;
					}

					System.out.println("Parsed" + parsed);

					for (String str : parsed) {
						String[] responseArray = str.split(",");

						if (!outputParams.isEmpty()) {
							Reuse.storeRunTimeParameters(responseArray, outputParams);
						}

						String responseStatus = responseArray[0];
						responseStatus = responseStatus.substring(responseStatus.indexOf("//") + 2);

					}

				} else if (!response.isEmpty()) {
					String[] responseArray = response.split(",");

					if (!outputParams.isEmpty()) {
						Reuse.storeRunTimeParameters(responseArray, outputParams);
					}

				} else {
					Demo1.gbTestCaseStatus = "Fail";
					Demo1.ReportStep(2, "Execute OFS msg",
							"Expected to inject the OFS" + applicationName + " ofs message ",
							"Execution failed as OFS response is empty");
				}

				if (txnCommittedStatus.equals("1")) {
					Demo1.gbTestCaseStatus = "Pass";
					Demo1.ReportStep(2, "Execute OFS msg", "Expected to inject " + applicationName + " ofs message ",
							applicationName + " OFS message was successfully injected");
				} else {
					Demo1.gbTestCaseStatus = "Fail";
					String error = response.split(",")[1];
					Demo1.ReportStep(2, "Execute OFS msg", "Expected to inject " + applicationName + " ofs message ",
							error);
				}

			}
		} catch (Exception E1) {
			System.out.println("ERROR::>" + Throwables.getStackTraceAsString(E1));
			Demo1.gbTestCaseStatus = "Fail";
			// Demo1.ReportStep(2, "<a class=\"cindex\" href=\"" + ValofsFileName + "\">" +
			// Description + "</a>", ExpectedResult + " should be executed", ExpectedResult
			// + "<b> is not executed </b>");
			Demo1.ReportStep(2, "Execute OFS msg", "Expected to inject " + applicationName + " ofs message ",
					"Failed to execute OFS message");
		}

	}

	private static String executeOfsMessage(String ofsMessage) {
		System.out.println("MSG::>" + ofsMessage);
		if (ofsMessage.contains("auto@")) {
			ofsMessage = Reuse.updateRuntimeValuesInOfs(ofsMessage);
		}

		StringBuffer buffer = new StringBuffer();
		try {
			String command = "cmd /c " + curDir + File.separator + "TestData" + File.separator + "ExecuteOfs.bat"
					+ " \"" + ofsMessage + "\"";
			System.out.println("COMMAND USED::" + command);
			Process p = Runtime.getRuntime().exec(command);

			BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String line = null;

			while ((line = input.readLine()) != null) {
				if (line.contains("Response")) {
					line = line.substring(line.indexOf(32)).trim();
					buffer.append(line);
					System.out.println(">>" + line);
				} else if (line.contains("txnCommitted")) {
					txnCommittedStatus = line.substring(line.indexOf(32)).trim();
				}
			}

			/* response = getResponseFromFile(responseFileName); */
			responseMessage = buffer.toString();

		} catch (IOException e) {
			System.out.println("ERROR::" + Throwables.getStackTraceAsString(e));
		}
		System.out.println("RESPONSE:::>" + responseMessage);
		return responseMessage;
	}

	public static void XMLValidate(String path, String rootTag, String position, String tagName, String expectedValue) {
		try {

			System.out.println("path::>" + path);
			if (path.contains("auto@")) {
				path = Reuse.updateRuntimeValuesInOfs(path);
			}

			System.out.println("ExpectedValue::>" + expectedValue);
			if (expectedValue.contains("auto@")) {
				expectedValue = Reuse.updateRuntimeValuesInOfs(expectedValue);
			}

			// creating a constructor of file class and parsing an XML file
			File file = new File(path);
			// an instance of factory that gives a document builder
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			// an instance of builder to parse the specified xml file
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(file);
			doc.getDocumentElement().normalize();
			System.out.println("Root element: " + doc.getDocumentElement().getNodeName());

			NodeList nodeList = doc.getElementsByTagName(rootTag);

			Node node = nodeList.item(Integer.parseInt(position));

			Element eElement = (Element) node;

			String value = eElement.getElementsByTagName(tagName).item(0).getTextContent();

			System.out.println("Value: " + value);

			if (value.equalsIgnoreCase(expectedValue)) {

				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify the text is equal in the file", "The text should be equal in the file",
						"The text is equal in the file");

			} else {

				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify the text is equal in the file", "The text should be equal in the file",
						"The text is not equal in the file");

			}

			/*
			 * // nodeList is not iterable, so we are using for loop for (int itr = 0; itr <
			 * nodeList.getLength(); itr++) { Node node = nodeList.item(itr);
			 * System.out.println("\nNode Name :" + node.getNodeName()); if
			 * (node.getNodeType() == Node.ELEMENT_NODE) { Element eElement = (Element)
			 * node; System.out.println("Student id: "+
			 * eElement.getElementsByTagName("STMT.ENTRY.ID").item(0).getTextContent());
			 * System.out.println("First Name: "+
			 * eElement.getElementsByTagName("ACCOUNT.NUMBER").item(0).getTextContent()); //
			 * System.out.println("Last Name: "+
			 * eElement.getElementsByTagName("lastname").item(0).getTextContent()); //
			 * System.out.println("Subject: "+
			 * eElement.getElementsByTagName("subject").item(0).getTextContent()); //
			 * System.out.println("Marks: "+
			 * eElement.getElementsByTagName("marks").item(0).getTextContent()); } }
			 */

		} catch (Exception e) {
			e.printStackTrace();

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify the text is equal in the file", "The text should be equal in the file",
					"The text is not equal in the file");
		}
	}

	public static void StoreXMLValue(String path, String rootTag, String position, String tagName,
			String variableName) {
		try {

			// creating a constructor of file class and parsing an XML file
			File file = new File(path);
			// an instance of factory that gives a document builder
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			// an instance of builder to parse the specified xml file
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(file);
			doc.getDocumentElement().normalize();
			System.out.println("Root element: " + doc.getDocumentElement().getNodeName());

			NodeList nodeList = doc.getElementsByTagName(rootTag);

			Node node = nodeList.item(Integer.parseInt(position));

			Element eElement = (Element) node;

			String value = eElement.getElementsByTagName(tagName).item(0).getTextContent();

			System.out.println("Value: " + value);

			Reuse.WriteProperties(variableName, value);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Store the text from the file", "The text should be Stored", "The text is stored");

		} catch (Exception e) {
			e.printStackTrace();

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Store the text from the file", "The text should be Stored", "The text is not stored");
		}
	}

	public static void readDataLineByLine(String file, String recid, String header, String expectedValue) {

		try {

			// Create an object of filereader
			// class with CSV file as a parameter.
			FileReader filereader = new FileReader(Demo1.curDir + File.separator + file);

			// create csvReader object passing
			// file reader as a parameter
			CSVReader csvReader = new CSVReader(filereader);
			String[] nextRecord;

			HashMap<String, String> csvValue = new HashMap<>();
			LinkedList<String> headers = new LinkedList<>();
			LinkedList<String> rows = new LinkedList<>();
			for (String s : csvReader.readNext()) {
				headers.add(s);
			}
//            System.out.println(headers);
			// we are going to read data line by line
			while ((nextRecord = csvReader.readNext()) != null) {

				for (String element : nextRecord) {

					if (element != null) {

						if (nextRecord[0].equalsIgnoreCase(recid)) {
							rows.add(element);
							// System.out.print(nextRecord[i] + "\t");

						}
					}
				}
			}
//            System.out.println(rows);

			if (headers.size() == rows.size()) {
				for (int i = 0; i < headers.size(); i++) {
					csvValue.put(headers.get(i), rows.get(i));
				}

			}

			System.out.println(csvValue);

			if (csvValue.get(header).equalsIgnoreCase(expectedValue)) {

				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Verify the text is equal in the file", "The text should be equal in the file",
						"The text is equal in the file" + header + ":" + expectedValue);

			} else {

				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Verify the text is equal in the file", "The text should be equal in the file",
						"The text is not equal in the file" + header + ":" + expectedValue);

			}

		} catch (Exception e) {
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify the text is equal in the file", "The text should be equal in the file",
					"The text is not equal in the file" + header + ":" + expectedValue);
		}
	}

	public static void RemoteScreenCapture(String path) {

		WebDriver augmentedDriver = null;
		File screenshot = null;
		try {
			// augmentedDriver = new Augmenter().augment(driver);

			if (Demo1.envName.equalsIgnoreCase("MOBILEAPP")) {
				screenshot = ((TakesScreenshot) Demo1.driver1).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(screenshot,
						new File(System.getProperty("user.dir") + File.separator + "TestData" + File.separator + path),
						true);
			} else {
				screenshot = ((TakesScreenshot) Demo1.driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(screenshot,
						new File(System.getProperty("user.dir") + File.separator + "TestData" + File.separator + path),
						true);
			}

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Get value from file", "Should be able to get the value from file",
					"screenshot is taken successufully");

		} catch (Exception e) {
			Reuse.log(e);
			// TODO Auto-generated catch block
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Get value from file", "Should be able to get the value from file", e.getMessage());

		} finally {
			augmentedDriver = null;
			screenshot = null;
		}

	}

	public static void compareImageBat(String image1, String image2) {

		try {
			FileWriter fr;
			String UserDirectory = Demo1.curDir;
			String[] Userloc = UserDirectory.split(":");
			fr = new FileWriter(UserDirectory + "\\TestData\\CompareImage.bat");

			fr.write("@echo off\n");
			fr.write("cd " + UserDirectory + "\\TestData\\Python39\n");

			fr.write("set x=\"" + UserDirectory + "\\TestData\\" + image1 + "\"\n");
			fr.write("set y=\"" + UserDirectory + "\\TestData\\" + image2 + "\"\n");

			fr.write("python -u \"ImageHashing.py\" %x% %y%" + "\n");

			fr.close();
			// earMod1CreateStat = true;
		} catch (Exception e) {

			e.printStackTrace();

		}
	}

	public static void runCompImg(String image1, String image2) {

		compareImageBat(image1, image2);

		System.out.println("Bat file created");

		String UserDirectory = Demo1.curDir;

		String path1 = "cmd /c " + UserDirectory + "\\TestData\\CompareImage.bat";
		try {

			Process p = Runtime.getRuntime().exec(path1);

			BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String line = null;
			boolean flag = false;

			while ((line = input.readLine()) != null) {
				System.out.println(">>" + line.length());
				System.out.println(">>" + line);
				if (line.equalsIgnoreCase("1")) {

					flag = true;

				}
			}

			if (flag) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Check <b>" + "</b> " + " image is compared",
						"<b>" + "</b> should  be compared and verified", "image is same");
			} else {

				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Check <b>" + "</b> " + " image is compared",
						"<b>" + "</b> should  be compared and verified", "image is different");

			}

		} catch (Exception e) {
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Check <b>" + "</b> " + " text replaced in jar", "<b>" + "</b> should  be replaced",
					"replaced");
		}
	}

	public static void openNewTab(By by, String elementType, String elementName) {
		try {

			String clickl = Keys.chord(Keys.CONTROL, Keys.ENTER);
			Demo1.driver.findElement(by).sendKeys(clickl);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Verify <b>" + elementType + " " + elementName + "</b> is AlphaNum",
					"" + elementName + " should be AlphaNum", "<b>" + elementName + "</b> AlphaNum");

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify <b>" + elementType + " " + elementName + "</b> is AlphaNum",
					"" + elementName + " should be AlphaNum", "<b>" + elementName + "</b> AlphaNum");
		}
	}

	public static void fullRemoteScreenCapture(String path) {

		WebDriver augmentedDriver = null;
		File screenshot = null;
		try {
			// augmentedDriver = new Augmenter().augment(driver);

			if (Demo1.envName.equalsIgnoreCase("MOBILEAPP")) {
				screenshot = ((TakesScreenshot) Demo1.driver1).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(screenshot,
						new File(System.getProperty("user.dir") + File.separator + "TestData" + File.separator + path),
						true);
			} else {
				screenshot = ((TakesScreenshot) Demo1.driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(screenshot,
						new File(System.getProperty("user.dir") + File.separator + "TestData" + File.separator + path),
						true);
			}

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Get value from file", "Should be able to get the value from file",
					"screenshot is taken successufully");

		} catch (Exception e) {
			Reuse.log(e);
			// TODO Auto-generated catch block
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Get value from file", "Should be able to get the value from file", e.getMessage());

		} finally {
			augmentedDriver = null;
			screenshot = null;
		}

	}

	public static void fullPagescreenshot(String path) {
		try {

			// take screenshot of the entire page
			Screenshot screenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000))
					.takeScreenshot(Demo1.driver);
			try {
				ImageIO.write(screenshot.getImage(), "jpg",
						new File(System.getProperty("user.dir") + File.separator + "TestData" + File.separator + path));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Verify screeshot <b>", " screeshot should be saved", "</b> screeshot is  saved");

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Verify screeshot <b>", " screeshot should be saved", "</b> screeshot is not saved");
		}
	}

	public static void mouseMove(By by, String elementType, String elementName) {
		Actions actions = null;
		try {
			actions = new Actions(Demo1.driver);
			WebElement element = Demo1.driver.findElement(by);
			actions.moveToElement(element).build().perform();
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Mouse hover <b>" + elementName + "</b> " + elementType + "",
					"Should do mouse hover <b>" + elementName + "</b> " + elementType + " ", "mouse hovered");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Mouse hover on <b>" + elementName + "</b>",
					"Should be able to mouse hover on <b>" + elementName + " element",
					"Ubale to locate <b>" + elementName + "</b> " + elementType);
		} finally {
			actions = null;
		}
	}

// Browser console error support only in google chrome
	public static void ConsoleLog_Error(String log) {
		LogEntries logEntries = null;
		Logs logsError = null;
		String errorLogType, errorLog;
		try {
			if (log.toLowerCase().contentEquals("browser")) {
				if (Demo1.BrowName.contentEquals("googlechrome")) {
					logsError = Demo1.driver.manage().logs();
					logEntries = logsError.get(LogType.BROWSER);
				}
				Reuse.log("Error Log Count: " + logEntries.getAll().size());
				if (logEntries.getAll().size() > 0) {
					Reuse.log(Demo1.BrowName.toString());
					StringBuilder LogTypeError = new StringBuilder();
					for (LogEntry entry : logEntries) {
						errorLogType = entry.getLevel().toString();
						errorLog = entry.getMessage().toString();
						LogTypeError.append("Error LogType: <b>" + errorLogType + "</b> Error Log message: <b>"
								+ errorLog + "</b> has occured.<br/>");
						Reuse.log(new Date(entry.getTimestamp()) + " Error LogType: <b>" + errorLogType
								+ "</b> Error Log message: <b>" + errorLog + "</b>");
					}
					Demo1.ReportStep(2, "Browser Console Log", "Error LogType and Error Log message: should be empty.",
							LogTypeError.toString());
				} else {
					Demo1.ReportStep(2, "Browser Console Log", "Error LogType and Error Log message: should be empty.",
							"Error LogType and Error Log message has not occured.");
				}

			}

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Console status for Error LogType: <b>" + log + "</b> has failed",
					"Error Log message: <b>" + log + "</b> has empty", e.getMessage());

		}

	}

	public static void oInsertXML_TextArea(String fileName, String textBoxName, By by) throws IOException {

		File file;
		FileReader fileReader;
		BufferedReader read = null;

		try {
			file = new File(Demo1.curDir + File.separator + "TestData" + File.separator + fileName.trim());
			fileReader = new FileReader(file);
			read = new BufferedReader(fileReader);

			String s;
			StringBuilder xmlfile = new StringBuilder();

			while ((s = read.readLine()) != null) {
				xmlfile.append(s + "\n");
			}

			Demo1.driver.findElement(by).click();
			Actions actions = new Actions(Demo1.driver);
			actions.keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).build().perform();
			actions.sendKeys(Keys.DELETE).build().perform();
			JavascriptExecutor jse = (JavascriptExecutor) Demo1.driver;
			jse.executeScript("arguments[0].value=arguments[1]", Demo1.driver.findElement(by), xmlfile.toString());
//		jse.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", Demo1.driver.findElement(by),
//				"value", xmlfile.toString().trim());
//		Demo1.driver.findElement(by).click();
//		Demo1.driver.findElement(by).sendKeys(Keys.CONTROL, Keys.END);
//		Demo1.driver.findElement(by).sendKeys(" ");

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Inserting xmlRoute value in the <b>" + textBoxName + "</b> text box",
					"<b>" + textBoxName + "</b> value should be inserted in text area",
					"<b>" + textBoxName + "</b> value inserted in text area");

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Inserting route xml value in the <b>" + textBoxName + "</b> text box",
					"<b>" + textBoxName + "</b> value should be inserted in text area",
					"<b>" + textBoxName + "</b> value is not inserted in text area");
		} finally {
			read.close();
		}
	}

	public static void oSendKeysByValue(By by, String text, String textBoxName) {

		try {
			if (isElementPresent(by)) {
				try {
					Demo1.driver.findElement(by).click();
					Demo1.driver.findElement(by).sendKeys(text);

					if (Config.wealthRun) {
						// newly added to test the loader element
						try {
							Thread.sleep(100);
						} catch (InterruptedException e) {
							e.printStackTrace();
							System.out.println("Error while adding sleep time");
						}
						checkWealthSpinnerElement();
					}

				} catch (Exception e) {
					JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
					js.executeScript("arguments[0].value='" + text + "';", Demo1.driver.findElement(by));
					js.executeScript("var event = new Event('change');arguments[0].dispatchEvent(event);",
							Demo1.driver.findElement(by));
					js.executeScript("var event = new Event('blur');arguments[0].dispatchEvent(event);",
							Demo1.driver.findElement(by));

					Reuse.log(e);
				}
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Input text in to the field <b>" + textBoxName + "</b>",
						"Input text <b>" + text + "</b>", "Text <b>" + text + "</b> entered Successfully");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Input text in to the field <b>" + textBoxName + "</b>",
					"Input text <b>" + text + "</b>", "Unbale to locate textbox <b>" + textBoxName + "</b>");
			Demo1.logger.error(e);
		}

	}

	public static void RemoveSpecialCharacters_StoreValueinFile(String variable, String elementName, By by,
			String removeChar) {

		String eleText = "";
		String action = "";
		String strProcessed = "";
		try {
			eleText = Demo1.driver.findElement(by).getText();
			if (eleText != null & eleText.trim().isEmpty()) {
				eleText = Demo1.driver.findElement(by).getAttribute("value");
				if (eleText == null) {
					eleText = "";
				}
			}
			if (eleText != null && eleText.length() > 0 && !eleText.equals("")) {

				strProcessed = Reuse.getProcessedString(action, eleText.trim());
				strProcessed = strProcessed.replaceAll("[" + removeChar + "]", "");
				System.out.println("paramter " + strProcessed);

				Reuse.WriteProperties(variable, strProcessed);
				Demo1.gbTestCaseStatus = "Pass";
				eleText = escapeHtml3(eleText);
				Demo1.ReportStep(2, "Store <b>" + strProcessed + "</b> in <b>" + variable + "</b> ",
						"<b>" + strProcessed + "</b> should be stored in <b>" + variable + "</b> ", "Stored");
			}

			else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Store <b>" + strProcessed + "</b> in <b>" + variable + "</b> ",
						"<b>" + strProcessed + "</b> should be stored in <b>" + variable + "</b> ",
						"Value may not present in the element provided");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Store <b>" + strProcessed + "</b> in <b>" + variable + "</b> ",
					"<b>" + strProcessed + "</b> should be stored in <b>" + variable + "</b> ",
					"Value may not present in the element provided");
		}
	}

	public static void SelectLastChars_StoreValueinFile(String variable, String elementName, By by, int noofChar) {

		String eleText = "";
		String strProcessed = "";
		String lastchars = "";
		try {
			eleText = Demo1.driver.findElement(by).getText();
			if (eleText != null & eleText.trim().isEmpty()) {
				eleText = Demo1.driver.findElement(by).getAttribute("value");
				if (eleText == null) {
					eleText = "";
				}
			}
			if (eleText != null && eleText.length() > 0 && !eleText.equals("")) {

				strProcessed = eleText.trim();

				if (strProcessed.length() > noofChar) {
					lastchars = strProcessed.substring(strProcessed.length() - noofChar);
				} else {
					lastchars = strProcessed;
				}

				System.out.println("paramter " + lastchars);

				Reuse.WriteProperties(variable, lastchars);
				Demo1.gbTestCaseStatus = "Pass";
				eleText = escapeHtml3(eleText);
				Demo1.ReportStep(2, "Store <b>" + lastchars + "</b> in <b>" + variable + "</b> ",
						"<b>" + lastchars + "</b> should be stored in <b>" + variable + "</b> ", "Stored");
			}

			else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Store <b>" + lastchars + "</b> in <b>" + variable + "</b> ",
						"<b>" + lastchars + "</b> should be stored in <b>" + variable + "</b> ",
						"Value may not present in the element provided");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Store <b>" + lastchars + "</b> in <b>" + variable + "</b> ",
					"<b>" + lastchars + "</b> should be stored in <b>" + variable + "</b> ",
					"Value may not present in the element provided");
		}
	}

	public static void SelectFirstChars_StoreValueinFile(String variable, String elementName, By by, int noofChar) {

		String eleText = "";
		String strProcessed = "";
		String firstchars = "";
		try {
			eleText = Demo1.driver.findElement(by).getText();
			if (eleText != null & eleText.trim().isEmpty()) {
				eleText = Demo1.driver.findElement(by).getAttribute("value");
				if (eleText == null) {
					eleText = "";
				}
			}
			if (eleText != null && eleText.length() > 0 && !eleText.equals("")) {

				strProcessed = eleText.trim();

				if (strProcessed.length() > noofChar) {
					firstchars = strProcessed.substring(0, noofChar);
				} else {
					firstchars = strProcessed;
				}

				System.out.println("paramter " + firstchars);

				Reuse.WriteProperties(variable, firstchars);
				Demo1.gbTestCaseStatus = "Pass";
				eleText = escapeHtml3(eleText);
				Demo1.ReportStep(2, "Store <b>" + firstchars + "</b> in <b>" + variable + "</b> ",
						"<b>" + firstchars + "</b> should be stored in <b>" + variable + "</b> ", "Stored");
			}

			else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Store <b>" + firstchars + "</b> in <b>" + variable + "</b> ",
						"<b>" + firstchars + "</b> should be stored in <b>" + variable + "</b> ",
						"Value may not present in the element provided");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Store <b>" + firstchars + "</b> in <b>" + variable + "</b> ",
					"<b>" + firstchars + "</b> should be stored in <b>" + variable + "</b> ",
					"Value may not present in the element provided");
		}
	}

	public static void SelectSpecificChars_StoreValueinFile(String variable, String elementName, By by, int startIndex,
			int EndIndex) {

		String eleText = "";
		String strProcessed = "";
		String specificchars = "";
		try {
			eleText = Demo1.driver.findElement(by).getText();
			if (eleText != null & eleText.trim().isEmpty()) {
				eleText = Demo1.driver.findElement(by).getAttribute("value");
				if (eleText == null) {
					eleText = "";
				}
			}
			if (eleText != null && eleText.length() > 0 && !eleText.equals("")) {

				strProcessed = eleText.trim();

				if (strProcessed.length() > 0) {
					specificchars = strProcessed.substring(startIndex, EndIndex);
				} else {
					specificchars = strProcessed;
				}

				System.out.println("paramter " + specificchars);

				Reuse.WriteProperties(variable, specificchars);
				Demo1.gbTestCaseStatus = "Pass";
				eleText = escapeHtml3(eleText);
				Demo1.ReportStep(2, "Store <b>" + specificchars + "</b> in <b>" + variable + "</b> ",
						"<b>" + specificchars + "</b> should be stored in <b>" + variable + "</b> ", "Stored");
			}

			else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Store <b>" + specificchars + "</b> in <b>" + variable + "</b> ",
						"<b>" + specificchars + "</b> should be stored in <b>" + variable + "</b> ",
						"Value may not present in the element provided");
			}
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Store <b>" + specificchars + "</b> in <b>" + variable + "</b> ",
					"<b>" + specificchars + "</b> should be stored in <b>" + variable + "</b> ",
					"Value may not present in the element provided");
		}
	}

	public static void uploadfileUsingJS(String elementName, String filename, By by, By by1) {
		try {
			String path = Demo1.curDir + "\\TestData\\" + filename;
			Reuse.log(path);
			JavascriptExecutor executor = (JavascriptExecutor) Demo1.driver;
			// To disable a click function
			executor.executeScript("HTMLInputElement.prototype.click = function() {                     "
					+ "  if(this.type !== 'file') HTMLElement.prototype.click.call(this);  " + "};");

			Demo1.driver.findElement(by).click();
			oWait(2);
			WebElement findElement = Demo1.driver.findElement(by1);
			findElement.sendKeys(path);
			// To enable a click function
			executor.executeScript("delete HTMLInputElement.prototype.click");
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Attach a file in <b>" + elementName + "</b>", "File should be attached successfully",
					"File is attached successfully");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Attach a file in <b>" + elementName + "</b>", "File should be attached successfully",
					"File is not attached successfully");
		}
	}

	public static void uploadfile(String elementName, String filename, By by) {
		try {
			String path = Demo1.curDir + "\\TestData\\" + filename;
			Reuse.log(path);
			WebElement findElement = Demo1.driver.findElement(by);
			findElement.sendKeys(path);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Attach a file in <b>" + elementName + "</b>", "File should be attached successfully",
					"File is attached successfully");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Attach a file in <b>" + elementName + "</b>", "File should be attached successfully",
					"File is not attached successfully");
		}
	}

	public static void oInsertTextIn_TextEditor(String fileName, String textBoxName, By by) throws IOException {

		File file;
		FileReader fileReader;
		BufferedReader read = null;

		try {
			file = new File(Demo1.curDir + File.separator + "TestData" + File.separator + fileName.trim());
			fileReader = new FileReader(file);
			read = new BufferedReader(fileReader);

			String s;
			StringBuilder xmlfile = new StringBuilder();

			while ((s = read.readLine()) != null) {
				xmlfile.append(s + "\n");
			}

			Demo1.driver.findElement(by).click();
			oWait(3);
			Actions actions = new Actions(Demo1.driver);
			actions.keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).build().perform();
			actions.sendKeys(Keys.SPACE).build().perform();
			actions.sendKeys(xmlfile.toString().trim()).build().perform();
			actions.keyDown(Keys.CONTROL).keyDown(Keys.SHIFT).sendKeys(Keys.END).keyUp(Keys.SHIFT).keyUp(Keys.CONTROL)
					.build().perform();
			actions.sendKeys(Keys.SPACE).build().perform();

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Inserting the value in the <b>" + textBoxName + "</b> text Editor",
					"<b>" + textBoxName + "</b> value should be inserted in text Editor",
					"<b>" + textBoxName + "</b> value inserted in text Editor");

		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Inserting the value in the <b>" + textBoxName + "</b> text Editor",
					"<b>" + textBoxName + "</b> value should be inserted in text Editor",
					"<b>" + textBoxName + "</b> value is not inserted in text Editor");
		} finally {
			read.close();
		}
	}

	public static void ReadPropertiesFile_UpdateInJSON(String propkey, String jsonkey, String jsonFileName)
			throws IOException {
		FileWriter file = null;
		Properties prop;
		FileReader propertyreader;
		FileReader jsonread;
		String propvalue = null;
		try {
			if(Config.Mode.equals("LMS")) {
				propertyreader = new FileReader(Config.TestDataFileLocation + "\\testVariables.prperties");
           }
           else {
        	   propertyreader=new FileReader(Demo1.curDir + File.separator+"TestData"+ File.separator+"testVariables.prperties");
           }
			prop = new Properties();
			prop.load(propertyreader);
			propvalue = prop.getProperty(propkey);
			System.out.println(propvalue);

			jsonread = new FileReader(
					Demo1.curDir + File.separator + "TestData" + File.separator + jsonFileName.trim());
			JSONParser parser = new JSONParser();
			Object obj = parser.parse(jsonread);
			org.json.simple.JSONObject json = (org.json.simple.JSONObject) obj;
			System.out.println(json);
			json.put(jsonkey, propvalue);
			// JsonParser ok = new JsonParser();
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			String prettyJsonString = gson.toJson(json);
			System.out.println(prettyJsonString);
			Reuse.log(prettyJsonString);

			file = new FileWriter(Demo1.curDir + File.separator + "TestData" + File.separator + jsonFileName.trim());
			file.write(prettyJsonString);
			file.flush();
			Demo1.ReportStep(2,
					"Read Property key <b>" + propkey + "</b> value as <b>" + propvalue
							+ "</b> from property file and update in json file to the key <b>" + jsonkey
							+ "</b> as value <b>" + propvalue + "</b>",
					"Property file value should be updated to json file",
					"Property file value is updated to json file");
		} catch (Exception e) {
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2,
					"Read Property key <b>" + propkey + "</b> value as <b>" + propvalue
							+ "</b> from property file and update in json file to the key <b>" + jsonkey
							+ "</b> as value <b>" + propvalue + "</b>",
					"Property file value should be updated to json file",
					"Property file value is not updated to json file" + e.getMessage());
		} finally {
			file.close();
		}
	}

	public static void ReadTextFromTextArea_AddInFile(String fileName, String textBoxName, By by) {
		FileWriter file = null;
		String path = null;
		try {
			String textarea = Demo1.driver.findElement(by).getText();
			path = Demo1.curDir + File.separator + "TestData" + File.separator + fileName.trim();
			file = new FileWriter(path);
			file.write(textarea);
			file.flush();
			file.close();
			Demo1.ReportStep(2, "Read text from <b>" + textBoxName + "</b> and add it in file",
					"Text should be added to the file <b>" + path + "</b>", "Text is added to the file");
		} catch (Exception e) {
			e.printStackTrace();
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Read text from <b>" + textBoxName + "</b> and add it in file",
					"Text should be added to the file <b>" + path + "</b>", "Text is not added to the file");
		}
	}

	public static void Add_JSONObjects_To_ExistingJSONFile(String JSONExistingFileName, String JSONObjectsFileName) {
		BufferedReader br;
		StringBuilder sb;
		StringBuilder strb;

		try {
			String ExistingJson = Demo1.curDir + File.separator + "TestData" + File.separator
					+ JSONExistingFileName.trim();
			String JsonToAppend = Demo1.curDir + File.separator + "TestData" + File.separator
					+ JSONObjectsFileName.trim();
			String line;
			// this will first gets the existing json string from the existing file.
			br = new BufferedReader(new FileReader(ExistingJson));
			sb = new StringBuilder();
			line = br.readLine();
			while (line != null) {
				sb.append(line);
				sb.append("\n");
				line = br.readLine();
			}
			// this removes the trailing bracket
			String str = sb.toString();
			String sourceWord = "]";
			strb = new StringBuilder(str);
			int index = strb.lastIndexOf(sourceWord);
			strb.replace(index, sourceWord.length() + index, "");
			FileWriter fws = new FileWriter(ExistingJson, false);
			fws.write(strb.toString().trim());// appends the string to the file
			fws.write(",");
			fws.write("\n");
			fws.close();

			// this will gets the json objects from the Json to append file.
			BufferedReader br1 = new BufferedReader(new FileReader(JsonToAppend));
			StringBuilder sb1 = new StringBuilder();
			line = br1.readLine();
			while (line != null) {
				sb1.append(line);
				sb1.append("\n");
				line = br1.readLine();
			}
			String str1 = sb1.toString();
			String sl = str1.substring(1);
			String sourceWord1 = "]";
			StringBuilder strb1 = new StringBuilder(sl);
			int index1 = strb1.lastIndexOf(sourceWord1);
			strb1.replace(index1, sourceWord1.length() + index1, "");

			// To append json objects to existing Json file
			FileWriter fw = new FileWriter(ExistingJson, true); // the true will append the new data
			fw.write(strb1.toString().trim());// appends the string to the file
			fw.write("\n");
			fw.write("]");
			fw.close();
			Demo1.ReportStep(2,
					"Fetch JSON objects from <b>" + JSONObjectsFileName + "</b> and add it to the file <b>"
							+ JSONExistingFileName + "</b>",
					"JSON objects should be added to other JSON file",
					"JSON objects should be added to other JSON file");
		} catch (Exception e) {
			e.printStackTrace();
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2,
					"Fetch JSON objects from <b>" + JSONObjectsFileName + "</b> and add it to the file <b>"
							+ JSONExistingFileName + "</b>",
					"JSON objects should be added to other JSON file", "JSON objects is not added to other JSON file");
		}

	}

	public static void ClickIf_OR_NOT_ElementDisplayed(String Element1, String Element2, By by1, By by2, int sec) {

		JavascriptExecutor executor = (JavascriptExecutor) Demo1.driver;
		try {
			if (Demo1.driver.findElements(by1).size() > 0) {
				// Demo1.driver.findElement(by1).click();
				executor.executeScript("arguments[0].click();", Demo1.driver.findElement(by1));
				oWait(sec);
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Click on <b>" + Element1 + "</b>", "Should be Clicked on <b>" + Element1 + "</b>",
						"Clicked on <b>" + Element1 + "</b>");
			} else if (Demo1.driver.findElements(by2).size() > 0) {
				// Demo1.driver.findElement(by2).click();
				executor.executeScript("arguments[0].click();", Demo1.driver.findElement(by2));
				oWait(sec);
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "Click on <b>" + Element2 + "</b>", "Should be Clicked on <b>" + Element2 + "</b>",
						"Clicked on <b>" + Element2 + "</b>");
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "Click on element available by locator", "Element should be Clicked ",
						"unable to identify the locator");
			}

		} catch (Exception e) {
			Reuse.log(e);
			e.printStackTrace();
			Demo1.logger.error("Element is not identified " + e);
		}
	}

	public static void compareDate(String dateFormat, String action, String startDate, String endDate,
			String verifyByValue) {
		
		int difference=0;
		
		try {
			boolean isMatched = false;
			if (startDate.contains("auto@")) {
				String runTimeVariableName = startDate.replace("auto@", "");
				runTimeVariableName = runTimeVariableName.substring(0, runTimeVariableName.length() - 1);
				// startDate = StoreText.txtAndVal.get(runTimeVariableName);
				startDate = Reuse.GetPropertyValue(runTimeVariableName);
			}
			
			//this will fetch today date
			else if(startDate.contains("CURRENTDATE")) {
				Date date = new Date();
				SimpleDateFormat ft = new SimpleDateFormat(dateFormat);
				startDate = ft.format(date);
			}

			if (endDate.contains("auto@")) {
				String runTimeVariableName = endDate.replace("auto@", "");
				runTimeVariableName = runTimeVariableName.substring(0, runTimeVariableName.length() - 1);
				endDate = Reuse.GetPropertyValue(runTimeVariableName);
			}

			if (verifyByValue.contains("auto@")) {
				String runTimeVariableName = verifyByValue.replace("auto@", "");
				runTimeVariableName = runTimeVariableName.substring(0, runTimeVariableName.length() - 1);
				verifyByValue = Reuse.GetPropertyValue(runTimeVariableName);
			}
			// Define the date format
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateFormat);

			// Parse the date strings into LocalDate objects
			LocalDate currentDate = LocalDate.parse(startDate, formatter);
			LocalDate targetDate = LocalDate.parse(endDate, formatter);

			// Calculate the period between the two dates
			Period period = currentDate.until(targetDate);
			
			switch (action.trim().toUpperCase()) {
			
			case "DAYS":
				difference = (int) ChronoUnit.DAYS.between(currentDate, targetDate);
				if (Integer.parseInt(verifyByValue) == difference) {
					isMatched = true;
					break;
				}

			case "MONTHS":
				difference = (int) ChronoUnit.MONTHS.between(currentDate, targetDate);
				if (Integer.parseInt(verifyByValue) == difference) {
					isMatched = true;
					break;
				}

			case "WEEKS":
				difference = (int) ChronoUnit.WEEKS.between(currentDate, targetDate);
				if (Integer.parseInt(verifyByValue) == difference) {
					isMatched = true;
					break;
				}

			case "YEARS":
				difference = (int) ChronoUnit.YEARS.between(currentDate, targetDate);
				if (Integer.parseInt(verifyByValue) == difference) {
					isMatched = true;
					break;
				}

			default:
				Demo1.logger.error("Error in compare Date. " + action + " not matched");

			}

			if (isMatched) {
				isMatched = false;
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "To compare the date difference between "+ startDate+" and "+endDate+"", "Total <b>"+action +" </b>difference between "+ startDate+" and "+endDate+""
						+ " Should match with "+verifyByValue+"","Total <b>"+action +" </b>difference between "+ startDate+" and "+endDate+""
								+ " matches with expected value "+difference+" = "+verifyByValue+"");
						 
			} else {
				// msg
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "To compare the date difference between "+ startDate+" and "+endDate+"", "Total <b>"+action +"</b> difference between "+ startDate+" and "+endDate+""
						+ " Should match with "+verifyByValue+"","Total <b>"+action +"</b> difference between "+ startDate+" and "+endDate+""
								+ " not matches with expected value "+difference+" = "+verifyByValue+"");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Reuse.log(e);
			Demo1.logger.error(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To compare the date difference between "+ startDate+" and "+endDate+"", "Total <b>"+action +"</b> difference between "+ startDate+" and "+endDate+""
					+ " Should match with "+verifyByValue+"","Total <b>"+action +"</b> difference between "+ startDate+" and "+endDate+""
							+ " not matches with expected value "+difference+" = "+verifyByValue+"");
		}

		
	}
	
	
	
	public static void click_MultipleElements(String elementName, By by, By by1, By by2, boolean toClick) {
		try {
			List<WebElement> elements = Demo1.driver.findElements(by);
			System.out.println("Element size : "+ elements.size());
			WebDriverWait wait = new WebDriverWait(Demo1.driver, Duration.ofSeconds(Config.TIME_OUT));
			for (WebElement element : elements) {
				 boolean clicked = false;
			        int attempts = 0;
			        while (!clicked && attempts < 1) { // Attempt to click up to 1 time
			            try {
			                element.click();
			                clicked = true;
			            } catch (StaleElementReferenceException e) {
			                // if Element is stale, re-locating the element again
			            	element=Demo1.driver.findElement(by);
			            	element.click();
			                attempts++;
			            }
			        }
			        //to click other elements if needed need to set flag as true to enable it
			        if(toClick==true) {
			        	WebElement ele1 = Demo1.driver.findElement(by1);
						Synchronize.defaultAjaxSync();
						WebElement ele2 = Demo1.driver.findElement(by2);
						wait.until(ExpectedConditions.elementToBeClickable(ele1));
						ele1.click();
						Synchronize.defaultAjaxSync();
						wait.until(ExpectedConditions.elementToBeClickable(ele2));
						ele2.click();
			        }
	            
				Synchronize.defaultAjaxSync();
	        }
			
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "Click Multiple elements <b>" + elementName + "</b>",
					"Should be able to click on <b>" + elementName + "</b>",
					"Element <b>" + elementName + "</b> is clicked");
		} catch (Exception e) {
			e.printStackTrace();
			Demo1.logger.error("Click_Element " + e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Click Multiple elements <b>" + elementName + "</b>",
					"Should be able to click on <b>" + elementName + "</b>",
					"Element <b>" + elementName + "</b> not present/unable to locate element");
		}

	}
	

	
	
	public static void domReady(WebDriver driver) throws InterruptedException {

		String state = ((JavascriptExecutor)Demo1.driver).executeScript("return document.readyState").toString();

		for (int i = 0; i < 10; i++) {

		Thread.sleep(3000);

		if(state.contains("complete")) {

		break;

		}else {

		state = ((JavascriptExecutor)Demo1.driver).executeScript("return document.readyState").toString();

		}

		}

		}
	
	/**
     * Parses the integer string and upon failure, defaults to defaultValue.
     *
     * @param desc the description for logging failures
     * @param intString the int string to parse
     * @param defaultValue the default value used on failure
     * @return the int
     */
	public static int parseIntSafely(String desc, String intString, int defaultValue)
	{
	    try
	    {
	        return Integer.parseInt( intString.trim() );
	    }
	    catch (Exception e)
	    {
	        log(desc + ": Could not parse " + intString + " defaulting to " + defaultValue);
	        
	        return defaultValue;
	    }
	}

    /**
     * Parses the integer from the paramArgs array at the specified paramIndex, upon failure defaults to defaultValue.
     *
     * @param desc the description for logging failures
     * @param paramArgs the param args
     * @param paramIndex the param index
     * @param defaultValue the default value used on failure
     * @return the int
     */
    public static int parseIntSafely(String desc, String[] paramArgs, int paramIndex, int defaultValue)
    {
        if ( paramArgs != null && paramArgs.length > paramIndex )
        {
            return parseIntSafely( desc, paramArgs[paramIndex], defaultValue );
        }
        
        log(desc + ": Cannot get parameter from " + StringUtils.join( paramArgs, "," ) + " at index " + paramIndex + ", so defaulting to " + defaultValue);

        return defaultValue;
    }

}
