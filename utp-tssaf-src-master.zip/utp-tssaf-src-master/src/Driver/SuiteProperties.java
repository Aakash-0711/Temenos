package Driver;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

/**
 * Created by shanmugamarun on 29-06-2017.
 */
public class SuiteProperties {
    public static String PaginationNextButton ;
    static Properties prop = new Properties();
    public static void main(String[] args) {
        try{
            //load a properties file
            String currDir=Demo1.curDir;
            InputStream input = new FileInputStream(currDir+"\\Config\\SuiteConfig.properties");
            prop.load(input);
            PaginationNextButton=getProperty("PaginationNextButton");
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    static String getProperty(String attr){
        try {
            return prop.getProperty(attr).trim();
        }catch (Exception e1){
            e1.printStackTrace();
        }
        return "";
    }


}
