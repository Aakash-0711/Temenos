package Driver;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;

public class Synchronize {
    public static boolean isAccessable(String url, int timeout) {
        url = url.replaceFirst("https", "http"); // Otherwise an exception may
        // be thrown on invalid SSL
        // certificates.
        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(url)
                    .openConnection();
            connection.setConnectTimeout(timeout);
            connection.setReadTimeout(timeout);
            connection.setRequestMethod("HEAD");
            int responseCode = connection.getResponseCode();
            if (responseCode != 200) {
                return false;
            }
        } catch (IOException exception) {
            return false;
        }
        return true;
    }
    public static void defaultAjaxSync() {

           try {
            if (Config.jsSync.trim().equalsIgnoreCase("true")) {

                if (!Demo1.Nextcomponent.toLowerCase().contains("alert")) {

                    Synchronize.jQueryAJAXCallsHaveCompleted();

                    if(Config.Mode.toUpperCase().trim().contains("MODALWORKFLOWS")){
                        UXPLoading();
                    }


                    ajaxSync(100);
                }

            }
        } catch (Exception e1) {
            e1.printStackTrace();
            Demo1.logger.error("ERROR::" + e1.getStackTrace());
        }
    }

	private static void UXPLoading() {



	    if(! Demo1.envName.equalsIgnoreCase("MOBILEAPP") && ! Demo1.envName.equalsIgnoreCase("API"))
        {

    	Wait<WebDriver> gWait = new FluentWait<>(Demo1.driver).withTimeout(Duration.ofSeconds(100))
                .pollingEvery(Duration.ofMillis(600)).ignoring(NoSuchElementException.class);
        Function<WebDriver, Boolean> function = new Function<WebDriver, Boolean>() {
            @Override
			public Boolean apply(WebDriver arg0) {
                Boolean active = arg0.findElement(By.xpath("//img[contains(@src,'loading.gif')]")).isDisplayed();
                return !active;
             }
        };

        gWait.until(function);



        }

    }

    private static void ajaxSync(int timeoutInSeconds) {
        try {

            if(! Demo1.envName.equalsIgnoreCase("MOBILEAPP") && ! Demo1.envName.equalsIgnoreCase("API"))
            {
                ajaxWait(timeoutInSeconds);
                WebDriverWait wait = new WebDriverWait(Demo1.driver, Duration.ofSeconds(timeoutInSeconds));
                // wait for Javascript to load
                ExpectedCondition<Boolean> jsLoad = new ExpectedCondition<Boolean>() {
                    @Override
                    public Boolean apply(WebDriver driver) {
                        return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
                                .equals("complete");
                    }
                };
                wait.until(jsLoad);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void ajaxWait(int timeoutInSeconds) {

        WebDriver driver = Demo1.driver;

        try {
            if (driver instanceof JavascriptExecutor) {
                JavascriptExecutor jsDriver = (JavascriptExecutor) driver;

                for (int i = 0; i < timeoutInSeconds; i++) {

                    Object numberOfAjaxConnections = jsDriver.executeScript("return window.openHTTPs");
                    // return should be a number
                    if (numberOfAjaxConnections instanceof Long) {
                        Long n = (Long) numberOfAjaxConnections;
                        // System.out.println("Number of active calls: " + n);
                        if (n.longValue() == 0L)
                            break;
                    } else {
                        // If its not a number page might have been loaded
                        // freshly indicating the monkey
                        // path is replased or we havent yet done the patch.
                        monkeyPatchXMLHttpRequest();
                    }
                    Thread.sleep(100);
                }
            } else {
                System.out.println("Web driver: " + driver + " cannot execute javascript");
            }
        } catch (InterruptedException e) {
            System.out.println(e);
        }
    }


    private static void jQueryAJAXCallsHaveCompleted() {

        if(! Demo1.envName.equalsIgnoreCase("MOBILEAPP")  && ! Demo1.envName.equalsIgnoreCase("API") )
        {

        FluentWait<WebDriver> wait = new FluentWait<>(Demo1.driver);
        wait.pollingEvery(Duration.ofMillis(250));
        wait.withTimeout(Duration.ofSeconds(100));


        Function<WebDriver, Boolean> function = new Function<WebDriver, Boolean>() {
            @Override
			public Boolean apply(WebDriver arg0) {
                Boolean active = (Boolean) ((JavascriptExecutor) arg0).executeScript("return jQuery.active == 0;");
                return active;
            }
        };

        wait.until(function);

        }
    }

    private static void monkeyPatchXMLHttpRequest() {
        WebDriver driver = Demo1.driver;
        try {
            if (driver instanceof JavascriptExecutor) {
                JavascriptExecutor jsDriver = (JavascriptExecutor) driver;
                Object numberOfAjaxConnections = jsDriver.executeScript("return window.openHTTPs");
                if (numberOfAjaxConnections instanceof Long) {
                    return;
                }
                String script = "  (function() {" + "var oldOpen = XMLHttpRequest.prototype.open;"
                        + "window.openHTTPs = 0;"
                        + "XMLHttpRequest.prototype.open = function(method, url, async, user, pass) {"
                        + "window.openHTTPs++;" + "this.addEventListener('readystatechange', function() {"
                        + "if(this.readyState == 4) {" + "window.openHTTPs--;" + "}" + "}, false);"
                        + "oldOpen.call(this, method, url, async, user, pass);" + "}" + "})();";
                jsDriver.executeScript(script);
            } else {
                System.out.println("Web driver: " + driver + " cannot execute javascript");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    //to handle spinner element in WSC/WEALTH
    public static void dataLoaderLoading(String loaderXPath) {
        Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        try{
            if(Demo1.driver.findElement(By.xpath(loaderXPath)).isDisplayed()){
                System.out.println("WSE Loader element is displayed now.");

                Wait<WebDriver> flWait = new FluentWait<>(Demo1.driver)
                        .withTimeout(Duration.ofSeconds(Config.wseTimeOut * 60))       //Config.TIME_OUT
                        .pollingEvery(Duration.ofMillis(100))
                        .ignoring(NoSuchElementException.class)
                        .ignoring(StaleElementReferenceException.class)
                        .withMessage("Timed out after checking for WSE Spinner element for " + Config.wseTimeOut * 60 + " Seconds");


                Function<WebDriver, Boolean> function = new Function<WebDriver, Boolean>() {
                    @Override
					public Boolean apply(WebDriver arg0) {
                        try{
                            if(arg0.findElement(By.xpath(loaderXPath)) != null){
                                Boolean active = arg0.findElement(By.xpath(loaderXPath)).isDisplayed();
                                return !active;
                            }else {
                                System.out.println("Spinner element is not present.");
                                return true;
                            }
                        }catch(Exception e){
                            System.out.println("Spinner element is not present.");
                            return true;
                        }
                    }
                };
                flWait.until(function);

                System.out.println("WSE Loader element is stopped from display.");
            }else{
                Demo1.logger.error("WSE Loader element is not displayed now.");
            }
            Thread.sleep(600);
        }catch (Exception e) {
            Demo1.logger.error("Error: WSE Loader element is not available::" + e.getMessage());
            e.printStackTrace();
        }

        Demo1.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Config.TIME_OUT));
    }
}
