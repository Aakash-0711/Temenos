package Driver;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.function.Function;

public class Config {

	public static String mobileTestExecutioPlatform, androidAppPackageName, androidAppActivityName, defaultAppiumServer,
			defaultURL;
	public static int defaultAppiumPort = 0;
	public static String appiumHomePath, appFilePath;

	public static boolean resetapp;

	public static String BrowName, hostIP, RunNo, productName, resultsWithDateAndTime, gbApplicationName, testRun,
			testedOn, buildNo, mobileServer, Server, BrowserInfo, runParallel;
	public static String runMBTest, runChannelsTest;
	public static String ScreenshotsForFailedSteps, ScreenshotsForPassedSteps;
	public static int TIME_OUT = 0, mobTimeout = 0;
	public static int mobilePort;
	public static int mbTestPriority = 0;
	public static int channelsTestPriority = 0;
	public static int ElementNotPresentWait = 0;
	public static String deviceName, deviceVersion, platform, android_appPackageName, android_appActivityName,
			ChromeEmulatorName;
	public static String appURL, appURL1, appURL2, appURL3, logFolder, logFolder1, logFolder2, appURL4, appURL5;
	public static String skipTestCaseCheckPoint, skipTestRun;
	public static String testware;
	public static String dedicatedBrowserInstance;
	public static String textBoxEvent;
	public static String jsSync;
	public static String downloadType;
	public static Integer OverrideHardCodedWait;
	public static String framewrkPathForFSO;
	public static String applicationServerHomePath;
	public static String responseTimeReportLevel;
	public static String smartClick;
	public static String Mode, istanbulDumpPath, TCDWebDriverEnvVar;
	public static String firefoxVersion, headLessMode, DBName, batchHome, runPriority;
	public static String unixHost, unixUsername, unixPort, unixPassword, tdsDBUsername, tdsDBPassword, tdsDBPortNo,
			tdsSID, export_jboss_home, export_pdb_home, set_path;
	public static String preJSfunction, postJSfunction,TestDataFileLocation;

	public static String chromeBinaryPath;

	static Properties prop = new Properties();
	public static int suiteRetryCounter;
	public static int failedRetryCounter;
	public static String wseLoaderXpath;
	public static int wseTimeOut;
	public static String defaultScreenResolutionNeeded;
	public static boolean wealthRun, wealthWsc, UXPBRun;
	public static boolean replayOfScripts;
	
	public static Double waitForExternalProcessAdjustment;
    public static Integer waitForExternalProcessMaxInSecs, waitForExternalProcessMinInSecs;

	public static void ReadProFile() {

		try {
			// load a properties file
			String currDir = Demo1.curDir;
			InputStream input = new FileInputStream(currDir + "/Config/config.properties");
			prop.load(input);
			// get the property values
			BrowserInfo = getProperty("browserInfo").trim();
			try {
				runPriority = prop.getProperty("runPriority").trim();
			} catch (Exception e) {
				runPriority = "no";
			}
			try {
				runParallel = prop.getProperty("runParallel").trim();
			} catch (Exception e) {
				runParallel = "no";
			}
			try {
				dedicatedBrowserInstance = prop.getProperty("dedicatedBrowserInstance").trim();
			} catch (Exception e1) {
				dedicatedBrowserInstance = "no";
			}

			try {
				OverrideHardCodedWait = Integer.parseInt(getProperty("OverrideHardCodedWait"));
			} catch (Exception e1) {
				OverrideHardCodedWait = 0;
			}
			try {
				deviceName = prop.getProperty("deviceName").trim();
			} catch (Exception e) {
				deviceName = "";
			}
			try {
				deviceVersion = prop.getProperty("deviceVersion").trim();
			} catch (Exception e) {
				deviceVersion = "";
			}
			try {
				mobileTestExecutioPlatform = prop.getProperty("mobileTestExecutioPlatform").trim();
			} catch (Exception e) {
				mobileTestExecutioPlatform = "";
			}
			try {
				androidAppPackageName = prop.getProperty("androidAppPackageName").trim();
			} catch (Exception e) {
				androidAppPackageName = "";
			}
			try {
				androidAppActivityName = prop.getProperty("androidAppActivityName").trim();
			} catch (Exception e) {
				androidAppActivityName = "";
			}
			try {
				defaultAppiumServer = prop.getProperty("defaultAppiumServer").trim();
			} catch (Exception e) {
				defaultAppiumServer = "";
			}
			try {
				defaultAppiumPort = Integer.parseInt(prop.getProperty("defaultAppiumPort").trim());
			} catch (Exception e) {
				defaultAppiumPort = 4723;
			}
			try {
				appiumHomePath = prop.getProperty("appiumHomePath").trim();
			} catch (Exception e) {
				appiumHomePath = "";
			}
			try {
				appFilePath = prop.getProperty("appFilePath").trim();
			} catch (Exception e) {
				appFilePath = "";
			}
			try {
				resetapp = Boolean.parseBoolean(prop.getProperty("resetapp").toLowerCase().trim());
			} catch (Exception e) {
				resetapp = false;
			}
			try {
				applicationServerHomePath = prop.getProperty("applicationServerHomePath").trim();
			} catch (Exception e) {
				applicationServerHomePath = "";
			}
			try {
				responseTimeReportLevel = prop.getProperty("responseTimeReportLevel").trim();
			} catch (Exception e) {
				responseTimeReportLevel = "INFO";
			}

			// framewrkPathForFSO = getProperty("FolderNameForFSO");
			try {
				framewrkPathForFSO = getProperty("FolderNameForFSO");
			} catch (Exception e7) {
				System.out.println("framewrkPathForFSO is not in config");
			}

			try {
				TCDWebDriverEnvVar = getProperty("TCDWebDriverEnvVar");
			} catch (Exception e7) {
//                System.out.println("TCDWebDriverEnvVar is not in config");
			}
			try {
				firefoxVersion = prop.getProperty("firefoxVersion").trim();
			} catch (Exception e) {
				firefoxVersion = "";
			}
			try {
				headLessMode = prop.getProperty("headLessMode").trim();
			} catch (Exception e) {
				headLessMode = "No";
			}
			try {
				DBName = prop.getProperty("DBName").trim();
			} catch (Exception e) {
				DBName = "H2";
			}

			jsSync = getProperty("jsSync");
			Server = getProperty("server").trim();
			RunNo = getProperty("resultsFolderName").trim();
			productName = getProperty("productName").trim();
			resultsWithDateAndTime = getProperty("resultsWithDateAndTime").trim();
			BrowName = getProperty("browser").trim();
			hostIP = getProperty("machineIP").trim();
			downloadType = getProperty("downloadType").trim();
			runMBTest = getProperty("RunMBTest").trim();
			runChannelsTest = getProperty("RunChannelsTest").trim();
			textBoxEvent = getProperty("textBoxEvent").trim();
			mbTestPriority = Integer.parseInt(getProperty("MBTestPriority").trim());
			channelsTestPriority = Integer.parseInt(getProperty("ChannelsTestPriority").trim());
			gbApplicationName = getProperty("applicationName").trim();
			testRun = getProperty("testRun").trim();
			buildNo = getProperty("buildNo").trim();
			TIME_OUT = Integer.parseInt(getProperty("DefaultWaitTime").trim());
			ScreenshotsForFailedSteps = getProperty("screenshotsForFailedSteps").trim();
			ScreenshotsForPassedSteps = getProperty("screenshotsForPassedSteps").trim();
			deviceName = getProperty("DEVICE_NAME").trim();
			deviceVersion = getProperty("DEVICE_VERSION").trim();
			deviceVersion = getProperty("DEVICE_VERSION").trim();
			platform = getProperty("PLATFORM").trim();
			android_appPackageName = getProperty("ANDROID_APP-PACKAGE").trim();
			android_appActivityName = getProperty("ANDROID_APP-ACTIVITY").trim();
			mobileServer = getProperty("MobileServer").trim();
			mobilePort = Integer.parseInt(getProperty("MobilePort").trim());
			ChromeEmulatorName = getProperty("chromeEmulatorName").trim();
			appURL = getProperty("URL").trim();
			appURL1 = getProperty("URL1").trim();
			appURL2 = getProperty("URL2").trim();
			appURL3 = getProperty("URL3").trim();
			appURL4 = getProperty("URL4").trim();
			appURL5 = getProperty("URL5").trim();
			skipTestCaseCheckPoint = getProperty("skipTestCase").trim();
			testware = getProperty("testware").trim();
			preJSfunction = getProperty("preJSfunction").trim();
			postJSfunction = getProperty("postJSfunction").trim();
			TestDataFileLocation = getProperty("TestDataFileLocation").trim();
			//newly added
			 waitForExternalProcessAdjustment = getDoubleProperty("waitForExternalProcessAdjustment");
		     waitForExternalProcessMaxInSecs = getIntegerProperty("waitForExternalProcessMaxInSecs");
		     waitForExternalProcessMinInSecs = getIntegerProperty("waitForExternalProcessMinInSecs");

			try {
				UXPBRun = Boolean.parseBoolean(prop.getProperty("UXPBRun").trim());
			} catch (Exception e) {
				UXPBRun = false;
			}

			try {
				logFolder = getProperty("logFolder").trim();
			} catch (Exception e) {

			}
			try {
				logFolder1 = getProperty("logFolder1").trim();
			} catch (Exception e) {

			}
			try {
				logFolder2 = getProperty("logFolder2").trim();
			} catch (Exception e) {

			}
			try {
				istanbulDumpPath = prop.getProperty("istanbulDumpPath").trim();
			} catch (Exception e) {

			}
			try {
				skipTestRun = prop.getProperty("skipTestRun").trim();
			} catch (Exception e) {
				skipTestRun = "";
			}

			try {
				mobTimeout = Integer.parseInt(getProperty("DefaultWaitTimeMobile").trim());
			} catch (Exception e6) {

				mobTimeout = Integer.parseInt(getProperty("DefaultWaitTime").trim());
				// TODO Auto-generated catch block
				// Uncomment and replace with appropriate logger
				// LOGGER.error(e6, e6);
			}
			try {
				unixPort = prop.getProperty("UnixPort").trim();
			} catch (Exception e6) {
				unixPort = "";
				// TODO Auto-generated catch block
				// Uncomment and replace with appropriate logger
				// LOGGER.error(e6, e6);
			}
			try {
				unixHost = prop.getProperty("UnixHost").trim();
			} catch (Exception e6) {
				// TODO Auto-generated catch block
				// Uncomment and replace with appropriate logger
				// LOGGER.error(e6, e6);
			}
			try {
				unixUsername = prop.getProperty("UnixUserName").trim();
			} catch (Exception e5) {
				// TODO Auto-generated catch block
				// Uncomment and replace with appropriate logger
				// LOGGER.error(e5, e5);
			}
			try {
				unixPassword = prop.getProperty("UnixPassword").trim();
			} catch (Exception e4) {
				// TODO Auto-generated catch block
				// Uncomment and replace with appropriate logger
				// LOGGER.error(e4, e4);
			}

			try {
				export_jboss_home = prop.getProperty("export_jboss_home").trim();
			} catch (Exception e3) {
				// TODO Auto-generated catch block
				// Uncomment and replace with appropriate logger
				// LOGGER.error(e3, e3);
			}
			try {
				export_pdb_home = prop.getProperty("export_pdb_home").trim();
			} catch (Exception e2) {
				// TODO Auto-generated catch block
				// Uncomment and replace with appropriate logger
				// LOGGER.error(e2, e2);
			}
			try {
				set_path = prop.getProperty("set_path").trim();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				// Uncomment and replace with appropriate logger
				// LOGGER.error(e1, e1);
			}
			try {
				defaultURL = prop.getProperty("defaultURL").trim();
			} catch (Exception e) {
				defaultURL = "";
			}
////////////////////////////////////////////////////////////////////////
			try {
				String s = prop.getProperty("suiteRetryCounter").trim();
				if (!s.isEmpty()) {
					suiteRetryCounter = Integer.parseInt(s);
				} else {
					suiteRetryCounter = 0;
				}
			} catch (Exception e) {
				e.printStackTrace();
				suiteRetryCounter = 0;
			}

			try {
				String s = prop.getProperty("failedRetryCounter").trim();
				if (!s.isEmpty()) {
					failedRetryCounter = Integer.parseInt(s);
				} else {
					failedRetryCounter = 0;
				}
			} catch (Exception e) {
				e.printStackTrace();
				failedRetryCounter = 0;
			}
/////////////////////////////////////////////////////////////////////////////////

			try {
				String s = prop.getProperty("ElementNotPresentWait").trim();
				if (!s.isEmpty()) {
					ElementNotPresentWait = Integer.parseInt(s);
				} else {
					ElementNotPresentWait = TIME_OUT;
				}
			} catch (Exception e) {
				ElementNotPresentWait = TIME_OUT;
				e.printStackTrace();
			}
			smartClick = getProperty("UXP.smartclick");

			Mode = getProperty("Mode");

			try {
				wealthRun = Boolean.parseBoolean(prop.getProperty("wealthRun").trim());
			} catch (Exception e) {
				wealthRun = false;
			}

			try {
				wealthWsc = Boolean.parseBoolean(prop.getProperty("wealthWsc").trim());
			} catch (Exception e) {
				wealthWsc = false;
			}

			if (wealthWsc) {
				wseLoaderXpath = prop.getProperty("wseLoaderXpath");
				System.out.println("LOADER XPATH::" + wseLoaderXpath);
				Demo1.logger.info("LOADER XPATH::" + wseLoaderXpath);

				String timeout = prop.getProperty("wseTimeOut");

				if (timeout == null) {
					wseTimeOut = 2; // default value
				} else {
					wseTimeOut = Integer.parseInt(timeout);
				}
				System.out.println("WSE TIMEOUT::" + wseTimeOut * 60 + " Seconds");

				// defaultScreenResolutionNeeded
				try {
					defaultScreenResolutionNeeded = prop.getProperty("defaultScreenResolutionNeeded").trim();
				} catch (Exception exp) {
					defaultScreenResolutionNeeded = "";
				}
				System.out.println("defaultScreenResolutionNeeded::" + defaultScreenResolutionNeeded);
			}

			try {
				replayOfScripts = Boolean.parseBoolean(prop.getProperty("ReplayOfScripts").trim());
			} catch (Exception e) {
				replayOfScripts = false;
			}
			try {
				batchHome = prop.getProperty("BatchHome").trim();
			} catch (Exception exp) {
				batchHome = "";
			}

			try {
				chromeBinaryPath = prop.getProperty("chromeBinaryPath").trim();
			} catch (Exception e) {
				chromeBinaryPath = "";
			}

			try {
				defaultScreenResolutionNeeded = prop.getProperty("defaultScreenResolutionNeeded").trim();
			} catch (Exception exp) {
				defaultScreenResolutionNeeded = "";
			}
		} catch (IOException ex) {
			ex.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "Configure properties file", "Configure properties", ex.getMessage());
		}
	}

	public static String getProperty(String attr) {
		String temp = "";
		try {
			temp = prop.getProperty(attr);
			if (temp == null) {
				Reuse.log("Could not find  a variable in the props with the provided key" + attr);

				return "";
			} else {
				return temp.trim();
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return temp;
	}
	
	private static Double getDoubleProperty(String propertyName)
    {
        return getProperty( propertyName, x -> Double.valueOf( x ) );
    }
    
    private static Integer getIntegerProperty(String propertyName)
    {
        return getProperty( propertyName, x -> Integer.valueOf( x ) );
    }
    
    private static <T> T getProperty(String propertyName, Function<String, T> conversionFunction)
    {
        String propertyValue = prop.getProperty( propertyName );
        
        if ( propertyValue == null )
        {
            return null;
        }
            
        propertyValue = propertyValue.trim();
        
        if ( propertyValue.isEmpty() )
        {
            log("Property " + propertyName + " is empty after trimming, returning null");

            return null;
        }
        
        try
        {
            T result = conversionFunction.apply( propertyValue );
            
            log("Processed Property " + propertyName + "=" + result);
            
            return result;
        }
        catch (Exception ex)
        {
            log("Error converting " + propertyName + "=" + propertyValue + ": " + ex.getMessage());
        }
        
        return null;
    }
    
    private static void log(String message)
    {
        if ( Driver.Demo1.logger != null )
            Driver.Demo1.logger.info( message );
        
        Reuse.log( message );
    }
}
