package Driver;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;

import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.monitorjbl.xlsx.StreamingReader;

public class ReadExceiReport {

    public static void main()  {
        // TODO Auto-generated method stub

        String curDir = System.getProperty("user.dir");
        System.out.println("CURRENT DIR:::" + curDir);

        String testwareFolder = "";
        String threadName = (new File(curDir)).getName();

        Path path = Paths.get(curDir);

        if (path.getParent().endsWith("ParallelPipe") && path.getParent().getParent().endsWith("ParallelRun")) {
            testwareFolder = path.getParent().getParent() + File.separator + "Testwares" + File.separator + threadName
                    + File.separator + "Testware";
        } else {
            testwareFolder = path + File.separator + "TestWare";
        }

        String excelFilePath = testwareFolder + File.separator + "Testware.xlsx";
        System.out.println(
                "TestCase details are fetched from TestWare::" + excelFilePath + "  for creating the IndexHtml file.");

        /*
         * FileInputStream inputStream = new FileInputStream(new
         * File(excelFilePath));
         */
        Workbook workbook = null;
        ZipSecureFile.setMinInflateRatio(0.0d);
        
        workbook = StreamingReader.builder().rowCacheSize(50) // number of rows to keep in memory
		            .bufferSize(4096) // path
		            .open(new File(excelFilePath)); // InputStream or File for XLSX file (required)
        
        Sheet firstSheet = workbook.getSheetAt(1);
        String TestCaseid = "";
        String FunctionalIndex = "";
        String Complexity = "";
        String ActualTestCaseId = "";
        String description = "", Navigation = "", reportGroup = "";

        Iterator<Row> iterator = firstSheet.iterator();
        iterator.next();
        int a = 0;

        try {

            while (iterator.hasNext()) {
                Row nextRow = iterator.next();
                Iterator<Cell> cellIterator = nextRow.cellIterator();

                int count = -1;

                // updated to fetch all TestPlan details - mahesh
                while (cellIterator.hasNext()) {
                    count++;
                    Cell cell = cellIterator.next();

                    System.out.print("COLUMN:::" + count);
                    if (count == 0) {

                        if (isCellEmpty(cell)) {
                            TestCaseid = "";
                            break;
                        } else {
                            TestCaseid = cell.getStringCellValue();
                            System.out.println("::" + TestCaseid);
                        }

                        /*
                         * TestCaseid =
                         * cellIterator.next().getStringCellValue();
                         */
                    } else if (count == 1) {

                        if (isCellEmpty(cell)) {
                            FunctionalIndex = "";
                        } else {
                            FunctionalIndex = cell.getStringCellValue();
                        }
                        System.out.println("::" + FunctionalIndex);

                        /*
                         * FunctionalIndex =
                         * cellIterator.next().getStringCellValue();
                         */
                    } else if (count == 2) {

                        if (isCellEmpty(cell)) {
                            description = "";
                        } else {
                            description = cell.getStringCellValue();
                        }

                        System.out.println("::" + description);
                        /*
                         * description =
                         * cellIterator.next().getStringCellValue();
                         */
                    } else if (count == 3) {

                        if (isCellEmpty(cell)) {
                            Complexity = "";
                        } else {
                            Complexity = cell.getStringCellValue();
                        }

                        System.out.println("::" + Complexity);
                        /*
                         * Complexity =
                         * cellIterator.next().getStringCellValue();
                         */
                    } else if (count == 4) {

                        if (isCellEmpty(cell)) {
                            Navigation = "";
                        } else {
                            Navigation = cell.getStringCellValue();
                        }
                        System.out.println("::" + Navigation);
                        /*
                         * Navigation =
                         * cellIterator.next().getStringCellValue();
                         */
                    } else if (count == 5) {
                        // do nothing
                    } else if (count == 6) {
                        // do nothing
                    } else if (count == 7) {
                        // do nothing
                        System.out.println();
                    } else if (count == 8) {

                        if (isCellEmpty(cell)) {
                            reportGroup = "";
                        } else {
                            reportGroup = cell.getStringCellValue();
                        }
                        System.out.println("::" + reportGroup);
                        /*
                         * reportGroup =
                         * cellIterator.next().getStringCellValue();
                         */
                    } else if (count > 8) {
                        break;
                    }
                }

                if (TestCaseid.startsWith("TC")) {
                    if (TestCaseid.contains("~")) {
                        a = TestCaseid.indexOf("~");
                        ActualTestCaseId = TestCaseid.substring(0, a);
                    } else {
                        ActualTestCaseId = TestCaseid;
                    }

                    if (!(CreateIndexFile.functionalityIndexDetailsMap.containsKey(ActualTestCaseId))) {
                        CreateIndexFile.functionalityIndexDetailsMap.put(ActualTestCaseId, FunctionalIndex);
                        CreateIndexFile.criticalityDetailsMap.put(ActualTestCaseId, Complexity);
                        CreateIndexFile.reportGroupDetailsMap.put(ActualTestCaseId, reportGroup);

                        System.out.println("TestCase Details:::" + ActualTestCaseId + ":::" + FunctionalIndex + ":::"
                                + Complexity + ":::" + reportGroup);
                    }

                } else if (TestCaseid.isEmpty()) {
                    break;
                }
            }
        } catch (Exception E) {
            System.out.println("Read Testware.xlsx Exception::" + E);
        }
        finally {
			try {
				workbook.close();
			} catch (IOException e) {
			}
		}

    }

    public static boolean isCellEmpty(final Cell cell) {
        if ((cell == null) || (cell.getCellType() == CellType.BLANK) || (cell.getCellType() == CellType.STRING && cell.getStringCellValue().trim().isEmpty())) {
            return true;
        }

        return false;
    }
}
