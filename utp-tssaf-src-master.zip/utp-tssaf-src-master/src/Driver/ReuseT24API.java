package Driver;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.endsWith;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.isA;
import static org.hamcrest.Matchers.isIn;
import static org.hamcrest.Matchers.isOneOf;
import static org.hamcrest.Matchers.lessThanOrEqualTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;
import static uk.co.datumedge.hamcrest.json.SameJSONAs.sameJSONAs;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.IOUtils;
import org.hamcrest.Matchers;
import org.hamcrest.core.Every;
import org.json.JSONArray;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.utils.ExcelDataConfig;
import com.utils.GlobalConfig;
import com.utils.ReusableTestDataFunctions;

import cucumber.api.Delimiter;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Cookie;
import io.restassured.parsing.Parser;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.QueryableRequestSpecification;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.SpecificationQuerier;

public class ReuseT24API {

	public static RequestSpecification request;
	public static Response response;
	public static String requesturi;
	public static String requestJsonContents;
	public static Map<String, String> queryParameters;
	public static Map<String, String> queryParametersTextFile;

	public static GlobalConfig globalConfig;
	public static GlobalConfig globalConfigSMBBusinessLogin;

	private String authToken = null;
	private String authTokenFilePath = null;
	

	static ReusableTestDataFunctions resuableObject = new ReusableTestDataFunctions();

	public static HashMap<String, Object> bundle = new HashMap<>();
	
	public static ArrayList<String> responseTime;
	
	public static String Endpoint;

	public static void API_SetUp_KeyCloak(String uri, String path) {
		try {
			RestAssured.defaultParser = Parser.JSON;
			request = RestAssured.given().log().all();
			request.urlEncodingEnabled(true);
			request.baseUri(uri);
			request.contentType(ContentType.URLENC);

			if (path.contains("auto@"))
				requesturi = Reuse.updateRuntimeValuesInOfs(path);
			else
				requesturi = path;

			if (requesturi.contains(" "))
				requesturi = requesturi.replaceAll(" ", "%20");
            
			Endpoint=uri+requesturi;
            System.out.println(Endpoint);
			//System.out.println(requesturi);

			queryParameters = new HashMap<>();
			queryParametersTextFile = new HashMap<>();

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To start api session", "API seesion of " + requesturi + "is started",
					"API seesion started successfully");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To start api session", "API seesion of " + path + "is not started",
					"API seesion not successfully started");
		}
	}

	public static void API_setUp(String uri, String path, String userName, String password) {
		try {

			RestAssured.defaultParser = Parser.JSON;
			request = RestAssured.given().log().all();
			request.urlEncodingEnabled(false);
			request.baseUri(uri);
			// request.basePath(path);
			request.auth().basic(userName, password);

			if (path.contains("auto@"))
				requesturi = Reuse.updateRuntimeValuesInOfs(path);
			else
				requesturi = path;

			if (requesturi.contains(" "))
				requesturi = requesturi.replaceAll(" ", "%20");
			Endpoint=uri+requesturi;
            System.out.println(Endpoint);
			//System.out.println(requesturi);

			queryParameters = new HashMap<>();
			queryParametersTextFile = new HashMap<>();

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To start api session", "API seesion of " + requesturi + "is started",
					"API seesion started successfully");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To start api session", "API seesion of " + path + "is not started",
					"API seesion not successfully started");
		}
	}

	// @Given("^the request path is \"(.*)\"$")
	public static void givenRequest(String path) throws Throwable {
		requesturi = path;
	}

	// @When("^a \"(GET|POST|PUT|PATCH|DELETE)\" request is sent$")
	public static void API_whenISendTheRequest(String method) throws Throwable {
		try {
			request.queryParams(queryParameters);
			switch (method) {
			case "GET":
				response = request.get(requesturi);
				break;
			case "PUT":
				response = request.put(requesturi);
				break;
			case "POST":
				response = request.post(requesturi);
				break;
			case "DELETE":
				response = request.delete(requesturi);
				break;
			case "PATCH":
				response = request.patch(requesturi);
				break;
			default:
				break;
			}

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To request api ", "API request of " + method + "should be sent",
					"API request sent successfully");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To request api ", "API request of " + method + "is should be sent",
					"API request not sent successfully");
		}
	}

	// @Then("^the response status code should be (\\d+)$")
	public static void API_theResponseStatusEquals(int status) throws Throwable {
		// assertEquals(status, response.statusCode());

		try {
			if (status == response.statusCode()) {
				System.out.println("Response code =" + response.statusCode());
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "To verify the response code ", "API response code should be equal to" + status,
						"API response code " + response.statusCode() + " is equal to expected status code" + status);
			} else {
				System.out.println("Response code =" + response.statusCode());
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "To verify the response code ", "API response code should be equal to" + status,
						"API response code " + response.statusCode() + " is not equal to expected status code"
								+ status);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Reuse.log(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To verify the response code ", "API response code should be equal to" + status,
					"API response code " + response.statusCode() + " is not equal to expected status code" + status
							+ "and failed with" + e.getMessage());
		}

	}
	
	public static void API_GetResponseTime() {

		try {   
			long time;
			String restime = null;
			if(response.statusCode()==200 || response.statusCode()==201 || response.statusCode()==400
					|| response.statusCode()== 404 | response.statusCode()== 405) {
				time = response.getTime();
				restime = String.valueOf(time);
				System.out.println("Response Time: " + restime);
			}
			responseTime = new ArrayList<String>();
			responseTime.add(Endpoint);
			responseTime.add(restime);
			StringBuffer br=new StringBuffer();
			
			FileWriter fw = new FileWriter(Demo1.curDir + File.separator + "TestData" + File.separator +"ResponseTime.csv", true);
            BufferedWriter writer = new BufferedWriter(fw);
            br.append(responseTime.get(0)+ "," + responseTime.get(1));
            writer.write(br.toString());
            writer.newLine();
            writer.close();
            Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To capture the response time ","API response time should be captured","API response Time is " + response.getTime());
		} catch (Exception e) {
			e.printStackTrace();
			Reuse.log(e);
			 Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "To capture the response time ","API response time should be captured","API response Time is not captured");
          
		}

	}

	public static void API_theResponseTimeGreater(int status) throws Throwable {
		// assertEquals(status, response.statusCode());

		try {
			if (status > response.getTime()) {
				System.out.println("Response code =" + response.getTime());
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "To verify the response time ", "API response code should be greater to" + status,
						"API response code " + response.getTime() + " is greater to expected status code" + status);
			} else {
				System.out.println("Response code =" + response.getTime());
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "To verify the response time ", "API response code should be greater to" + status,
						"API response code " + response.getTime() + " is not greater to expected status code" + status);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Reuse.log(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To verify the response code ", "API response code should be equal to" + status,
					"API response code " + response.statusCode() + " is not equal to expected status code" + status
							+ "and failed with" + e.getMessage());
		}

	}

	public static void API_theResponseTimeLesser(int status) throws Throwable {
		// assertEquals(status, response.statusCode());

		try {
			if (status < response.getTime()) {
				System.out.println("Response code =" + response.getTime());
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "To verify the response time ", "API response code should be lesser to" + status,
						"API response code " + response.getTime() + " is lesser to expected status code" + status);
			} else {
				System.out.println("Response code =" + response.getTime());
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "To verify the response time ", "API response code should be lesser to" + status,
						"API response code " + response.getTime() + " is not lesser to expected status code" + status);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Reuse.log(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To verify the response code ", "API response code should be equal to" + status,
					"API response code " + response.statusCode() + " is not equal to expected status code" + status
							+ "and failed with" + e.getMessage());
		}

	}

	public static void API_VerifyjsonDateProp(String property, String ExpectedValue) {
		// response.then().body(property, not(hasKey(property)));

		try {
			String s1 = null;
			if (response.getContentType().contains("xml")) {
				s1 = xmlResponseValidation(property);

			} else {

				s1 = response.jsonPath().getString(property);
			}

			if (ExpectedValue.contains("auto@")) {
				ExpectedValue = Reuse.updateRuntimeValuesInOfs(ExpectedValue);
			}

			System.out.println(s1 + ":::::" + ExpectedValue);

			if (validateJavaDate(s1)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "To verify property is  Equals to expected date value",
						" property should  Equals to expected date value",
						"The property is  Equals to expected date value" + s1 + "=" + ExpectedValue);
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "To verify property is Equals to expected value",
						" property should Equals to expected value",
						"The property is NOT Equals to expected date value" + s1 + "not =" + ExpectedValue);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To verify property is Equals to expected date value",
					" property should Equals to expected date value",
					"The property is NOT Equals to expected date value");

		}

	}

	public static boolean validateJavaDate(String strDate) {
		/* Check if date is 'null' */
		if (strDate.trim().equals("")) {
			return true;
		}
		/* Date is not 'null' */
		else {
			/*
			 * Set preferred date format, For example MM-dd-yyyy,
			 * MM.dd.yyyy,dd.MM.yyyy etc.
			 */
			SimpleDateFormat sdfrmt = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			sdfrmt.setLenient(false);

			/*
			 * Create Date object parse the string into date
			 */
			try {
				Date javaDate = sdfrmt.parse(strDate);
				System.out.println(strDate + " is valid date format");
			}
			/* Date format is invalid */
			catch (ParseException e) {
				System.out.println(strDate + " is Invalid Date format");
				return false;
			}
			/* Return true if date format is valid */
			return true;
		}

	}

	/*
	 * public static void API_AcceptOverrides(String method){
	 *
	 * try {
	 *
	 * if( response.statusCode()== 400){
	 *
	 *
	 * if( response.jsonPath().get("override") != null){
	 *
	 * response.getHeaders();
	 *
	 * JSONObject override_header_obj = new JSONObject(response.getHeaders());
	 *
	 *
	 * JSONObject obje = new
	 * JSONObject(response.jsonPath().get("override").toString()); JSONArray
	 * overrideArray = obje.getJSONArray("overrideDetails");
	 *
	 * for (Object object : overrideArray) { if ( object instanceof JSONObject )
	 * { ((JSONObject) object).put("responseCode", "YES"); } }
	 * obje.put("overrideDetails", overrideArray);
	 * override_header_obj.put("override", obje);
	 *
	 * JSONObject bodyObject = new JSONObject(); JSONObject json = new
	 * JSONObject(); json.put("body", bodyObject); json.put("header",
	 * override_header_obj);
	 *
	 * request.content(json.toString());
	 *
	 * } }
	 *
	 * switch (method) { case "GET": response = request.get(requesturi); break;
	 * case "PUT": response = request.put(requesturi); break; case "POST":
	 * response = request.post(requesturi); break; case "DELETE": response =
	 * request.delete(requesturi); break; case "PATCH": response =
	 * request.patch(requesturi); break; default: break; }
	 *
	 * Demo1.gbTestCaseStatus = "Pass"; Demo1.ReportStep(2, "To request api ",
	 * "API request of " + method + "should be sent",
	 * "API request sent successfully");
	 *
	 * } catch (Exception e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); Reuse.log(e); Demo1.gbTestCaseStatus = "Fail";
	 * Demo1.ReportStep(2, "To request api ", "API request of " + method +
	 * "is should be sent", "API request not sent successfully"); }
	 *
	 *
	 *
	 * }
	 *
	 *
	 */

	@SuppressWarnings("deprecation")
	public static void API_AcceptOverrides(String method, String payLoad) {

		try {

			if (response.statusCode() == 400) {

				if (response.jsonPath().get("override") != null) {


					ObjectMapper objectMapper = new ObjectMapper();
					JSONObject obje1 = null;
					JSONObject jsonPayload1 = null;
					try {
						String json = objectMapper.writeValueAsString(response.jsonPath().get("override"));
						System.out.println(json);
						
						//To handle overrides if type contains warning
						JsonParser parser = new JsonParser() ;
					    JsonObject jsonObj = (JsonObject) parser.parse(json);
					    JsonArray objectsize = (JsonArray) jsonObj.get("overrideDetails");
					    for (int i = 0; i < objectsize.size(); i++) {
					        JsonObject devices = (JsonObject) objectsize.get(i);
					        JsonElement jsonElement = devices.get("type");
					        if(jsonElement.toString().contains("Warning")) {
					        devices.addProperty("responseCode", "RECEIVED");
					        }
					    }   
					    System.out.println(jsonObj.toString());
						obje1 = new JSONObject(jsonObj.toString());

						jsonPayload1 = new JSONObject();
						jsonPayload1.put("override", obje1);

						System.out.println(jsonPayload1);

					} catch (JsonProcessingException e) {
						e.printStackTrace();
					}

					// String overrideHeader =
					// objectMapper.writeValueAsString(response.jsonPath().get("header"));
					// JSONObject override_header_obj = new
					// JSONObject(overrideHeader);

					String payload = "";
					try {

						// request.body(IOUtils.toString(new
						// FileInputStream(System.getProperty("user.dir") +
						// "/TestData/" + body)));

						payload = IOUtils
								.toString(new FileInputStream(System.getProperty("user.dir") + "/TestData/" + payLoad));
					} catch (IOException e) {
						e.printStackTrace();
					}
					JSONObject jsonPayload = new JSONObject(payload);
					jsonPayload.put("header", jsonPayload1);
					jsonPayload.put("body", jsonPayload.get("body"));

					System.out.println(jsonPayload);

					String jsonContent = jsonPayload.toString();

					if (jsonContent.contains("auto@")) {
						jsonContent = Reuse.updateRuntimeValuesInOfs(jsonContent);
					}

					request.body(jsonContent);


				}
			}

			switch (method) {
			case "GET":
				response = request.get(requesturi);
				break;
			case "PUT":
				response = request.put(requesturi);
				break;
			case "POST":
				response = request.post(requesturi);
				break;
			case "DELETE":
				response = request.delete(requesturi);
				break;
			case "PATCH":
				response = request.patch(requesturi);
				break;
			default:
				break;
			}

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To request api ", "API request of " + method + "should be sent",
					"API request sent successfully");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To request api ", "API request of " + method + "is should be sent",
					"API request not sent successfully");
		}

	}

	// @Given("^query parameter \"([^\"]*)\" is set to \"([^\"]*)\"$")
	public static void API_givenAQueryParameter(String queryParameterName, String queryParameterValue) {
		try {

			if (queryParameterValue.contains("auto@"))
				queryParameterValue = Reuse.updateRuntimeValuesInOfs(queryParameterValue);

			queryParameters.put(queryParameterName, queryParameterValue);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To store the query parameter ", "Store Query parameter name and value",
					"Stored Query parameter name and value");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To store the query parameter ", "Store Query parameter name and value",
					"Store Query parameter name and value is not succesful");
		}
	}

	public static void API_givenAQueryParameterFromStored(String queryParameterName, String queryParameterValue) {
		try {
			String bundleValueStore = resuableObject.fetchKeyValues(queryParameterValue);

			queryParameters.put(queryParameterName, bundleValueStore);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To store the query parameter ", "Store Query parameter name and value",
					"Stored Query parameter name and value");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To store the query parameter ", "Store Query parameter name and value",
					"Store Query parameter name and value is not succesful");
		}
	}

	public static String givenLoginClaimsToken(String claimsTokenKey) throws Throwable {
		String token = null;
		try {

			JsonPath responseBody = JsonPath.from(response.body().asString());

			token = responseBody.getString(claimsTokenKey);

			globalConfig.setToken(token);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To get claim token from response ", "To get claim token from response and store token",
					"claim token from response and store token is succesful");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To get claim token from response ", "To get claim token from response and store token",
					"claim token from response and store token is not succesful");
		}

		return token;
	}

	// @Given("^get the identity claims token value is set for header key
	// \"(.*)\"$")
	public static void givenClaimsTokenValueSetBundleValue(String headerKey) throws Throwable {

		try {
			System.out.println("CLAIMSTOKEN_VALUE: " + globalConfig.getToken());
			request.header(headerKey, globalConfig.getToken());

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To set token in header ", "Token should be set in request header",
					"Token is set in the header of the request");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To set token in header ", "Token should be set in request header",
					"Token is not set in the header of the request");
		}

	}

	// @Given("^Application response api JSessionID cookies value is set to
	// \"(.*)\"$")
	public static void givenCookiesValue(String cookiesValue) throws Throwable {

		try {
			Cookie cookie = response.getDetailedCookie(cookiesValue);
			String JsessionID = cookie.getValue();
			globalConfig.setCookie(JsessionID);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To get cookiesValue from response ",
					"To get cookiesValue from response and store value",
					"cookiesValue from response and store value is succesful");

		} catch (Exception e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To get cookiesValue from response ",
					"To get cookiesValue from response and store value",
					"cookiesValue from response and store value is not succesful");
		}
	}

	// @Given("^get the cookies JSessionId value is set for header key
	// \"(.*)\"$")
	public static void givenCookiesJSessionIdValueSetBundleValue(String headerKey) throws Throwable {

		try {
			System.out.println("JESSION_ID VALUE : " + globalConfig.getCookie());
			request.header(headerKey, "JSESSIONID=" + globalConfig.getCookie());

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To set Jsessionid in header ", "Jsessionid should be set in request header",
					"Jsessionid is set in the header of the request");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To set Jsessionid in header ", "Jsessionid should be set in request header",
					"Jsessionid is not set in the header of the request");

		}

	}

	// @Given("^login shared secret SME business banking token set in global
	// config is set to \"(.*)\"$")
	public void givenLoginBusinessBankingToken(String smeTokenKey) throws Throwable {

		JsonPath responseBody = JsonPath.from(response.body().asString());

		String smeLoginToken = responseBody.getString(smeTokenKey);

		System.out.println("smeLoginToken Value : " + smeLoginToken);

		globalConfigSMBBusinessLogin.setSmeUserLoginToken(smeLoginToken);
	}

	// @Given("^get the identity SME business banking token value is set for
	// header key \"(.*)\"$")
	public void givenSMEBusinessBankingTokenValueSetBundleValue(String headerKey) throws Throwable {

		System.out.println("CLAIMSTOKENVALUE: Token value for SMB Business Secret Login : "
				+ globalConfigSMBBusinessLogin.getSmeUserLoginToken());
		request.header(headerKey, globalConfigSMBBusinessLogin.getSmeUserLoginToken());

	}

	// @Given("^the request body is set to the contents of \"(.*)\"$")

	public static void API_givenRequestBodyByFile(String body) {
		try {

			String jsonContent = IOUtils
					.toString(new FileInputStream(System.getProperty("user.dir") + "/TestData/" + body));

			if (jsonContent.contains("auto@")) {
				jsonContent = Reuse.updateRuntimeValuesInOfs(jsonContent);
			}

			request.body(jsonContent);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To set body of the content to file ", "To set body of the content to file ",
					"To set body of the content to file sucessfull");

		} catch (Exception e) {
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To set body of the content to file ", "To set body of the content to file ",
					"To set body of the content to file not sucessfull");

		}
	}

	// @Given("^request header \"([^\"]*)\" is set to \"(.*)\"$")
	public static void API_givenRequestHeader(String headerName, String headerValue) throws Throwable {
		try {

			if (headerValue.contains("auto@"))
				headerValue = Reuse.updateRuntimeValuesInOfs(headerValue);

			request.header(headerName, headerValue);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To set headername and its headervalue in header ",
					"headername and its headervalue should be set in request header",
					"headername and its headervalue is set in the header of the request");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To set headername and its headervalue in header ",
					"headername and its headervalue should be set in request header",
					"headername and its headervalue is set in the header of the request is not sucessfull");
		}
	}

	// @Given("^set security session cookie response api value is set in global
	// config value$")
	public static void givenSecuritySessionCookiesValue() throws Throwable {

		try {
			Map<String, String> allCookies = response.getCookies();

			System.out.println("myCookies list value : " + allCookies);

			globalConfig.setSecuritySessionCookie(allCookies.toString());

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To get cookiesvalue from response ", "To get cookiesvalue from response and store",
					"To get cookiesvalue from response and store is successfull");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To get cookiesvalue from response ", "To get cookiesvalue from response and store",
					"To get cookiesvalue from response and store is not successfull");
		}

	}

	/*
	 * Security Session Cookie get for Infinity Onboarding App
	 */

	// @Given("^get the security session cookie response api value is set for
	// header key \"(.*)\"$")
	public static void givenSecuritySessionCookiesValueSetBundleValue(String headerKey) throws Throwable {

		try {
			System.out.println("Cookie Value to be set in header : " + globalConfig.getSecuritySessionCookie());
			request.header(headerKey, globalConfig.getSecuritySessionCookie());

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To get cookiesvalue from stored value ", "To get cookiesvalue ",
					"To get cookiesvalue and set in the header");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To get cookiesvalue from stored value ", "To get cookiesvalue ",
					"To get cookiesvalue and set in the header is not successful");
		}

	}

	// @Then("^JSON property \"([^\"]*)\" should be null$")
	public static void API_jsonPropertyShouldBeNull(String property) {
		// response.then().body(property, nullValue());

		try {

			String s1 = null;
			if (response.getContentType().contains("xml")) {
				s1 = xmlResponseValidation(property);

			} else {
				s1 = response.jsonPath().getString(property);
			}
			System.out.println(s1);
			if (s1 == null) {

				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "To verify property is null", " property should be null",
						"The property is null" + s1);

			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "To verify property is null", " property should be null",
						"The property is not null" + s1);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To verify property is null", " property should be null", "The property is not null");
		}

	}

	public static void API_jsonPropertyShouldBeNotNull(String property) {

		try {

			String s1 = null;
			if (response.getContentType().contains("xml")) {
				s1 = xmlResponseValidation(property);

			} else {

				response.then().body(property, notNullValue());
			}
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To verify property is not null", " property should be not null",
					"The property is not null");

		} catch (Exception e1) {
			e1.printStackTrace();

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To verify property isnot  null", " property should be not null",
					"The property is null");
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e1, e1);
		}

	}

	// @Then("^JSON property \"([^\"]*)\" should not exist$")
	public static void API_jsonPropertyShouldNotExist(String property) {
		// response.then().body(property, not(hasKey(property)));

		try {

			String s1 = null;
			if (response.getContentType().contains("xml")) {
				s1 = xmlResponseValidation(property);

			} else {
				s1 = response.jsonPath().getString(property);

			}

			System.out.println(s1);

			if (s1 != null) {

				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "To verify property is NOT EXIST", " property should NOT EXIST",
						"The property is EXIST");

			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "To verify property is NOT EXIST", " property should NOT EXIST",
						"The property is EXIST");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			// Reuse.log(e);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To verify property is NOT EXIST", " property should not exist",
					"The property is not exist");
		}

	}

	public static void API_jsonPropertyShouldExist(String property) {
		// response.then().body(property, not(hasKey(property)));

		try {

			String s1 = null;
			if (response.getContentType().contains("xml")) {
				xmlResponseValidation(property);

			} else {
				s1 = response.jsonPath().getString(property);
			}

			System.out.println(s1);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To verify property is  EXIST", " property should  exist", "The property is  exist");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To verify property is EXIST", " property should EXIST", "The property is NOT EXIST");
		}

	}

	public static String xmlResponseValidation(String property) {
		String value = "";

		try {
			System.out.println("xml Response: Entered validation criteria for XML");
			String resp = response.asString();

			try (BufferedWriter writer = new BufferedWriter(
					new FileWriter(System.getProperty("user.dir") + "/TestData/XMLFILE.xml"))) {
				writer.write(resp);
			} catch (IOException e) {
				// Handle the exception
			}

			String[] arrPar = property.split("\\.");

			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			// an instance of builder to parse the specified xml file
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(System.getProperty("user.dir") + "/TestData/XMLFILE.xml");

			doc.getDocumentElement().normalize();
			System.out.println("Root element: " + doc.getDocumentElement().getNodeName());
			NodeList nodeList = doc.getElementsByTagName(arrPar[0]);
			// nodeList is not iterable, so we are using for loop

			if (property.contains("TextContent")) {
				Node node = nodeList.item(Integer.parseInt(arrPar[1]));
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) node;

					value = eElement.getElementsByTagName(arrPar[2]).item(Integer.parseInt(arrPar[3])).getTextContent();
				}
			} else {

				Node node = nodeList.item(Integer.parseInt(arrPar[1]));
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) node;

					value = eElement.getElementsByTagName(arrPar[2]).item(Integer.parseInt(arrPar[3])).getAttributes()
							.getNamedItem(arrPar[4]).getNodeValue();
				}

			}

			System.out.println("Valuee" + value);

			// System.out.println(
			// doc.getElementsByTagName("value").getLength());
		} catch (DOMException e) {
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
		}
		return value;

	}

	public static void API_xmlPropertyShouldExist(String property) {
		// response.then().body(property, not(hasKey(property)));

		try {

			String s1 = null;
			if (response.getContentType().contains("xml")) {
				xmlResponseValidation(property);

			} else {
				s1 = response.jsonPath().getString(property);
			}

			System.out.println("Value::" + s1);
			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To verify property is  EXIST", " property should  exist", "The property is  exist");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To verify property is EXIST", " property should EXIST", "The property is NOT EXIST");
		}

	}

	public static void API_VerifyjsonProperty(String property, String ExpectedValue) {
		// response.then().body(property, not(hasKey(property)));

		try {

			if (ExpectedValue.contains("auto@")) {
				ExpectedValue = Reuse.updateRuntimeValuesInOfs(ExpectedValue);
			}
			String s1 = null;
			if (response.getContentType().contains("xml")) {
				System.out.println("XML content type");
				s1 = xmlResponseValidation(property);

			} else {

				//if array element is used
				if(property.contains("[x]")){
					int i=0;
					while(i>=0) {
						String finalXpath = property.replace("[x]", "[" + i + "]");
						System.out.println("FINAL UPDATED JSON PATH::" + finalXpath);
						s1 = response.jsonPath().getString(finalXpath);
						if (s1.equals(ExpectedValue)) {
							break;
						}
						i++;
					}
				}else{
					s1 = response.jsonPath().getString(property);
				}
				
				
			}

			System.out.println(s1 + ":::::" + ExpectedValue);

			if (ExpectedValue.equalsIgnoreCase(s1)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "To verify property is Equals to expected value",
						" property should  Equals to expected value",
						"The property is  Equals to expected value " + s1 + "=" + ExpectedValue);
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "To verify property is Equals to expected value",
						" property should Equals to expected value",
						"The property is NOT Equals to expected value " + s1 + "not =" + ExpectedValue);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To verify property is Equals to expected value",
					" property should Equals to expected value", "The property is NOT Equals to expected value");

		}

	}
	
	public static void API_VerifyjsonPropertyContains(String property, String ExpectedValue) {
		// response.then().body(property, not(hasKey(property)));

		try {

			if (ExpectedValue.contains("auto@")) {
				ExpectedValue = Reuse.updateRuntimeValuesInOfs(ExpectedValue);
			}
			String s1 = null;
			if (response.getContentType().contains("xml")) {
				System.out.println("XML content type");
				s1 = xmlResponseValidation(property);

			} else {

				//if array element is used
				if(property.contains("[x]")){
					int i=0;
					while(i>=0) {
						String finalXpath = property.replace("[x]", "[" + i + "]");
						System.out.println("FINAL UPDATED JSON PATH::" + finalXpath);
						s1 = response.jsonPath().getString(finalXpath);
						if (s1.equals(ExpectedValue)) {
							break;
						}
						i++;
					}
//					for (int i = 0; i < 100; i++) {
//						String finalXpath = property.replace("[x]", "[" + i + "]");
//						System.out.println("FINAL XPATH UPDATED::" + finalXpath);
//						s1 = response.jsonPath().getString(finalXpath);
//					}
				}else{
					s1 = response.jsonPath().getString(property);
				}
			}

			System.out.println(s1 + ":::::" + ExpectedValue);

			if (s1.contains(ExpectedValue)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "To verify property value contains the expected value",
						"property value should contains the expected value",
						"property value contains the expected value " + s1 + "=" + ExpectedValue);
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "To verify property value contains the expected value",
						"property value should contains the expected value",
						"The property is NOT Equals to expected value " + s1 + "not =" + ExpectedValue);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To verify property value contains the expected value",
					"property value should contains the expected value", "The property is NOT Equals to expected value");

		}
	}
	
	public static void API_VerifyjsonPropertyByRegEx(String property, String ExpectedValue, String regEx) {
		try {
			if (ExpectedValue.contains("auto@")) {
				ExpectedValue = Reuse.updateRuntimeValuesInOfs(ExpectedValue);
			}
			String s1 = null;
			String s2=null;
			if (response.getContentType().contains("xml")) {
				System.out.println("XML content type");
				s1 = xmlResponseValidation(property);

			} else {
				//if array element is used
				if(property.contains("[x]")){
					int i=0;
					while(i>=0) {
						String finalXpath = property.replace("[x]", "[" + i + "]");
						System.out.println("FINAL UPDATED JSON PATH::" + finalXpath);
						s1 = response.jsonPath().getString(finalXpath);
						if (s1.replaceAll("["+regEx+"]", "").equals(ExpectedValue)) {
							break;
						}
						i++;
					}
				}else{
					s1 = response.jsonPath().getString(property);
				}
				 
				s2 = s1.replaceAll("["+regEx+"]", "");
				
			}

			System.out.println(s2 + ":::::" + ExpectedValue);

			if (ExpectedValue.equalsIgnoreCase(s2)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "To verify property is Equals to expected value",
						" property should  Equals to expected value",
						"The property is  Equals to expected value " + s2 + "=" + ExpectedValue);
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "To verify property is Equals to expected value",
						" property should Equals to expected value",
						"The property is NOT Equals to expected value " + s2 + "not =" + ExpectedValue);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To verify property is Equals to expected value",
					" property should Equals to expected value", "The property is NOT Equals to expected value");

		}

	}
	
	public static void API_VerifyjsonPropertyContainsByRegEx(String property, String ExpectedValue, String regEx) {
		try {
			if (ExpectedValue.contains("auto@")) {
				ExpectedValue = Reuse.updateRuntimeValuesInOfs(ExpectedValue);
			}
			String s1 = null;
			String s2=null;
			if (response.getContentType().contains("xml")) {
				System.out.println("XML content type");
				s1 = xmlResponseValidation(property);

			} else {
				//if array element is used
				if(property.contains("[x]")){
					int i=0;
					while(i>=0) {
						String finalXpath = property.replace("[x]", "[" + i + "]");
						System.out.println("FINAL UPDATED JSON PATH::" + finalXpath);
						s1 = response.jsonPath().getString(finalXpath);
						if (s1.replaceAll("["+regEx+"]", "").equals(ExpectedValue)) {
							break;
						}
						i++;
					}
				}else{
					s1 = response.jsonPath().getString(property);
				}
				 
				s2 = s1.replaceAll("["+regEx+"]", "");
				
			}

			System.out.println(s2 + ":::::" + ExpectedValue);

			if (s2.contains(ExpectedValue)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "To verify property value contains the expected value",
						"property value should contains the expected value",
						"property value contains the expected value " + s2 + "=" + ExpectedValue);
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "To verify property value contains the expected value",
						"property value should contains the expected value",
						"The property is NOT Equals to expected value " + s2 + "not =" + ExpectedValue);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
						e.printStackTrace();
						Reuse.log(e);
						Demo1.gbTestCaseStatus = "Fail";
						Demo1.ReportStep(2, "To verify property value contains the expected value",
								"property value should contains the expected value",
								"The property is NOT Equals to expected value");

		}

	}



	public static void API_VerifyXmlProperty(String property, String ExpectedValue) {
		// response.then().body(property, not(hasKey(property)));

		try {
			String s1 = response.xmlPath().getString(property);

			if (ExpectedValue.contains("auto@")) {
				ExpectedValue = Reuse.updateRuntimeValuesInOfs(ExpectedValue);
			}

			System.out.println(s1 + ":::::" + ExpectedValue);

			if (ExpectedValue.equalsIgnoreCase(s1)) {
				Demo1.gbTestCaseStatus = "Pass";
				Demo1.ReportStep(2, "To verify property is  Equals to expected value",
						" property should  Equals to expected value",
						"The property is  Equals to expected value" + s1 + "=" + ExpectedValue);
			} else {
				Demo1.gbTestCaseStatus = "Fail";
				Demo1.ReportStep(2, "To verify property is Equals to expected value",
						" property should Equals to expected value",
						"The property is NOT Equals to expected value" + s1 + "not =" + ExpectedValue);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To verify property is Equals to expected value",
					" property should Equals to expected value", "The property is NOT Equals to expected value");

		}

	}

	public static void API_jsonPropertyPrimaryCoApp(String varpCif, String varpParty, String varcCif, String varcParty,
			String varstatus, String varprocessId) {
		// response.then().body(property, not(hasKey(property)));

		String pCif = "", pParty = "", cCif = "", cParty = "", status = "", processId = "";

		try {

			List<Map<String, String>> s1 = response.jsonPath().getList("entityItems");
			System.out.println("EntityItems" + s1);

			for (Map<String, String> element : s1) {

				if (element.get("entityItemDefinitionName").toString().equalsIgnoreCase("metadata")) {
					String s2 = element.get("entry");

					try {
						pCif = s2.substring(s2.indexOf("\"CIF\":\""), s2.indexOf("\",", s2.indexOf("\"CIF\":\"")))
								.replace("\"", "").split(":")[1];
						Reuse.WriteProperties(varpCif, pCif);
					} catch (Exception e) {
						System.out.println("Primary Applicant cif is empty");

					}
					try {
						pParty = s2
								.substring(s2.indexOf("\"PartyId\":\""),
										s2.indexOf("\",", s2.indexOf("\"PartyId\":\"")))
								.replace("\"", "").split(":")[1];
						Reuse.WriteProperties(varpParty, pParty);
					} catch (Exception e) {
						System.out.println("Primary Applicant partyid is empty");

					}
					try {
						status = s2
								.substring(s2.indexOf("\"Status\":\""), s2.indexOf("\",", s2.indexOf("\"Status\":\"")))
								.replace("\"", "").split(":")[1];
						Reuse.WriteProperties(varstatus, status);
					} catch (Exception e) {
						System.out.println("Primary Applicant status is empty");

					}
					try {
						processId = s2
								.substring(s2.indexOf("\"ProcessId\":\""),
										s2.indexOf(",", s2.indexOf("\"ProcessId\":\"")))
								.replace("\"", "").replace("}", "").replace("]", "").split(":")[1];
						Reuse.WriteProperties(varprocessId, processId);
					} catch (Exception e) {
						System.out.println("Primary Applicant processid is empty");

					}
					try {
						cCif = s2
								.substring(s2.lastIndexOf("\"CIF\":\""),
										s2.indexOf("\",", s2.lastIndexOf("\"CIF\":\"")))
								.replace("\"", "").split(":")[1];
						Reuse.WriteProperties(varcCif, cCif);
					} catch (Exception e) {
						System.out.println("Primary coApplicant cif is empty");

					}
					try {
						cParty = s2
								.substring(s2.lastIndexOf("\"PartyId\":\""),
										s2.indexOf("\",", s2.lastIndexOf("\"PartyId\":\"")))
								.replace("\"", "").split(":")[1];
						Reuse.WriteProperties(varcParty, cParty);

					} catch (Exception e) {
						System.out.println("Primary coApplicant partyid is empty");

					}

					System.out
							.println(pCif + ":" + pParty + ":" + cCif + ":" + cParty + ":" + status + ":" + processId);

				}

			}

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To verify property are stored", " property should be stored",
					"The property is stored");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			// Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To verify property are stored", " property should be stored",
					"The property is not stored and issue in response");
		}

	}

	public static void API_jsonPropertyPrimaryApp(String varpCif, String varpParty, String varstatus,
			String varprocessId) {
		// response.then().body(property, not(hasKey(property)));

		String pCif = "", pParty = "", cCif = "", cParty = "", status = "", processId = "";

		try {

			List<Map<String, String>> s1 = response.jsonPath().getList("entityItems");
			System.out.println("EntiryItems" + s1);

			for (Map<String, String> element : s1) {

				if (element.get("entityItemDefinitionName").toString().equalsIgnoreCase("metadata")) {
					String s2 = element.get("entry");

					try {
						pCif = s2.substring(s2.indexOf("\"CIF\":\""), s2.indexOf("\",", s2.indexOf("\"CIF\":\"")))
								.replace("\"", "").split(":")[1];
						Reuse.WriteProperties(varpCif, pCif);
					} catch (Exception e) {
						System.out.println("Primary Applicant cif is empty");

					}
					try {
						pParty = s2
								.substring(s2.indexOf("\"PartyId\":\""),
										s2.indexOf("\",", s2.indexOf("\"PartyId\":\"")))
								.replace("\"", "").split(":")[1];
						Reuse.WriteProperties(varpParty, pParty);
					} catch (Exception e) {
						System.out.println("Primary Applicant partyid is empty");

					}
					try {
						status = s2
								.substring(s2.indexOf("\"Status\":\""), s2.indexOf("\",", s2.indexOf("\"Status\":\"")))
								.replace("\"", "").split(":")[1];
						Reuse.WriteProperties(varstatus, status);
					} catch (Exception e) {
						System.out.println("Primary Applicant status is empty");

					}
					try {
						processId = s2
								.substring(s2.indexOf("\"ProcessId\":\""),
										s2.indexOf(",", s2.indexOf("\"ProcessId\":\"")))
								.replace("\"", "").replace("}", "").replace("]", "").split(":")[1];
						Reuse.WriteProperties(varprocessId, processId);
					} catch (Exception e) {
						System.out.println("Primary Applicant processid is empty");

					}

					// Reuse.WriteProperties(varcCif, cCif );
					// Reuse.WriteProperties(varcParty, cParty );

					System.out.println(pCif + ":" + pParty + ":" + status + ":" + processId);

				}

			}

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To verify property are stored", " property should be stored",
					"The property is stored");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			// Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To verify property are stored", " property should be stored",
					"The property is not stored and issue in the response");
		}

	}

	public static void API_jsonPropertyAccNo(String varAcc1) {
		// response.then().body(property, not(hasKey(property)));

		String pAcc1 = "", pParty = "", cCif = "", cParty = "", status = "", processId = "";

		try {

			List<Map<String, String>> s1 = response.jsonPath().getList("entityItems");
			// System.out.println("EntiryItems"+s1);

			for (Map<String, String> element : s1) {

				if (element.get("entityItemDefinitionName").toString().equalsIgnoreCase("ProductSelection")) {
					String s2 = element.get("entry");

					System.out.println("Entry" + s2);

					try {

						pAcc1 = s2
								.substring(s2.indexOf("\"AccountNumber\":\""),
										s2.indexOf("\"}", s2.indexOf("\"AccountNumber\":\"")))
								.replace("\"", "").split(":")[1];
						Reuse.WriteProperties(varAcc1, pAcc1);
					} catch (Exception e) {
						System.out.println("Primary Applicant cif is empty");

					}

					// Reuse.WriteProperties(varcCif, cCif );
					// Reuse.WriteProperties(varcParty, cParty );

					System.out.println(pAcc1);

					// System.out.println(pCif +":"+ pParty +":"+ status +":"+
					// processId);

				}

			}

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To verify property are stored", " property should be stored",
					"The property is stored");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			// Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To verify property are stored", " property should be stored",
					"The property is not stored and issue in the response");
		}

	}

	// @Then("^JSON property \"([^\"]*)\" should exist$")
	public void jsonPropertyShouldExist(String property) {
		response.then().body(property, notNullValue());

	}

	// @And("^the response header \"([^\"]*)\" should be \"([^\"]*)\"$")
	public static void API_theResponseHeaderShouldBeEqualTo(String name, String value) throws Throwable {

		try {
			assertThat(response.getHeader(name), equalTo(value));

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To verify header property is  equals" + response.getHeader(name) + "=" + value,
					" property should  exist", "The property is  exist");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To verify header property is  equals" + response.getHeader(name) + "=" + value,
					" property should EXIST", "The property is NOT EXIST");
		}

	}

	// @Then("^JSON property \"([^\"]*)\" should be a decimal number$")
	public static void API_jsonPropertyShouldBeADecimalNumber(String property) {

		try {
			JsonPath responseBody = JsonPath.from(response.body().asString());

			assertThat(responseBody.getDouble(property), notNullValue());

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To verify property is  decimal", " property should  be decimal",
					"The property is  decimal");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reuse.log(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To verify property is decimal", " property should decimal",
					"The property is NOT decimal");
		}
	}

	// @Given("^And request body \"([^\"]*)\" is set to \"([^\"]*)\"$")
	public static void API_updateRequestStringDynamicValues(String replaceKey, String replaceValue) {
		try {
			requestJsonContents = requestJsonContents.replace(replaceKey, replaceValue);
			request.body(requestJsonContents);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2,
					"To send request body with replacing key and value" + replaceKey + "and " + replaceValue,
					" To send request body should be successfull", "To send request body is successfull");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
			e.printStackTrace();
			Reuse.log(e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2,
					"To send request body with replacing key and value" + replaceKey + "and " + replaceValue,
					" To send request body should be successfull", "To send request body is not successfull");
		}
	}

	// @Given("^I post the following static input request as json (.*?)$")
	public static void API_givenRequestBodyContent(String jsonBody) {
		try {
			requestJsonContents = jsonBody;

			// System.out.println("MSG::>" + jsonBody);
			if (jsonBody.contains("auto@")) {
				jsonBody = Reuse.updateRuntimeValuesInOfs(jsonBody);
			}

			request.body(jsonBody);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To send request body", " To send request body should be successfull",
					"To send request body is successfull");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To send request body", " To send request body should be successfull",
					"To send request body is not successfull");
		}
	}

	// @Given("^request header \"([^\"]*)\" is set with bundle value \"(.*)\"$")
	public static void API_givenRequestHeaderBundleValue(String headerName, String bundleValue) throws Throwable {

		// String bundleValueStore = cucumberInteractionSession.scenarioBundle()
		// .getString(bundleValue.replace("{", "").replace("}", ""));

		try {
			String bundleValueStore = resuableObject.fetchKeyValues(bundleValue);
			request.header(headerName, bundleValueStore);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To send request header with stored value",
					" To send request header should be successfull", "To send request header is successfull");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To send request header with stored value",
					" To send request header should be successfull", "To send request header is not successfull");
		}

	}

	// @Given("^and store CLAIM_TOKEN to the file path \"([^\"]*)\"$")
	public void storeClaimTokenToFile(String path) throws Throwable {
		this.authTokenFilePath = path;
		File file = new File(path);
		FileWriter writer = new FileWriter(file);
		writer.write(this.authToken);
		writer.close();

		/*
		 * IOUtils.write(this.authToken, new
		 * FileOutputStream(System.getProperty("user.dir") + "/" + path),
		 * "UTF-8")
		 */
	}

	// @Given("^and use last authenticated CLAIM_TOKEN for the request header
	// \"([^\"]*)\"$")
	public void useClaimToken(String headerKey) throws Throwable {
		try {
			String authFileToken = IOUtils
					.toString(new FileInputStream(System.getProperty("user.dir") + "/" + this.authTokenFilePath));
			request.header(headerKey, authFileToken);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// @Given("^the request body after dynamically updated values is set to the
	// contents of \"(.*)\"$")
	public void givenRequestBodyDynamicUpdateValue(String body) {
		try {
			request.body(IOUtils.toString(new FileInputStream(System.getProperty("user.dir") + "/" + body)));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// @Given("^request form param values for x-www-form-urlencoded header type
	// key \"([^\"]*)\" value is set to \"([^\"]*)\"$")
	public static void API_givenRequestFormParam(String formKey, String formValue) throws Throwable {

		try {

			if (formValue.contains("auto@"))
				formValue = Reuse.updateRuntimeValuesInOfs(formValue);

			request.formParam(formKey, formValue);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To send request  with formparam value", " To send request  should be successfull",
					"To send request  is successfull");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To send request  with formparam value",
					" To send request header should be successfull", "To send request header is not successfull");
		}

	}

	public static void API_givenRequestMultiParam(String formKey, String formValue) throws Throwable {

		try {

			if (formValue.contains("auto@"))
				formValue = Reuse.updateRuntimeValuesInOfs(formValue);

			request.multiPart(formKey, formValue);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To send request  with multipart value", " To send request  should be successfull",
					"To send request  is successfull");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To send request  with multipart value",
					" To send request header should be successfull", "To send request header is not successfull");
		}

	}

	public static void API_givenRequestMultiParam_file(String body) throws Throwable {

		try {

			File f = new File(System.getProperty("user.dir") + "/TestData/" + body);

			request.multiPart(f);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To send request  with multipart value", " To send request  should be successfull",
					"To send request  is successfull");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To send request  with multipart value",
					" To send request header should be successfull", "To send request header is not successfull");
		}

	}

	// @Then("^the response status code should be one of \"([^\"]*)\"$")
	public void theResponseStatusEquals(List<Integer> statusList) throws Throwable {
		System.out.println(Optional.ofNullable(response.getBody()).map(ResponseBody::prettyPrint).orElse(""));
		System.out.println("Actual: " + response.getStatusCode());
		statusList.forEach(item -> System.out.println("Expected: " + item));
		assertTrue(statusList.contains(response.getStatusCode()));
	}

	// @Then("^the response body should be empty")
	public static void API_responseBodyShouldBeEmpty() {

		try {
			assertTrue(response.getBody().asString().isEmpty());

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To verify response body is empty", " To verification should be successfull",
					"To verification  is successfull");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To verify response body is empty", " To verification should be successfull",
					"To verification  is not successfull");
		}

	}

	// @Then("^Log all the responses in console")
	public static void API_logResponses() {

		try {
			response.then().log().headers();
			response.then().log().cookies();
			System.out.println("Actual Status Code: " + response.getStatusCode());
			System.out.println("Response Body: ");
			System.out.println(System.lineSeparator());
			Optional.ofNullable(response.getBody()).map(ResponseBody::prettyPrint).orElse("");

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To log response", " To log response should be successfull",
					"To log response  is successfull");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To log response", " To log response should be successfull",
					"To log response  is not successfull");
		}

	}

	// @Then("^Log all the requestbody in console")
	public static void API_logRequestBody() {

		try {
			request.given().log().body().get().asString();

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To log response body", " To log response body should be successfull",
					"To log response  body is successfull");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To log response body", " To log response body should be successfull",
					"To log response body is not successfull");
		}

	}

	// @Then("^the response body should equal \"(.+)\"$")
	public void responseBodyShouldEqual(String value) {
		response.then().assertThat().contentType(equalTo(value));
	}

	// @Then("^JSON boolean property \"([^\"]*)\" should equal (true|false)$")
	public void jsonResponseBooleanPropertyXEqualsY(String property, boolean value) {
		response.then().body(property, notNullValue());
		boolean actualValue = JsonPath.from(response.body().asString()).getBoolean(property);
		assertEquals(value, actualValue);
		response.then().body(property, equalTo(actualValue));
	}

	// @Then("^JSON integer property \"([^\"]*)\" should equal (\\d+)$")
	public void jsonResponseIntegerPropertyXEqualsNumberY(String property, int value) throws Throwable {
		response.then().body(property, notNullValue());
		int actualValue = JsonPath.from(response.body().asString()).getInt(property);
		assertEquals(value, actualValue);
	}

	// @Then("^JSON integer property \"([^\"]*)\" should equal \"([^\"]*)\"$")
	public void jsonResponseIntegerPropertyXEqualsNumberZ(String property, int value) throws Throwable {
		response.then().body(property, notNullValue());
		int actualValue = JsonPath.from(response.body().asString()).getInt(property);
		assertEquals(value, actualValue);
	}

	// @Then("^JSON integer property \"([^\"]*)\" should be greater than
	// (\\d+)$")
	public void jsonResponseIntegerPropertyXGreaterThanY(String property, int minimum) throws Throwable {
		response.then().body(property, notNullValue());
		int actualValue = JsonPath.from(response.body().asString()).getInt(property);
		response.then().body(property, greaterThanOrEqualTo(minimum));
	}

	// @Then("^JSON integer property \"([^\"]*)\" should be less than (\\d+)$")
	public void jsonResponseIntegerPropertyXLessThanY(String property, int maximum) throws Throwable {
		response.then().body(property, notNullValue());
		int actualValue = JsonPath.from(response.body().asString()).getInt(property);
		response.then().body(property, lessThanOrEqualTo(maximum));
	}

	// @Then("^JSON integer property \"([^\"]*)\" should be greater than (\\d+)
	// and less than (\\d+)$")
	public void jsonResponseIntegerPropertyXGreaterThanYLessThanZ(String property, int minimum, int maximum)
			throws Throwable {
		response.then().body(property, notNullValue());
		int actualValue = JsonPath.from(response.body().asString()).getInt(property);
		response.then().body(property, allOf(greaterThanOrEqualTo(minimum), lessThanOrEqualTo(maximum)));
	}

	// @Then("^JSON string property \"([^\"]*)\" should be a local link ending
	// with \"(.+)\"$")
	public void jsonResponseStringPropertyXIsALinkEndingInY(String property, String ending) throws Throwable {
		response.then().body(property, notNullValue());
		response.then().body(property, endsWith(ending));
	}

	// @Then("^JSON string property \"([^\"]*)\" should equal \"(.*)\"$")
	public void jsonResponseStringPropertyXEqualsNumberY(String property, String value) throws Throwable {
		response.then().body(property, notNullValue());
		response.then().body(property, equalTo(value));

	}

	// Contains Value Assertion for Json Object in response

	// @Then("^JSON string property \"(.*)\" should contains value \"(.*)\"$")
	public void jsonResponseStringPropertyXContainsNumberY(String property, String value) throws Throwable {
		response.then().body(property, notNullValue());
		String actualValue = JsonPath.from(response.body().asString()).getString(property);
		assertTrue(actualValue.contains(value));

	}

	// @Then("^JSON string property \"([^\"]*)\" should match \"(.+)\"$")
	public void jsonResponseStringPropertyXMatchesY(String property, String regex) throws Throwable {
		response.then().body(property, notNullValue());
		String actualValue = JsonPath.from(response.body().asString()).getString(property);
		assertTrue(actualValue.matches(regex));
	}

	// @Then("^JSON string property \"([^\"]*)\" should be at least (\\d*)
	// characters and at most (\\d*) characters$")
	public void jsonResponseStringPropertyIsCorrectLength(String property, int minLength, int maxLength)
			throws Throwable {
		response.then().body(property, notNullValue());
		int actualLength = JsonPath.from(response.body().asString()).getString(property).length();
		assertTrue(actualLength >= minLength && actualLength <= maxLength);
	}

	// @Then("^JSON property \"([^\"]*)\" should contain (\\d+) elements?$")
	public void jsonResponsePropertyContainsNNumberOfElements(String property, int count) throws Throwable {
		JsonPath responseBody = JsonPath.from(response.body().asString());
		response.then().body(property, notNullValue());
		assertThat(responseBody.get(property), isA(List.class));
		List<Object> actualValue = responseBody.getList(property);
		assertEquals(count, actualValue.size());
	}

	// @Then("^JSON property \"([^\"]*)\" should contain at least (\\d+)
	// elements?$")
	public void jsonResponsePropertyContainsAtLeastNNumberOfElements(String property, int count) throws Throwable {
		JsonPath responseBody = JsonPath.from(response.body().asString());
		response.then().body(property, notNullValue());
		assertThat(responseBody.get(property), isA(List.class));
		List<Object> actualValue = responseBody.getList(property);
		assertThat(actualValue.size(), greaterThanOrEqualTo(count));
	}

	// @Then("^JSON property \"([^\"]*)\" should contain at most (\\d+)
	// elements?$")
	public void jsonResponsePropertyContainsAtMostNNumberOfElements(String property, int count) throws Throwable {
		JsonPath responseBody = JsonPath.from(response.body().asString());
		response.then().body(property, notNullValue());
		assertThat(responseBody.get(property), isA(List.class));
		List<Object> actualValue = responseBody.getList(property);
		assertThat(actualValue.size(), lessThanOrEqualTo(count));
	}

	// @Then("^JSON property (.*?) should contain at least (\\d+) elements? and
	// at most (\\d+) elements?$")
	public void jsonResponsePropertyContainsAtLeastMAndAtMostNNumberOfElements(String property, int min, int max)
			throws Throwable {
		JsonPath responseBody = JsonPath.from(response.body().asString());
		response.then().body(property, notNullValue());
		assertThat(responseBody.get(property), isA(List.class));
		List<Object> actualValue = responseBody.getList(property);
		assertThat(actualValue.size(), allOf(greaterThanOrEqualTo(min), lessThanOrEqualTo(max)));
	}

	// @Then("^JSON root array should contain (\\d+) elements?$")
	public void jsonResponseRootArrayContainsAtMostNNumberOfElements(int count) throws Throwable {
		JsonPath responseBody = JsonPath.from(response.body().asString());
		assertThat(responseBody.get(), isA(List.class));
		List<Object> actualValue = responseBody.get();
		assertEquals(count, actualValue.size());
	}

	// @Then("^all elements in JSON array (.*?) should be equal to one of
	// \"(.*?)\"")
	public void jsonResponseArrayElementsMatchGivenValue(String property, String elements) {
		JsonPath responseBody = JsonPath.from(response.body().asString());
		response.then().body(property, notNullValue());
		assertThat(responseBody.get(property), isA(List.class));
		for (Object o : responseBody.getList(property)) {
			assertThat(o, isOneOf(elements.split(",")));
		}
	}

	// @Then("^JSON property \"([^\"]*)\" should be a decimal number greater
	// than (-?\\d+) and less than (-?\\d+)$")
	public void jsonPropertyShouldBeADecimalNumberGreaterThanXAndLessThanY(String property, long minimum,
			long maximum) {
		JsonPath responseBody = JsonPath.from(response.body().asString());
		Number value = responseBody.get(property), minNum = minimum, maxNum = maximum;
		assertThat(value, notNullValue());
		assertThat(value.doubleValue(),
				allOf(greaterThanOrEqualTo(minNum.doubleValue()), lessThanOrEqualTo(maxNum.doubleValue())));
	}

	// @Then("^the JSON response root should be array$")
	public void theJSONResponseRootShouldBeArray() {
		JsonPath responseBody = JsonPath.from(response.body().asString());
		assertThat(responseBody.get(), isA(List.class));
	}

	// @Then("^the JSON object \\[(\\d+)] should have key \"([^\"]*)\" and value
	// \"([^\"]*)\"$")
	public void theJSONObjectShouldHaveTypeNumericAndValue(int arg0, String arg1, String arg2) {
		JsonPath responseBody = JsonPath.from(response.body().asString());
		assertThat(responseBody.get(), isA(List.class));
		List<Object> actualValue = responseBody.get();
		response.then().body(arg1, notNullValue());
		HashMap value = (HashMap) actualValue.get(arg0);
		assertTrue(value.containsKey(arg1));
		assertEquals(value.get(arg1), arg2);
	}

	// @Then("^the JSON object \\[(\\d+)] should have key \"([^\"]*)\" and value
	// should be array$")
	public void theJSONObjectShouldHaveKeyAndValueShouldBeArray(int arg0, String arg1) {
		JsonPath responseBody = JsonPath.from(response.body().asString());
		assertThat(responseBody.get(), isA(List.class));
		List<Object> actualValue = responseBody.get();
		HashMap value = (HashMap) actualValue.get(arg0);
		response.then().body(arg1, notNullValue());
		assertTrue(value.containsKey(arg1));
		assertThat((List) value.get(arg1), isA(List.class));
	}

	// @Then("^the JSON array \"([^\"]*)\" in the position (\\d+) should have
	// key \"([^\"]*)\" and value \"([^\"]*)\"$")
	public void theJSONObjectDataPositionShouldHaveKeyAndValue(String array, int arg0, String arg1, String arg2) {
		List<Object> actualValue = getJsonArray(array);
		HashMap value = (HashMap) actualValue.get(arg0);
		response.then().body(array, notNullValue());
		assertTrue(value.containsKey(arg1));
		assertEquals(value.get(arg1), arg2);
	}

	// Expected value comparison from feature File

	// @Then("^In the JSON array with datatype assertion in response
	// \"([^\"]*)\" in the position (\\d+) should have key \"([^\"]*)\" and
	// value \"([^\"]*)\"$")
	public void theJSONObjectDataDatatypePositionShouldHaveKeyAndValue(String array, int arg0, String arg1,
			String arg2) {
		List<Object> actualValue = getJsonArray(array);
		HashMap value = (HashMap) actualValue.get(arg0);
		response.then().body(array, notNullValue());
		assertTrue(value.containsKey(arg1));
		if (!arg2.equals("")) {
			assertEquals(value.get(arg1), arg2);
		}

		resuableObject.checkType(value.get(arg1));
	}

	// Expected value comparison from Expected Static Text File

	// @Then("^In the JSON array with expected value assertion from file in
	// response \"([^\"]*)\" in the position (\\d+) should have expected
	// variable key \"([^\"]*)\" and actual property key \"([^\"]*)\" with
	// expected values from file path \"(.*)\"$")
	public void theJSONObjectPositionShouldHaveKeyAndValueExpectedFilePath(String array, int arg0, String expectedKey,
			String key) {
		List<Object> actualValue = getJsonArray(array);
		HashMap value = (HashMap) actualValue.get(arg0);
		response.then().body(array, notNullValue());
		String expectedValue = resuableObject.compareKeyValuesTextFiles(expectedKey);
		assertTrue(value.containsKey(key));
		assertEquals("Expected and Actual json property values are equal: ", expectedValue, value.get(key));
		System.out.println("<--- Expected and Actual json property values are equal ---> " + System.lineSeparator()
				+ "Expected Value = " + expectedValue);
		resuableObject.checkType(value.get(key));
	}

	// Method to check the Integer datatype of property from the json response

	// @Then("^JSON response jsonObject Integer property \"([^\"]*)\" datatype
	// check$")
	public void jsonResponseJsonObjectIntegerPropertyDatatypeCheck(String property) throws Throwable {
		int responseBody = JsonPath.from(response.body().asString()).getInt(property);
		response.then().body(property, notNullValue());
		resuableObject.checkType(responseBody);

	}

	// Method to check the String datatype of property from the json response

	// @Then("^JSON response jsonObject String property \"([^\"]*)\" datatype
	// check$")
	public void jsonResponseJsonObjectStringPropertyDatatypeCheck(String property) throws Throwable {
		String responseBody = JsonPath.from(response.body().asString()).getString(property);
		response.then().body(property, notNullValue());
		resuableObject.checkType(responseBody);

	}

	// @Then("^the JSON array \"([^\"]*)\" should have an element with key
	// \"([^\"]*)\" and value \"([^\"]*)\"$")
	public void theJSONObjectDataShouldHaveKeyAndValue(String array, String key, String val) {
		response.then().body(array, notNullValue());
		List<String> actualValues = getValuesFromJsonArrayWithKey(key, array);
		assertThat(actualValues, hasItem(val));
	}

	// @Then("^the JSON array root path key \"(.*)\" should contains the string
	// value \"(.*)\"$")
	public void theJSONObjectDataShouldHaveKeyContainsValue(String arrayKey, String Containsvalue) {
		response.then().body(arrayKey, Every.everyItem(Matchers.containsString(Containsvalue)));

	}

	public static String replaceLast(String text, String regex, String replacement) {
		return text.replaceFirst("(?s)" + regex + "(?!.*?" + regex + ")", replacement);
	}

	// @Then("^store the response data from restassured json response \"(.*)\"
	// in keyvalue pair \"(.*)\" from file path \"(.*)\"$")
	public static void API_storeResponsePropertyField(String key, String value) throws Throwable {
		try {

			String propertyKey = null;

			if (response.getContentType().contains("xml")) {
				propertyKey = xmlResponseValidation(value);

			} else {
				JsonPath responseBody = JsonPath.from(response.body().asString());
				propertyKey = responseBody.getString(value);

				if (propertyKey.startsWith("[") && propertyKey.endsWith("]")) {

                    	propertyKey = propertyKey.replaceAll("[^a-z A-Z 0-9.]", "");
    					System.out.println("prop1: " + propertyKey);
    					propertyKey = propertyKey.replaceAll("[^a-z A-Z 0-9.]", "");
    					System.out.println("prop2: " + propertyKey);
				}
				else {
					System.out.println("prop1: " + propertyKey);
				}
			}
			resuableObject.storeKeyValues(key, propertyKey);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To store property in file ", " To store property in file should be sucessfull",
					"To store property in file is sucessfull");

		} catch (Exception e) {
			e.printStackTrace();
			Reuse.log(e);
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To store property in file ", " To store property in file should be sucessfull",
					"To store property in file is not sucessfull");
		}
	}

	// To store a value from the json array response

	// @Then("^store the value from json array response in the variable \"(.*)\"
	// taken from keyvalue pair \"(.*)\" under the json array \"(.*)\" to get
	// value of \"(.*)\" from file path \"(.*)\"$")
	public static void API_storeResponsePropField(String key, String value, String jsonValue, String storeValue)
			throws Throwable {
		try {
			JsonPath responseBody = JsonPath.from(response.body().asString());
			String propertyKey = responseBody.getString(value);
			JSONObject jsonObject = new JSONObject(propertyKey);
			JSONArray tsmresponse = (JSONArray) jsonObject.get(jsonValue);
			String idValue = null;
			for (int i = 0; i < tsmresponse.length(); i++) {
				idValue = tsmresponse.getJSONObject(i).getString(storeValue);
				resuableObject.storeKeyValues(key, idValue);
			}

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To store property in file ", " To store property in file should be sucessfull",
					"To store property in file is sucessfull");

		} catch (Exception e) {
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To store property in file ", " To store property in file should be sucessfull",
					"To store property in file is not sucessfull");
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
		}
	}

	// @Then("^split and store the response data from restassured json response
	// \"(.*)\" in keyvalue pair \"(.*)\" from file path \"(.*)\"$")
	public static void API_splitStoreResponsePropertyField(String key, String value) throws Throwable {

		try {

			JsonPath responseBody = JsonPath.from(response.body().asString());
			String propertyKey = responseBody.getString(value);
			String[] arrSplit = propertyKey.split(",");

			for (int i = 0; i < arrSplit.length; i++) {
				String KeyName = key + i;
				propertyKey = arrSplit[i];
				resuableObject.storeKeyValues(KeyName, propertyKey);
			}

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To store property in file ", " To store property in file should be sucessfull",
					"To store property in file is sucessfull");

		} catch (Exception e) {
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To store property in file ", " To store property in file should be sucessfull",
					"To store property in file is not sucessfull");
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);
		}

	}

	// @Then("^fetch the response data for rest assured json response \"(.*)\"
	// from file path \"(.*)\"$")
	public static void API_fetchResponsePropertyField(String key) throws Throwable {

		// scenarioBundleStepDefs.setBundleStringValue(key,
		// resuableObject.fetchKeyValues(key, fileName));

		try {

			bundle.put(key, resuableObject.fetchKeyValues(key));

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To get property in file ", " To get property in file should be sucessfull",
					"To get property in file is sucessfull" + resuableObject.fetchKeyValues(key).toString());

		} catch (Exception e) {
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To get property in file ", " To get property in file should be sucessfull",
					"To get property in file is not sucessfull" + resuableObject.fetchKeyValues(key).toString());

		}

	}

	// @Given("^request content \"([^\"]*)\" is set with bundle value
	// \"(.*)\"$")
	public static void API_givenRequestBodyBundleValue(String requestKeyName, String bundleValue) throws Throwable {
		// String bundleValueStore =
		// scenarioBundleStepDefs.getBundleStringValue(bundleValue);
		String bundleValueStore = null;
		try {
			// bundleValueStore = (String) bundle.get(bundleValue);

			bundleValueStore = resuableObject.fetchKeyValues(bundleValue);

			System.out.println("bundleValue:::" + bundleValue);

			requestJsonContents = requestJsonContents.replace(requestKeyName, bundleValueStore);
			request.body(requestJsonContents);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To request content is set with stored value ",
					" To request content is set with stored value to be succesfull" + bundleValueStore,
					"To request content is set with stored value is succesfull");

		} catch (Exception e) {

			e.printStackTrace();
			Reuse.log(e);
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To request content is set with stored value ",
					" To request content is set with stored value to be succesfull" + bundleValueStore,
					"To request content is set with stored value is not succesfull");
		}

	}

	// Scenario Bundle fetch the values from json response and update dynamic
	// values in json payload request input file

	// @Given("^request body fetch from scenario bundle key value \"(.*)\" is
	// update with dynamic values \"(.*)\" from the json file path \"(.*)\"$")
	public static void API_updateRequestFileDynamicValuesFromScenarioBundle(String jsonpath, String dynamicValue,
			String jsonFilePath) throws Exception {

		// String bundleValueStore = cucumberInteractionSession.scenarioBundle()
		// .getString(dynamicValue.replace("{", "").replace("}", ""));
		String bundleValueStore = null;
		try {

			bundleValueStore = resuableObject.fetchKeyValues(dynamicValue);

			// resuableObject.updateRequestFileDynamicValues(jsonpath,
			// bundleValueStore, jsonFilePath);

			String body = resuableObject.updateRequestFileDynamicValues(jsonpath, bundleValueStore, jsonFilePath);
			System.out.println("Body Values: " + body);

			request.body(body);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To request content is set with stored value ",
					" To request content is set with stored value to be succesfull" + jsonpath + bundleValueStore
							+ jsonFilePath,
					"To request content is set with stored value is succesfull");

		} catch (Exception e) {

			e.printStackTrace();
			Reuse.log(e);
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To request content is set with stored value ",
					" To request content is set with stored value to be succesfull" + jsonpath + bundleValueStore
							+ jsonFilePath,
					"To request content is set with stored value is not succesfull");
		}

	}

	// Scenario Bundle fetch the array values from json response and update
	// dynamic
	// values in json payload request input file

	// @Given("^request body fetch from scenario bundle key value \"(.*)\" is
	// update with array dynamic values \"(.*)\" from the json file path
	// \"(.*)\"$")
	public static void API_updateRequestFileDynamicArrayValuesFromScenarioBundle(String jsonpath, String dynamicValue,
			String jsonFilePath) throws Exception {

		// String bundleValueStore = cucumberInteractionSession.scenarioBundle()
		// .getString(dynamicValue.replace("{", "").replace("}", ""));
		//
		String bundleValueStore = null;
		try {

			bundleValueStore = resuableObject.fetchKeyValues(dynamicValue);

			resuableObject.updateArrayRequestFileDynamicValues(jsonpath, bundleValueStore, jsonFilePath);

			String body = resuableObject.updateArrayRequestFileDynamicValues(jsonpath, bundleValueStore, jsonFilePath);
			System.out.println("Body Values: " + body);

			request.body(body);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To request content is set with stored value ",
					" To request content is set with stored value to be succesfull" + jsonpath + bundleValueStore
							+ jsonFilePath,
					"To request content is set with stored value is succesfull");

		} catch (Exception e) {

			e.printStackTrace();
			Reuse.log(e);
			// TODO Auto-generated catch block
			// Uncomment and replace with appropriate logger
			// LOGGER.error(e, e);

			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To request content is set with stored value ",
					" To request content is set with stored value to be succesfull" + jsonpath + bundleValueStore
							+ jsonFilePath,
					"To request content is set with stored value is not succesfull");
		}

	}

	// validate multiple array/object values from the response --- validate from
	// feature file

	// @Then("^the JSON array \"([^\"]*)\" should have key \"([^\"]*)\" with
	// string multiple array values \"([^\"]*)\"$")

	public void theJSONArrayShouldHaveMultipleValues(String arrayJsonPath, String key,
			@Delimiter(":") List<String> values) {
		// Validate given jsonpath is array
		JsonPath responseBody = JsonPath.from(response.body().asString());
		Iterable<Object> ItrResponseBody = responseBody.getList(arrayJsonPath);
		assertEquals(true, ItrResponseBody instanceof List);
		response.then().body(arrayJsonPath, notNullValue());

		List<String> respValues = new ArrayList<>();
		for (Object obj : ItrResponseBody) {
			@SuppressWarnings("unchecked")
			Map<String, String> props = (Map<String, String>) obj;
			respValues.add(props.get(key));

			// Datatype also asserted for multiple values in Array List

			resuableObject.checkType(props.get(key));
		}

		/*
		 * * Check the Assertion values if not equal to "" passing in feature
		 * files otherwise if expected value is passed it will assert with
		 * Actual value in Response
		 */

		if (!values.equals("")) {

			for (String val : values) {

				assertEquals(true, respValues.contains(val));

				for (String assertValue : respValues)

					if (assertValue.equals(val)) {
						assertEquals(assertValue, val);
					}
			}

		}

	}

	// @Then("^the JSON array \"([^\"]*)\" should have key \"(.*)\" with values
	// \"(.*)\"$")
	public void theJSONArrayShouldHaveValues(String arrayJsonPath, String key, @Delimiter(":") List<String> values) {
		// Validate given jsonpath is array
		Iterable<Object> responseBody = JsonPath.from(response.body().asString()).getList(arrayJsonPath);
		assertEquals(true, responseBody instanceof List);
		response.then().body(arrayJsonPath, notNullValue());
		for (String val : values) {
			assertThat(getValuesFromJsonArrayWithKey(key, arrayJsonPath), hasItem(val));
		}

	}

	// @Given("^response content \"([^\"]*)\" should be an empty array$")
	public void givenRequestEmptyArrayCheck(String jsonPath) throws Throwable {
		JsonPath responseBody = JsonPath.from(response.body().asString());
		assertThat(responseBody.getList(jsonPath).size(), equalTo(0));
	}

	// @Given("^response content \"([^\"]*)\" should not be an empty array$")
	public void givenRequestNotEmptyArrayCheck(String jsonPath) throws Throwable {
		JsonPath responseBody = JsonPath.from(response.body().asString());
		assertThat(responseBody.getList(jsonPath).size(), greaterThanOrEqualTo(1));
	}

	// fetch the values from json response and update direct dynamic string
	// values in json payload request input file

	// @Given("^request body key \"(.*)\" is update with dynamic values \"(.*)\"
	// from the json file path \"(.*)\"$")
	public void updateRequestFileDynamicValues(String jsonpath, String dynamicValue, String jsonFilePath) {

		resuableObject.updateRequestFileDynamicValues(jsonpath,
				dynamicValue.replace("{TIMESTAMP}", String.valueOf(System.currentTimeMillis()).replace("}", "")),
				jsonFilePath);

	}

	// @Then("^JSON string parent and child json object property \"([^\"]*)\"
	// should equal \"(.*)\"$")
	public void jsonResponseStringJsonParentAndChildPropertyXequalsY(String property, String value) throws Throwable {
		String actualValue = JsonPath.from(response.body().asString()).getString(property);
		response.then().body(property, notNullValue());
		assertEquals(value, actualValue);
	}

	// Parent and child json object value not equal assertion - used for
	// negative
	// scenarios

	// @Then("^JSON string parent and child json object property \"([^\"]*)\"
	// should not equal \"(.*)\"$")
	public void jsonResponseStringJsonParentAndChildPropertyXnotequalsY(String property, String value)
			throws Throwable {
		String actualValue = JsonPath.from(response.body().asString()).getString(property);
		response.then().body(property, notNullValue());
		assertNotEquals(value, actualValue);
	}

	private List<Object> getJsonArray(String array) {
		JsonPath responseBody = JsonPath.from(response.body().asString());
		assertThat(responseBody.get(array), notNullValue());
		return responseBody.get(array);
	}

	private List<String> getJsonArrayValues(String array) {
		return getJsonArray(array).stream().map(object -> Objects.toString(object, null)).collect(Collectors.toList());
	}

	private List<String> getValuesFromJsonArrayWithKey(String key, String array) {
		List<String> values = new ArrayList<>();
		for (Object obj : getJsonArray(array)) {
			Map<String, String> props = (Map<String, String>) obj;
			values.add(props.get(key));
		}
		return values;
	}

	/*
	 * Expected value comparison from Expected Static Text File fetch list of
	 * values from a single json array/object
	 */

	// @Then("^the JSON array \"([^\"]*)\" should have expected variable key
	// \"(.*)\" and actualPropertyKey \"(.*)\" with expected values from file
	// path \"(.*)\"$")
	public void theJSONArrayShouldHaveValuesExpectedTxtFilePath(String arrayJsonPath, String expectedKey, String key) {
		/* Validate given jsonpath is array */
		Iterable<Object> responseBody = JsonPath.from(response.body().asString()).getList(arrayJsonPath);
		assertEquals(true, responseBody instanceof List);
		response.then().body(arrayJsonPath, notNullValue());

		String expectedValue = resuableObject.compareKeyValuesTextFiles(expectedKey);

		String[] expectedSpiltValue = expectedValue.split(":");

		for (String val : expectedSpiltValue) {

			assertThat(getValuesFromJsonArrayWithKey(key, arrayJsonPath), hasItem(val));
		}

	}

	/*
	 * Expected value comparison from Expected Static Excel Files fetch list of
	 * values from a single json array/object
	 */

	// @Then("^the JSON array \"([^\"]*)\" comparing expected and actual json
	// response values from expected variable key \"(.*)\" with actual property
	// from response \"(.*)\" and sheetindex (\\d+) rownumber (\\d+) and
	// columnnumber (\\d+) from the expected excel file path \"(.*)\"$")
	public void theJSONArrayShouldHaveValuesExpectedExcelFilePath(String arrayJsonPath, String expectedVariableKey,
			String actualPropertyKey, int sheetNumber, int rowNumber, int ColumnNumber, String expectedFilePath) {
		/* Validate given jsonpath is array */
		Iterable<Object> responseBody = JsonPath.from(response.body().asString()).getList(arrayJsonPath);
		assertEquals(true, responseBody instanceof List);
		response.then().body(arrayJsonPath, notNullValue());

		ExcelDataConfig excel = new ExcelDataConfig(expectedFilePath);

		String expectedValue_Excel = excel.getExpectedValueExcelData(sheetNumber, rowNumber, ColumnNumber);

		if (!(expectedValue_Excel == null) && !(expectedVariableKey == null)) {

			String[] expectedSpiltValue = expectedValue_Excel.split(":");

			for (String val : expectedSpiltValue) {

				assertThat(getValuesFromJsonArrayWithKey(actualPropertyKey, arrayJsonPath), hasItem(val));
			}
		}

	}

	// @Then("^JSON response string property key \"([^\"]*)\" should equal value
	// \"([^\"]*)\"$")
	public void jsonResponseStringPropertyXEqualsValueZ(String property, String value) throws Throwable {
		String actualValue = JsonPath.from(response.body().asString()).getString(property);
		assertEquals(value, actualValue);
	}

	// JsonObject should not equal value - used for negative scenarios

	// @Then("^JSON response string property key \"(.*)\" should not equal value
	// \"(.*)\"$")
	public void jsonResponseStringPropertyXNotEqualsValueZ(String property, String value) throws Throwable {
		String actualValue = JsonPath.from(response.body().asString()).getString(property);
		assertNotEquals(value, actualValue);
	}

	// ENABLE for TXT - Expected and actual values comparison.

	// @Then("^Compare the Expected and Actual json response values passing
	// expectedKey \"(.*)\" and actualPropertyKeyValue is \"(.*)\" from the
	// expected file path \"(.*)\"$")
	public void compareExpectedAndActualValuesPropertyXPropertyYFiles(String expectedKey, String actualPropertyKeyValue)
			throws Throwable {

		JsonPath responseBody = JsonPath.from(response.body().asString());
		response.then().body(actualPropertyKeyValue, notNullValue());
		String actualValue = responseBody.getString(actualPropertyKeyValue);

		String expectedValue = resuableObject.compareKeyValuesTextFiles(expectedKey);
		assertEquals("Expected and Actual json property values are equal from txt file: ", expectedValue, actualValue);
		System.out.println("<--- Expected and Actual json property values are equal from txt file ---> "
				+ System.lineSeparator() + "Expected Value = " + expectedValue);

	}

	// Excel Expected and Actual String values comparison based on expected
	// variable
	// key ---

	// @Then("^Compare the Expected and Actual json response values from
	// expected variable key \"(.*)\" with actual property from response
	// \"(.*)\" and sheetindex (\\d+) rownumber (\\d+) and columnnumber (\\d+)
	// from the expected excel file path \"(.*)\"$")
	public void compareExpectedAndActualValuesPropertyXPropertyYExcelFile(String expectedVariableKey,
			String actualPropertyKey, int sheetNumber, int rowNumber, int ColumnNumber, String expectedFilePath)
			throws Throwable {

		JsonPath responseBody = JsonPath.from(response.body().asString());
		response.then().body(actualPropertyKey, notNullValue());
		String actualValue = responseBody.getString(actualPropertyKey);

		ExcelDataConfig excel = new ExcelDataConfig(expectedFilePath);

		String expectedValue_Excel = excel.getExpectedValueExcelData(sheetNumber, rowNumber, ColumnNumber);

		if (!(expectedValue_Excel == null) && !(expectedVariableKey == null)) {

			assertEquals("Expected and Actual json property values are equal from excel file : ", expectedValue_Excel,
					actualValue);
			System.out.println("<--- Expected and Actual json property values are equal from excel file ---> "
					+ System.lineSeparator() + "Expected Value = " + expectedValue_Excel);

		}

	}

	// @Then("^Clear all the expected json values from file path \"(.*)\"$")
	public void clearExpectedValuesPropertyFile() throws Throwable {
		resuableObject.removeExpectedValuesPropertyFile();
	}

	/*
	 * To get the UTC time and store in the request payload
	 *
	 */

	// @Given("^the request body key \"(.*)\" is update with dynamic values
	// \"(.*)\" with current system date and time \"(.*)\" from the json file
	// path \"(.*)\"$")
	public void updateRequestFileSystemDate(String jsonpath, String ValueTobeUpdate, String dateTime,
			String jsonFilePath) {
		OffsetDateTime value = OffsetDateTime.now(ZoneId.of("UTC"));
		dateTime = value.toString();
		String valueConcat = ValueTobeUpdate.concat(dateTime);
		resuableObject.updateRequestFileDynamicValues(jsonpath, valueConcat, jsonFilePath);
	}

	/*
	 * To split and store comma separated response values
	 *
	 */

	/*
	 * Compare the Full Json Response of expected and actual values in lineant
	 * mode using sameJSONAs method
	 */

	// @Then("^Check full response with expected json content using sameJSONAs
	// method from file path \"(.*)\"$")
	public void fullResponseAssertionWithJSONFileSameJson(String expectedJSONFilePath) throws Throwable {
		String actualJSONResponse = response.asString();

		File expectedResponsefile = new File(expectedJSONFilePath);

		String expectedResponse = IOUtils
				.toString(new FileInputStream(System.getProperty("user.dir") + "/" + expectedJSONFilePath));

		System.out.println(expectedResponse);
		assertThat(actualJSONResponse,
				sameJSONAs(expectedResponse).allowingExtraUnexpectedFields().allowingAnyArrayOrdering());

	}

	/*
	 * Compare the Full Json Response of expected and actual values in lineant
	 * mode using SkyCreamer method
	 */

	// @Then("^Compare full response with expected JSON content using skycreamer
	// method from file path \"(.*)\"$")

	public void fullResponseAssertionWithJSONFileSkyCreamer(String expectedJSONFilePath) throws Throwable

	{

		String actualJSONResponse = response.asString();

		String expectedResponsefile = IOUtils
				.toString(new FileInputStream(System.getProperty("user.dir") + "/" + expectedJSONFilePath));

		/*
		 * Lenient mode will ignore any missing fields in JSON
		 * JSONAssert.assertEquals(expected, data, false);
		 */

		JSONAssert.assertEquals(expectedResponsefile, actualJSONResponse, JSONCompareMode.LENIENT);

	}

	// To check if response complies with the JSON schema

	// @Then("^check if response complies with Json schema template from file
	// path \"(.*)\"$")
	public void checkResponseMatchesSchema(String schemaPath) throws Throwable {

		File poSchema = new File(schemaPath);

		System.out.println("Schema is: " + poSchema.toString());
		System.out.println("response :" + response.body().asString());
		response.then().body(matchesJsonSchema(poSchema));
	}

	// ========== To check for multi-part file upload ==========

	// @Then("^upload a multipart file document with key \"(.*)\" from file path
	// \"(.*)\"$")
	public void uploadFile(String controlName, String filePath) throws Throwable {

		File fileToBeUploaded = new File(System.getProperty("user.dir") + "/" + filePath);
		request = request.multiPart(controlName, fileToBeUploaded);

	}

	// ========== To check for multi-part file download ============

	// @Then("^check if multipart file download is successful and size is equal
	// to file uploaded from file path \"(.*)\"$")
	public void verifyFileDownload(String uploadedFilePath) throws Exception {

		int uploadedFileSize;
		File uploadedFile = new File(System.getProperty("user.dir") + "/" + uploadedFilePath);

		uploadedFileSize = (int) uploadedFile.length();

		byte[] downloadedFile = response.asByteArray();

		// assertEquals(fileSize, downloadedFile.length);

		if (uploadedFileSize == downloadedFile.length) {
			System.out.println("File download is successful and file size is same");
		} else {

			System.out.println("The uploaded file length is: " + uploadedFileSize);
			System.out.println("---------------------------------------");
			System.out.println("The downloaded file length is: " + downloadedFile.length);
			throw new Exception("Mismatch in downloaded file size/content or download did not happen correctly");
		}
	}

	/*
	 * To verify whether the provided input value is present in the json nested
	 * array response and assert if both are equal
	 */

	// @Then("^to verify whether the provided json response key \"(.*)\" is
	// equal to the input present in the value \"(.*)\"$")
	public void checkIfValueExistsInNestedJSONArray(String key, String value) {
		String responseString = response.body().asString();
		String assertValue = resuableObject.searchValueFromNestedJSONArray(responseString, value);
		System.out.println(assertValue);
		assertTrue("Value does not exist", value.equals(assertValue));
	}

	// ___________________________________----------------------________________________________

	public void givenRequestAuthentication(String uri, String usernameKey, String usernameValue, String passwordKey,
			String passwordValue, String providerKey, String providerValue, String loginOptionsKey,
			String loginOptionsValue) throws Throwable {

		request.baseUri(uri);
		request.header("Content-Type", "application/x-www-form-urlencoded");
		request.header("X-Kony-App-Key", System.getProperty("kony.cucumber.appkey"));
		request.header("X-Kony-App-Secret", System.getProperty("kony.cucumber.appsecret"));

		request.formParam(usernameKey, usernameValue);
		request.formParam(passwordKey, passwordValue);
		request.formParam(providerKey, providerValue);
		request.formParam(loginOptionsKey, loginOptionsValue);

	}

	public void givenRequestAPIAuthentication(String uri, String usernameKey, String usernameValue, String passwordKey,
			String passwordValue, String providerKey, String providerValue, String loginOptionsKey,
			String loginOptionsValue) throws Throwable {

		request.baseUri(uri);

		request.header("Content-Type", "application/x-www-form-urlencoded");
		request.header("X-Kony-App-Key", System.getProperty("kony.cucumber.appkey"));
		request.header("X-Kony-App-Secret", System.getProperty("kony.cucumber.appsecret"));
		request.header("X-Kony-AC-API-Access-Token", "yKegmTtA28hciLeMryqd");

		request.formParam(usernameKey, usernameValue);
		request.formParam(passwordKey, passwordValue);
		request.formParam(providerKey, providerValue);
		request.formParam(loginOptionsKey, loginOptionsValue);

	}

	// @Given("^get the identity refresh token value is set for header key
	// \"(.*)\"$")
	public void givenRefreshTokenValueSetBundleValue(String headerKey) throws Throwable {

		System.out.println("Refresh Token value for Shared Secret Login : " + globalConfig.getSharedSecretLoginToken());
		request.header(headerKey, globalConfig.getSharedSecretLoginToken());

	}

	// * Compare values from Feature file fetch list of values from a single
	// json
	// * array/object

	/*
	 * public void givenRequestBasePathBundleValue(String bundleVariable, String
	 * path) throws Throwable {
	 *
	 * String basePathbundleValueStore =
	 * cucumberInteractionSession.scenarioBundle()
	 * .getString(bundleVariable.replace("{", "").replace("}", ""));
	 *
	 * // String basePathbundleValueStore = bundleVariable.replace("{",
	 * "").replace("}", "");
	 *
	 * requesturi = path + "/" + basePathbundleValueStore;
	 *
	 * }
	 */

	// QueryParams get from Text file Variable like ScenarioBundle

	/*
	 * // @Given(
	 * "^query parameter fetch from text file \"([^\"]*)\" is set to \"([^\"]*)\"$"
	 * ) public void givenAQueryParameterFetchFromTextFile(String
	 * queryParameterName, String queryParameterVariable) {
	 *
	 * String queryParameterbundleValueStore =
	 * cucumberInteractionSession.scenarioBundle()
	 * .getString(queryParameterVariable.replace("{", "").replace("}", ""));
	 *
	 * queryParametersTextFile.put(queryParameterName,
	 * queryParameterbundleValueStore);
	 *
	 * request.queryParams(queryParametersTextFile);
	 *
	 * }
	 */

	// @Then("^the JSON array \"([^\"]*)\" should not have an element with key
	// \"([^\"]*)\" and values? \"([^\"]*)\"$")
	public void theJSONObjectDataShouldNotHaveKeyAndValue(String array, String key,
			@Delimiter(":") List<String> values) {
		response.then().body(array, notNullValue());
		List<String> actualValues = getValuesFromJsonArrayWithKey(key, array);
		for (String val : values) {
			assertThat(actualValues, not(hasItem(val)));
		}
	}

	// @Then("^the JSON array \"([^\"]*)\" should have values? \"([^\"]*)\"$")
	public void theJSONArrayShouldHaveValues(String array, @Delimiter(":") List<String> values) {
		response.then().body(array, notNullValue());
		for (String val : values) {
			assertThat(getJsonArrayValues(array), hasItem(val));
		}
	}

	// @Then("^the JSON array \"([^\"]*)\" should not have values other than
	// \"([^\"]*)\"$")
	public void theJSONArrayShouldNotHaveValuesOtherThan(String array, @Delimiter(":") List<String> values) {
		response.then().body(array, notNullValue());
		for (String value : getJsonArrayValues(array)) {
			assertThat(value, isIn(values));
		}

	}

	// Scenario Bundle fetch the array values from json response and update
	// dynamic
	// values with single quotes and back slash removal
	// values in json payload request input file

	// @Given("^the request body fetch from scenario bundle key value \"(.*)\"
	// is update with array dynamic values \"(.*)\" and property \"(.*)\" from
	// the json file path \"(.*)\"$")
	public void updateRequestFileDynamicArrayValuesFromScenarioBundleJayWayLib(String jsonArraypath,
			String dynamicValue, String property, String jsonFilePath) throws Exception {

		// String bundleValueStore = cucumberInteractionSession.scenarioBundle()
		// .getString(dynamicValue.replace("{", "").replace("}", ""));

		String bundleValueStore = resuableObject.fetchKeyValues(dynamicValue);

		String body = resuableObject.updateJsonFileContentsJayWayLib(jsonArraypath, property, bundleValueStore,
				jsonFilePath);
		System.out.println("Body Values: " + body);

		request.body(body);

	}

	// Scenario Bundle fetch the array values from json response and update
	// dynamic
	// values with double quotes and back slash
	// values in json payload request input file

	// @Given("^the request body fetch from scenario bundle key value \"(.*)\"
	// is update with array dynamic values \"(.*)\" and property having
	// doublequotes with backslash value \"(.*)\" from the json file path
	// \"(.*)\"$")
	public void updateRequestFileDynamicArrayValuesFromScenarioBundleJayWayLibFeatures(String jsonArraypath,
			String dynamicValue, String property, String jsonFilePath) throws Exception {

		// String bundleValueStore = cucumberInteractionSession.scenarioBundle()
		// .getString(dynamicValue.replace("{", "").replace("}", ""));

		String bundleValueStore = resuableObject.fetchKeyValues(dynamicValue);

		String body = resuableObject.updateJsonFileContentsJayWayLibFeatures(jsonArraypath, property, bundleValueStore,
				jsonFilePath);
		System.out.println("Body Values: " + body);

		request.body(body);

	}

	// Scenario Bundle fetch the array values from json response and update
	// dynamic
	// values in json payload request input file without String only plain Array
	// in
	// Json payload file

	// @Given("^the request body fetch from scenario bundle key value \"(.*)\"
	// is update without string array with dynamic values \"(.*)\" and property
	// \"(.*)\" from the json file path \"(.*)\"$")
	public void updateRequestFileDynamicArrayValuesFromScenarioBundleJayWayLibPlainArray(String jsonArraypath,
			String dynamicValue, String property, String jsonFilePath) throws Exception {

		// String bundleValueStore = cucumberInteractionSession.scenarioBundle()
		// .getString(dynamicValue.replace("{", "").replace("}", ""));

		String bundleValueStore = resuableObject.fetchKeyValues(dynamicValue);

		String body = resuableObject.updateJsonFileContentsJayWayLibPlainArray(jsonArraypath, property,
				bundleValueStore, jsonFilePath);
		System.out.println("Body Values: " + body);

		request.body(body);

	}

	// @Given("^the request body key \"(.*)\" is update with dynamic values
	// \"(.*)\" with uniqueId value \"(.*)\" from the json file path \"(.*)\"$")
	public void updateRequestFileDynamicValuesConcatWithUniqueId(String jsonpath, String ValueTobeUpdate, String uniqID,
			String jsonFilePath) {

		// String uniqueId =
		// cucumberInteractionSession.scenarioBundle().getString(uniqID);

		String uniqueId = resuableObject.fetchKeyValues(uniqID);

		String valueConcat = ValueTobeUpdate.concat(uniqueId);

		resuableObject.updateRequestFileDynamicValues(jsonpath, valueConcat, jsonFilePath);

	}

	// @Given("^the request body key \"(.*)\" is update with dynamic values with
	// next increment business days value \"(.*)\" from the json file path
	// \"(.*)\"$")
	public void updateRequestFileDynamicValuesUpdateWithBusinessDaysIncrement(String jsonpath,
			String businessDaysIncrement, String jsonFilePath) {

		// String dateIncrement =
		// cucumberInteractionSession.scenarioBundle().getString(businessDaysIncrement);

		String dateIncrement = resuableObject.fetchKeyValues(businessDaysIncrement);

		int i = 1;
		i++;
		String dateAfterIncrementOne = String.valueOf(Integer.parseInt(dateIncrement) + i);

		StringBuilder StartDateBuilder = new StringBuilder(dateAfterIncrementOne);
		StartDateBuilder.insert(4, '-');
		StartDateBuilder.insert(7, '-');

		String modifiedDateWithHyphen = StartDateBuilder.toString();

		resuableObject.updateRequestFileDynamicValues(jsonpath, modifiedDateWithHyphen, jsonFilePath);

	}

	// * To store a dynamic run time generated value into the test data file
	// *

	// @Then("^store the random data \"(.*)\" with dynamic values \"(.*)\" with
	// uniqueId value \"(.*)\" in file path \"(.*)\"$")
	public void storePassingPropertyField(String key, String Name, String value) throws Throwable {

		// String uniqueId =
		// cucumberInteractionSession.scenarioBundle().getString(value);

		String uniqueId = resuableObject.fetchKeyValues(value);

		String valueConcat = Name.concat(uniqueId);

		resuableObject.storeKeyValues(key, valueConcat);

	}

	// * To compare values stored in two variables and check if the second value
	// is
	// * greater

	// @Then("^compare two values \"(.*)\" and \"(.*)\" to check if second value
	// is greater$")
	public void compareTwoNumbers(String num1, String num2) {
		String number1 = resuableObject.fetchKeyValues(num1);
		String number2 = resuableObject.fetchKeyValues(num2);
		long n1 = Long.valueOf(number1).longValue();
		long n2 = Long.valueOf(number2).longValue();
		assertTrue("Second number is smaller", n1 < n2);
		System.out.println("Second number is greater" + System.lineSeparator() + "1st value = " + n1
				+ System.lineSeparator() + "2nd value = " + n2 + "");
	}

	/*
	 * Security Session Cookie set for Infinity Onboarding App
	 */

	/*
	 * // @Given(
	 * "^do the login API authentication for the service request path and username password from property file$"
	 * ) public void givenRequestAPIAuthentication() throws Throwable {
	 *
	 * System.out.println("Property getLoginURI : " +
	 * endPointConfig.getLoginURI());
	 * request.baseUri(endPointConfig.getLoginURI()); }
	 *
	 * // Implemented for End to End Spotlight test project comprising another
	 * App like // Retail DBP project login url
	 *
	 * // @Given(
	 * "^do the login API authentication for the second service request url from property file$"
	 * ) public void givenRequestAPIAuthenticationApp2() throws Throwable {
	 *
	 * System.out.println("Property getLoginURI2 : " +
	 * endPointConfig.getLoginURI2());
	 * request.baseUri(endPointConfig.getLoginURI2()); }
	 */

	// @Given("^I set the request header values for X-Kony-ReportingParams$")
	public void givenRequestHeaderReportingParams() throws Throwable {

		request.header("X-Kony-ReportingParams",
				"{\"os\":\"71\",\"dm\":\"\",\"did\":\"1544592656431-5e10-a1f1-7b6f\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36\",\"aid\":\"KonyOLB\",\"aname\":\"Customer360\",\"chnl\":\"Mobile\",\"plat\":\"windows\",\"aver\":\"1.0.0\",\"atype\":\"spa\",\"stype\":\"b2c\",\"kuid\":\"admin2\",\"mfaid\":\"61cffb74-340f-497f-b637-ff553e93dae5\",\"mfbaseid\":\"92b54bcc-e43e-4a62-bbd9-f7d1ca009391\",\"mfaname\":\"KonyBankingAdminConsole\",\"sdkversion\":\"8.3.5\",\"sdktype\":\"js\",\"fid\":\"frmLogin\",\"rsid\":\"1544972285376-6808-1496-9004\",\"svcid\":\"login_KonyBankingAdminConsoleIdentityService\"}");
	}

	/*
	 * // @Given(
	 * "^I set the request header values for X-Kony-App-Key and X-Kony-App-Secret-Key$"
	 * ) public void givenRequestKonyAppKeySecretKey() throws Throwable {
	 *
	 * request.header("X-Kony-App-Key", globalConfig.getAppKey());
	 * request.header("X-Kony-App-Secret", endPointConfig.getAppSecret()); }
	 *
	 * // Second appkey and secretkey2 for end to end spotlight tests project
	 * adding // another application like RetailDBP app-credentials
	 *
	 * // @Given(
	 * "^I set the request header values for second X-Kony-App-Key2 and X-Kony-App-Secret-Key2$"
	 * ) public void givenRequestKonyAppKey2SecretKey2() throws Throwable {
	 *
	 * request.header("X-Kony-App-Key", endPointConfig.getAppKey2());
	 * request.header("X-Kony-App-Secret", endPointConfig.getAppSecret2()); }
	 */

	public static void JMSToken(String uri) {
		StringBuilder content = new StringBuilder();
		try {

			RestAssured.defaultParser = Parser.JSON;
			request = RestAssured.given().log().all();
			request.urlEncodingEnabled(false);
			request.baseUri(uri);
			// request.basePath(path);

			requesturi = uri;
			response = request.get(requesturi);

			System.out.println(response.statusCode());
			System.out.println(response.asString());

			try (BufferedReader in = new BufferedReader(new InputStreamReader(response.asInputStream()))) {

				String line;
				content = new StringBuilder();

				while ((line = in.readLine()) != null) {
					content.append(line);
					content.append(System.lineSeparator());
				}
			}

			String token = content.toString();

			System.out.println(token);

			// requesturi = path;

			// response = request.get(path);

			queryParameters = new HashMap<>();
			queryParametersTextFile = new HashMap<>();

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To start api session", "API seesion of " + requesturi + "is started",
					"API seesion started successfully");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			Reuse.log(e);
			e.printStackTrace();
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To start api session", "API seesion of " + uri + "is not started",
					"API seesion not successfully started");
		}

	}

	public static void API_storeMultiLevelJsonProperty(String inputPath, String propertyNeeded) {
		/*
		 * RequestSpecification request = RestAssured.given().log().all();
		 * request.urlEncodingEnabled(false); request.header("Authorization",
		 * "eyJraWQiOiJLQTAxIiwidHlwIjoiSldUIiwiYWxnIjoiUlMyNTYifQ.eyJhdWQiOiJJUklTIiwic3ViIjoiVDI0Iiwicm9sZUlkIjoiSU5GSU5JVFkuT05CT0FSRElORyIsImlzcyI6IkZhYnJpYyIsImRieFVzZXJJZCI6IjAwMDEiLCJleHAiOjMxNjQ4NDY5NjMsImlhdCI6MTU4ODA0Njk2MywidXNlcklkIjoiVDI0IiwiX2lzc21ldGEiOiJodHRwczpcL1wvZGJ4bGVuZGluZ3FhLmtvbnljbG91ZC5jb21cL3NlcnZpY2VzXC9UMjRJU0V4dHJhXC9nZXRwdWJsaWNrZXkiLCJqdGkiOiI3OTZkNjUyNy1mNmEwLTQ4YmItYmI0NS1hZmQyMzdhZTUwZmYifQ.g-5pPTK1sSZUbbvZ-ScgN6kEOv8uSpvGcYjH1miF_mHV3vr3kDVXCspz3sbFHgCHK-UmU8v6xGIXSOntL4Go5oO5LyYsLS7ZwcU-JCOIK_8CF4DTLEYaIPDrA2U21tJkfxQ37QRzeAF_7tqnWOe-LzTbtLPTDZmHcVTTZzx3ZCqUa55OyaDJT2KGkU578p7O1fq333Dvjlbn2tBFGYUOPnCHzLU4Z5PTlNLqtbxaA-G8IAdidaUfTHD2MzFFLnhnTGmqkr7JlQfukYL98KjUtHU-hOQx6XQCo-kQWWVOVQlZUp6W8oWCR56iFYjRCVDNv0J852VpKy2YCkRHVoAD8g"
		 * ); //request.queryParams(queryParameters);
		 *
		 * Response respon = request.get(
		 * "http://52.172.25.203:8010/ms-storage-api/api/v0.9.0/origination/storage/entityDefinitions/onboarding/entityItems/?key=4WDR68T"
		 * ); String response = respon.body().asString();
		 * System.out.println("\n\n" + response + "\n");
		 */

		JsonPath jsonPathContent = JsonPath.from(response.asString());
		System.out.println("JSON>>" + jsonPathContent.toString());

		// String input =
		// "entityItems[x].entityItemDefinitionName=ApplicantMetaData";
		// String input = "entityItems[0].entityItemDefinitionName";
		// String input = "entityItems[0].entityItemDefinitionName";

		try{
			String property1 = "";
			String property2 = "";
			if (propertyNeeded.contains("#")) {
				property1 = propertyNeeded.split("#")[0];
				property2 = propertyNeeded.split("#")[1];
			}

			if (inputPath.contains("=")) {
				String property = inputPath.substring(inputPath.lastIndexOf("=") + 1);
				inputPath = inputPath.replace("=" + property, "");

				if (inputPath.contains("[x]")) {

					for (int i = 0; i < 100; i++) {
						String finalXpath = inputPath.replace("[x]", "[" + i + "]");

						System.out.println("XPATH::" + finalXpath);
						System.out.println("JSON::" + jsonPathContent.toString());

						System.out.println(">>" + jsonPathContent.getString(finalXpath));

						if (jsonPathContent.getString(finalXpath).equals(property)) {
							String newPath = inputPath.replace("[x]", "[" + i + "]");
							newPath = newPath.substring(0, inputPath.lastIndexOf("."));
							System.out.println("@" + newPath);

							newPath = newPath + "." + property1;
							System.out.println("##" + newPath);
							String key=null;

							try {
								JSONObject obj = new JSONObject(jsonPathContent.getString(newPath));
								// looping thru inner array of entry if present
								String finalValue = "";
								if (property2.contains("[x]")) {
									// Products[x].AccountNumber=auto@ACCNT_NO

									String upd = property2.substring(0, property2.indexOf("[x]"));
									//JSONObject normObj = (JSONObject) obj.get(upd);
									JSONArray arrayObj = (JSONArray) obj.get(upd);
									System.out.println(arrayObj.toString());

									for (int j = 0; j < 100; j++) {
										JSONObject newObj = (JSONObject) arrayObj.get(j);
										String finalProp = property2.substring(property2.indexOf(".")+1, property2.indexOf("="));
										System.out.println(finalProp);

										finalValue = (String) newObj.get(finalProp);
										Demo1.logger.info("FINAL VALUE PARSED::" + finalValue);
										break;
									}

									if (property2.contains("auto@")) {
										key = property2.split("=")[1].replace("auto@", "");
										Reuse.WriteProperties(key, finalValue);
										System.out.println("KEY::" + key + "\tVALUE::" + finalValue);
									} else {
										System.out.println("VALUE FETCHED::" + obj.get(property2));
									}
								} else {
									if (property2.contains("auto@")) {
										key = property2.split("=")[1].replace("auto@", "");
										Reuse.WriteProperties(key, obj.get(property2.split("=")[0]).toString());
										System.out.println(
												"KEY::" + key + "\tVALUE::" + obj.get(property2.split("=")[0]).toString());
									} else {
										System.out.println("VALUE FETCHED::" + obj.get(property2));
									}
								}

								Demo1.gbTestCaseStatus = "Pass";
				                Demo1.ReportStep(2, key + " should be fetched from response and stored", "Property should be fetched from response and stored",
				                		key + " is fetched from response and stored successfully");

								break;
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}
				}
			} else {
				if (inputPath.contains("[x]")) {
					for (int i = 0; i < 100; i++) {
						String finalXpath = inputPath.replace("[x]", "[" + i + "]");

						System.out.println("XPATH::" + finalXpath);
						System.out.println("JSON::" + jsonPathContent);

						System.out.println(">>" + jsonPathContent.getString(finalXpath));

						if (!property1.isEmpty() && property2.isEmpty()) {
							try {
								JSONObject obj = new JSONObject(jsonPathContent.getString(finalXpath));
								System.out.println("FOUND::" + obj.get(property1));
								break;
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}
				} else {
					System.out.println(">>" + jsonPathContent.getString(inputPath));
				}

				Demo1.gbTestCaseStatus = "Pass";
	            Demo1.ReportStep(2, property1 + " should be fetched from response and stored", "Property should be fetched from response and stored",
	            		property1 + " is fetched from response and stored successfully");

			}
		}catch(Exception e){
			Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Property should be fetched from response and stored", "Property should be fetched from response and stored",
            		"Failed to fetch the property from response/Failed to store the property in TestData");

		}
	}
	
	public static void API_SetRequestBodyFormParamByFile(String key, String body) {

		try {

			File f = new File(System.getProperty("user.dir") + "/TestData/" + body);

			request.header("Content-Type","multipart/form-data").contentType("multipart/form-data").multiPart(key,f);

			Demo1.gbTestCaseStatus = "Pass";
			Demo1.ReportStep(2, "To set request body by form data multipart value", "Set request body by form data using key as <b>"+key+"</b> and value as <b>"+body+"</b> should be successful",
					"Set request body by form data using key as <b>"+key+"</b> and value as <b>"+body+"</b> is successful");

		} catch (Exception e) {
			e.printStackTrace();
			Reuse.log(e);
			Demo1.gbTestCaseStatus = "Fail";
			Demo1.ReportStep(2, "To set request body by form data multipart value", "Set request body by form data using key as <b>"+key+"</b> and value as "+body+" should be successful",
					"Set request body by form data using keys as <b>"+key+"</b> and value as <b>"+body+"</b> is not successful");
		}

	}

}
