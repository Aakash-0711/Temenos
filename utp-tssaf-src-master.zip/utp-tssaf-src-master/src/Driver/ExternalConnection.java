package Driver;

import static org.apache.commons.lang3.StringEscapeUtils.escapeHtml3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.ibatis.jdbc.ScriptRunner;

import com.google.common.base.Throwables;

import net.neoremind.sshxcute.core.ConnBean;
import net.neoremind.sshxcute.core.IOptionName;
import net.neoremind.sshxcute.core.Result;
import net.neoremind.sshxcute.core.SSHExec;
import net.neoremind.sshxcute.core.SysConfigOption;
import net.neoremind.sshxcute.exception.TaskExecFailException;
import net.neoremind.sshxcute.task.CustomTask;
import net.neoremind.sshxcute.task.impl.ExecCommand;

/**
 * TODO: Document me!
 *
 * @author mohammedbilal
 *
 */
public class ExternalConnection {






    public static String getProcessedDBurl(String url)
    {

 try {

            if(url.contains("Config.")){

                url=url.split("\\.")[1];

                 url  = Config.getProperty(url);


                }
            System.out.println(url +":"+ url);

        } catch (Exception e) {
            System.out.println("Problem in config properties");
            Reuse.log(e);
        }


        return url;

    }



    public static String[] getProcessedExpectedValues(String url)
    {
        String[] values = null;
 try {

     url =  getProcessedQuery(url);

          values=url.split("\\|\\|");

            for(String i : values)
            System.out.println("Value :"+ i);

        } catch (Exception e) {
            System.out.println("Problem in expected value");

        }


        return values;

    }


    public static void dB_CheckColumnExists(String url,String table,String column) throws Exception
    {
        DatabaseMetaData dbm;
        ResultSet rs = null;
        boolean ismet;

        Thread.sleep(5000);


        url = getProcessedDBurl(url);

        Connection conn = null;
        String driverjdbc = null;

        if(url.contains("sqlserver"))
        {
            driverjdbc = Config.getProperty("DB.MSSQL.DRIVER");

        }else if(url.contains("oracle")){

            driverjdbc =  Config.getProperty("DB.ORACLE.DRIVER");
        }else if(url.contains("postgresql")){

        	driverjdbc = Config.getProperty("DB.POSTGRESSQL.DRIVER");
        }



        Demo1.gbTestCaseStatus = "Pass";
        boolean DBconnect = true;
        try
        {
            Class.forName(driverjdbc);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        System.out.println("Driver Loaded");

        try
        {
            conn = DriverManager.getConnection(url);
        }
        catch (java.sql.SQLException EX)
        {
            DBconnect = false;
            Demo1.gbTestCaseStatus = "Fail";
            EX.printStackTrace();
            System.out.println("Problem with Connection correct your ORACLE URL/DBNAME/CREDENTIAL");
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Check table exists", "Error while connecting to DB",
                    Throwables.getStackTraceAsString(EX));
        }

        try
        {
            if (DBconnect)
            {
                ismet = false;
                dbm = conn.getMetaData();
                rs = dbm.getColumns(null, null, table, column);
                if (rs.next())
                {
                    ismet = true;
                }

                if (ismet)
                {
                        Demo1.gbTestCaseStatus = "Pass";
                        Demo1.ReportStep(2, "Check if "+column+" Column is existing in " + table + " table",
                                column+" Column should be existing in " + table + " Table", column+" Column exists in " + table + " Table");

                    }
                    else
                    {
                        Demo1.gbTestCaseStatus = "Fail";
                        Demo1.ReportStep(2, "Check if "+column+" Column is existing in " + table + " Table",
                                column+" Column should be existing in " + table + " Table", column+" Column doesn't exist in " + table + " Table");

                    }


                }


        }

        catch (Exception ex)
        {

            /*Demo1.gbTestCaseStatus = "Warn";
            Demo1.TestStepWarningCount = Demo1.TestStepWarningCount + 1;
            Demo1.logger.warn("Warning in " + Demo1.gbCurrTestCaseName + "  --->" + ex);*/
            System.out.println(ex);
            ex.printStackTrace();
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Check table", "Verify if the table : " + table + " exists",
                    table + " is not available");
        }
        finally
        {

            rs.close();

            conn.close();




        }
    }


    public static void dB_CheckColumnNotExists(String url,String table,String column) throws Exception
    {
        DatabaseMetaData dbm;
        ResultSet rs = null;
        boolean ismet;

        Thread.sleep(5000);


        url = getProcessedDBurl(url);

        Connection conn = null;
        String driverjdbc = null;

        if(url.contains("sqlserver"))
        {
            driverjdbc = Config.getProperty("DB.MSSQL.DRIVER");

        }else if(url.contains("oracle")){

            driverjdbc =  Config.getProperty("DB.ORACLE.DRIVER");
        }else if(url.contains("postgresql")){

        	driverjdbc = Config.getProperty("DB.POSTGRESSQL.DRIVER");
        }



        Demo1.gbTestCaseStatus = "Pass";
        boolean DBconnect = true;
        try
        {
            Class.forName(driverjdbc);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        System.out.println("Driver Loaded");

        try
        {
            conn = DriverManager.getConnection(url);
        }
        catch (java.sql.SQLException EX)
        {
            DBconnect = false;
            Demo1.gbTestCaseStatus = "Fail";
            EX.printStackTrace();
            System.out.println("Problem with Connection correct your ORACLE URL/DBNAME/CREDENTIAL");
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Check table exists", "Error while connecting to DB",
                    Throwables.getStackTraceAsString(EX));
        }

        try
        {
            if (DBconnect)
            {
                ismet = false;
                dbm = conn.getMetaData();
                rs = dbm.getColumns(null, null, table, column);
                if (rs.next())
                {
                    ismet = true;
                }

                if (!ismet)
                {
                        Demo1.gbTestCaseStatus = "Pass";
                        Demo1.ReportStep(2, "Check if "+column+" Column is existing in " + table + " table",
                                column+" Column should not be existing in " + table + " Table", column+" Column does not exists in " + table + " Table");

                    }
                    else
                    {
                        Demo1.gbTestCaseStatus = "Fail";
                        Demo1.ReportStep(2, "Check if "+column+" Column is existing in " + table + " Table",
                                column+" Column should not be existing in " + table + " Table", column+" Column  exist in " + table + " Table");

                    }


                }

        }

        catch (Exception ex)
        {

            /*Demo1.gbTestCaseStatus = "Warn";
            Demo1.TestStepWarningCount = Demo1.TestStepWarningCount + 1;
            Demo1.logger.warn("Warning in " + Demo1.gbCurrTestCaseName + "  --->" + ex);*/
            System.out.println(ex);
            ex.printStackTrace();
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Check table", "Verify if the table : " + table + " exists",
                    table + " is not available");
        }
        finally
        {
            rs.close();
//            stmt.close();
                    conn.close();
        }
    }

    public static void dB_CheckJobStatus(String url, String query, String waitTime) throws Exception
    {


        ResultSet rs = null;
        Statement stmt = null;

        Thread.sleep(5000);


        url = getProcessedDBurl(url);

        Connection conn = null;
        String driverjdbc = null;

        if(url.contains("sqlserver"))
        {
            driverjdbc = Config.getProperty("DB.MSSQL.DRIVER");

        }else if(url.contains("oracle")){

            driverjdbc =  Config.getProperty("DB.ORACLE.DRIVER");
        }else if(url.contains("postgresql")){

        	driverjdbc = Config.getProperty("DB.POSTGRESSQL.DRIVER");
        }


        Demo1.gbTestCaseStatus = "Pass";
        boolean DBconnect = true;
        try
        {
            Class.forName(driverjdbc);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        System.out.println("Driver Loaded");

        try
        {
            conn = DriverManager.getConnection(url);
        }
        catch (java.sql.SQLException EX)
        {
            DBconnect = false;
            Demo1.gbTestCaseStatus = "Fail";
            System.out.println("Problem with Connection correct your ORACLE URL/DBNAME/CREDENTIAL");
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Check DB exists", "Error while connecting to DB",
            Throwables.getStackTraceAsString(EX));
        }

        if (DBconnect)
        {
            try
            {

                stmt = conn.createStatement();
                boolean ismet = false;
                int timeOutInsec=Integer.parseInt(waitTime);


               for(int i=0;i<=2;i++){
                    rs = stmt.executeQuery(query);
                    if (!rs.isBeforeFirst())
                    {
                        System.out.println("Job is done");
                        ismet = true;
                        break ;
                    }
                    else
                    {
                        System.out.println("Job is still executing");

                        if (Config.OverrideHardCodedWait > 1)
                        {
                            // Thread.sleep(Config.OverrideHardCodedWait);
                        }
                        else
                        {
                            int secToWait = timeOutInsec;
                            Reuse.oWait(secToWait);
                        }
                    }
                }

                if (!ismet)
                {
                    Demo1.gbTestCaseStatus = "Fail";

                    Demo1.ReportStep(2, "Trigger SQL Server Agent Job",
                    " job should be started"," job is not started");
                }

                else
                {
                    Demo1.gbTestCaseStatus = "Pass";

                    Demo1.ReportStep(2, "Trigger SQL Server Agent Job",
                    " job should be started"," job is started");
                }
            }
            catch (Exception ex)
            {

                System.out.println(ex);
                ex.printStackTrace();
                Demo1.gbTestCaseStatus = "Fail";
                //Demo1.ReportStep(2, "Verify record count of " + tabe1 + " and " + tabe2,
                        //"Record count should be " + action, Throwables.getStackTraceAsString(ex));

            }
            finally
            {
                rs.close();
                stmt.close();
                        conn.close();
            }
        }
    }



    public static void dB_CheckTableExists(String url, String table) throws Exception
    {
        DatabaseMetaData dbm;
        ResultSet rs = null;
        boolean ismet;

        Thread.sleep(5000);


        url = getProcessedDBurl(url);

        Connection conn = null;
        String driverjdbc = null;

        if(url.contains("sqlserver"))
        {
            driverjdbc = Config.getProperty("DB.MSSQL.DRIVER");

        }else if(url.contains("oracle")){

            driverjdbc =  Config.getProperty("DB.ORACLE.DRIVER");
        }else if(url.contains("mariadb")){

        	//driverjdbc =  Config.getProperty("DB.MARIADB.DRIVER");
        	driverjdbc = "org.mariadb.jdbc.Driver";
        }else if(url.contains("postgresql")){

        	driverjdbc = Config.getProperty("DB.POSTGRESSQL.DRIVER");
        }


        Demo1.gbTestCaseStatus = "Pass";
        boolean DBconnect = true;
        try
        {
            Class.forName(driverjdbc);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        System.out.println("Driver Loaded");

        try
        {
            conn = DriverManager.getConnection(url);
        }
        catch (java.sql.SQLException EX)
        {
            DBconnect = false;
            Demo1.gbTestCaseStatus = "Fail";
            EX.printStackTrace();
            System.out.println("Problem with Connection correct your ORACLE URL/DBNAME/CREDENTIAL");
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Check table exists", "Error while connecting to DB",
                    Throwables.getStackTraceAsString(EX));
        }

        try
        {
            if (DBconnect)
            {
                ismet = false;
                dbm = conn.getMetaData();
                String db = conn.getCatalog();
                rs = dbm.getTables(null, null, table, null);
                if (rs.next())
                {
                    ismet = true;
                }

                if (ismet)
                {
                    Demo1.gbTestCaseStatus = "Pass";

                        Demo1.ReportStep(2, "Check if "+table+" table is existing in " + db + " database",
                        table+" table should be existing in " + db + " database", table+" table exists in " + db + " database");

                }
                    else
                    {
                        Demo1.gbTestCaseStatus = "Fail";

                        Demo1.ReportStep(2, "Check if "+table+" table is existing in " + db + " database",
                                table+" table should be existing in " + db + " database", table+" table doesn't exist in " + db + " database");

                    }

                }



        }

        catch (Exception ex)
        {

            System.out.println(ex);
            ex.printStackTrace();
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Check table", "Verify if the table : " + table + " exists",
                    table + " is not available");
        }
        finally
        {
            rs.close();
//            stmt.close();
                    conn.close();
        }
    }

    public static void dB_CheckTableNotExists(String url, String table) throws Exception
    {
        DatabaseMetaData dbm;
        ResultSet rs = null;
        boolean ismet;

        Thread.sleep(5000);


        url = getProcessedDBurl(url);

        Connection conn = null;
        String driverjdbc = null;

        if(url.contains("sqlserver"))
        {
            driverjdbc = Config.getProperty("DB.MSSQL.DRIVER");

        }else if(url.contains("oracle")){

            driverjdbc =  Config.getProperty("DB.ORACLE.DRIVER");
        }else if(url.contains("postgresql")){

        	driverjdbc = Config.getProperty("DB.POSTGRESSQL.DRIVER");
        }


        Demo1.gbTestCaseStatus = "Pass";
        boolean DBconnect = true;
        try
        {
            Class.forName(driverjdbc);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        System.out.println("Driver Loaded");

        try
        {
            conn = DriverManager.getConnection(url);
        }
        catch (java.sql.SQLException EX)
        {
            DBconnect = false;
            Demo1.gbTestCaseStatus = "Fail";
            EX.printStackTrace();
            System.out.println("Problem with Connection correct your ORACLE URL/DBNAME/CREDENTIAL");
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Check table exists", "Error while connecting to DB",
                    Throwables.getStackTraceAsString(EX));
        }

        try
        {
            if (DBconnect)
            {
                ismet = false;
                dbm = conn.getMetaData();
                String db = conn.getCatalog();
                rs = dbm.getTables(null, null, table, null);
                if (rs.next())
                {
                    ismet = true;
                }

                if (!ismet)
                {
                    Demo1.gbTestCaseStatus = "Pass";

                        Demo1.ReportStep(2, "Check if "+table+" table is existing in " + db + " database",
                        table+" table should not be existing in " + db + " database", table+" table does not exists in " + db + " database");

                }
                    else
                    {
                        Demo1.gbTestCaseStatus = "Fail";

                        Demo1.ReportStep(2, "Check if "+table+" table is existing in " + db + " database",
                                table+" table should not be existing in " + db + " database", table+" table exist in " + db + " database");

                    }

                }



        }

        catch (Exception ex)
        {

            System.out.println(ex);
            ex.printStackTrace();
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Check table", "Verify if the table : " + table + " exists",
                    table + " is not available");
        }
        finally
        {
            rs.close();
//            stmt.close();
                    conn.close();
        }
    }


    public static void dB_VerifyDataTypeOfColumn(String url, String query, String column, String expectedDataType) throws Exception
    {
        DatabaseMetaData dbm;
        ResultSet rs = null;
        Statement stmt = null;
        boolean ismet;
        String dataType=null;

        Thread.sleep(5000);


        url = getProcessedDBurl(url);

        Connection conn = null;
        String driverjdbc = null;

        if(url.contains("sqlserver"))
        {
            driverjdbc = Config.getProperty("DB.MSSQL.DRIVER");

        }else if(url.contains("oracle")){

            driverjdbc =  Config.getProperty("DB.ORACLE.DRIVER");
        }else if(url.contains("postgresql")){

        	driverjdbc = Config.getProperty("DB.POSTGRESSQL.DRIVER");
        }

        Demo1.gbTestCaseStatus = "Pass";
        boolean DBconnect = true;
        try
        {
            Class.forName(driverjdbc);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        System.out.println("Driver Loaded");

        try
        {
            conn = DriverManager.getConnection(url);
        }
        catch (java.sql.SQLException EX)
        {
            DBconnect = false;
            Demo1.gbTestCaseStatus = "Fail";
            System.out.println("Problem with Connection correct your ORACLE URL/DBNAME/CREDENTIAL");
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Check DB exists", "Error while connecting to DB",
            Throwables.getStackTraceAsString(EX));
        }

        if (DBconnect)
        {
            try
            {
                query=Reuse.getProcessedQuery(query);
                stmt = conn.createStatement();
                ismet = false;
                rs = stmt.executeQuery(query);
                ResultSetMetaData rsMetaData = rs.getMetaData();
                int numberOfColumns = rsMetaData.getColumnCount();
                for (int i = 1; i <= numberOfColumns; i++)
                {
                    if (column.equals(rsMetaData.getColumnName(i)))
                    {
                        dataType = rsMetaData.getColumnTypeName(i);
                        System.out.println("getColumnType : " + rsMetaData.getColumnType(i));
                        System.out.println("getColumnLabel : " + rsMetaData.getColumnLabel(i));
                        System.out.println("getColumnDisplaySize : " + rsMetaData.getColumnDisplaySize(i));
                        System.out.println("BaseDatatype of " + column + " column in "+ " table is : " + dataType);
                    }
                }
                //String ExpectedDataType = Demo1.runTimeMap.get(HashName);
               // DataType = "[" + DataType + "]";
                if (dataType.equalsIgnoreCase(expectedDataType))
                {
                    ismet = true;
                }

                if (!ismet)
                {
                    Demo1.gbTestCaseStatus = "Fail";

                    Demo1.ReportStep(2, "Verify datatype of " + column + " column",
                    column+" datatype should be " +expectedDataType,column+" datatype is " +dataType);
                }

                else
                {
                    Demo1.gbTestCaseStatus = "Pass";

                    Demo1.ReportStep(2, "Verify datatype of " + column + " column",
                            column+" datatype should be " +expectedDataType,column+" datatype is " +dataType);
                }
            }
            catch (Exception ex)
            {

                System.out.println(ex);
                ex.printStackTrace();
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Check table", "Verify if the column : " + column + " exists",
                        column + " is not available");

            }
            finally
            {
                rs.close();
                stmt.close();
                        conn.close();
            }
        }
    }


    public static void dbExecuteSqlstatments(Connection conn, File inputFile)
    {
         conn = null;
        // Delimiter
        String delimiter = ";";

        // Create scanner
        Scanner scanner;
        try
        {
            scanner = new Scanner(inputFile).useDelimiter(delimiter);
        }
        catch (FileNotFoundException e1)
        {
            e1.printStackTrace();
            return;
        }

        // Loop through the SQL file statements
        Statement currentStatement = null;
        while(scanner.hasNext())
        {
            // Get statement
            String rawStatement = scanner.next() + delimiter;
            try
            {
                // Execute statement
                currentStatement = conn.createStatement();
                ResultSet rs;
                currentStatement.execute(rawStatement);


              rs =  currentStatement.getResultSet();

              if(rs.next())
                  System.out.println(rs.getString(1));

                Demo1.gbTestCaseStatus = "Pass";

                Demo1.ReportStep(2, "Query should be executed " ,
                        "Query should be executed " +rawStatement , "Query executed succesfully ");


            }
            catch (SQLException e)
            {
                e.printStackTrace();

                Demo1.gbTestCaseStatus = "Fail";

                Demo1.ReportStep(2, "Query should be executed " ,
                        "Query should be executed " +rawStatement , "Query not executed succesfully "+e.getMessage());
            }




            finally
            {
                // Release resources
                if (currentStatement != null)
                {
                    try
                    {
                        currentStatement.close();
                    }
                    catch (SQLException e)
                    {
                        e.printStackTrace();
                    }
                }
                currentStatement = null;


                        try {
                            conn.close();
                        } catch (SQLException e) {
                            // TODO Auto-generated catch block
                            // Uncomment and replace with appropriate logger
                            // LOGGER.error(e, e);
                        }

            }
        }
    scanner.close();
    }

    public static void dB_ExecuteSQLScript(String url, String path) throws Exception
    {
        Connection conn = null;

        boolean ismet;


        Thread.sleep(5000);


        url = getProcessedDBurl(url);

        String driverjdbc = null;

        if(url.contains("sqlserver"))
        {
            driverjdbc = Config.getProperty("DB.MSSQL.DRIVER");

        }else if(url.contains("oracle")){

            driverjdbc =  Config.getProperty("DB.ORACLE.DRIVER");
        }else if(url.contains("postgresql")){

        	driverjdbc = Config.getProperty("DB.POSTGRESSQL.DRIVER");
        }


        Demo1.gbTestCaseStatus = "Pass";
        boolean DBconnect = true;
        try
        {
            Class.forName(driverjdbc);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        System.out.println("Driver Loaded");

        try
        {
            conn = DriverManager.getConnection(url);
        }
        catch (java.sql.SQLException EX)
        {
            DBconnect = false;
            Demo1.gbTestCaseStatus = "Fail";
            System.out.println("Problem with Connection correct your ORACLE URL/DBNAME/CREDENTIAL");
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Check DB exists", "Error while connecting to DB",
            Throwables.getStackTraceAsString(EX));
        }

        if (DBconnect)
        {
            try
            {

                ismet = false;
                File CP_file = new File(path);
                dbExecuteSqlstatments(conn,CP_file);
                ismet = true;

                if (!ismet)
                {
                    Demo1.gbTestCaseStatus = "Fail";

                    Demo1.ReportStep(2, "Execute a SQL File",
                            " SQL File : "+path+" should be executed", " SQL File : "+path+" is not executed");
                }

                else
                {
                    Demo1.gbTestCaseStatus = "Pass";

                    Demo1.ReportStep(2, "Execute a SQL File",
                            " SQL File : "+path+" should be executed", " SQL File : "+path+" is executed");
                }
            }
            catch (Exception ex)
            {

                System.out.println(ex);
                ex.printStackTrace();
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Check query", "Verify if the query : " +  " exists",
                         " query is not available");
            }
            finally {

                        conn.close();
            }
        }
    }


    public static void dB_ExecuteScriptRunner(String url, String path) throws Exception
    {
        Connection conn = null;

        boolean ismet;


        Thread.sleep(5000);


        url = getProcessedDBurl(url);

        String driverjdbc = null;

        if(url.contains("sqlserver"))
        {
            driverjdbc = Config.getProperty("DB.MSSQL.DRIVER");

        }else if(url.contains("oracle")){

            driverjdbc =  Config.getProperty("DB.ORACLE.DRIVER");
        }else if(url.contains("postgresql")){

        	driverjdbc = Config.getProperty("DB.POSTGRESSQL.DRIVER");
        }


        Demo1.gbTestCaseStatus = "Pass";
        boolean DBconnect = true;
        try
        {
            Class.forName(driverjdbc);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        System.out.println("Driver Loaded");

        try
        {
            conn = DriverManager.getConnection(url);
        }
        catch (java.sql.SQLException EX)
        {
            DBconnect = false;
            Demo1.gbTestCaseStatus = "Fail";
            System.out.println("Problem with Connection correct your ORACLE URL/DBNAME/CREDENTIAL");
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Check DB exists", "Error while connecting to DB",
            Throwables.getStackTraceAsString(EX));
        }

        if (DBconnect)
        {
            try
            {

                ismet = false;
                File CP_file = new File(path);

                ScriptRunner sr = new ScriptRunner(conn);
                //Creating a reader object
                Reader reader = new BufferedReader(new FileReader(CP_file));
                //Running the script
                sr.runScript(reader);

                ismet = true;

                if (!ismet)
                {
                    Demo1.gbTestCaseStatus = "Fail";

                    Demo1.ReportStep(2, "Execute a SQL File",
                            " SQL File : "+path+" should be executed", " SQL File : "+path+" is not executed");
                }

                else
                {
                    Demo1.gbTestCaseStatus = "Pass";

                    Demo1.ReportStep(2, "Execute a SQL File",
                            " SQL File : "+path+" should be executed", " SQL File : "+path+" is executed");
                }
            }
            catch (Exception ex)
            {

                System.out.println(ex);
                ex.printStackTrace();
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Check query", "Verify if the query : " +  " exists",
                         " query is not available");
            }
            finally {

                        conn.close();
            }
        }
    }



    public static void dB_ExecuteProcedure(String url, String procedureName, String parameters) throws Exception
    {


        Thread.sleep(5000);


        url = getProcessedDBurl(url);

        Connection conn = null;
        String driverjdbc = null;
        CallableStatement stmt = null;
        if(url.contains("sqlserver"))
        {
            driverjdbc = Config.getProperty("DB.MSSQL.DRIVER");

        }else if(url.contains("oracle")){

            driverjdbc =  Config.getProperty("DB.ORACLE.DRIVER");
        }else if(url.contains("postgresql")){

        	driverjdbc = Config.getProperty("DB.POSTGRESSQL.DRIVER");
        }

        Demo1.gbTestCaseStatus = "Pass";
        boolean DBconnect = true;
        try
        {
            Class.forName(driverjdbc);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        System.out.println("Driver Loaded");

        try
        {
            conn = DriverManager.getConnection(url);
        }
        catch (java.sql.SQLException EX)
        {
            DBconnect = false;
            Demo1.gbTestCaseStatus = "Fail";
            System.out.println("Problem with Connection correct your ORACLE URL/DBNAME/CREDENTIAL");
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Check DB exists", "Error while connecting to DB",
            Throwables.getStackTraceAsString(EX));
        }

        if (DBconnect)
        {
            try
            {

               parameters = getProcessedQuery(parameters);

               String parametersArray[] = getProcessedExpectedValues(parameters);

               int noOfParameters = parametersArray.length;



               StringBuilder para= new StringBuilder("?");
               for(int i=1; i<noOfParameters; i++){

                   para.append(",?");
               }

            if(url.contains("postgresql")) {
                String  callProcedure = "CALL "+procedureName+"("+para+")";

                System.out.println(callProcedure);

                stmt=conn.prepareCall(callProcedure);
            }
            else{
                String  callProcedure = "{call "+procedureName+"("+para+")}";

                System.out.println(callProcedure);

                stmt=conn.prepareCall(callProcedure);
            }

          //  System.out.println(callProcedure);

          //  stmt=conn.prepareCall(callProcedure);

            for(int i=1; i<=noOfParameters; i++){

                System.out.println(i +" parameter "+ parametersArray[i-1]);

                if(url.contains("postgresql")) {
                    if(i==3 || i==5) {
                        // i==3 --> 0
                        // i==5 --> 0
                    	stmt.setInt(i, Integer.parseInt(parametersArray[i-1]));
                    }
                    else
                    {
                    	stmt.setString(i, parametersArray[i-1] );
                    }
                }
                else
                {
                    stmt.setString(i, parametersArray[i-1] );
                }
            }


            System.out.println("stmt"+stmt);

                int success = stmt.executeUpdate();

                if(url.contains("postgresql")) {
                	if (success==1) 
                    {
                        Demo1.gbTestCaseStatus = "Fail";

                        Demo1.ReportStep(2, "call Procedure/Insert/Update/Delete record into "  +" table " ,
                                "Should call Procedure/Insert/Update/Delete a record into "  +" table ", "Record is not call Procedure/Insert/Update/Delete into " +" table ");
                    } 
                    else 
                    {
                        Demo1.gbTestCaseStatus = "Pass";

                        Demo1.ReportStep(2, "call Procedure/Insert/Update/Delete record into "  +" table " ,
                                "Should call Procedure/Insert/Update/Delete a record into " +" table ", "Record call Procedure/Insert/Update/Delete successfully into "  +" table ");
                    }
                }
                else {
                	if (success!=1) 
                    {
                        Demo1.gbTestCaseStatus = "Fail";

                        Demo1.ReportStep(2, "call Procedure/Insert/Update/Delete record into "  +" table " ,
                                "Should call Procedure/Insert/Update/Delete a record into "  +" table ", "Record is not call Procedure/Insert/Update/Delete into " +" table ");
                    } 
                    else 
                    {
                        Demo1.gbTestCaseStatus = "Pass";

                        Demo1.ReportStep(2, "call Procedure/Insert/Update/Delete record into "  +" table " ,
                                "Should call Procedure/Insert/Update/Delete a record into " +" table ", "Record call Procedure/Insert/Update/Delete successfully into "  +" table ");
                    }
                }

            }
            catch (Exception ex)
            {

                System.out.println(ex);
                ex.printStackTrace();
                Reuse.log(ex);
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Check query", "Verify if the query : " +  " exists",
                        " query is not available");

            }
            finally{

                stmt.close();
                        conn.close();
            }
        }

    }

    public static void dB_UpdateRecord(String url, String query) throws Exception
    {

        Statement stmt = null;
        boolean ismet;


        Thread.sleep(5000);


        url = getProcessedDBurl(url);

        Connection conn = null;
        String driverjdbc = null;

        if(url.contains("sqlserver"))
        {
            driverjdbc = Config.getProperty("DB.MSSQL.DRIVER");

        }else if(url.contains("oracle")){

            driverjdbc =  Config.getProperty("DB.ORACLE.DRIVER");
        }else if(url.contains("postgresql")){

        	driverjdbc = Config.getProperty("DB.POSTGRESSQL.DRIVER");
        }

        Demo1.gbTestCaseStatus = "Pass";
        boolean DBconnect = true;
        try
        {
            Class.forName(driverjdbc);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        System.out.println("Driver Loaded");

        try
        {
            conn = DriverManager.getConnection(url);
        }
        catch (java.sql.SQLException EX)
        {
            DBconnect = false;
            Demo1.gbTestCaseStatus = "Fail";
            System.out.println("Problem with Connection correct your ORACLE URL/DBNAME/CREDENTIAL");
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Check DB exists", "Error while connecting to DB",
            Throwables.getStackTraceAsString(EX));
        }

        if (DBconnect)
        {
            try
            {
                query=Reuse.getProcessedQuery(query);
                stmt = conn.createStatement();



                ismet = false;
                stmt.executeUpdate(query);



                ismet = true;

                if (!ismet)
                {
                    Demo1.gbTestCaseStatus = "Fail";

                    Demo1.ReportStep(2, "Insert/Update/Delete record into "  +" table " ,
                            "Should Insert/Update/Delete a record into "  +" table ", "Record is not Insert/Update/Delete into " +" table ");
                }
                else
                {
                    Demo1.gbTestCaseStatus = "Pass";

                    Demo1.ReportStep(2, "Insert/Update/Delete record into "  +" table " ,
                            "Should Insert/Update/Delete a record into " +" table ", "Record Insert/Update/Delete successfully into "  +" table ");
                }
            }
            catch (Exception ex)
            {

                System.out.println(ex);
                ex.printStackTrace();
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Check query", "Verify if the query : " +  " exists",
                        " query is not available");

            }
            finally {

                stmt.close();
                        conn.close();
            }
        }

    }


    public static void dB_StartSQLServerAgentJob(String url, String jobName) throws Exception
    {

        boolean ismet;
        Statement stmt=null;





        url = getProcessedDBurl(url);

        Connection conn = null;
        String driverjdbc = null;

        if(url.contains("sqlserver"))
        {
            driverjdbc = Config.getProperty("DB.MSSQL.DRIVER");

        }else if(url.contains("oracle")){

            driverjdbc =  Config.getProperty("DB.ORACLE.DRIVER");
        }else if(url.contains("postgresql")){

        	driverjdbc = Config.getProperty("DB.POSTGRESSQL.DRIVER");
        }

        Demo1.gbTestCaseStatus = "Pass";
        boolean DBconnect = true;
        try
        {
            Class.forName(driverjdbc);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        System.out.println("Driver Loaded");

        try
        {
            conn = DriverManager.getConnection(url);
        }
        catch (java.sql.SQLException EX)
        {
            DBconnect = false;
            Demo1.gbTestCaseStatus = "Fail";
            System.out.println("Problem with Connection correct your ORACLE URL/DBNAME/CREDENTIAL");
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Check DB exists", "Error while connecting to DB",
            Throwables.getStackTraceAsString(EX));
        }

        if (DBconnect)
        {
            try
            {
                stmt = conn.createStatement();
                 ismet = false;
                String jobExString = "EXEC msdb.dbo.sp_start_job N'%s'";
                String jobExcute = String.format(jobExString, jobName);
                CallableStatement cs = conn.prepareCall(jobExcute);
                cs.execute();
                System.out.println("Job started..");
                ismet = true;
                if (!ismet)
                {
                    Demo1.gbTestCaseStatus = "Fail";

                    Demo1.ReportStep(2, "Trigger SQL Server Agent Job",
                    jobName+" job should be started",jobName+" job is not started");
                }

                else
                {
                    Demo1.gbTestCaseStatus = "Pass";

                    Demo1.ReportStep(2, "Trigger SQL Server Agent Job",
                    jobName+" job should be started",jobName+" job is started");
                }
            }
            catch (Exception ex)
            {

                System.out.println(ex);
                ex.printStackTrace();
                Demo1.gbTestCaseStatus = "Fail";
                //Demo1.ReportStep(2, "Verify record count of " + tabe1 + " and " + tabe2,
                        //"Record count should be " + action, Throwables.getStackTraceAsString(ex));

            }
            finally
            {
                stmt.close();
                        conn.close();
            }
        }
    }


    public static void db_CheckDataPresentInTable(String url, String query) {
        try{


            ResultSet rs = null;
            Statement stmt = null;

            url = getProcessedDBurl(url);

            Connection conn = null;
            String driverjdbc = null;

            if(url.contains("sqlserver"))
            {
                driverjdbc = Config.getProperty("DB.MSSQL.DRIVER");

            }else if(url.contains("oracle")){

                driverjdbc =  Config.getProperty("DB.ORACLE.DRIVER");
            }else if(url.contains("postgresql")){

        	    driverjdbc = Config.getProperty("DB.POSTGRESSQL.DRIVER");
            }

            Demo1.gbTestCaseStatus = "Pass";
            boolean DBconnect = true;
            try
            {
                Class.forName(driverjdbc);
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }

            System.out.println("Driver Loaded");

            try
            {
                conn = DriverManager.getConnection(url);
            }
            catch (java.sql.SQLException EX)
            {
                DBconnect = false;
                Demo1.gbTestCaseStatus = "Fail";
                System.out.println("Problem with Connection correct your ORACLE URL/DBNAME/CREDENTIAL");
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Check DB exists", "Error while connecting to DB",
                Throwables.getStackTraceAsString(EX));
            }

            if (DBconnect)
            {
                try
                {
                    query=Reuse.getProcessedQuery(query);

                    System.out.println("query:"+query);

                    stmt = conn.createStatement();

                     rs=stmt.executeQuery(query);
                    String actualValue=null;

                    if(rs.next())
                    actualValue =rs.getString(1);


                    System.out.println("Actual Value:"+actualValue);

                    if(!actualValue.isEmpty())
                    {
                        Demo1.gbTestCaseStatus = "Pass";

                                     Demo1.ReportStep(2, "Verify data present in the DB", "<b>"
                                        + actualValue + " : should be present in DB" , "<b>" + actualValue
                                        + "</b> is present in DB");


                    } else {
                        Demo1.gbTestCaseStatus = "Fail";
                        Demo1.ReportStep(2, "Verify data present in the DB", "<b>"
                                + actualValue + " : Data should be present in DB" , "<b>" + actualValue
                                + "</b> Data is not present in DB");
                    }

                    //step5 close the connection object
//                    conn.close();


                }
                catch (Exception ex)
                {

                    System.out.println(ex);
                    ex.printStackTrace();
                    Demo1.gbTestCaseStatus = "Fail";
                    Demo1.ReportStep(2, "Check query", "Verify if the query : " +  " exists",
                            " query is not available");

                }
                finally {
                    rs.close();
                    stmt.close();
                            conn.close();
                }
            }




          }catch(Exception e){
              Reuse.log(e);
              e.printStackTrace();
              Demo1.gbTestCaseStatus = "Fail";
             Demo1.ReportStep(2, "Failed to get data from DB", "Get data from DB",
                      "Failed to get data from DB for command:" + query + e.getMessage());

              Demo1.logger.error(e);
          }

          }



    public static void dB_VerifyDataWithEV(String url,String query,String expectedValue) {
        try{

            ResultSet rs = null;
            Statement stmt = null;

            url = getProcessedDBurl(url);

            Connection conn = null;
            String driverjdbc = null;

            if(url.contains("sqlserver"))
            {
                driverjdbc = Config.getProperty("DB.MSSQL.DRIVER");

            }else if(url.contains("oracle")){

                driverjdbc =  Config.getProperty("DB.ORACLE.DRIVER");
            }else if(url.contains("postgresql")){

        	    driverjdbc = Config.getProperty("DB.POSTGRESSQL.DRIVER");
            }

            Demo1.gbTestCaseStatus = "Pass";
            boolean DBconnect = true;
            try
            {
                Class.forName(driverjdbc);
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }

            System.out.println("Driver Loaded");

            try
            {
                conn = DriverManager.getConnection(url);
            }
            catch (java.sql.SQLException EX)
            {
                DBconnect = false;
                Demo1.gbTestCaseStatus = "Fail";
                System.out.println("Problem with Connection correct your ORACLE URL/DBNAME/CREDENTIAL");
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Check DB exists", "Error while connecting to DB",
                Throwables.getStackTraceAsString(EX));
            }
            if (DBconnect)
            {
                try
                {
                    query=Reuse.getProcessedQuery(query);

                    System.out.println("query:"+query);

                    stmt = conn.createStatement();

//                     rs=stmt.executeQuery(query);
                    String actualValue=null;


                    String[] values = getProcessedExpectedValues(expectedValue);


                    for(int i=1; i<= values.length; i++){
                        rs=stmt.executeQuery(query);
                        if(rs.next())
                            actualValue =rs.getString(i);
                        else
                        {
                            actualValue = null;
                            System.out.println("Please check the columns/values in the query");
                        }

                            System.out.println("Actual Value:"+actualValue);

                            if(actualValue!=null&&actualValue.equalsIgnoreCase(values[i-1]))
                            {
                                Demo1.gbTestCaseStatus = "Pass";
                                             Demo1.ReportStep(2, "Verify text <b>" + actualValue
                                        + "</b> equals <b>" + values[i-1] + "</b>", "<b>"
                                                + actualValue + "</b> should equal <b>"
                                                + values[i-1] + "</b>", "<b>" + actualValue
                                                + "</b> text equal <b>" + values[i-1] + "</b>");
                            } else {
                                Demo1.gbTestCaseStatus = "Fail";
                                Demo1.ReportStep(2, "Verify text <b>" + actualValue
                                        + "</b> equals <b>" + values[i-1] + "</b>", "<b>"
                                                + actualValue + "</b> should equal <b>"
                                                + values[i-1] + "</b>", "Actual text <b>" + actualValue
                                                + "</b>");
                            }
                    }

                    //step5 close the connection object
//                    conn.close();

                }
                catch (Exception ex)
                {

                    System.out.println(ex);
                    ex.printStackTrace();
                    Demo1.gbTestCaseStatus = "Fail";
                    Demo1.ReportStep(2, "Check query", "Verify if the query : " +  " exists",
                            " query is not available");

                }
                finally {
                    rs.close();
                    stmt.close();
                            conn.close();
                }
            }



          }catch(Exception e){
              Reuse.log(e);
              e.printStackTrace();
              Demo1.gbTestCaseStatus = "Fail";
              Demo1.ReportStep(2, "Failed to get data from DB", "Failed to get data from DB",
                      "Failed to get data from DB" + "</b>" + e.getMessage());
              Demo1.logger.error(e);
          }

          }


    public static void dB_VerifyDataContainsWithEV(String url,String query,String expectedValue) {
        try{

            ResultSet rs = null;
            Statement stmt = null;

            url = getProcessedDBurl(url);

            Connection conn = null;
            String driverjdbc = null;

            if(url.contains("sqlserver"))
            {
                driverjdbc = Config.getProperty("DB.MSSQL.DRIVER");

            }else if(url.contains("oracle")){

                driverjdbc =  Config.getProperty("DB.ORACLE.DRIVER");
            }else if(url.contains("postgresql")){

        	    driverjdbc = Config.getProperty("DB.POSTGRESSQL.DRIVER");
            }

            Demo1.gbTestCaseStatus = "Pass";
            boolean DBconnect = true;
            try
            {
                Class.forName(driverjdbc);
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }

            System.out.println("Driver Loaded");

            try
            {
                conn = DriverManager.getConnection(url);
            }
            catch (java.sql.SQLException EX)
            {
                DBconnect = false;
                Demo1.gbTestCaseStatus = "Fail";
                System.out.println("Problem with Connection correct your ORACLE URL/DBNAME/CREDENTIAL");
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Check DB exists", "Error while connecting to DB",
                Throwables.getStackTraceAsString(EX));
            }
            if (DBconnect)
            {
                try
                {
                    query=Reuse.getProcessedQuery(query);

                    System.out.println("query:"+query);

                    stmt = conn.createStatement();

//                     rs=stmt.executeQuery(query);
                    String actualValue=null;


                    String[] values = getProcessedExpectedValues(expectedValue);


                    for(int i=1; i<= values.length; i++){
                        rs=stmt.executeQuery(query);
                    if(rs.next())
                    actualValue =rs.getString(i).toString().trim();
                    else
                    {
                        actualValue = null;
                        System.out.println("Please check the columns/values in the query");
                    }

                    System.out.println("Actual Value:"+actualValue);

                    if(actualValue!=null&&actualValue.contains(values[i-1]))
                    {
                        Demo1.gbTestCaseStatus = "Pass";
                                     Demo1.ReportStep(2, "Verify text <b>" + actualValue
                                + "</b> contains <b>" + values[i-1] + "</b>", "<b>"
                                        + actualValue + "</b> should contains <b>"
                                        + values[i-1] + "</b>", "<b>" + actualValue
                                        + "</b> text contains <b>" + values[i-1] + "</b>");
                    } else {
                        Demo1.gbTestCaseStatus = "Fail";
                        Demo1.ReportStep(2, "Verify text <b>" + actualValue
                                + "</b> contains <b>" + values[i-1] + "</b>", "<b>"
                                        + actualValue + "</b> should contains <b>"
                                        + values[i-1] + "</b>", "Actual text <b>" + actualValue
                                        + "</b>");
                    }

                    }
                    //step5 close the connection object
//                    conn.close();


                }
                catch (Exception ex)
                {

                    System.out.println(ex);
                    ex.printStackTrace();
                    Demo1.gbTestCaseStatus = "Fail";
                    Demo1.ReportStep(2, "Check query", "Verify if the query : " +  " exists",
                            " query is not available");

                }
                finally {

                    rs.close();
                    stmt.close();
                            conn.close();
                }
            }



          }catch(Exception e){
              Reuse.log(e);
              e.printStackTrace();
              Demo1.gbTestCaseStatus = "Fail";
              Demo1.ReportStep(2, "Failed to get data from DB", "Failed to get data from DB",
                      "Failed to get data from DB" + "</b>" + e.getMessage());
              Demo1.logger.error(e);
          }

          }


    public static void dB_VerifyDataNEWithEV(String url,String query,String expectedValue) {
        try{

            ResultSet rs = null;
            Statement stmt = null;

            url = getProcessedDBurl(url);

            Connection conn = null;
            String driverjdbc = null;

            if(url.contains("sqlserver"))
            {
                driverjdbc = Config.getProperty("DB.MSSQL.DRIVER");

            }else if(url.contains("oracle")){

                driverjdbc =  Config.getProperty("DB.ORACLE.DRIVER");
            }else if(url.contains("postgresql")){

        	    driverjdbc = Config.getProperty("DB.POSTGRESSQL.DRIVER");
            }

            Demo1.gbTestCaseStatus = "Pass";
            boolean DBconnect = true;
            try
            {
                Class.forName(driverjdbc);
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }

            System.out.println("Driver Loaded");

            try
            {
                conn = DriverManager.getConnection(url);
            }
            catch (java.sql.SQLException EX)
            {
                DBconnect = false;
                Demo1.gbTestCaseStatus = "Fail";
                System.out.println("Problem with Connection correct your ORACLE URL/DBNAME/CREDENTIAL");
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Check DB exists", "Error while connecting to DB",
                Throwables.getStackTraceAsString(EX));
            }
            if (DBconnect)
            {
                try
                {
                    query=Reuse.getProcessedQuery(query);

                    System.out.println("query:"+query);

                    stmt = conn.createStatement();

//                     rs=stmt.executeQuery(query);
                    String actualValue=null;


                    String[] values = getProcessedExpectedValues(expectedValue);


                    for(int i=1; i<= values.length; i++){
                        rs=stmt.executeQuery(query);
                    if(rs.next())
                    actualValue =rs.getString(i);
                    else
                    {
                        actualValue = null;
                        System.out.println("Please check the columns/values in the query");
                    }

                    System.out.println("Actual Value:"+actualValue);

                    if(actualValue!=null&&!actualValue.equals(values[i-1]))
                    {
                        Demo1.gbTestCaseStatus = "Pass";
                                     Demo1.ReportStep(2, "Verify text <b>" + actualValue
                                + "</b> contains <b>" + values[i-1] + "</b>", "<b>"
                                        + actualValue + "</b> should contains <b>"
                                        +  values[i-1] + "</b>", "<b>" + actualValue
                                        + "</b> text contains <b>" +  values[i-1] + "</b>");
                    } else {
                        Demo1.gbTestCaseStatus = "Fail";
                        Demo1.ReportStep(2, "Verify text <b>" + actualValue
                                + "</b> contains <b>" +  values[i-1] + "</b>", "<b>"
                                        + actualValue + "</b> should contains <b>"
                                        +  values[i-1] + "</b>", "Actual text <b>" + actualValue
                                        + "</b>");
                    }

                    }
                    //step5 close the connection object
//                    conn.close();


                }
                catch (Exception ex)
                {

                    System.out.println(ex);
                    ex.printStackTrace();
                    Demo1.gbTestCaseStatus = "Fail";
                    Demo1.ReportStep(2, "Check query", "Verify if the query : " +  " exists",
                            " query is not available");

                }
                finally {
                    rs.close();
                    stmt.close();
                            conn.close();
                }
            }



          }catch(Exception e){
              Reuse.log(e);
              e.printStackTrace();
              Demo1.gbTestCaseStatus = "Fail";
              Demo1.ReportStep(2, "Failed to get data from DB", "Failed to get data from DB",
                      "Failed to get data from DB" + "</b>" + e.getMessage());
              Demo1.logger.error(e);
          }

          }

    public static void dB_StoreDataToFile(String url,String query,String variableName) {
        try{

            ResultSet rs = null;
            Statement stmt = null;

            url = getProcessedDBurl(url);

            Connection conn = null;
            String driverjdbc = null;

            if(url.contains("sqlserver"))
            {
                driverjdbc = Config.getProperty("DB.MSSQL.DRIVER");

            }else if(url.contains("oracle")){

                driverjdbc =  Config.getProperty("DB.ORACLE.DRIVER");
            }else if(url.contains("postgresql")){

        	    driverjdbc = Config.getProperty("DB.POSTGRESSQL.DRIVER");
            }

            Demo1.gbTestCaseStatus = "Pass";
            boolean DBconnect = true;
            try
            {
                Class.forName(driverjdbc);
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }

            System.out.println("Driver Loaded");

            try
            {
                conn = DriverManager.getConnection(url);
            }
            catch (java.sql.SQLException EX)
            {
                DBconnect = false;
                Demo1.gbTestCaseStatus = "Fail";
                System.out.println("Problem with Connection correct your ORACLE URL/DBNAME/CREDENTIAL");
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Check DB exists", "Error while connecting to DB",
                Throwables.getStackTraceAsString(EX));
            }


            if (DBconnect)
            {
                try
                {
                    query=Reuse.getProcessedQuery(query);

                    System.out.println("query:"+query);

                    stmt = conn.createStatement();

//                     rs=stmt.executeQuery(query);
                    String actualValue=null;


                    String[] values = getProcessedExpectedValues(variableName);


                    for(int i=1; i<= values.length; i++){
                        rs=stmt.executeQuery(query);
                    if(rs.next())
                    actualValue =rs.getString(i);
                    else
                    {
                        actualValue = null;
                        System.out.println("Please check the columns/values in the query");
                    }

                    System.out.println("Actual Value:"+actualValue);

                    if(actualValue!=null && actualValue.length()>0 && !actualValue.equals("")) {

                        Reuse.WriteProperties(values[i-1], actualValue);
                        Demo1.gbTestCaseStatus = "Pass";
                        actualValue = escapeHtml3(actualValue);

                        Demo1.ReportStep(2, "Store actual value: <b>" + actualValue + "</b> in variable name:<b>" + values[i-1] + "</b> ", "<b>Actual value:" + actualValue + "</b> should be stored in variable name:<b>" + values[i-1] + "</b> ", "Actual value:"+actualValue+"</b> is stored in variable name: <b>"+values[i-1]);

                    }

                    else{
                        Demo1.gbTestCaseStatus = "Fail";
                        Demo1.ReportStep(2, "Store actual value:<b>"+actualValue+"</b> in variable name: <b>"+values[i-1]+"</b> ","<b> Actual value:"+actualValue+"</b> should be stored in variable name: <b>"+values[i-1],"Actual value:"+actualValue+"</b> is not stored in variable name: <b>"+values[i-1]);


                    }

                    }
                    //step5 close the connection object
//                    conn.close();


                }
                catch (Exception ex)
                {

                    System.out.println(ex);
                    ex.printStackTrace();
                    Demo1.gbTestCaseStatus = "Fail";
                    Demo1.ReportStep(2, "Check query", "Verify if the query : " +  " exists",
                            " query is not available");

                }
                finally {
                    rs.close();
                    stmt.close();
                            conn.close();
                }
            }



          }catch(Exception e){
              Reuse.log(e);
              e.printStackTrace();
              Demo1.gbTestCaseStatus = "Fail";
              Demo1.ReportStep(2, "Failed to get data from DB", "Get data from DB",
                      "Failed to get data from unix from command:" + query + e.getMessage());

              Demo1.logger.error(e);
          }

          }


    public static void dB_StoreDateToFile(String url, String query,String variableName) {
        try{
            ResultSet rs = null;
            Statement stmt = null;

            url = getProcessedDBurl(url);

            Connection conn = null;
            String driverjdbc = null;

            if(url.contains("sqlserver"))
            {
                driverjdbc = Config.getProperty("DB.MSSQL.DRIVER");

            }else if(url.contains("oracle")){

                driverjdbc =  Config.getProperty("DB.ORACLE.DRIVER");
            }else if(url.contains("postgresql")){

        	    driverjdbc = Config.getProperty("DB.POSTGRESSQL.DRIVER");
            }

            Demo1.gbTestCaseStatus = "Pass";
            boolean DBconnect = true;
            try
            {
                Class.forName(driverjdbc);
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }

            System.out.println("Driver Loaded");

            try
            {
                conn = DriverManager.getConnection(url);
            }
            catch (java.sql.SQLException EX)
            {
                DBconnect = false;
                Demo1.gbTestCaseStatus = "Fail";
                System.out.println("Problem with Connection correct your ORACLE URL/DBNAME/CREDENTIAL");
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Check DB exists", "Error while connecting to DB",
                Throwables.getStackTraceAsString(EX));
            }



            if (DBconnect)
            {
                try
                {
                    query=Reuse.getProcessedQuery(query);

                    System.out.println("query:"+query);

                    stmt = conn.createStatement();

//                     rs=stmt.executeQuery(query);
                    String actualValue=null;

                    String[] values = getProcessedExpectedValues(variableName);

                    for(int i=1; i<= values.length; i++){
                        rs=stmt.executeQuery(query);
                    if(rs.next())
                    actualValue =rs.getDate(i).toString();
                    else
                    {
                        actualValue = null;
                        System.out.println("Please check the columns/values in the query");
                    }

                    System.out.println("Actual Value:"+actualValue);

                    if(actualValue!=null && actualValue.length()>0 && !actualValue.equals("")) {

                        Reuse.WriteProperties(values[i-1], actualValue);
                        Demo1.gbTestCaseStatus = "Pass";
                        actualValue = escapeHtml3(actualValue);
                        Demo1.ReportStep(2, "Store actual value:<b>" + actualValue + "</b> in variable name: <b>" + values[i-1] + "</b> ", "<b>  Actual value:" + actualValue + "</b> should be stored in variable name: <b>" + values[i-1] + "</b> ", "Actual value:"+actualValue+"</b> is stored in variable name: <b>"+values[i-1]);
                    }

                    else{
                        Demo1.gbTestCaseStatus = "Fail";
                        Demo1.ReportStep(2, "Store actual value:<b>"+actualValue+"</b> in variable name: <b>"+values[i-1]+"</b> ","<b> Actual value:"+actualValue+"</b> should be stored in variable name: <b>"+values[i-1],"Actual value:"+actualValue+"</b> is not stored in variable name: <b>"+values[i-1]);
                    }

                    }
                    //step5 close the connection object
//                    conn.close();


                }
                catch (Exception ex)
                {

                    System.out.println(ex);
                    ex.printStackTrace();
                    Demo1.gbTestCaseStatus = "Fail";
                    Demo1.ReportStep(2, "Check query", "Verify if the query : " +  " exists",
                            " query is not available");

                }
                finally {
                    rs.close();
                    stmt.close();
                            conn.close();
                }
            }



          }catch(Exception e){
              Reuse.log(e);
              e.printStackTrace();
              Demo1.gbTestCaseStatus = "Fail";

              Demo1.ReportStep(2, "Failed to get data from DB", "Get data from DB",
                      "Failed to get data from DB for command:" + query + e.getMessage());

              Demo1.logger.error(e);
          }

          }




    public static void storeAndVerifyDataFromDB(String query, String variableName, String expectedValue) {
        try{

            String host = Config.unixHost;
            String sid =Config.tdsSID;
            String user = Config.tdsDBUsername;
            String password = Config.tdsDBPassword;
            String portNo = Config.tdsDBPortNo;

            List<String> queryResult = new ArrayList<>();

          //step1 load the driver class
          Class.forName("oracle.jdbc.driver.OracleDriver");

          //step2 create  the connection object
          Connection con=DriverManager.getConnection(
                  "jdbc:oracle:thin:@"+host+":"+portNo+":"+sid,user,password);

//          "jdbc:oracle:thin:@maa2wmlx1:1521:prodb1","tdsuser","tdsuser")

          //step3 create the statement object
          Statement stmt=con.createStatement();

          query=getProcessedQuery(query);


          System.out.println("query:"+query);
          //step4 execute query
          ResultSet rs=stmt.executeQuery(query);
          String actualValue=null;
          while(rs.next())  {
          System.out.println(rs.getString(1));
           actualValue =rs.getString(1);
          queryResult.add(rs.getString(1));
          }

          actualValue =queryResult.get(0);

          System.out.println("Actual Value:"+actualValue);

          if(expectedValue.contentEquals(actualValue))
          {
              Demo1.gbTestCaseStatus = "Pass";
                           Demo1.ReportStep(2, "Verify text <b>" + actualValue
                      + "</b> contains <b>" + expectedValue + "</b>", "<b>"
                              + actualValue + "</b> should contains <b>"
                              + expectedValue + "</b>", "<b>" + actualValue
                              + "</b> text contains <b>" + expectedValue + "</b>");




          } else {
              Demo1.gbTestCaseStatus = "Fail";
              Demo1.ReportStep(2, "Verify text <b>" + actualValue
                      + "</b> contains <b>" + expectedValue + "</b>", "<b>"
                              + actualValue + "</b> should contains <b>"
                              + expectedValue + "</b>", "Actual text <b>" + actualValue
                              + "</b>");
          }

          //step5 close the connection object
          con.close();



          }catch(Exception e){
              Reuse.log(e);
              e.printStackTrace();
              Demo1.gbTestCaseStatus = "Fail";
              Demo1.ReportStep(2, "Failed to get data from DB", "Failed to get data from DB",
                      "Failed to get data from DB" + "</b>" + e.getMessage());
              Demo1.logger.error(e);
          }

          }






    public static String getProcessedQuery( String queryWithVariable) {
        try {

            if(queryWithVariable.contains("var@")){
                String temp = null;
                do{
                    temp = queryWithVariable.substring(queryWithVariable.indexOf("var@")+ 4);
                    temp = temp.substring(0, temp.indexOf(64));

                    String text = Reuse.GetPropertyValue(temp);


                    queryWithVariable = queryWithVariable.replace("var@" + temp + "@", text);
                }while(queryWithVariable.contains("@var"));
           System.out.println("QueryWithVar:"+queryWithVariable);
           }

        } catch (Exception e) {
            Reuse.log(e);
        }
        return queryWithVariable;
    }


    public static String getProcessedCommand( String commandWithVariable) {
        try {

            if(commandWithVariable.contains("var@")){
                String temp = null;
                do{
                    temp = commandWithVariable.substring(commandWithVariable.indexOf("var@") + "var@".length());
                    temp = temp.substring(0, temp.indexOf(64));

                    String text = Reuse.GetPropertyValue(temp);
                    System.out.println(text);

                    commandWithVariable = commandWithVariable.replace("var@" + temp + "@", text);
                }while(commandWithVariable.contains("var@"));

                System.out.println(commandWithVariable);
            }

        } catch (Exception e) {
            Reuse.log(e);
        }
        return commandWithVariable;
    }



    public static void unix_VerifyDataContainsFromUnix(String command, String expectedValue) {

        try {
            String host = Config.unixHost;
            String user = Config.unixUsername;
            String password = Config.unixPassword;

            SSHExec.setOption(IOptionName.HALT_ON_FAILURE, true);
            ConnBean cb = new ConnBean(host, user, password);

            if(!Config.unixPort.isEmpty())
            {
                SysConfigOption.SSH_PORT_NUMBER = Integer.parseInt(Config.unixPort);
            }else{
                System.out.println("Default port number");
            }

            SysConfigOption.INTEVAL_TIME_BETWEEN_TASKS = 1000;

            SSHExec ssh = SSHExec.getInstance(cb);


            command = Reuse.getProcessedCommand(command);

            String cmd[] ={Config.export_jboss_home,Config.export_pdb_home,Config.set_path,command};

            CustomTask ct2 = new ExecCommand(cmd);

            ssh.connect();

            Result r1 = null;

            String actualValue = null;
            try {
                r1 = ssh.exec(ct2);

                actualValue = r1.sysout;

                System.out.println("Query Result" + r1.sysout);

            } catch (TaskExecFailException e) {
                Reuse.log(e);
                e.printStackTrace();
                Demo1.gbTestCaseStatus = "Fail";

                Demo1.ReportStep(2, "Get data from unix", "Run Unix command :"+command +"successfuly",
                        "Failed to get data from unix" + "</b>" + e.getMessage());
                Demo1.logger.error(e);
            }


            if(actualValue.contains(expectedValue))
            {
                Demo1.gbTestCaseStatus = "Pass";
                             Demo1.ReportStep(2, "Verify actual text: <b>" + actualValue
                        + "</b> contains <b>" + expectedValue + "</b>", "<b>"
                                + actualValue + "</b> should contains <b>"
                                + expectedValue + "</b>", "<b>" + actualValue
                                + "</b> text contains <b>" + expectedValue + "</b>");
            } else {
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Verify actual text:<b>" + actualValue
                        + "</b> contains <b>" + expectedValue + "</b>", "<b>"
                                + actualValue + "</b> should contains <b>"
                                + expectedValue + "</b>", "Actual text <b>" + actualValue
                                + "</b> text doesn't contains <b>" + expectedValue + "</b>");
            }


            System.out.println("Return code: " + r1.rc);



            ssh.disconnect();
        } catch (Exception e) {
            Reuse.log(e);
            e.printStackTrace();
            Demo1.gbTestCaseStatus = "Fail";

            Demo1.ReportStep(2, "Failed to get data from unix", "Get data from unix",
                    "Failed to get data from unix from command:" + command + e.getMessage());
            Demo1.logger.error(e);
        }

    }


    public static void unix_VerifyDataNotEqualsFromUnix(String command, String expectedValue) {

        try {
            String host = Config.unixHost;
            String user = Config.unixUsername;
            String password = Config.unixPassword;

            SSHExec.setOption(IOptionName.HALT_ON_FAILURE, true);
            ConnBean cb = new ConnBean(host, user, password);

            if(!Config.unixPort.isEmpty())
            {
                SysConfigOption.SSH_PORT_NUMBER = Integer.parseInt(Config.unixPort);
            }else{
                System.out.println("Default port number");
            }

            SysConfigOption.INTEVAL_TIME_BETWEEN_TASKS = 1000;

            SSHExec ssh = SSHExec.getInstance(cb);


            command = Reuse.getProcessedCommand(command);

            String cmd[] ={Config.export_jboss_home,Config.export_pdb_home,Config.set_path,command};

            CustomTask ct2 = new ExecCommand(cmd);

            ssh.connect();

            Result r1 = null;

            String actualValue = null;
            try {
                r1 = ssh.exec(ct2);

                actualValue = r1.sysout;

                System.out.println("Query Result" + r1.sysout);

            } catch (TaskExecFailException e) {
                Reuse.log(e);
                e.printStackTrace();
                Demo1.gbTestCaseStatus = "Fail";

                Demo1.ReportStep(2, "Get data from unix", "Run Unix command :"+command +"successfuly",
                        "Failed to get data from unix" + "</b>" + e.getMessage());
                Demo1.logger.error(e);
            }


            if(!actualValue.equals(expectedValue))
            {
                Demo1.gbTestCaseStatus = "Pass";
                             Demo1.ReportStep(2, "Verify actual text: <b>" + actualValue
                        + "</b> contains <b>" + expectedValue + "</b>", "<b>"
                                + actualValue + "</b> should not contains <b>"
                                + expectedValue + "</b>", "<b>" + actualValue
                                + "</b> text not contains <b>" + expectedValue + "</b>");
            } else {
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Verify actual text:<b>" + actualValue
                        + "</b> contains <b>" + expectedValue + "</b>", "<b>"
                                + actualValue + "</b> should contains <b>"
                                + expectedValue + "</b>", "Actual text <b>" + actualValue
                                + "</b> text  contains <b>" + expectedValue + "</b>");
            }


            System.out.println("Return code: " + r1.rc);



            ssh.disconnect();
        } catch (Exception e) {
            Reuse.log(e);
            e.printStackTrace();
            Demo1.gbTestCaseStatus = "Fail";

            Demo1.ReportStep(2, "Failed to get data from unix", "Get data from unix",
                    "Failed to get data from unix from command:" + command + e.getMessage());
            Demo1.logger.error(e);
        }

    }


    public static void unix_VerifyDataEqualsFromUnix(String command, String expectedValue) {

        try {
            String host = Config.unixHost;
            String user = Config.unixUsername;
            String password = Config.unixPassword;

            SSHExec.setOption(IOptionName.HALT_ON_FAILURE, true);
            ConnBean cb = new ConnBean(host, user, password);

            if(!Config.unixPort.isEmpty())
            {
                SysConfigOption.SSH_PORT_NUMBER = Integer.parseInt(Config.unixPort);
            }else{
                System.out.println("Default port number");
            }

            SysConfigOption.INTEVAL_TIME_BETWEEN_TASKS = 1000;

            SSHExec ssh = SSHExec.getInstance(cb);


            command = Reuse.getProcessedCommand(command);

            String cmd[] ={Config.export_jboss_home,Config.export_pdb_home,Config.set_path,command};

            CustomTask ct2 = new ExecCommand(cmd);

            ssh.connect();

            Result r1 = null;

            String actualValue = null;
            try {
                r1 = ssh.exec(ct2);

                actualValue = r1.sysout;

                System.out.println("Query Result" + r1.sysout);

            } catch (TaskExecFailException e) {
                Reuse.log(e);
                e.printStackTrace();
                Demo1.gbTestCaseStatus = "Fail";

                Demo1.ReportStep(2, "Get data from unix", "Run Unix command :"+command +"successfuly",
                        "Failed to get data from unix" + "</b>" + e.getMessage());
                Demo1.logger.error(e);
            }


            if(actualValue.equals(expectedValue))
            {
                Demo1.gbTestCaseStatus = "Pass";
                             Demo1.ReportStep(2, "Verify actual text: <b>" + actualValue
                        + "</b> contains <b>" + expectedValue + "</b>", "<b>"
                                + actualValue + "</b> should  be equals to <b>"
                                + expectedValue + "</b>", "<b>" + actualValue
                                + "</b> text  is equals to <b>" + expectedValue + "</b>");
            } else {
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Verify actual text:<b>" + actualValue
                        + "</b> contains <b>" + expectedValue + "</b>", "<b>"
                                + actualValue + "</b> should be equals to <b>"
                                + expectedValue + "</b>", "Actual text <b>" + actualValue
                                + "</b> text not equals to <b>" + expectedValue + "</b>");
            }


            System.out.println("Return code: " + r1.rc);



            ssh.disconnect();
        } catch (Exception e) {
            Reuse.log(e);
            e.printStackTrace();
            Demo1.gbTestCaseStatus = "Fail";

            Demo1.ReportStep(2, "Failed to get data from unix", "Get data from unix",
                    "Failed to get data from unix from command:" + command + e.getMessage());
            Demo1.logger.error(e);
        }

    }


    public static void unix_StoreStatIdByImport(String command, String variableName) {

        try {
            String host = Config.unixHost;
            String user = Config.unixUsername;
            String password = Config.unixPassword;

            SSHExec.setOption(IOptionName.HALT_ON_FAILURE, true);
            ConnBean cb = new ConnBean(host, user, password);

            if(!Config.unixPort.isEmpty())
            {
                SysConfigOption.SSH_PORT_NUMBER = Integer.parseInt(Config.unixPort);
            }else{
                System.out.println("Default port number");
            }

            SysConfigOption.INTEVAL_TIME_BETWEEN_TASKS = 1000;

            SSHExec ssh = SSHExec.getInstance(cb);

            String cmd[] ={Config.export_jboss_home,Config.export_pdb_home,Config.set_path,command};

            CustomTask ct2 = new ExecCommand(cmd);

            ssh.connect();

            Result r1 = null;

            String actualValue = null;
            try {
                r1 = ssh.exec(ct2);

                actualValue = r1.sysout;

                System.out.println("Query Result" + r1.sysout);

            } catch (TaskExecFailException e) {
                Reuse.log(e);
                e.printStackTrace();
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Get data from unix", "Run Unix command :"+command +"successfuly",
                        "Failed to get data from unix" + "</b>" + e.getMessage());
                Demo1.logger.error(e);
            }


            String statId = null;
            try {
                statId = actualValue.substring(actualValue.indexOf("statId"));
                statId = statId.substring(0, statId.indexOf("\n"));
                statId=statId.split("=")[1];
                System.out.println("Stat_id is :"+statId);


            if(statId!=null && statId.length()>0 && !statId.equals("")) {

                Reuse.WriteProperties(variableName, statId);
                Demo1.gbTestCaseStatus = "Pass";
                actualValue = escapeHtml3(statId);
                Demo1.ReportStep(2, "Store stat_id in variable Name:" + variableName , "<b>" + statId + "</b> should be stored in <b>" + variableName + "</b> ", "Stored"+ statId + "</b> in " + variableName);
            }

            else{
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Store stat_id in variable Name:" + variableName," Stat_Id should be stored in <b>"+variableName+"</b> "," Stat_Id is not stored in variable name:<b>"+variableName);
            }

            } catch (Exception e) {
                e.printStackTrace();
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Store stat_id in variable Name:" + variableName," Stat_Id should be stored in <b>"+variableName+"</b> "," Stat_Id is not stored in variable name:<b>"+variableName + e.getMessage());

            }

            System.out.println("Return code: " + r1.rc);

            ssh.disconnect();

        } catch (Exception e) {
            Reuse.log(e);
            e.printStackTrace();
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Failed to get data from unix", "Get data from unix",
                    "Failed to get data from unix from command:" + command + e.getMessage());
            Demo1.logger.error(e);
        }

    }


    public static void unix_StoreExportedFileNameAndPath(String command, String variableName, String pathVarName) {

        try {
            String host = Config.unixHost;
            String user = Config.unixUsername;
            String password = Config.unixPassword;

            SSHExec.setOption(IOptionName.HALT_ON_FAILURE, true);
            ConnBean cb = new ConnBean(host, user, password);

            if(!Config.unixPort.isEmpty())
            {
                SysConfigOption.SSH_PORT_NUMBER = Integer.parseInt(Config.unixPort);
            }else{
                System.out.println("Default port number");
            }


            SysConfigOption.INTEVAL_TIME_BETWEEN_TASKS = 1000;

            SSHExec ssh = SSHExec.getInstance(cb);

            String cmd[] ={Config.export_jboss_home,Config.export_pdb_home,Config.set_path,command};

            CustomTask ct2 = new ExecCommand(cmd);

            ssh.connect();

            Result r1 = null;

            String actualValue = null;
            try {
                r1 = ssh.exec(ct2);

                actualValue = r1.sysout;

                System.out.println("Query Result" + r1.sysout);

            } catch (TaskExecFailException e) {
                Reuse.log(e);
                e.printStackTrace();
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Get data from unix", "Run Unix command :"+command +"successfuly",
                        "Failed to get data from unix" + "</b>" + e.getMessage());
                Demo1.logger.error(e);
            }


            String fileName = null;
            String pathName = null;
            try {


              fileName = actualValue.substring(actualValue.indexOf("Export file"));
              fileName = fileName.split("=")[1].trim();

              pathName = fileName.substring(0, fileName.lastIndexOf('/')+1).trim();



              fileName = fileName.substring(fileName.lastIndexOf('/')+1).trim();



              System.out.println(fileName);


            if(fileName!=null && fileName.length()>0 && !fileName.equals("")) {

                Reuse.WriteProperties(variableName, fileName);
                Demo1.gbTestCaseStatus = "Pass";
                actualValue = escapeHtml3(fileName);
                Demo1.ReportStep(2, "Store File Name in variable Name:" + variableName , "<b>" + fileName + "</b> should be stored in <b>" + variableName + "</b> ", "Stored"+ fileName + "</b> in " + variableName);
            }

            else{
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Store stat_id in variable Name:" + variableName," File name should be stored in <b>"+variableName+"</b> "," File Name is not stored in variable name:<b>"+variableName);
            }

            if(pathName!=null && pathName.length()>0 && !pathName.equals("")) {

                Reuse.WriteProperties(pathVarName, pathName);
                Demo1.gbTestCaseStatus = "Pass";
                actualValue = escapeHtml3(pathVarName);
                Demo1.ReportStep(2, "Store path in variable Name:" + pathVarName , "<b>" + pathName + "</b> should be stored in <b>" + pathVarName + "</b> ", "Stored"+ pathName + "</b> in " + pathVarName);
            }

            else{
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Store path in variable Name:" + pathVarName," Path should be stored in <b>"+pathVarName+"</b> "," Path is not stored in variable name:<b>"+pathVarName);
            }

            } catch (Exception e) {
                e.printStackTrace();
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Store file name in variable Name:" + variableName," File Name should be stored in <b>"+variableName+"</b> "," File Name is not stored in variable name:<b>"+variableName + e.getMessage());

            }

            System.out.println("Return code: " + r1.rc);

            ssh.disconnect();

        } catch (Exception e) {
            Reuse.log(e);
            e.printStackTrace();
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Failed to get data from unix", "Get data from unix",
                    "Failed to get data from unix from command:" + command + e.getMessage());
            Demo1.logger.error(e);
        }

    }

    public static void unix_VerifyFilePresentInUnixPath(String path, String expectedValue) {

        try {
            String host = Config.unixHost;
            String user = Config.unixUsername;
            String password = Config.unixPassword;

            SSHExec.setOption(IOptionName.HALT_ON_FAILURE, true);
            ConnBean cb = new ConnBean(host, user, password);

            if(!Config.unixPort.isEmpty())
            {
                SysConfigOption.SSH_PORT_NUMBER = Integer.parseInt(Config.unixPort);
            }else{
                System.out.println("Default port number");
            }

            SysConfigOption.INTEVAL_TIME_BETWEEN_TASKS = 1000;

            SSHExec ssh = SSHExec.getInstance(cb);


            path = Reuse.getProcessedCommand(path);

            expectedValue = Reuse.getProcessedCommand(expectedValue);

            String cmd[] ={Config.export_jboss_home,Config.export_pdb_home,Config.set_path,"cd "+ path,"ls" };


            CustomTask ct2 = new ExecCommand(cmd);

            ssh.connect();

            Result r1 = null;

            String actualValue = null;
            try {
                r1 = ssh.exec(ct2);

                actualValue = r1.sysout;

//                System.out.println("Query Result" + r1.sysout);

            } catch (TaskExecFailException e) {
                Reuse.log(e);
                e.printStackTrace();
                Demo1.gbTestCaseStatus = "Fail";

                Demo1.ReportStep(2, "Get data from unix", "Run Unix command :"+path +"successfuly",
                        "Failed to get data from unix" + "</b>" + e.getMessage());
                Demo1.logger.error(e);
            }


            if(actualValue.contains(expectedValue))
            {
                Demo1.gbTestCaseStatus = "Pass";
                             Demo1.ReportStep(2, "Verify actual text: <b>"
                        + "</b> contains <b>" + expectedValue + "</b>", "<b>"
                                + actualValue + "</b> should contains <b>"
                                + expectedValue + "</b>", "<b>" + actualValue
                                + "</b> text contains <b>" + expectedValue + "</b>");
            } else {
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Verify actual text:<b>"
                        + "</b> contains <b>" + expectedValue + "</b>", "<b>"
                                + actualValue + "</b> should contains <b>"
                                + expectedValue + "</b>", "Actual text <b>" + actualValue
                                + "</b> text doesn't contains <b>" + expectedValue + "</b>");
            }


            System.out.println("Return code: " + r1.rc);



            ssh.disconnect();
        } catch (Exception e) {
            Reuse.log(e);
            e.printStackTrace();
            Demo1.gbTestCaseStatus = "Fail";

            Demo1.ReportStep(2, "Failed to get data from unix", "Get data from unix",
                    "Failed to get data from unix from command:" + path + e.getMessage());
            Demo1.logger.error(e);
        }

    }


    public static void unix_ExecuteCLI(String command) {

        try {
            String host = Config.unixHost;
            String user = Config.unixUsername;
            String password = Config.unixPassword;

            SSHExec.setOption(IOptionName.HALT_ON_FAILURE, true);
            ConnBean cb = new ConnBean(host, user, password);

            if(!Config.unixPort.isEmpty())
            {
                SysConfigOption.SSH_PORT_NUMBER = Integer.parseInt(Config.unixPort);
            }else{
                System.out.println("Default port number");
            }

            SysConfigOption.INTEVAL_TIME_BETWEEN_TASKS = 1000;

            SSHExec ssh = SSHExec.getInstance(cb);


            command = Reuse.getProcessedCommand(command);

            String cmd[] ={Config.export_jboss_home,Config.export_pdb_home,Config.set_path,command};

            CustomTask ct2 = new ExecCommand(cmd);

            ssh.connect();

            Result r1 = null;

            String actualValue = null;
            try {
                r1 = ssh.exec(ct2);

                actualValue = r1.sysout;
                Demo1.gbTestCaseStatus = "Pass";
                Demo1.ReportStep(2, "Verify actual text: <b>" + actualValue
          + "</b> for command"+command, "<b>"
                   + actualValue +  "</b>", "<b>" + actualValue
                  + "</b>");

                System.out.println("Query Result" + r1.sysout);

            } catch (TaskExecFailException e) {
                Reuse.log(e);
                e.printStackTrace();
                Demo1.gbTestCaseStatus = "Fail";

                Demo1.ReportStep(2, "Get data from unix", "Run Unix command :"+command +"successfuly",
                        "Failed to get data from unix" + "</b>" + e.getMessage());
                Demo1.logger.error(e);
            }





            System.out.println("Return code: " + r1.rc);



            ssh.disconnect();
        } catch (Exception e) {
            Reuse.log(e);
            e.printStackTrace();
            Demo1.gbTestCaseStatus = "Fail";

            Demo1.ReportStep(2, "Failed to get data from unix", "Get data from unix",
                    "Failed to get data from unix from command:" + command + e.getMessage());
            Demo1.logger.error(e);
        }

    }

    public static void dB_ExecuteQueryBasedOnTimeout(String url, String query, String expValue, String action, int timeOut) throws Exception
    {
    	boolean valueFound = false;
    	boolean skipped = false;
        url = getProcessedDBurl(url);
        Connection conn = null;
        String driverjdbc = null;

        query = Reuse.getValueOfRunTimeVariables(query);

        if(url.contains("sqlserver"))
        {
            driverjdbc = Config.getProperty("DB.MSSQL.DRIVER");

        }else if(url.contains("oracle")){

            driverjdbc =  Config.getProperty("DB.ORACLE.DRIVER");
        }else if(url.contains("mariadb")){

        	driverjdbc = "org.mariadb.jdbc.Driver";
        }else if(url.contains("postgresql")){

            driverjdbc = Config.getProperty("DB.POSTGRESSQL.DRIVER");
        }

        Demo1.gbTestCaseStatus = "Pass";
        boolean DBconnect = true;
        try
        {
            Class.forName(driverjdbc);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        System.out.println("Driver Loaded");

        try
        {
            conn = DriverManager.getConnection(url);
            System.out.println("Connection successful.!");
        }
        catch (java.sql.SQLException EX)
        {
            DBconnect = false;
            Demo1.gbTestCaseStatus = "Fail";
            EX.printStackTrace();
            System.out.println("Problem with Connection correct your ORACLE URL/DBNAME/CREDENTIAL");
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Check table exists", "Error while connecting to DB",
                    Throwables.getStackTraceAsString(EX));
        }

        try
        {
        	String resultValue = null;
        	int timeTaken = 0;
            do{
            	if (DBconnect)
                {
                	Statement currentStatement = conn.createStatement();
                    currentStatement.execute(query);
                    ResultSet rs = currentStatement.getResultSet();

                    if(rs.next())
                    	resultValue = rs.getString(1);

                    if(action.equals("NOT-EQUALS")){
                    	if(!resultValue.equals(expValue)){
                    		//action completed
                    		valueFound = true;
                    		Demo1.logger.info("DB Query execution is successful.");
                    	}else{
                    		Thread.sleep(60000);
                    		timeTaken++;
                    		if(timeTaken == timeOut){
                    			valueFound = true;
                    			skipped = true;
                    		}else{
                    			Demo1.logger.info("Actual Value::" + resultValue );
                    			Demo1.logger.info("Time taken::" + timeTaken + " minute(s)");
                    		}
                    	}
                    }
                }
            }while(!valueFound);

            if(skipped){
            	Demo1.logger.info("Maximum timeout reached, so failed abrubtly.");
            	Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "Execute query", "Given query should be executed", "Given query was not executed properly");
            }else if(valueFound){
            	Demo1.logger.info("Successfully executed the query");
            	Demo1.gbTestCaseStatus = "Pass";
                Demo1.ReportStep(2, "Execute query", "Given query should be executed", "Given query was executed successfully");
            }
        }catch (Exception ex){
            System.out.println(ex);
            ex.printStackTrace();
            Demo1.logger.info(Throwables.getStackTraceAsString(ex));
            Demo1.gbTestCaseStatus = "Fail";
            Demo1.ReportStep(2, "Execute query", "Given query should be executed", "Given query was not executed properly");
        }finally{
            conn.close();
        }
    }

}
