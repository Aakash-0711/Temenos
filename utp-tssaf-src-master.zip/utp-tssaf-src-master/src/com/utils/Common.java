package com.utils;

public class Common {

    public static String getWorkingDir(){
        String dir = System.getProperty("user.dir");
        return dir;
    }
}
