package com.utils;

public class GlobalConfig {

	private String token;
	private String cookie;
	private String securitySessionCookie;
	private String sharedSecretLoginToken;
	private String smeUserLoginToken;

	public String getSmeUserLoginToken() {
		return smeUserLoginToken;
	}

	public void setSmeUserLoginToken(String smeUserLoginToken) {
		this.smeUserLoginToken = smeUserLoginToken;
	}

	public String getSharedSecretLoginToken() {
		return sharedSecretLoginToken;
	}

	public void setSharedSecretLoginToken(String sharedSecretLoginToken) {
		this.sharedSecretLoginToken = sharedSecretLoginToken;
	}

	public String getCookie() {
		return cookie;
	}

	public void setCookie(String cookie) {
		this.cookie = cookie;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * @return the securitySessionCookie
	 */
	public String getSecuritySessionCookie() {
		return securitySessionCookie;
	}

	/**
	 * @param securitySessionCookie the securitySessionCookie to set
	 */
	public void setSecuritySessionCookie(String securitySessionCookie) {
		this.securitySessionCookie = securitySessionCookie;
	}

}
