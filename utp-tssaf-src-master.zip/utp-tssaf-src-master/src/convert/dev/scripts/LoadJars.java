package convert.dev.scripts;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;

/**
 * TODO: Document me!
 *
 * @author rashishkumar
 *
 */
public class LoadJars {

    private static String className;
    public static boolean loadjar = false;
    public static URLClassLoader sysloader;
    private static final Class[] parameters = new Class[]{URL.class};
    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub

        try {

        //String pathToJar = "C:\\Workspace\\Temenos01stMarch\\TAFJ\\lib";
        String pathToJar =  batfileCall.tafjHome + File.separator + "lib";

        File filepath = new File(pathToJar);
        File[] paths = filepath.listFiles(new FilenameFilter() {
            @Override
			public boolean accept(File dir, String name) {
                return name.toLowerCase().endsWith(".jar");
            }
        });

        if (!loadjar) {

            for (File eachFile : paths) {

                System.out.println("Jar Name -" + eachFile.getName());

                addFile(eachFile);

            }

            loadjar = true;

        }


        } catch (Exception E) {

            E.printStackTrace();
            System.out.println("Unable to load Class -" + className);
        }

    }


    public static void addFile(String s) throws IOException {
        File f = new File(s);
        addFile(f);
     }//end method

     public static void addFile(File f) throws IOException {
        addURL(f.toURL());
     }//end method


     public static void addURL(URL u) throws IOException {

       sysloader = (URLClassLoader) ClassLoader.getSystemClassLoader();
       Class sysclass = URLClassLoader.class;

       try {
          Method method = sysclass.getDeclaredMethod("addURL", parameters);
          method.setAccessible(true);
          method.invoke(sysloader, new Object[]{u});
       } catch (Throwable t) {
          t.printStackTrace();
          throw new IOException("Error, could not add URL to system classloader");
       }//end try catch

        }//end method

}
