package convert.dev.scripts;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.Properties;


public class batfileCall {

    private static String className;
    private static String[] response;
    public static String applicationName, ofsMessage, tafjHome, outputParams, javaHome;
    static String curDir = System.getProperty("user.dir");
    public static String[] main(String[] args) {

Properties prop = new Properties();

        InputStream input;

        try {
            input = new FileInputStream(curDir + "\\Config\\config.properties");
            prop.load(input);

            tafjHome = prop.getProperty("TAFJHOME").trim();
            javaHome = prop.getProperty("JAVAHOME").trim();

            System.out.println("tafjhome"+tafjHome + javaHome);


            LoadJars.main(new String[] { "" });

        } catch (IOException e) {
            System.out.println("Unable to read the config file");
        }

        try {
            //className = "Test.Call.At.tSubRoutineruntimeload";
            className = "Test.Call.At.tStaticSubRoutineCall";
            Class c = LoadJars.sysloader.loadClass(className);

            String tafjhome = tafjHome;

            String[] param = new String[args.length+1];
            param[0] = tafjhome;

            for (int j=0;j<args.length;j++) {

                param[j+1] = args[j];
            }

            if (className.equals("Test.Call.At.tStaticSubRoutineCall")) {

                Object o = c.newInstance();
                Method m1 = c.getDeclaredMethod("main", java.lang.String[].class);
                // Object[] test = new Object[] { "EB.READLISTT" , "SELECT
                // F.SEAT.SCRIPT.GROUP" , "" , "" , "" , ""};
                response = (String[]) m1.invoke(o, new Object[] { param });

//                response = (String[]) m1.invoke(o, new Object[] { "OFS.CALL.BULK.MANAGER","GCS","TSA.SERVICE,INPUT/I/PROCESS,INPUTT/123456,COB,SERVICE.CONTROL:1:1=AUTO","","" });

                System.out.println("Response Size - " + response.length);
                System.out.println(response[0]);
            }

        } catch (Exception cnfe) {

            cnfe.printStackTrace();
            System.out.println("Unable to get response from T24 Routine call");

        }

        return response;
    }

}
