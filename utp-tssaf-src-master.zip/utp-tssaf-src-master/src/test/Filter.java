package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Created by shanmugamarun on 02-05-2017.
 */
public class Filter {
    static WebDriver driver;

    public static void main(String[] args) throws Exception {

        driver = new FirefoxDriver();
        driver.get("http://10.44.5.111:9089/Browser/");
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.findElement(By.id("userId")).sendKeys("SSOUSER2");
        driver.findElement(By.id("password")).sendKeys("123456");
        driver.findElement(By.name("commit")).click();
        driver.findElement(By.name("WORKINGELEMENTS[1].NAVIGATION[1].COMMANDLINE")).sendKeys("CUSTOMER I F3");
        driver.findElement(By.xpath("//a[@title='Execute']")).click();
        WebElement parent = driver.findElement(By.xpath("//div[contains(@id,'RELATION-CODE')]"));
        parent.findElement(By.xpath("//span[contains(@onclick,'handle')]")).click();
//div[contains(@id,'RELATION-CODE')]//span[contains(@onclick,'handle')]



    }
}
