package test;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.output.TeeOutputStream;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.FluentWait;

import Driver.Demo1;
import Driver.Reuse;


/**
 * Created by shanmugamarun on 27-04-2017.
 */
public class Page {

    static WebDriver driver;
    private static int linksCount = 0;
    public static TeeOutputStream out;

    public static void main(String[] args) throws Exception {
        String logDIR = System.getProperty("user.dir");

        File f = new File(logDIR+"/logs/LOG"+ Reuse.getDateTimeStamp()+".txt");

        try {
            FileOutputStream fos = new FileOutputStream(f);
            //we will want to print in standard "System.out" and in "file"
            TeeOutputStream myOut=new TeeOutputStream(System.out, fos);
            PrintStream ps = new PrintStream(myOut, true); //true - auto-flush after println
            System.setOut(ps);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Program execution has started ");

        System.exit(0);
               driver = new FirefoxDriver();
        driver.get("http://dgwtsxc2:9089/Browser/");
     //   driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.findElement(By.id("userId")).sendKeys("SSOUSER2");
        driver.findElement(By.id("password")).sendKeys("123456");
        driver.findElement(By.name("commit")).click();
      UXPLoading();
       // ajaxWait(10);
       // jQueryAJAXCallsHaveCompleted();
        driver.findElement(By.name("WORKINGELEMENTS[1].NAVIGATION[1].COMMANDLINE")).sendKeys("AA.PRD.DES.FACILITY L");
        driver.findElement(By.xpath("//a[@title='Execute']")).click();
        //UXPLoading();
     }

    private static void monkeyPatchXMLHttpRequest() {
        WebDriver driver = Demo1.driver;
        try {
            if (driver instanceof JavascriptExecutor) {
                JavascriptExecutor jsDriver = (JavascriptExecutor) driver;
                Object numberOfAjaxConnections = jsDriver.executeScript("return window.openHTTPs");
                if (numberOfAjaxConnections instanceof Long) {
                    return;
                }
                String script = "  (function() {" + "var oldOpen = XMLHttpRequest.prototype.open;"
                        + "window.openHTTPs = 0;"
                        + "XMLHttpRequest.prototype.open = function(method, url, async, user, pass) {"
                        + "window.openHTTPs++;" + "this.addEventListener('readystatechange', function() {"
                        + "if(this.readyState == 4) {" + "window.openHTTPs--;" + "}" + "}, false);"
                        + "oldOpen.call(this, method, url, async, user, pass);" + "}" + "})();";
                jsDriver.executeScript(script);
            } else {
                System.out.println("Web driver: " + driver + " cannot execute javascript");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    private static void ajaxWait(int timeoutInSeconds) {

        WebDriver driver = Demo1.driver;

        try {
            if (driver instanceof JavascriptExecutor) {
                JavascriptExecutor jsDriver = (JavascriptExecutor) driver;

                for (int i = 0; i < timeoutInSeconds; i++) {

                    Object numberOfAjaxConnections = jsDriver.executeScript("return window.openHTTPs");
                    // return should be a number
                    if (numberOfAjaxConnections instanceof Long) {
                        Long n = (Long) numberOfAjaxConnections;
                        // System.out.println("Number of active calls: " + n);
                        if (n.longValue() == 0L)
                            break;
                    } else {
                        // If its not a number page might have been loaded
                        // freshly indicating the monkey
                        // path is replased or we havent yet done the patch.
                        monkeyPatchXMLHttpRequest();
                    }
                    Thread.sleep(100);
                }
            } else {
                System.out.println("Web driver: " + driver + " cannot execute javascript");
            }
        } catch (InterruptedException e) {
            System.out.println(e);
        }
    }
    public static void jQueryAJAXCallsHaveCompleted() {


        FluentWait<WebDriver> wait = new FluentWait<>(Demo1.driver);
        wait.pollingEvery(Duration.ofMillis(250));
        wait.withTimeout(Duration.ofSeconds(100));
        com.google.common.base.Function<WebDriver, Boolean> function = new com.google.common.base.Function<WebDriver, Boolean>() {
            @Override
			public Boolean apply(WebDriver arg0) {
                Boolean active = (Boolean) ((JavascriptExecutor) arg0).executeScript("return jQuery.active == 0;");
                return active;
            }
        };

        wait.until(function);
    }

    public static void UXPLoading() {
        FluentWait<WebDriver> wait = new FluentWait<>(driver);
        wait.pollingEvery(Duration.ofMillis(250));
        wait.withTimeout(Duration.ofSeconds(100)).ignoring(NoSuchElementException.class).ignoring(StaleElementReferenceException.class);
        com.google.common.base.Function<WebDriver, Boolean> function = new com.google.common.base.Function<WebDriver, Boolean>() {
            @Override
			public Boolean apply(WebDriver arg0) {
                Boolean active = arg0.findElement(By.xpath("//img[contains(@src,'loading.gif')]")).isDisplayed();
                if(active){
                    return  false;
                }else{
                    return true;
                }
            }
        };
        wait.until(function);
    }
    public static void VerifyPagination(By by, String str) throws Exception {
        try {
            boolean isthere = false;
            boolean found = false;
            breakDo:
            do {

                Thread.sleep(5000);
                //table[@class='resultTable primpableEnqResultsTable mainResultTable']
                List<WebElement> pagesize = driver.findElement(by).findElements(By.xpath("//tr/td[1]"));
                driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);


                for (WebElement e : pagesize) {
                    try {
                        String txt = e.getText();
                        System.out.println(txt);
                        if (txt.toLowerCase().contains(str.toLowerCase())) {
                            found = true;
                            break breakDo;
                        }
                    } catch (Exception x1) {

                    }
                }
                try {
                    new Actions(driver).moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Page')]")))
                            .build().perform();

                    driver.findElement(By.xpath("//a[text()='>']")).click();
                    //   driver.findElement(By.xpath("//a[contains(@class,'pagination-item') and text()='>']")).click();

                    isthere = true;

                } catch (Exception e) {
                    isthere = false;
                    break;
                } finally {
                    driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

                }


            } while (isthere);

            if (found) {

                System.out.println("Match Found ");
            } else {
                System.out.println("No Match Found ");

            }

        } catch (Exception e1) {
        }
    }



    public static void VerifyPaginationa(String xpath, String str) throws Exception {
        try {


            boolean isthere = false;
            boolean found = false;
            breakDo:
            do {

                Thread.sleep(5000);
                //table[@class='resultTable primpableEnqResultsTable mainResultTable']
                List<WebElement> pagesize = driver.findElements(By.xpath("//table[@class='resultTable primpableEnqResultsTable mainResultTable']//tr/td[1]"));
                driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);


                for (WebElement e : pagesize) {
                    try {
                        String txt = e.getText();
                        if (txt.contains(str)) {
                            found = true;
                            break breakDo;
                        }
                    } catch (Exception x1) {

                    }
                }
                try {

                    new Actions(driver).moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Page')]")))
                            .build().perform();

                    driver.findElement(By.xpath("//a[text()='>']")).click();
                    //   driver.findElement(By.xpath("//a[contains(@class,'pagination-item') and text()='>']")).click();

                    isthere = true;

                } catch (Exception e) {
                    isthere = false;
                    break;
                } finally {
                    driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

                }


            } while (isthere);

            if (found) {

            } else {

            }

        } catch (Exception e1) {

        }
    }
}
