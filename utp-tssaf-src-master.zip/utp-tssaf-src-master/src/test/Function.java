package test;

import static Driver.Reuse.isElementPresent;

import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import Driver.Demo1;


/**
 * Created by shanmugamarun on 25-04-2017.
 */
public class Function {
    static String baseURL = "http://10.92.6.159:9089/Browser/";

    public static void main(String[] args) {
        System.setProperty("webdriver.gecko.driver", "D:\\Selenium\\geckodriver-v0.16.0-win64\\geckodriver.exe");
        WebDriver driver = new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.get(baseURL);
        driver.findElement(By.xpath("id('userId')")).sendKeys("SSOUSER1");
        driver.findElement(By.xpath("id('password')")).sendKeys("SSOUSER1");
        driver.findElement(By.xpath("//INPUT[@value='Login']")).click();
        driver.findElement(By.xpath("//input[contains(@class,'command-line')]")).sendKeys("CUSTOMER");
        driver.findElement(By.xpath("//a[@title='Execute']")).click();
        driver.findElement(By.xpath("id('C1__BUT_59666E37CA98156F22153')")).click();
        WebElement element = driver.findElement(By.xpath("//div[contains(@id,'CONTACT-DATE')]//button"));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
        JOptionPane.showInputDialog(null);
        // js.executeScript("window.scrollTo(0,"+element.getLocation().y+")");
        js.executeScript("arguments[0].click();", element);
        // element.click();
        Select month = new Select(driver.findElement(By.xpath("//select[normalize-space(@class)='ui-datepicker-month']")));
        month.selectByVisibleText("Jan");
        Select year = new Select(driver.findElement(By.xpath("//select[normalize-space(@class)='ui-datepicker-year']")));
        year.selectByVisibleText("2015");
        driver.findElement(By.xpath("//a[@class='ui-state-default' and text()='10']")).click();
    }

//"16-Jan-2016,xpath=//div[contains(@id,'CONTACT-DATE')]//button"
    public static void DateSelector( By by,String date,String textBoxName) throws Exception {
        try {
            WebElement element;
            String[] arrDate = date.trim().split("-");
            String iDate = arrDate[0].trim();
            String iMonth = arrDate[1];
            String iYear = arrDate[2];
            if (isElementPresent(by)) {
                element = Demo1.driver.findElement(by);
                JavascriptExecutor js = (JavascriptExecutor) Demo1.driver;
                ((JavascriptExecutor) Demo1.driver).executeScript("arguments[0].scrollIntoView(true);", element);
                js.executeScript("arguments[0].click();", element);
                Select month = new Select(Demo1.driver.findElement(By.xpath("//select[normalize-space(@class)='ui-datepicker-month']")));
                month.selectByVisibleText(iMonth);
                Select year = new Select(Demo1.driver.findElement(By.xpath("//select[normalize-space(@class)='ui-datepicker-year']")));
                year.selectByVisibleText(iYear);
                Demo1.driver.findElement(By.xpath("//a[@class='ui-state-default' and text()='" + iDate + "']")).click();
                Demo1.ReportStep(2, "Selecting adte in  <b>date picker</b>", "<b>Date</b> should be selected", "Check box is already selected");
                Demo1.gbTestCaseStatus = "Pass";
                Demo1.ReportStep(2, "datepicker in to the field <b>" + textBoxName + "</b>", "Input text <b>" + date + "</b>", "Text <b>" + date + "</b> entered Successfully");
            }
            else {
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "datepicker in to the field <b>" + textBoxName + "</b>", "Input text <b>" + date + "</b>", "Element <b>" + textBoxName + " </b> not present/unable to locate element");
            }
        } catch (Exception e) {
                Demo1.logger.error(e);
                Demo1.gbTestCaseStatus = "Fail";
                Demo1.ReportStep(2, "datepicker in to the field <b>" + textBoxName
                            + "</b>", "datepicker <b>" + date + "</b>",
                    "Unbale to locate textbox <b>" + textBoxName + "</b>");
                Demo1.logger.error(e);
        }

    }
}


